# Auto Server V2.1.1

Backend independente para o aplicativo Android e para o painel web. A automação
é executada no servidor: fechar o aplicativo, a aba ou o navegador não interrompe
os envios.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde do serviço: `/health`
- Retorno Google OAuth: `/oauth/google/callback`

## Recursos

- Login do mesmo usuário no Android e no navegador.
- Configuração de live, mensagens, intervalo, modo econômico e limite por hora.
- Controles Iniciar, Pausar e Parar no aplicativo e no painel web.
- Status, próxima execução, contadores, erros e registros recentes.
- Seletor de contas Google aberto sem `login_hint`; o e-mail escolhido ainda é
  validado contra o cadastro administrativo.
- Refresh token e Client Secret criptografados com AES-256-GCM.
- Estado persistido no SQLite e retomada automática dos workers após reinício.
- Cookies web HttpOnly/SameSite, proteção CSRF e validação de origem.
- Docker Compose em segundo plano com `restart: unless-stopped`.

## Dados persistentes

O banco continua em `data/peralta.sqlite` para manter compatibilidade com a
instalação V2.1.0. A pasta `data/` e o arquivo `.env` formam um conjunto: sem a
mesma `APP_ENCRYPTION_KEY`, as autorizações Google existentes não podem ser
descriptografadas.

Nunca substitua nem apague `data/` ou `.env` durante uma atualização. Use o
script `ATUALIZAR_SEM_PERDER_DADOS.sh`, que cria backup, copia os dados para a
nova versão, testa `/health` e religa a versão anterior se houver falha.

## Cota por usuário

Para cotas realmente independentes, use Perfis API cujos Client IDs e Secrets
venham de projetos Google Cloud diferentes. Vários OAuth Clients no mesmo projeto
continuam usando a mesma cota do projeto.

## OAuth

O Client OAuth deve ser do tipo **Web application**. Cadastre exatamente:

`https://SEU-DOMINIO/oauth/google/callback`

A troca do nome/pacote Android não altera essa URI HTTPS.
