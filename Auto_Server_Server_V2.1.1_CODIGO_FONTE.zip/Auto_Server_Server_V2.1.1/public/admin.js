'use strict';
const $=id=>document.getElementById(id),show=(id,on)=>$(id).classList.toggle('hidden',!on);
const feedback=(id,message,ok=false)=>{const el=$(id);el.textContent=message||'';el.className='feedback '+(message?(ok?'ok':'err'):'');};
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
let csrfToken='',authenticated=false,data={users:[],apiProfiles:[]},details='';
async function api(url,{method='GET',body}={}) {
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{const headers={'Accept':'application/json'};if(body!==undefined)headers['Content-Type']='application/json';if(csrfToken)headers['X-CSRF-Token']=csrfToken;
    const r=await fetch(url,{method,body:body===undefined?undefined:JSON.stringify(body),headers,credentials:'same-origin',signal:controller.signal});let j;
    try{j=await r.json();}catch{throw new Error(`Resposta inválida (HTTP ${r.status}). Confira a URL e o proxy do servidor.`);}
    if(!r.ok||j.ok!==true){if(r.status===401&&authenticated){authenticated=false;csrfToken='';show('dashboard',false);show('login',true);show('logout',false);}throw new Error(j.error||`HTTP ${r.status}`);}return j;
  }catch(e){if(e.name==='AbortError')throw new Error('Tempo esgotado. Verifique o servidor e tente novamente.');throw e;}finally{clearTimeout(timer);}
}
async function bootstrap(expectSession=false) {
  const b=await api('/dbmadmin/api/bootstrap');authenticated=b.authenticated;csrfToken=b.csrfToken||'';
  show('setup',b.needsSetup);show('login',!b.needsSetup&&!b.authenticated);show('dashboard',b.authenticated);show('logout',b.authenticated);
  if(expectSession&&!b.authenticated)throw new Error('Senha aceita, mas a sessão não foi mantida. Abra o domínio HTTPS configurado e confira os cookies do navegador.');
  if(authenticated)await loadData();
}
function form(id,fb,action) {$(id).addEventListener('submit',async e=>{e.preventDefault();const b=$(id).querySelector('button'),label=b.textContent;b.disabled=true;b.textContent='AGUARDE…';feedback(fb,'');try{await action();}catch(err){feedback(fb,err.message);}finally{b.disabled=false;b.textContent=label;}});}
form('setupForm','setupFb',async()=>{await api('/dbmadmin/api/setup',{method:'POST',body:{setupToken:$('setupToken').value,username:$('setupUser').value,password:$('setupPass').value}});await bootstrap(true);$('setupForm').reset();});
form('loginForm','loginFb',async()=>{await api('/dbmadmin/api/login',{method:'POST',body:{username:$('loginUser').value,password:$('loginPass').value}});await bootstrap(true);$('loginPass').value='';feedback('globalFb','');});
$('logout').onclick=async()=>{try{await api('/dbmadmin/api/logout',{method:'POST',body:{}});}catch(e){feedback('globalFb',e.message);}finally{csrfToken='';authenticated=false;await bootstrap().catch(e=>feedback('globalFb',e.message));}};
function resetProfile(){ $('profileForm').reset();$('profileId').value='';$('profileTitle').textContent='Novo perfil API'; }
function resetUser(){ $('userForm').reset();$('userId').value='';$('userTitle').textContent='Novo usuário'; }
$('cancelProfile').onclick=resetProfile;$('cancelUser').onclick=resetUser;
form('profileForm','profileFb',async()=>{const id=$('profileId').value,body={name:$('profileName').value,clientId:$('clientId').value,clientSecret:$('clientSecret').value,active:$('profileActive').value==='true'};
  if(!id&&!body.clientSecret)throw new Error('Informe o Client Secret.');if(id&&body.clientSecret&&!confirm('Alterar credenciais exigirá nova autorização dos usuários deste perfil. Continuar?'))return;
  await api('/dbmadmin/api/profiles'+(id?'/'+id:''),{method:id?'PATCH':'POST',body});resetProfile();await loadData();feedback('profileFb','Perfil salvo.',true);
});
form('userForm','userFb',async()=>{const id=$('userId').value,body={email:$('userEmail').value,googleEmail:$('userGoogleEmail').value,password:$('userPass').value,apiProfileId:$('userProfile').value,active:$('userActive').value==='true'};
  if(!id&&!body.password)throw new Error('Informe a senha inicial.');const old=data.users.find(u=>u.id===id);if(old&&(old.googleEmail!==body.googleEmail||old.apiProfileId!==body.apiProfileId)&&!confirm('O usuário precisará autorizar o YouTube novamente. Continuar?'))return;
  await api('/dbmadmin/api/users'+(id?'/'+id:''),{method:id?'PATCH':'POST',body});resetUser();await loadData();feedback('userFb','Usuário salvo.',true);
});
form('passwordForm','passwordFb',async()=>{await api('/dbmadmin/api/password',{method:'POST',body:{currentPassword:$('oldAdminPass').value,password:$('newAdminPass').value}});$('passwordForm').reset();await bootstrap();feedback('loginFb','Senha alterada. Entre novamente.',true);});
async function loadData(){data=await api('/dbmadmin/api/data');const selected=$('userProfile').value;
  $('userProfile').innerHTML='<option value="">Selecione</option>'+data.apiProfiles.map(p=>`<option value="${esc(p.id)}" ${p.active?'':'disabled'}>${esc(p.name)}${p.active?'':' (inativo)'}</option>`).join('');$('userProfile').value=selected;
  $('profiles').innerHTML=data.apiProfiles.map(p=>`<div class="item"><div><b>${esc(p.name)}</b><div class="meta">${esc(p.clientId)}<br>${p.active?'Ativo':'Inativo'}</div></div><div class="actions"><button data-action="profile-edit" data-id="${esc(p.id)}">EDITAR</button><button class="danger" data-action="profile-delete" data-id="${esc(p.id)}">EXCLUIR</button></div></div>`).join('')||'<p>Nenhum perfil cadastrado.</p>';
  $('users').innerHTML=data.users.map(u=>`<div class="item"><div><b>${esc(u.email)}</b><div class="meta">Google autorizado: ${esc(u.googleEmail)}<br>YouTube: ${u.oauthConnected?'conectado':'aguardando autorização'} • ${esc(u.status)}<br>Enviadas: ${u.sent} • Falhas: ${u.failures} • Tentativas: ${u.attempts}${u.lastError?'<br>'+esc(u.lastError):''}</div><span class="badge ${u.active?'green':'red'}">${u.active?'ATIVO':'BLOQUEADO'}</span></div><div class="actions"><button data-action="user-edit" data-id="${esc(u.id)}">EDITAR</button><button data-action="user-toggle" data-id="${esc(u.id)}">${u.active?'BLOQUEAR':'ATIVAR'}</button><button data-action="user-revoke" data-id="${esc(u.id)}">ENCERRAR SESSÕES</button><button data-action="user-logs" data-id="${esc(u.id)}">LOGS</button><button class="danger" data-action="user-delete" data-id="${esc(u.id)}">EXCLUIR</button></div></div>`).join('')||'<p>Nenhum usuário cadastrado.</p>';
  $('updatedAt').textContent='Atualizado às '+new Date().toLocaleTimeString();
}
document.addEventListener('click',async e=>{const b=e.target.closest('button[data-action]');if(!b)return;const id=b.dataset.id,action=b.dataset.action;b.disabled=true;
  try{if(action==='profile-edit'){const p=data.apiProfiles.find(p=>p.id===id);$('profileId').value=p.id;$('profileName').value=p.name;$('clientId').value=p.clientId;$('clientSecret').value='';$('profileActive').value=String(p.active);$('profileTitle').textContent='Editar perfil API';$('profileForm').scrollIntoView({behavior:'smooth',block:'center'});}
    if(action==='profile-delete'&&confirm('Excluir este perfil? Usuários vinculados impedem a exclusão.')){await api('/dbmadmin/api/profiles/'+id,{method:'DELETE',body:{}});await loadData();}
    if(action==='user-edit'){const u=data.users.find(u=>u.id===id);$('userId').value=u.id;$('userEmail').value=u.email;$('userGoogleEmail').value=u.googleEmail;$('userPass').value='';$('userProfile').value=u.apiProfileId;$('userActive').value=String(u.active);$('userTitle').textContent='Editar usuário';$('userForm').scrollIntoView({behavior:'smooth',block:'center'});}
    if(action==='user-toggle'){const u=data.users.find(u=>u.id===id);await api('/dbmadmin/api/users/'+id,{method:'PATCH',body:{active:!u.active}});await loadData();}
    if(action==='user-revoke'&&confirm('Encerrar as sessões deste usuário? A execução no servidor continua.')){await api('/dbmadmin/api/users/'+id+'/revoke',{method:'POST',body:{}});feedback('globalFb','Sessões encerradas.',true);}
    if(action==='user-delete'&&confirm('Excluir usuário, configurações e histórico? Esta ação encerra os envios.')){await api('/dbmadmin/api/users/'+id,{method:'DELETE',body:{}});await loadData();}
    if(action==='user-logs'){const d=await api('/dbmadmin/api/users/'+id+'/logs');showDetails('Últimos 100 registros',d.logs,true);}
  }catch(err){feedback('globalFb',err.message);}finally{b.disabled=false;}
});
function showDetails(title,value,download=false){details=JSON.stringify(value,null,2);$('detailsTitle').textContent=title;$('detailsText').textContent=details;show('detailsPanel',true);show('downloadDetails',download);$('detailsPanel').scrollIntoView({behavior:'smooth'});}
$('refreshBtn').onclick=()=>loadData().catch(e=>feedback('globalFb',e.message));
$('diagBtn').onclick=()=>api('/dbmadmin/api/diagnostics').then(d=>showDetails('Diagnóstico',d)).catch(e=>feedback('globalFb',e.message));
$('auditBtn').onclick=()=>api('/dbmadmin/api/audit').then(d=>showDetails('Auditoria administrativa',d.events,true)).catch(e=>feedback('globalFb',e.message));
$('downloadDetails').onclick=()=>{const url=URL.createObjectURL(new Blob([details],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='Auto_Server_Registros.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
setInterval(()=>{if(authenticated&&document.visibilityState==='visible')loadData().catch(e=>feedback('globalFb',e.message));},15000);
bootstrap().catch(e=>feedback('globalFb',e.message));
