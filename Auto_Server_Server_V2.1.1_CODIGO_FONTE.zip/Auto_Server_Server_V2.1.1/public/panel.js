'use strict';
const $=id=>document.getElementById(id);
const show=(id,on)=>$(id).classList.toggle('hidden',!on);
let csrfToken='',authenticated=false,currentState=null,draftVersion=-1,dirty=false,busy=false,serverOffset=0;

class ApiError extends Error{constructor(status,message){super(message);this.status=status;}}
function feedback(message,ok=false){const el=$('globalFeedback');el.textContent=message||'';el.className='feedback '+(message&&ok?'ok':'');}
function loginFeedback(message,ok=false){const el=$('loginFeedback');el.textContent=message||'';el.className='feedback '+(message&&ok?'ok':'');}
function setBusy(on){busy=on;document.querySelectorAll('button').forEach(button=>button.disabled=on);}

async function api(url,{method='GET',body}={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{
    const headers={Accept:'application/json'};
    if(body!==undefined){headers['Content-Type']='application/json';if(csrfToken)headers['X-CSRF-Token']=csrfToken;}
    const response=await fetch(url,{method,headers,body:body===undefined?undefined:JSON.stringify(body),credentials:'same-origin',signal:controller.signal});
    let data;try{data=await response.json();}catch{throw new ApiError(response.status,`Resposta inválida do servidor (HTTP ${response.status}).`);}
    if(!response.ok||data.ok!==true)throw new ApiError(response.status,data.error||`HTTP ${response.status}`);
    return data;
  }catch(error){if(error.name==='AbortError')throw new ApiError(0,'Tempo de conexão esgotado.');throw error;}finally{clearTimeout(timer);}
}

function loggedOut(message=''){
  authenticated=false;csrfToken='';currentState=null;draftVersion=-1;dirty=false;
  show('loginPanel',true);show('dashboard',false);show('logoutButton',false);
  if(message)loginFeedback(message);
}

async function bootstrap(){
  const data=await api('/api/web/bootstrap');
  if(!data.authenticated){loggedOut();return;}
  authenticated=true;csrfToken=data.csrfToken;show('loginPanel',false);show('dashboard',true);show('logoutButton',true);
  await refreshState(true);
}

function number(id){return Number($(id).value);}
function configBody(){return {liveUrl:$('liveUrl').value.trim(),intervalMinutes:number('intervalMinutes'),intervalSeconds:number('intervalSeconds'),intervalMs:number('intervalMs'),messages:$('messages').value,economyMode:$('economyMode').checked,maxPerHour:number('maxPerHour'),expectedVersion:draftVersion};}
function countMessages(){const count=$('messages').value.split(/\r?\n/).map(value=>value.trim()).filter(Boolean).length;$('messageCount').textContent=`${count} ${count===1?'mensagem':'mensagens'}`;}
function markDirty(){if(!currentState)return;dirty=true;$('saveState').textContent='Rascunho não salvo';countMessages();syncEconomy();}
function syncEconomy(){$('maxPerHour').disabled=!$('economyMode').checked||busy;}

function fillConfig(config){
  $('liveUrl').value=config.liveUrl||'';$('intervalMinutes').value=config.intervalMinutes;$('intervalSeconds').value=config.intervalSeconds;$('intervalMs').value=config.intervalMs;$('messages').value=config.messages||'';$('economyMode').checked=!!config.economyMode;$('maxPerHour').value=config.maxPerHour;draftVersion=config.version;dirty=false;$('saveState').textContent='Sincronizado';countMessages();syncEconomy();
}

function statusName(status){return status==='running'?'RODANDO':status==='paused'?'PAUSADO':'PARADO';}
function formatDuration(ms){const total=Math.max(0,Math.round(ms/1000)),minutes=Math.floor(total/60),seconds=total%60;return minutes?`${minutes} min ${String(seconds).padStart(2,'0')} s`:`${seconds} s`;}
function formatTime(iso){const date=new Date(iso);return Number.isNaN(date.getTime())?'—':date.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});}
function renderRuntime(data){
  const runtime=data.runtime,status=runtime.status||'stopped',badge=$('statusBadge');badge.textContent=statusName(status);badge.className='status '+status;
  $('statusTitle').textContent=status==='running'?'Automação em execução':status==='paused'?'Automação pausada':'Automação parada';
  $('statusDetail').textContent=status==='running'&&runtime.nextAt?`Próximo envio previsto às ${formatTime(runtime.nextAt)}.`:status==='paused'?'Os dados estão salvos. Toque em Iniciar para continuar.':'Toque em Iniciar quando a configuração estiver pronta.';
  $('sentCount').textContent=runtime.sent;$('failureCount').textContent=runtime.failures;$('attemptCount').textContent=runtime.attempts;$('hourlyCount').textContent=runtime.hourlySent;
  $('effectiveDelay').textContent=`Intervalo efetivo: ${formatDuration(runtime.effectiveDelayMs)}`;
  $('accountTitle').textContent=runtime.oauthConnected?'YouTube conectado':'YouTube não conectado';
  $('accountDetail').textContent=runtime.oauthConnected?`Conta ativa: ${runtime.oauthEmail}`:`Conta permitida: ${data.user.googleEmail}`;
  $('oauthButton').textContent=runtime.oauthConnected?'TROCAR CONTA GOOGLE':'ENTRAR COM GOOGLE';show('disconnectButton',runtime.oauthConnected);
  $('lastError').textContent=runtime.lastError||'';show('lastError',!!runtime.lastError);
  renderLogs(data.logs||[]);
}

function renderLogs(logs){
  const root=$('logs');root.replaceChildren();
  if(!logs.length){const empty=document.createElement('p');empty.className='muted';empty.textContent='Sem atividade recente.';root.append(empty);return;}
  for(const entry of logs){const item=document.createElement('article');item.className='log '+(entry.status||'');const head=document.createElement('div');head.className='log-head';const type=document.createElement('span');type.textContent=String(entry.type||'atividade').toUpperCase();const at=document.createElement('time');at.dateTime=entry.at||'';at.textContent=entry.at?new Date(entry.at).toLocaleString():'—';head.append(type,at);item.append(head);if(entry.message){const message=document.createElement('div');message.className='log-message';message.textContent=entry.message;item.append(message);}if(entry.error){const error=document.createElement('div');error.className='log-error';error.textContent=entry.error;item.append(error);}root.append(item);}
}

async function refreshState(forceConfig=false){
  if(!authenticated)return;
  try{const data=await api('/api/state');serverOffset=Number(data.serverTime||Date.now())-Date.now();currentState=data;if(forceConfig||!dirty)fillConfig(data.config);renderRuntime(data);feedback('');}
  catch(error){if(error.status===401)loggedOut('Sua sessão expirou. Entre novamente.');else feedback(error.message);}
}

async function saveConfig(){
  if(!currentState)throw new ApiError(0,'Aguarde a sincronização do servidor.');
  if(!$('configForm').reportValidity())throw new ApiError(0,'Revise os campos destacados.');
  const result=await api('/api/config',{method:'PUT',body:configBody()});currentState.config=result.config;dirty=false;$('saveState').textContent='Configuração salva';await refreshState(true);
}

async function control(action){
  setBusy(true);feedback('');try{if(action==='start'&&dirty)await saveConfig();await api('/api/control/'+action,{method:'POST',body:{}});await refreshState(false);feedback(action==='start'?'Execução iniciada no servidor.':action==='pause'?'Execução pausada.':'Execução parada.',true);}catch(error){if(error.status===401)loggedOut('Sua sessão expirou. Entre novamente.');else feedback(error.message);}finally{setBusy(false);syncEconomy();}
}

$('loginForm').addEventListener('submit',async event=>{event.preventDefault();setBusy(true);loginFeedback('Entrando…',true);try{await api('/api/login',{method:'POST',body:{email:$('loginEmail').value.trim(),password:$('loginPassword').value,privacyAccepted:$('privacyAccepted').checked}});$('loginPassword').value='';await bootstrap();feedback('Login concluído.',true);}catch(error){loginFeedback(error.message);}finally{setBusy(false);syncEconomy();}});
$('configForm').addEventListener('input',markDirty);
$('configForm').addEventListener('submit',async event=>{event.preventDefault();setBusy(true);try{await saveConfig();feedback('Configuração salva no servidor.',true);}catch(error){feedback(error.status===409?'A configuração mudou em outra sessão. Seu rascunho foi mantido; descarte-o ou copie antes de recarregar.':error.message);}finally{setBusy(false);syncEconomy();}});
$('reloadButton').addEventListener('click',()=>{if(dirty&&!confirm('Descartar as alterações ainda não salvas?'))return;refreshState(true);});
$('startButton').addEventListener('click',()=>control('start'));
$('pauseButton').addEventListener('click',()=>control('pause'));
$('stopButton').addEventListener('click',()=>control('stop'));
$('refreshButton').addEventListener('click',()=>refreshState(false));
$('oauthButton').addEventListener('click',async()=>{setBusy(true);try{const result=await api('/api/oauth/start?client=web');location.assign(result.url);}catch(error){feedback(error.message);setBusy(false);syncEconomy();}});
$('disconnectButton').addEventListener('click',async()=>{if(!confirm('Desconectar esta conta do YouTube e pausar a automação?'))return;setBusy(true);try{const result=await api('/api/oauth/disconnect',{method:'POST',body:{}});await refreshState(true);feedback(result.warning||'Conta do YouTube desconectada.',!result.warning);}catch(error){feedback(error.message);}finally{setBusy(false);syncEconomy();}});
$('clearLogsButton').addEventListener('click',async()=>{if(!confirm('Limpar os registros recentes?'))return;setBusy(true);try{await api('/api/logs/clear',{method:'POST',body:{}});await refreshState(false);feedback('Registros limpos.',true);}catch(error){feedback(error.message);}finally{setBusy(false);syncEconomy();}});
$('logoutButton').addEventListener('click',async()=>{if(!confirm('Sair do painel? A execução no servidor continuará.'))return;setBusy(true);try{await api('/api/logout',{method:'POST',body:{}});}catch(error){feedback(error.message);}finally{setBusy(false);loggedOut('Você saiu. A automação no servidor não foi interrompida.');}});
$('deleteAccountButton').addEventListener('click',async()=>{if(!confirm('Excluir definitivamente sua conta, configuração e histórico deste servidor?'))return;setBusy(true);try{await api('/api/account',{method:'DELETE',body:{}});loggedOut('Conta excluída do servidor.');}catch(error){feedback(error.message);}finally{setBusy(false);}});

const oauthResult=new URLSearchParams(location.search).get('oauth');if(oauthResult){feedback(oauthResult==='ok'?'Conta Google autorizada. Confira os dados e inicie a execução.':'A autorização Google não foi concluída.',oauthResult==='ok');history.replaceState({},'',location.pathname);}
setInterval(()=>{if(authenticated&&document.visibilityState==='visible'&&!busy)refreshState(false);},5000);
setInterval(()=>{if(!currentState||currentState.runtime.status!=='running'||!currentState.runtime.nextAt)return;const left=new Date(currentState.runtime.nextAt).getTime()-(Date.now()+serverOffset);$('statusDetail').textContent=left>0?`Próximo envio em ${formatDuration(left)} (${formatTime(currentState.runtime.nextAt)}).`:'Preparando o próximo envio…';},1000);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refreshState(false);});
bootstrap().catch(error=>{loggedOut();loginFeedback(error.message);});
