'use strict';
const {test,before,after}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'peralta-tests-'));
process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL='http://localhost:8080';process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security'),v=require('../lib/validation');
const {createApp}=require('../server');
const {createWorkers}=require('../lib/workers');
let server,base,cookie,csrf,profileId,userId,token,userCookie,webCsrf;
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function req(route,{method='GET',body,admin=false,web=false,bearer=token,csrfOverride,origin,userAgent}={}) {
  const headers={'Content-Type':'application/json'};if(admin){headers.Cookie=cookie;headers['X-CSRF-Token']=csrfOverride??csrf;}else if(web){headers.Cookie=userCookie;if(csrfOverride!==null)headers['X-CSRF-Token']=csrfOverride??webCsrf;}else if(bearer)headers.Authorization='Bearer '+bearer;if(origin)headers.Origin=origin;if(userAgent)headers['User-Agent']=userAgent;
  const r=await fetch(base+route,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(10000)});
  return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};
}
before(async()=>{server=createApp().listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));base='http://127.0.0.1:'+server.address().port;});
after(async()=>{server.closeAllConnections();await new Promise(r=>server.close(r));store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});
test('setup exige código e cria apenas um administrador sob concorrência',async()=>{
  assert.equal((await req('/dbmadmin/api/setup',{method:'POST',body:{setupToken:'wrong',username:'admin',password:'valid-test-password'}})).status,403);
  const results=await Promise.all(['admin','admin2'].map(username=>req('/dbmadmin/api/setup',{method:'POST',body:{setupToken:process.env.SETUP_TOKEN,username,password:'valid-test-password'}})));
  assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);assert.equal(store.admins().length,1);cookie=results.find(r=>r.status===200).cookie;
  const b=await req('/dbmadmin/api/bootstrap',{admin:true});assert.equal(b.body.authenticated,true);csrf=b.body.csrfToken;
});
test('cookie, CSRF, origem e perfil administrativo',async()=>{
  assert.equal((await req('/dbmadmin/api/profiles',{admin:true,csrfOverride:'invalid',method:'POST',body:{}})).status,403);
  assert.equal((await req('/dbmadmin/api/profiles',{admin:true,origin:'https://untrusted.example',method:'POST',body:{}})).status,403);
  const r=await req('/dbmadmin/api/profiles',{admin:true,method:'POST',body:{name:'Test profile',clientId:'123-test.apps.googleusercontent.com',clientSecret:'synthetic-not-google'}});assert.equal(r.status,200);profileId=r.body.id;
});
test('cadastro concorrente não duplica e-mail; usuário não acessa API de admin',async()=>{
  const body={email:'person@example.invalid',googleEmail:'google@example.invalid',password:'valid-user-password',apiProfileId:profileId};
  const r=await Promise.all([req('/dbmadmin/api/users',{admin:true,method:'POST',body}),req('/dbmadmin/api/users',{admin:true,method:'POST',body})]);assert.deepEqual(r.map(x=>x.status).sort(),[200,409]);userId=r.find(x=>x.status===200).body.id;
  const login=await req('/api/login',{method:'POST',body:{email:body.email,password:body.password,privacyAccepted:true}});assert.equal(login.status,200);token=login.body.token;userCookie=login.cookie;
  assert.equal((await req('/api/state')).status,200);assert.equal((await req('/dbmadmin/api/data')).status,401);
});
test('painel web usa cookie HttpOnly, bootstrap e CSRF sem depender da aba aberta',async()=>{
  const page=await fetch(base+'/painel');assert.equal(page.status,200);assert.match(await page.text(),/Auto Server/);assert.match(userCookie,/^auto_server_user=/);
  const bootstrap=await req('/api/web/bootstrap',{web:true});assert.equal(bootstrap.status,200);assert.equal(bootstrap.body.authenticated,true);webCsrf=bootstrap.body.csrfToken;assert.equal(typeof webCsrf,'string');assert.ok(webCsrf.length>20);
  const version=store.getUser(userId).config.version;
  assert.equal((await req('/api/config',{web:true,csrfOverride:null,method:'PUT',body:{expectedVersion:version}})).status,403);
  assert.equal((await req('/api/config',{web:true,method:'PUT',body:{expectedVersion:version}})).status,200);
});
test('OAuth mostra o seletor de contas e não força o e-mail sugerido',async()=>{
  const mobile=await req('/api/oauth/start');assert.equal(mobile.status,200);const mobileUrl=new URL(mobile.body.url);
  assert.equal(mobileUrl.searchParams.has('login_hint'),false);assert.ok(mobileUrl.searchParams.get('prompt').split(/\s+/).includes('select_account'));
  const web=await req('/api/oauth/start?client=web',{web:true});assert.equal(web.status,200);const webUrl=new URL(web.body.url);assert.ok(webUrl.searchParams.get('state').startsWith('w.'));assert.ok(store.consumeOAuthAttempt(webUrl.searchParams.get('state')));
  const legacy=await req('/api/oauth/start',{userAgent:'PeraltaChatAndroid/2.1.1'});const legacyUrl=new URL(legacy.body.url);assert.ok(legacyUrl.searchParams.get('state').startsWith('l.'));assert.ok(store.consumeOAuthAttempt(legacyUrl.searchParams.get('state')));
  const webReturn=await fetch(base+'/oauth/google/callback?state=w.invalid'),appReturn=await fetch(base+'/oauth/google/callback?state=a.invalid');assert.equal(webReturn.status,400);assert.match(await webReturn.text(),/\/painel\?oauth=erro/);assert.equal(appReturn.status,400);assert.match(await appReturn.text(),/autoserver:\/\/oauth-complete\?ok=0/);
});
test('versão impede sobrescrita de configuração e trocar live invalida o chat',async()=>{
  const initial=store.getUser(userId);store.updateUser(userId,u=>{u.runtime.activeLiveChatId='OLD';u.runtime.activeVideoId='AAAAAAAAAAA';});
  const r=await req('/api/config',{method:'PUT',body:{liveUrl:'BBBBBBBBBBB',messages:'Hello',expectedVersion:initial.config.version}});assert.equal(r.status,200);assert.equal(store.getUser(userId).runtime.activeLiveChatId,'');
  assert.equal((await req('/api/config',{method:'PUT',body:{messages:'overwrite',expectedVersion:initial.config.version}})).status,409);assert.equal(store.getUser(userId).config.messages,'Hello');
  assert.equal((await req('/api/config',{method:'PUT',body:{intervalMinutes:1e300,expectedVersion:r.body.config.version}})).status,400);
});
test('edição de senha preserva configuração concorrente e revoga sessão anterior',async()=>{
  const version=store.getUser(userId).config.version;
  const changing=req('/dbmadmin/api/users/'+userId,{admin:true,method:'PATCH',body:{password:'new-user-password'}});await pause(20);
  assert.equal((await req('/api/config',{method:'PUT',body:{expectedVersion:version,messages:'New configuration'}})).status,200);assert.equal((await changing).status,200);
  assert.equal(store.getUser(userId).config.messages,'New configuration');assert.equal((await req('/api/state')).status,401);
  const login=await req('/api/login',{method:'POST',body:{email:'person@example.invalid',password:'new-user-password',privacyAccepted:true}});token=login.body.token;assert.equal(login.status,200);
});
test('mudar e-mail Google remove autorização anterior; estado OAuth é consumido uma vez',async()=>{
  store.updateUser(userId,u=>{u.oauth.refreshTokenEnc=security.encryptText('synthetic');u.oauth.email=u.googleEmail;});
  assert.equal((await req('/dbmadmin/api/users/'+userId,{admin:true,method:'PATCH',body:{googleEmail:'new-google@example.invalid'}})).status,200);
  assert.equal(store.getUser(userId).oauth.refreshTokenEnc,'');assert.equal(store.getUser(userId).runtime.status,'paused');
  const state=security.randomState();store.saveOAuthAttempt(state,store.getUser(userId));assert.ok(store.consumeOAuthAttempt(state));assert.equal(store.consumeOAuthAttempt(state),null);
});
test('entrada de mensagens, URL, senha e números é validada',()=>{
  assert.equal(v.extractVideoId('https://evil.example/?v=AAAAAAAAAAA'),null);assert.equal(v.extractVideoId('https://youtu.be/AAAAAAAAAAA'),'AAAAAAAAAAA');
  assert.throws(()=>v.config({messages:'x'.repeat(201)}));assert.throws(()=>v.config({intervalSeconds:60}));assert.throws(()=>v.config({maxPerHour:NaN}));assert.throws(()=>v.password('short'));
});
function fixture(){const u=store.createUser({id:store.id('usr'),email:crypto.randomBytes(8).toString('hex')+'@example.invalid',googleEmail:'google@example.invalid',apiProfileId:profileId,active:true});return store.updateUser(u.id,u=>{u.config.liveUrl='AAAAAAAAAAA';u.config.messages='First\nSecond';u.config.intervalMinutes=0;u.config.intervalSeconds=1;u.runtime.status='running';u.oauth.refreshTokenEnc=security.encryptText('synthetic');});}
test('worker troca o destino e resolve o chat da nova live',async()=>{
  const u=fixture(),resolved=[],sent=[];let now=Date.now();const w=createWorkers({clock:()=>now,api:{getActiveLiveChatId:async(_u,_p,id)=>{resolved.push(id);return 'CHAT_'+id;},sendLiveChatMessage:async(_u,_p,chat,_m,options)=>{options.beforeSend();sent.push(chat);return {};}}});
  await w.step(u.id);store.updateUser(u.id,u=>{u.config.liveUrl='BBBBBBBBBBB';u.config.version++;u.runtime.activeLiveChatId='';u.runtime.activeVideoId='';});now+=1001;await w.step(u.id);
  assert.deepEqual(resolved,['AAAAAAAAAAA','BBBBBBBBBBB']);assert.deepEqual(sent,['CHAT_AAAAAAAAAAA','CHAT_BBBBBBBBBBB']);
});
test('parada durante localização ou renovação impede uma nova publicação',async()=>{
  for(const phase of ['lookup','token']){const u=fixture();let sent=0,w;w=createWorkers({api:{getActiveLiveChatId:async()=>{if(phase==='lookup')w.stop(u.id);return 'CHAT';},sendLiveChatMessage:async(_u,_p,_c,_m,o)=>{if(phase==='token')w.stop(u.id);o.beforeSend();sent++;}}});await w.step(u.id);assert.equal(sent,0);assert.equal(store.getUser(u.id).runtime.attempts,0);}
});
test('resposta antiga não restaura OAuth atualizado',async()=>{
  const u=fixture();let sent=0;const w=createWorkers({api:{getActiveLiveChatId:async(snapshot,_p,_id,o)=>{store.updateUser(u.id,u=>{u.oauth.version++;u.oauth.refreshTokenEnc=security.encryptText('new-synthetic');});snapshot.oauth.accessTokenEnc=security.encryptText('old-access');o.persist(snapshot.oauth);return 'CHAT';},sendLiveChatMessage:async()=>{sent++;}}});
  await w.step(u.id);assert.equal(sent,0);assert.equal(security.decryptText(store.getUser(u.id).oauth.refreshTokenEnc),'new-synthetic');assert.equal(store.getUser(u.id).oauth.accessTokenEnc,'');
});
test('cota na localização, mensagem inválida e resultado incerto pausam sem repetição',async()=>{
  for(const reason of ['quotaExceeded','messageTextInvalid','ambiguous']){const u=fixture();let calls=0;const error=Object.assign(new Error(reason),{reason,status:reason==='messageTextInvalid'?400:403});if(reason==='ambiguous'){delete error.status;error.ambiguousWrite=true;}
    const w=createWorkers({api:{getActiveLiveChatId:async()=>{if(reason==='quotaExceeded'){calls++;throw error;}return 'CHAT';},sendLiveChatMessage:async(_u,_p,_c,_m,o)=>{o.beforeSend();calls++;throw error;}}});await w.step(u.id);await w.step(u.id);assert.equal(calls,1);assert.equal(store.getUser(u.id).runtime.status,'paused');}
});
test('limite horário considera janela real e sobrevive a parar/iniciar',async()=>{
  const u=fixture(),now=Date.now();store.updateUser(u.id,u=>{u.config.economyMode=true;u.config.maxPerHour=2;u.runtime.hourlySends=[now-2000,now-1000];});const w=createWorkers({clock:()=>now});assert.equal(w.nextTarget(store.getUser(u.id)),now-2000+3600000);w.stop(u.id);w.start(u.id,true);w.pause(u.id);assert.equal(store.getUser(u.id).runtime.hourlySends.length,2);await w.shutdown();
});
test('criptografia detecta adulteração e tipos de token ficam separados',()=>{
  const enc=security.encryptText('synthetic');assert.equal(security.decryptText(enc),'synthetic');const p=enc.split('.');const b=Buffer.from(p[1],'base64url');b[0]^=1;p[1]=b.toString('base64url');assert.throws(()=>security.decryptText(p.join('.')));
  assert.throws(()=>security.verifySession(security.signSession('x','user',1).token,'admin'));
});
test('backup consistente pode ser aberto e preserva usuários',async()=>{
  const file=path.join(process.env.DATA_DIR,'test-backup.sqlite');await store.backupTo(file);const {DatabaseSync}=require('node:sqlite');const copy=new DatabaseSync(file,{readOnly:true});assert.equal(copy.prepare('SELECT COUNT(*) AS n FROM users').get().n,store.users().length);assert.equal(Object.values(copy.prepare('PRAGMA quick_check').get())[0],'ok');copy.close();
});
test('banco V2.1.0 abre sem mudar o esquema e preserva usuário e OAuth',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'auto-server-migrate-')),file=path.join(dir,'peralta.sqlite'),state='oauth-before-update';const {DatabaseSync}=require('node:sqlite'),old=new DatabaseSync(file);
  old.exec('CREATE TABLE users(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE COLLATE NOCASE,body TEXT NOT NULL); CREATE TABLE oauth_states(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,profile_id TEXT NOT NULL,version INTEGER NOT NULL,expires INTEGER NOT NULL); PRAGMA user_version=1;');
  const user={id:'existing-user',email:'saved@example.invalid',googleEmail:'google@example.invalid',apiProfileId:'existing-profile',active:true};old.prepare('INSERT INTO users VALUES(?,?,?)').run(user.id,user.email,JSON.stringify(user));old.prepare('INSERT INTO oauth_states VALUES(?,?,?,?,?)').run(crypto.createHash('sha256').update(state).digest('hex'),user.id,user.apiProfileId,1,Date.now()+60000);old.close();
  const code=`const s=require('./lib/store');const u=s.getUser('existing-user'),a=s.consumeOAuthAttempt('oauth-before-update'),file=s.DB_FILE;s.close();const {DatabaseSync}=require('node:sqlite'),db=new DatabaseSync(file,{readOnly:true}),columns=db.prepare('PRAGMA table_info(oauth_states)').all().length,version=db.prepare('PRAGMA user_version').get().user_version;db.close();console.log(JSON.stringify({email:u.email,oauth:!!a,columns,version}));`;
  const migrated=spawnSync(process.execPath,['-e',code],{cwd:path.join(__dirname,'..'),env:{...process.env,DATA_DIR:dir},encoding:'utf8'});assert.equal(migrated.status,0,migrated.stderr);assert.deepEqual(JSON.parse(migrated.stdout.trim()),{email:user.email,oauth:true,columns:5,version:1});fs.rmSync(dir,{recursive:true,force:true});
});
test('banco corrompido provoca falha, sem apagar o arquivo',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'peralta-corrupt-')),file=path.join(dir,'peralta.sqlite');fs.writeFileSync(file,'invalid-sqlite');const r=spawnSync(process.execPath,['-e',"require('./lib/store')"],{cwd:path.join(__dirname,'..'),env:{...process.env,DATA_DIR:dir}});assert.notEqual(r.status,0);assert.equal(fs.readFileSync(file,'utf8'),'invalid-sqlite');fs.rmSync(dir,{recursive:true,force:true});
});
test('tentativas excessivas de login recebem 429',async()=>{
  let status;for(let i=0;i<13;i++)status=(await req('/api/login',{method:'POST',body:{email:'missing@example.invalid',password:'wrong',privacyAccepted:true}})).status;assert.equal(status,429);
});
