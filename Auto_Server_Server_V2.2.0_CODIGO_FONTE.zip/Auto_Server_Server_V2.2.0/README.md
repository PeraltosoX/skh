# Auto Server V2.2.0

Servidor e painel web do Auto Server. A automação roda na VPS: fechar o
aplicativo, sair do painel ou fechar o navegador não interrompe os perfis que
estão em execução.

Esta entrega altera somente o servidor/painel. O projeto Android não faz parte
deste pacote e não foi modificado.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde do serviço: `/health`
- Retorno Google OAuth: `/oauth/google/callback`

## Principais recursos

- Login no Auto Server por **nome de usuário e senha**, sem e-mail ou `@`.
- Exatamente três perfis por usuário.
- API Google, OAuth, tokens, Conta Google permitida, mensagens, canais,
  intervalos, contadores, logs, status e worker separados por perfil.
- Perfis 1, 2 e 3 podem rodar ao mesmo tempo; iniciar, pausar ou parar um perfil
  não altera os outros.
- Um único monitor global consulta cada canal do YouTube uma vez, mesmo que o
  canal esteja cadastrado em vários usuários ou perfis.
- Cadastro de canal por `@handle`, `/channel/UC...`, `/c/...` ou `/user/...`.
- Até três transmissões recentes são examinadas por canal.
- Estados separados para live, chat e execução individual.
- Live programada com chat disponível já pode ser distribuída aos perfis.
- Ao detectar encerramento, a execução entra em finalização por cinco minutos,
  usando o horário real quando disponível.
- Lives finalizadas não são reativadas por resultados antigos.
- O modo econômico e o limite de mensagens por hora foram removidos da lógica e
  dos painéis. Campos antigos são apenas aceitos e ignorados para compatibilidade.
- Intervalo de envio mínimo e padrão de três minutos.
- O administrador controla o intervalo da busca global (padrão: três minutos).
- Seletor de Conta Google sempre aberto com `select_account`, sem `login_hint`.
- Client Secret, refresh token e access token nunca são retornados pelos painéis.
- Credenciais e tokens são criptografados com AES-256-GCM.
- SQLite persistente, cookies HttpOnly/SameSite, CSRF, validação de origem,
  auditoria e retomada dos workers após reinício.

## Compatibilidade com a versão anterior

As rotas históricas usadas pelo Android (`/api/state`, `/api/config`,
`/api/control/...` e `/api/oauth/...`) continuam disponíveis e apontam para o
Perfil 1. O campo JSON antigo chamado `email` no login também pode transportar o
novo nome de usuário, mas autenticação por endereço de e-mail não é mais aceita.

## Migration automática da V2.1.1

Na primeira inicialização com o banco anterior, o servidor faz uma migration
incremental e transacional:

1. preserva o usuário, senha, sessões, logs e tabelas antigas;
2. gera o nome de usuário a partir da parte anterior ao `@` do e-mail antigo;
3. cria exatamente os Perfis 1, 2 e 3;
4. copia API, OAuth, mensagens, configuração, contadores e execução atuais para
   o Perfil 1;
5. cria Perfis 2 e 3 vazios, com intervalo padrão de três minutos;
6. cria as tabelas de canais, lives, vínculos, estados e monitor global;
7. remove modo econômico/limite por hora da configuração migrada.

Se dois e-mails antigos gerarem o mesmo nome, o segundo recebe um sufixo
numérico. Confira os nomes em `/dbmadmin` após atualizar e ajuste-os se desejar.

O banco permanece em `data/peralta.sqlite`. A pasta `data/` e o arquivo `.env`
formam um conjunto: sem a mesma `APP_ENCRYPTION_KEY`, as autorizações Google
existentes não podem ser descriptografadas.

Use `ATUALIZAR_SEM_PERDER_DADOS.sh`; ele para a versão anterior, cria backup,
copia `.env` e `data/`, inicia a V2.2.0, testa `/health` e religa automaticamente
a V2.1.1 se houver falha. Nunca extraia a nova versão por cima da antiga.

## Google OAuth por perfil

Cada perfil utiliza um OAuth Client do tipo **Web application**. Cadastre
exatamente esta URI em cada Client ID:

`https://SEU-DOMINIO/oauth/google/callback`

Para cotas realmente independentes, crie os OAuth Clients em projetos Google
Cloud diferentes. Vários Clients no mesmo projeto compartilham a cota do
projeto.

## API de perfis

- `GET /api/profiles`
- `GET /api/profiles/:profileId`
- `GET /api/profiles/:profileId/status`
- `GET|PUT /api/profiles/:profileId/messages`
- `GET|PUT /api/profiles/:profileId/settings`
- `GET|POST|PUT|DELETE /api/profiles/:profileId/channels`
- `POST /api/profiles/:profileId/start|pause|stop`
- `GET|POST /api/profiles/:profileId/oauth/connect`
- `POST /api/profiles/:profileId/oauth/disconnect`
- `GET /api/profiles/:profileId/logs`

O `user_id` é sempre obtido da sessão. Não existe rota de usuário comum que
aceite o ID de outro usuário.

## Desenvolvimento e verificação

Requer Node.js 24.14 ou superior, ainda na linha 24:

```bash
npm ci
npm run check
npm test
npm start
```

Para produção, use o `docker-compose.yml` e os procedimentos em `INSTALAR.txt`
ou `ATUALIZAR_SEM_PERDER_DADOS.txt`.
