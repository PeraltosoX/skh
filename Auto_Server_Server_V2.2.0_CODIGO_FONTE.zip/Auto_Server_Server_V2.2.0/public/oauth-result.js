'use strict';
const target=document.body.dataset.oauthTarget;
if(target)setTimeout(()=>{location.href=target;},target.startsWith('/painel')?700:1600);
