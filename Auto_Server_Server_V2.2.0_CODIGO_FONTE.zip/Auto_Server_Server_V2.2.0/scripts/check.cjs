'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(['node_modules','data','.git'].includes(e.name))continue;const file=path.join(dir,e.name);if(e.isDirectory())walk(file);else if(/\.(c?js)$/.test(file)){const r=spawnSync(process.execPath,['--check',file],{stdio:'inherit'});if(r.status)process.exit(r.status);}}}
walk(path.join(__dirname,'..'));console.log('Sintaxe JavaScript validada.');
