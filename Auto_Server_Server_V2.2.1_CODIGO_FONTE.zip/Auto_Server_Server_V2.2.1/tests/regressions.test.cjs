'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'auto-server-tests-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';

const store = require('../lib/store');
const security = require('../lib/security');
const validation = require('../lib/validation');
const youtube = require('../lib/youtube');
const { normalizeChannelInput, extractChannelMetadata } = require('../lib/channel-normalizer');
const discovery = require('../lib/youtube-discovery');
const { createGlobalMonitor } = require('../lib/global-monitor');
const { createApp } = require('../server');
const { createWorkers } = require('../lib/workers');

let server;
let base;
let adminCookie;
let adminCsrf;
let userId;
let token;
let userCookie;
let webCsrf;

async function request(route, { method = 'GET', body, admin = false, web = false, bearer = token, csrfOverride, origin, userAgent } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (admin) {
    headers.Cookie = adminCookie;
    headers['X-CSRF-Token'] = csrfOverride ?? adminCsrf;
  } else if (web) {
    headers.Cookie = userCookie;
    if (csrfOverride !== null) headers['X-CSRF-Token'] = csrfOverride ?? webCsrf;
  } else if (bearer) headers.Authorization = `Bearer ${bearer}`;
  if (origin) headers.Origin = origin;
  if (userAgent) headers['User-Agent'] = userAgent;
  const response = await fetch(`${base}${route}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(10000)
  });
  const contentType = response.headers.get('content-type') || '';
  const responseBody = contentType.includes('application/json') ? await response.json() : await response.text();
  return { status: response.status, body: responseBody, cookie: response.headers.get('set-cookie')?.split(';')[0] };
}

before(async () => {
  server = createApp().listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  store.close();
  fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true });
});

test('setup exige código, CSRF e cria apenas um administrador', async () => {
  const denied = await request('/dbmadmin/api/setup', { method: 'POST', body: { setupToken: 'wrong', username: 'admin', password: 'valid-test-password' } });
  assert.equal(denied.status, 403);
  const results = await Promise.all(['admin', 'admin2'].map(username => request('/dbmadmin/api/setup', { method: 'POST', body: { setupToken: process.env.SETUP_TOKEN, username, password: 'valid-test-password' } })));
  assert.deepEqual(results.map(result => result.status).sort(), [200, 409]);
  adminCookie = results.find(result => result.status === 200).cookie;
  const bootstrap = await request('/dbmadmin/api/bootstrap', { admin: true });
  assert.equal(bootstrap.body.authenticated, true);
  adminCsrf = bootstrap.body.csrfToken;
  assert.equal((await request('/dbmadmin/api/global-monitor', { admin: true, csrfOverride: 'bad', method: 'PATCH', body: { intervalMinutes: 3 } })).status, 403);
  assert.equal((await request('/dbmadmin/api/global-monitor', { admin: true, origin: 'https://untrusted.invalid', method: 'PATCH', body: { intervalMinutes: 3 } })).status, 403);
});

test('cadastro usa nome de usuário sem arroba e cria exatamente três perfis', async () => {
  const body = { username: 'MKZ 01', password: 'valid-user-password', active: true };
  const results = await Promise.all([
    request('/dbmadmin/api/users', { admin: true, method: 'POST', body }),
    request('/dbmadmin/api/users', { admin: true, method: 'POST', body })
  ]);
  assert.deepEqual(results.map(result => result.status).sort(), [201, 409]);
  userId = results.find(result => result.status === 201).body.id;
  const profiles = store.userProfiles(userId);
  assert.deepEqual(profiles.map(profile => profile.profileNumber), [1, 2, 3]);
  assert.equal(new Set(profiles.map(profile => profile.id)).size, 3);
  assert.ok(profiles.every(profile => profile.config.intervalMinutes === 3));
  assert.equal((await request('/dbmadmin/api/users', { admin: true, method: 'POST', body: { username: 'bad@example.com', password: 'valid-user-password' } })).status, 400);
});

test('login por usuário funciona e login por e-mail é recusado', async () => {
  const login = await request('/api/login', { method: 'POST', body: { username: 'mkz 01', password: 'valid-user-password', privacyAccepted: true }, bearer: '' });
  assert.equal(login.status, 200);
  token = login.body.token;
  userCookie = login.cookie;
  assert.match(userCookie, /^auto_server_user=/);
  assert.equal(login.body.user.username, 'MKZ 01');
  assert.equal((await request('/api/login', { method: 'POST', body: { email: 'mkz@example.com', password: 'valid-user-password', privacyAccepted: true }, bearer: '' })).status, 400);
  assert.equal((await request('/dbmadmin/api/data')).status, 401);
});

test('painel web usa cookie HttpOnly, bootstrap e CSRF', async () => {
  const page = await fetch(`${base}/painel`);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /Perfil 1|PERFIL 1/);
  const bootstrap = await request('/api/web/bootstrap', { web: true });
  assert.equal(bootstrap.body.authenticated, true);
  webCsrf = bootstrap.body.csrfToken;
  assert.ok(webCsrf.length > 20);
  const version = store.getUserProfile(userId, 1).config.version;
  assert.equal((await request('/api/config', { web: true, csrfOverride: null, method: 'PUT', body: { intervalMinutes: 3, expectedVersion: version } })).status, 403);
  assert.equal((await request('/api/config', { web: true, method: 'PUT', body: { intervalMinutes: 3, expectedVersion: version } })).status, 200);
});

test('admin configura API e Conta Google de cada perfil separadamente', async () => {
  for (const number of [1, 2, 3]) {
    const result = await request(`/dbmadmin/api/users/${userId}/profiles/${number}`, {
      admin: true,
      method: 'PATCH',
      body: {
        name: `Operação ${number}`,
        enabled: true,
        googleEmail: `google${number}@example.invalid`,
        clientId: `${number}23-test.apps.googleusercontent.com`,
        clientSecret: `synthetic-secret-${number}`
      }
    });
    assert.equal(result.status, 200);
  }
  const profiles = store.userProfiles(userId);
  assert.deepEqual(profiles.map(profile => profile.googleEmail), ['google1@example.invalid', 'google2@example.invalid', 'google3@example.invalid']);
  assert.equal(security.decryptText(profiles[1].api.clientSecretEnc), 'synthetic-secret-2');
  const data = await request('/dbmadmin/api/data', { admin: true });
  assert.equal(JSON.stringify(data.body).includes('synthetic-secret'), false);
  assert.equal(JSON.stringify(data.body).includes('refreshTokenEnc'), false);
});

test('OAuth de cada perfil mostra seletor de contas e estado é consumido uma vez', async () => {
  const result = await request('/api/profiles/2/oauth/connect?client=web');
  assert.equal(result.status, 200);
  const url = new URL(result.body.url);
  assert.equal(url.searchParams.has('login_hint'), false);
  assert.ok(url.searchParams.get('prompt').split(/\s+/).includes('select_account'));
  assert.ok(url.searchParams.get('state').startsWith('w.'));
  const attempt = store.consumeOAuthAttempt(url.searchParams.get('state'));
  assert.equal(attempt.profile_number, 2);
  assert.equal(store.consumeOAuthAttempt(url.searchParams.get('state')), null);
  const legacy = await request('/api/oauth/start', { userAgent: 'PeraltaChatAndroid/2.1.4' });
  assert.equal(legacy.status, 200);
  const legacyUrl = new URL(legacy.body.url);
  assert.ok(legacyUrl.searchParams.get('state').startsWith('l.'));
  assert.equal(store.consumeOAuthAttempt(legacyUrl.searchParams.get('state')).profile_number, 1);
  const failed = await fetch(`${base}/oauth/google/callback?state=w.invalid`);
  assert.equal(failed.status, 400);
  assert.match(await failed.text(), /\/painel\?oauth=erro&amp;profile=1/);
});

test('configurações, mensagens, logs e comandos ficam isolados por perfil', async () => {
  const first = store.getUserProfile(userId, 1);
  const second = store.getUserProfile(userId, 2);
  assert.equal((await request('/api/profiles/1/settings', { method: 'PUT', body: { intervalMinutes: 4, messages: 'Perfil um', expectedVersion: first.config.version } })).status, 200);
  assert.equal((await request('/api/profiles/2/messages', { method: 'PUT', body: { messages: ['Perfil dois A', 'Perfil dois B'], expectedVersion: second.config.version } })).status, 200);
  assert.equal(store.getUserProfile(userId, 1).config.messages, 'Perfil um');
  assert.equal(store.getUserProfile(userId, 2).config.messages, 'Perfil dois A\nPerfil dois B');
  assert.equal(store.getUserProfile(userId, 3).config.messages, '');
  store.appendLog(store.getUserProfile(userId, 1), 'test', 'somente um');
  store.appendLog(store.getUserProfile(userId, 2), 'test', 'somente dois');
  assert.ok(store.logs(userId, 1).some(entry => entry.message === 'somente um'));
  assert.ok(!store.logs(userId, 1).some(entry => entry.message === 'somente dois'));
  assert.equal((await request('/api/profiles/4')).status, 400);
});

test('alterar identidade do Perfil 2 não remove OAuth dos Perfis 1 e 3', async () => {
  for (const number of [1, 2, 3]) store.updateUserProfile(userId, number, profile => {
    profile.oauth.refreshTokenEnc = security.encryptText(`token-${number}`);
    profile.oauth.email = `google${number}@example.invalid`;
  });
  const originalRevoke = youtube.revoke;
  youtube.revoke = async () => {};
  try {
    const result = await request(`/dbmadmin/api/users/${userId}/profiles/2`, { admin: true, method: 'PATCH', body: { googleEmail: 'novo2@example.invalid' } });
    assert.equal(result.status, 200);
  } finally { youtube.revoke = originalRevoke; }
  assert.ok(store.getUserProfile(userId, 1).oauth.refreshTokenEnc);
  assert.equal(store.getUserProfile(userId, 2).oauth.refreshTokenEnc, '');
  assert.ok(store.getUserProfile(userId, 3).oauth.refreshTokenEnc);
});

test('normalizador rejeita vídeo e unifica metadados do canal', () => {
  assert.equal(normalizeChannelInput(' youtube.com/@Canal/streams?x=1 ').canonicalUrl, 'https://www.youtube.com/@Canal');
  assert.throws(() => normalizeChannelInput('https://youtube.com/watch?v=AAAAAAAAAAA'), /vídeo/i);
  assert.throws(() => normalizeChannelInput('https://evil.invalid/@Canal'), /youtube\.com/i);
  const normalized = normalizeChannelInput('https://youtube.com/c/CanalAntigo/videos');
  const metadata = extractChannelMetadata('<meta itemprop="channelId" content="UC1234567890123456789012"><link rel="canonical" href="https://www.youtube.com/@CanalNovo"><meta property="og:title" content="Canal Novo">', normalized);
  assert.equal(metadata.channelId, 'UC1234567890123456789012');
  assert.equal(metadata.handle, '@CanalNovo');
  assert.equal(metadata.canonicalUrl, 'https://www.youtube.com/@CanalNovo');
});

test('registro global deduplica canal entre usuários e perfis', () => {
  const other = store.createUser({ id: store.id('usr'), username: 'Outro usuário', active: true, sessionVersion: 1 });
  const first = store.upsertGlobalChannel({ channelId: 'UC1234567890123456789012', handle: '@CanalUnico', canonicalUrl: 'https://www.youtube.com/@CanalUnico', displayName: 'Canal Único', originalInput: '@CanalUnico' });
  store.subscribeChannel(userId, 1, first, '@CanalUnico');
  const same = store.upsertGlobalChannel({ channelId: 'UC1234567890123456789012', handle: '@canalunico', canonicalUrl: 'https://www.youtube.com/@canalunico', displayName: 'Canal Único', originalInput: 'link alternativo' });
  const secondSubscription = store.subscribeChannel(other.id, 2, same, 'https://youtube.com/channel/UC1234567890123456789012');
  assert.equal(first.id, same.id);
  assert.equal(store.globalChannels(true).filter(channel => channel.channel_id === first.channel_id).length, 1);
  const firstSubscription = store.profileChannels(userId, 1).find(channel => channel.globalChannelId === first.id);
  assert.ok(store.removeSubscription(userId, 1, firstSubscription.id));
  assert.ok(store.globalChannels(true).some(channel => channel.id === first.id));
  assert.ok(store.removeSubscription(other.id, 2, secondSubscription.id));
  assert.ok(!store.globalChannels(true).some(channel => channel.id === first.id));
});

test('descoberta HTTP prioriza live e separa o estado do chat', () => {
  const initial = { contents: [{ videoRenderer: { videoId: 'AAAAAAAAAAA', title: { simpleText: 'Programada' }, upcomingEventData: { startTime: '2000000000' } } }, { videoRenderer: { videoId: 'BBBBBBBBBBB', title: { simpleText: 'Ao vivo' }, badges: [{ label: 'LIVE' }] } }] };
  const candidates = discovery.extractCandidatesFromStreams(`<script>var ytInitialData = ${JSON.stringify(initial)};</script>`);
  assert.deepEqual(candidates.map(candidate => candidate.videoId), ['BBBBBBBBBBB', 'AAAAAAAAAAA']);
  const player = { videoDetails: { videoId: 'BBBBBBBBBBB', title: 'Ao vivo', isLive: true, isLiveContent: true }, microformat: { playerMicroformatRenderer: { liveBroadcastDetails: { isLiveNow: true, startTimestamp: '2026-09-06T10:00:00Z' } } } };
  const data = { liveChatRenderer: { continuations: [] } };
  const state = discovery.resolveLiveState(`ytInitialPlayerResponse = ${JSON.stringify(player)}; ytInitialData = ${JSON.stringify(data)};`, { videoId: 'BBBBBBBBBBB', hintEnded: true });
  assert.equal(state.liveStatus, 'LIVE');
  assert.equal(state.chatStatus, 'AVAILABLE');
  assert.equal(state.confirmedActive, true);
});

test('descoberta HTTP reconhece lockupViewModel atual e não perde live após programadas', () => {
  const lockup = (videoId, badge, detail) => ({ richItemRenderer: { content: { lockupViewModel: {
    contentId: videoId,
    contentType: 'LOCKUP_CONTENT_TYPE_VIDEO',
    contentImage: { thumbnailViewModel: { overlays: [{ thumbnailBottomOverlayViewModel: { badges: [{ thumbnailBadgeViewModel: { text: badge, badgeStyle: badge === 'AO VIVO' ? 'THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE' : 'THUMBNAIL_OVERLAY_BADGE_STYLE_DEFAULT' } }] } }] } },
    metadata: { lockupMetadataViewModel: { title: { content: `Vídeo ${videoId}` }, metadata: { contentMetadataViewModel: { metadataRows: [{ metadataParts: [{ text: { content: detail } }] }] } } } }
  } } } });
  const initial = { contents: { richGridRenderer: { contents: [
    lockup('CCCCCCCCCCC', 'Em breve', 'Programado para amanhã'),
    lockup('DDDDDDDDDDD', 'Em breve', 'Programado para depois'),
    lockup('EEEEEEEEEEE', 'Em breve', 'Programado para outra data'),
    lockup('FFFFFFFFFFF', 'Em breve', 'Programado para o mês que vem'),
    lockup('GGGGGGGGGGG', 'AO VIVO', '1,2 mil assistindo'),
    lockup('HHHHHHHHHHH', '', 'Transmitido há 2 horas')
  ] } } };
  const candidates = discovery.extractCandidatesFromStreams(`ytInitialData = ${JSON.stringify(initial)};`);
  assert.deepEqual(candidates.map(candidate => candidate.videoId), ['GGGGGGGGGGG', 'CCCCCCCCCCC', 'DDDDDDDDDDD']);
  assert.equal(candidates[0].hintLive, true);
  assert.equal(candidates[1].hintScheduled, true);
  assert.ok(candidates.every(candidate => !candidate.hintEnded));
});

test('página programada não vira encerrada por conter LIVE_STREAM_OFFLINE', () => {
  const player = {
    playabilityStatus: { status: 'LIVE_STREAM_OFFLINE', reason: 'A transmissão começará em breve' },
    videoDetails: { videoId: 'IIIIIIIIIII', title: 'Programada', isLiveContent: true },
    microformat: { playerMicroformatRenderer: { liveBroadcastDetails: { startTimestamp: '2033-05-18T03:33:20Z' } } },
    liveStreamOfflineSlateRenderer: { scheduledStartTime: '2000000000' }
  };
  const data = { liveChatRenderer: { continuations: [] } };
  const state = discovery.resolveLiveState(`ytInitialPlayerResponse = ${JSON.stringify(player)}; ytInitialData = ${JSON.stringify(data)};`, { videoId: 'IIIIIIIIIII', hintScheduled: true }, Date.parse('2033-05-17T00:00:00Z'));
  assert.equal(state.liveStatus, 'SCHEDULED');
  assert.equal(state.chatStatus, 'AVAILABLE');
  assert.equal(state.confirmedActive, true);
});

test('grade preenchida em formato desconhecido gera erro em vez de falso zero', () => {
  const initial = { contents: { richGridRenderer: { contents: [{ richItemRenderer: { content: { futureVideoModel: { id: 'JJJJJJJJJJJ' } } } }] } } };
  assert.throws(() => discovery.extractCandidatesFromStreams(`ytInitialData = ${JSON.stringify(initial)};`), /formato.*não reconhece/i);
});

test('monitor global não sobrepõe ciclos e distribui uma descoberta', async () => {
  const channel = store.upsertGlobalChannel({ channelId: 'UC9999999999999999999999', handle: '@MonitorTeste', canonicalUrl: 'https://www.youtube.com/@MonitorTeste', displayName: 'Monitor Teste', originalInput: '@MonitorTeste' });
  const subscription1 = store.subscribeChannel(userId, 1, channel, '@MonitorTeste');
  const subscription2 = store.subscribeChannel(userId, 2, channel, '@MonitorTeste');
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  let calls = 0;
  const monitor = createGlobalMonitor({
    discover: async current => {
      calls++;
      await gate;
      return { channelMetadata: { channelId: current.channel_id, handle: current.handle, canonicalUrl: current.canonical_url, displayName: current.display_name }, lives: [{ videoId: 'CCCCCCCCCCC', title: 'Live programada', liveStatus: 'SCHEDULED', chatStatus: 'AVAILABLE', scheduledStartTime: '2026-09-07T10:00:00Z', resolved: true }] };
    }
  });
  const firstScan = monitor.scan({ manual: true });
  await new Promise(resolve => setImmediate(resolve));
  const overlapping = await monitor.scan({ manual: true });
  assert.equal(overlapping.skipped, true);
  release();
  const completed = await firstScan;
  assert.equal(completed.ok, true);
  assert.equal(calls, 1);
  assert.equal(store.getGlobalLiveByVideo('CCCCCCCCCCC').live_status, 'SCHEDULED');
  assert.equal(store.profileLiveStates(userId, 1).find(live => live.videoId === 'CCCCCCCCCCC').sendStatus, 'WAITING');
  assert.equal(store.profileLiveStates(userId, 2).find(live => live.videoId === 'CCCCCCCCCCC').sendStatus, 'WAITING');
  store.removeSubscription(userId, 1, subscription1.id);
  store.removeSubscription(userId, 2, subscription2.id);
});

test('falha em um canal não impede os outros canais no mesmo ciclo', async () => {
  const failing = store.upsertGlobalChannel({ channelId: 'UC7777777777777777777777', handle: '@CanalComErro', canonicalUrl: 'https://www.youtube.com/@CanalComErro', displayName: 'Canal com erro', originalInput: '@CanalComErro' });
  const healthy = store.upsertGlobalChannel({ channelId: 'UC6666666666666666666666', handle: '@CanalSaudavel', canonicalUrl: 'https://www.youtube.com/@CanalSaudavel', displayName: 'Canal saudável', originalInput: '@CanalSaudavel' });
  const failingSubscription = store.subscribeChannel(userId, 3, failing, failing.handle);
  const healthySubscription = store.subscribeChannel(userId, 3, healthy, healthy.handle);
  const monitor = createGlobalMonitor({
    discover: async channel => {
      if (channel.id === failing.id) throw new Error('falha temporária simulada');
      return { lives: [{ videoId: 'HHHHHHHHHHH', title: 'Live saudável', liveStatus: 'SCHEDULED', chatStatus: 'UNAVAILABLE', resolved: true }] };
    }
  });
  const result = await monitor.scan();
  assert.equal(result.ok, true);
  assert.equal(result.errors.length, 1);
  assert.equal(store.getGlobalLiveByVideo('HHHHHHHHHHH').live_status, 'SCHEDULED');
  assert.equal(store.profileLiveStates(userId, 3).some(live => live.videoId === 'HHHHHHHHHHH'), false);
  assert.match(store.globalChannels(false).find(channel => channel.id === failing.id).last_error, /simulada/);
  store.removeSubscription(userId, 3, failingSubscription.id);
  store.removeSubscription(userId, 3, healthySubscription.id);
});

test('encerramento usa janela de cinco minutos e não reativa live antiga', () => {
  const channel = store.upsertGlobalChannel({ channelId: 'UC8888888888888888888888', handle: '@FinalTeste', canonicalUrl: 'https://www.youtube.com/@FinalTeste', displayName: 'Final Teste', originalInput: '@FinalTeste' });
  const subscription = store.subscribeChannel(userId, 1, channel, '@FinalTeste');
  const live = store.upsertGlobalLive(channel.id, { videoId: 'DDDDDDDDDDD', title: 'Final', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', actualStartTime: '2026-09-06T10:00:00Z', resolved: true }).live;
  store.distributeLive(live.id);
  const endedAt = new Date(Date.now() - 1000).toISOString();
  store.upsertGlobalLive(channel.id, { videoId: 'DDDDDDDDDDD', title: 'Final', liveStatus: 'ENDED', chatStatus: 'ENDED', actualEndTime: endedAt, resolved: true });
  store.transitionLiveEnded(live.id);
  let state = store.profileLiveStates(userId, 1).find(item => item.videoId === 'DDDDDDDDDDD');
  assert.equal(state.sendStatus, 'FINISHING');
  store.finalizeExpiredLives(Date.parse(endedAt) + 299999);
  state = store.profileLiveStates(userId, 1).find(item => item.videoId === 'DDDDDDDDDDD');
  assert.equal(state.sendStatus, 'FINISHING');
  store.finalizeExpiredLives(Date.parse(endedAt) + 300001);
  state = store.profileLiveStates(userId, 1).find(item => item.videoId === 'DDDDDDDDDDD');
  assert.equal(state.sendStatus, 'FINALIZED');
  const old = store.upsertGlobalLive(channel.id, { videoId: 'DDDDDDDDDDD', title: 'Sinal antigo', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  assert.equal(old.live_status, 'ENDED');
  assert.ok(old.finalized_at);

  const falsePositive = store.upsertGlobalLive(channel.id, { videoId: 'KKKKKKKKKKK', title: 'Falso encerramento', liveStatus: 'ENDED', chatStatus: 'ENDED', resolved: true }).live;
  assert.ok(falsePositive.finalized_at);
  const recovered = store.upsertGlobalLive(channel.id, { videoId: 'KKKKKKKKKKK', title: 'Confirmada ao vivo', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', actualStartTime: '2026-09-06T10:00:00Z', resolved: true, confirmedActive: true }).live;
  assert.equal(recovered.live_status, 'LIVE');
  assert.equal(recovered.chat_status, 'AVAILABLE');
  assert.equal(recovered.finalized_at, null);
  store.distributeLive(recovered.id);
  assert.notEqual(store.profileLiveStates(userId, 1).find(item => item.videoId === 'KKKKKKKKKKK').sendStatus, 'FINALIZED');
  store.removeSubscription(userId, 1, subscription.id);
});

test('workers enviam com credenciais próprias e parar um perfil não altera outro', async () => {
  const workerUser = store.createUser({ id: store.id('usr'), username: 'Worker teste', active: true, sessionVersion: 1 });
  for (const number of [1, 2]) store.updateUserProfile(workerUser.id, number, profile => {
    profile.api = { clientId: `${number}23-worker.apps.googleusercontent.com`, clientSecretEnc: security.encryptText(`secret-${number}`), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText(`refresh-${number}`);
    profile.config.liveUrl = number === 1 ? 'EEEEEEEEEEE' : 'FFFFFFFFFFF';
    profile.config.messages = `Mensagem perfil ${number}`;
    profile.runtime.status = 'running';
  });
  const sent = [];
  const worker = createWorkers({
    api: {
      getActiveLiveChatId: async (profile, api, videoId) => `CHAT-${profile.profileNumber}-${api.clientId.slice(0, 1)}-${videoId}`,
      sendLiveChatMessage: async (profile, _api, chatId, message, options) => { options.beforeSend(); sent.push({ profile: profile.profileNumber, chatId, message }); }
    }
  });
  await worker.step(workerUser.id, 1);
  await worker.step(workerUser.id, 2);
  assert.deepEqual(sent.map(item => item.profile), [1, 2]);
  assert.equal(sent[0].message, 'Mensagem perfil 1');
  assert.equal(sent[1].message, 'Mensagem perfil 2');
  worker.stop(workerUser.id, 1);
  assert.equal(store.getUserProfile(workerUser.id, 1).runtime.status, 'stopped');
  assert.equal(store.getUserProfile(workerUser.id, 2).runtime.status, 'running');
  worker.start(workerUser.id, 2);
  worker.start(workerUser.id, 2);
  assert.equal(worker.hasWorker(workerUser.id, 2), true);
  assert.ok(worker.activeCount() <= 1);
  await worker.shutdown();
});

test('modo econômico foi removido e intervalo mínimo é três minutos', () => {
  assert.throws(() => validation.config({ intervalMinutes: 2 }), /3/);
  const output = validation.config({ intervalMinutes: 3, economyMode: true, maxPerHour: 10 });
  assert.deepEqual(output, { intervalMinutes: 3 });
  store.updateUserProfile(userId, 3, profile => {
    profile.config.economyMode = true;
    profile.config.maxPerHour = 5;
  });
  const profile = store.getUserProfile(userId, 3);
  assert.equal('economyMode' in profile.config, false);
  assert.equal('maxPerHour' in profile.config, false);
});

test('somente admin altera intervalo global; usuário apenas consulta', async () => {
  assert.equal((await request('/api/global-monitor/settings')).body.liveDiscoveryIntervalSeconds, 180);
  assert.equal((await request('/api/global-monitor/settings', { method: 'PATCH', body: { liveDiscoveryIntervalSeconds: 240 } })).status, 403);
  const changed = await request('/dbmadmin/api/global-monitor', { admin: true, method: 'PATCH', body: { intervalMinutes: 4 } });
  assert.equal(changed.status, 200);
  assert.equal(changed.body.monitoring.intervalSeconds, 240);
  assert.equal((await request('/api/global-monitor/settings')).body.liveDiscoveryIntervalSeconds, 240);
});

test('validação, criptografia e tipos de sessão permanecem protegidos', () => {
  assert.equal(validation.extractVideoId('https://evil.invalid/?v=AAAAAAAAAAA'), null);
  assert.equal(validation.extractVideoId('https://youtu.be/AAAAAAAAAAA'), 'AAAAAAAAAAA');
  assert.throws(() => validation.username('email@example.com'));
  assert.throws(() => validation.config({ messages: 'x'.repeat(201) }));
  assert.throws(() => validation.password('short'));
  const encrypted = security.encryptText('synthetic');
  assert.equal(security.decryptText(encrypted), 'synthetic');
  const parts = encrypted.split('.');
  const tag = Buffer.from(parts[1], 'base64url');
  tag[0] ^= 1;
  parts[1] = tag.toString('base64url');
  assert.throws(() => security.decryptText(parts.join('.')));
  assert.throws(() => security.verifySession(security.signSession('x', 'user', 1).token, 'admin'));
});

test('backup consistente abre e preserva usuários e três perfis', async () => {
  const file = path.join(process.env.DATA_DIR, 'test-backup.sqlite');
  await store.backupTo(file);
  const { DatabaseSync } = require('node:sqlite');
  const copy = new DatabaseSync(file, { readOnly: true });
  assert.equal(copy.prepare('SELECT COUNT(*) AS n FROM users').get().n, store.users().length);
  assert.equal(copy.prepare('SELECT COUNT(*) AS n FROM user_profiles WHERE user_id=?').get(userId).n, 3);
  assert.equal(Object.values(copy.prepare('PRAGMA quick_check').get())[0], 'ok');
  copy.close();
});

test('migration V2.1 preserva dados no Perfil 1 e cria Perfis 2 e 3', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'auto-server-migrate-'));
  const file = path.join(directory, 'peralta.sqlite');
  const { DatabaseSync } = require('node:sqlite');
  const old = new DatabaseSync(file);
  old.exec('CREATE TABLE profiles(id TEXT PRIMARY KEY,body TEXT NOT NULL); CREATE TABLE users(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE COLLATE NOCASE,body TEXT NOT NULL); CREATE TABLE oauth_states(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,profile_id TEXT NOT NULL,version INTEGER NOT NULL,expires INTEGER NOT NULL); PRAGMA user_version=1;');
  const legacyApi = { id: 'legacy-api', name: 'API antiga', clientId: '123-old.apps.googleusercontent.com', clientSecretEnc: 'encrypted-old', active: true, version: 4 };
  const legacyUser = {
    id: 'existing-user', email: 'saved@example.invalid', googleEmail: 'google@example.invalid', apiProfileId: legacyApi.id, passwordHash: 'hash', active: true, sessionVersion: 1,
    config: { liveUrl: 'GGGGGGGGGGG', intervalMinutes: 5, intervalSeconds: 0, intervalMs: 0, messages: 'Mensagem preservada', version: 7, messageIndex: 1, economyMode: true, maxPerHour: 2 },
    runtime: { status: 'paused', sent: 9, failures: 1, attempts: 10, connectionErrors: 0, lastError: '', nextAt: null, epoch: 3, hourlySends: [1] },
    oauth: { email: 'google@example.invalid', refreshTokenEnc: 'encrypted-refresh', accessTokenEnc: '', accessTokenExpiresAt: 0, scope: '', version: 2 }
  };
  old.prepare('INSERT INTO profiles VALUES(?,?)').run(legacyApi.id, JSON.stringify(legacyApi));
  old.prepare('INSERT INTO users VALUES(?,?,?)').run(legacyUser.id, legacyUser.email, JSON.stringify(legacyUser));
  old.close();
  const code = `const s=require('./lib/store');const u=s.getUser('existing-user'),p=s.userProfiles(u.id),file=s.DB_FILE;s.close();const {DatabaseSync}=require('node:sqlite'),db=new DatabaseSync(file,{readOnly:true}),version=db.prepare('PRAGMA user_version').get().user_version;db.close();console.log(JSON.stringify({username:u.username,count:p.length,messages:p[0].config.messages,minutes:p[0].config.intervalMinutes,oauth:p[0].oauth.refreshTokenEnc,api:p[0].api.clientId,economy:'economyMode' in p[0].config,blank:p[1].config.messages,version}));`;
  const migrated = spawnSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: { ...process.env, DATA_DIR: directory }, encoding: 'utf8' });
  assert.equal(migrated.status, 0, migrated.stderr);
  assert.deepEqual(JSON.parse(migrated.stdout.trim()), { username: 'saved', count: 3, messages: 'Mensagem preservada', minutes: 5, oauth: 'encrypted-refresh', api: legacyApi.clientId, economy: false, blank: '', version: 2 });
  fs.rmSync(directory, { recursive: true, force: true });
});

test('banco corrompido provoca falha sem apagar o arquivo', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'auto-server-corrupt-'));
  const file = path.join(directory, 'peralta.sqlite');
  fs.writeFileSync(file, 'invalid-sqlite');
  const result = spawnSync(process.execPath, ['-e', "require('./lib/store')"], { cwd: path.join(__dirname, '..'), env: { ...process.env, DATA_DIR: directory } });
  assert.notEqual(result.status, 0);
  assert.equal(fs.readFileSync(file, 'utf8'), 'invalid-sqlite');
  fs.rmSync(directory, { recursive: true, force: true });
});

test('tentativas excessivas de login recebem 429', async () => {
  let status;
  for (let index = 0; index < 13; index++) status = (await request('/api/login', { method: 'POST', body: { username: 'Usuário ausente', password: 'wrong', privacyAccepted: true }, bearer: '' })).status;
  assert.equal(status, 429);
});
