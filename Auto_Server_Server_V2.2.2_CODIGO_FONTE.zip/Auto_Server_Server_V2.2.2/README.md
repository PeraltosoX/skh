# Auto Server V2.2.2

Servidor e painel web do Auto Server. A automação roda na VPS: fechar o
aplicativo, sair do painel ou fechar o navegador não interrompe os perfis que
estão em execução.

Esta entrega altera somente o servidor/painel. O projeto Android não faz parte
deste pacote e não foi modificado.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde do serviço: `/health`
- Retorno Google OAuth: `/oauth/google/callback`

## Principais recursos

- Login no Auto Server por **nome de usuário e senha**, sem e-mail ou `@`.
- Exatamente três perfis por usuário.
- Exatamente um canal por perfil: até três canais por conta, um em cada perfil.
- API Google, OAuth, tokens, Conta Google permitida, mensagens, canais,
  intervalos, contadores, logs, status e worker separados por perfil.
- Perfis 1, 2 e 3 podem rodar ao mesmo tempo; iniciar, pausar ou parar um perfil
  não altera os outros.
- Um único monitor global consulta cada canal do YouTube uma vez, mesmo que o
  canal esteja cadastrado em vários usuários ou perfis.
- Cadastro de canal por `@handle`, `/channel/UC...`, `/c/...` ou `/user/...`.
- Até três transmissões recentes são examinadas por canal.
- O formato atual `lockupViewModel` e os formatos antigos da página `/streams`
  são reconhecidos; lives ao vivo têm prioridade mesmo após várias programadas.
- Estados separados para live, chat e execução individual.
- Live programada com chat disponível já pode ser distribuída aos perfis.
- Ao detectar encerramento, a execução entra em finalização por cinco minutos,
  usando o horário real quando disponível.
- Lives finalizadas não são reativadas por resultados antigos. Uma confirmação
  forte do próprio YouTube pode recuperar uma live marcada por engano.
- O modo econômico e o limite de mensagens por hora foram removidos da lógica e
  dos painéis. Campos antigos são apenas aceitos e ignorados para compatibilidade.
- Intervalo entre mensagens configurável em minutos e segundos.
- Menor intervalo permitido: 0 minuto e 1 segundo; segundos nunca ficam em zero.
- Novos perfis começam em 3 minutos e 1 segundo.
- O administrador controla o intervalo da busca global (padrão: três minutos)
  e a espera para consultar novamente um chat ainda indisponível (padrão: 120
  segundos; faixa de 15 a 3600 segundos).
- Seletor de Conta Google sempre aberto com `select_account`, sem `login_hint`.
- Client Secret, refresh token e access token nunca são retornados pelos painéis.
- Credenciais e tokens são criptografados com AES-256-GCM.
- SQLite persistente, cookies HttpOnly/SameSite, CSRF, validação de origem,
  auditoria e retomada dos workers após reinício.

## Alterações da V2.2.2

- Quando uma live já foi encontrada, mas o `activeLiveChatId` ainda não está
  disponível, a nova consulta à YouTube Data API ocorre após 120 segundos por
  padrão. A V2.2.1 repetia essa consulta após 15 segundos.
- O administrador pode mudar essa espera globalmente entre 15 e 3600 segundos
  em `/dbmadmin`. O valor fica salvo no banco e é aplicado aos perfis.
- A espera local sem nenhuma live continua em 15 segundos e não usa cota da
  YouTube Data API.
- Cada Perfil 1, 2 ou 3 aceita no máximo um canal. O servidor, o painel e as
  rotas da API aplicam o limite; para trocar pelo painel, remova o atual antes.
- O intervalo de mensagens agora aparece em campos separados de minutos e
  segundos. O menor valor é 0 minuto e 1 segundo, e um zero recebido no campo
  de segundos é normalizado para 1 por compatibilidade.

O monitor global de novas lives continua separado, com padrão de três minutos.
Não há mudança de schema entre V2.2.1 e V2.2.2; o mesmo `.env` e a mesma pasta
`data/` são preservados pelo atualizador.

Consulte `CHANGELOG_V2.2.2.txt` para a descrição completa desta entrega.

## Correção preservada da V2.2.1

A V2.2.0 deixou de encontrar transmissões quando o YouTube passou a entregar os
itens da aba `/streams` como `lockupViewModel`. Esta versão aceita os dois
formatos, prioriza a live atual antes de programadas/encerradas e corrige a
classificação de páginas `LIVE_STREAM_OFFLINE`, que também é usada pelo YouTube
para transmissões programadas. Se o site apresentar novamente uma grade
preenchida em um formato desconhecido, o monitor registra erro em vez de
informar falsamente `Candidatas: 0`.

Essa correção permanece integralmente incluída na V2.2.2.

## Compatibilidade com a versão anterior

As rotas históricas usadas pelo Android (`/api/state`, `/api/config`,
`/api/control/...` e `/api/oauth/...`) continuam disponíveis e apontam para o
Perfil 1. O campo JSON antigo chamado `email` no login também pode transportar o
novo nome de usuário, mas autenticação por endereço de e-mail não é mais aceita.

## Migration automática da V2.1.1

Na primeira inicialização com o banco anterior, o servidor faz uma migration
incremental e transacional:

1. preserva o usuário, senha, sessões, logs e tabelas antigas;
2. gera o nome de usuário a partir da parte anterior ao `@` do e-mail antigo;
3. cria exatamente os Perfis 1, 2 e 3;
4. copia API, OAuth, mensagens, configuração, contadores e execução atuais para
   o Perfil 1;
5. cria Perfis 2 e 3 vazios, com intervalo padrão de 3 minutos e 1 segundo;
6. cria as tabelas de canais, lives, vínculos, estados e monitor global;
7. remove modo econômico/limite por hora da configuração migrada.

Se dois e-mails antigos gerarem o mesmo nome, o segundo recebe um sufixo
numérico. Confira os nomes em `/dbmadmin` após atualizar e ajuste-os se desejar.

O banco permanece em `data/peralta.sqlite`. A pasta `data/` e o arquivo `.env`
formam um conjunto: sem a mesma `APP_ENCRYPTION_KEY`, as autorizações Google
existentes não podem ser descriptografadas.

Use `ATUALIZAR_SEM_PERDER_DADOS.sh`; ele para a versão anterior, cria backup,
copia `.env` e `data/`, inicia a V2.2.2, testa `/health` e religa automaticamente
a versão indicada no comando se houver falha. Nunca extraia a nova versão por
cima da antiga.

## Google OAuth por perfil

Cada perfil utiliza um OAuth Client do tipo **Web application**. Cadastre
exatamente esta URI em cada Client ID:

`https://SEU-DOMINIO/oauth/google/callback`

Para cotas realmente independentes, crie os OAuth Clients em projetos Google
Cloud diferentes. Vários Clients no mesmo projeto compartilham a cota do
projeto.

## API de perfis

- `GET /api/profiles`
- `GET /api/profiles/:profileId`
- `GET /api/profiles/:profileId/status`
- `GET|PUT /api/profiles/:profileId/messages`
- `GET|PUT /api/profiles/:profileId/settings`
- `GET|POST|PUT|DELETE /api/profiles/:profileId/channels`
- `POST /api/profiles/:profileId/start|pause|stop`
- `GET|POST /api/profiles/:profileId/oauth/connect`
- `POST /api/profiles/:profileId/oauth/disconnect`
- `GET /api/profiles/:profileId/logs`

O `user_id` é sempre obtido da sessão. Não existe rota de usuário comum que
aceite o ID de outro usuário.

## Desenvolvimento e verificação

Requer Node.js 24.14 ou superior, ainda na linha 24:

```bash
npm ci
npm run check
npm test
npm start
```

Para produção, use o `docker-compose.yml` e os procedimentos em `INSTALAR.txt`
ou `ATUALIZAR_SEM_PERDER_DADOS.txt`.
