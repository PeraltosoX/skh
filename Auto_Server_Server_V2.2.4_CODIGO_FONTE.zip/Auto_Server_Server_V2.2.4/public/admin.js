'use strict';

const $ = id => document.getElementById(id);
const show = (id, on) => $(id).classList.toggle('hidden', !on);
const feedback = (id, message, ok = false) => {
  const element = $(id);
  element.textContent = message || '';
  element.className = `feedback ${message ? ok ? 'ok' : 'err' : ''}`;
};
const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
let csrfToken = '';
let authenticated = false;
let data = { users: [], globalMonitoring: {}, apiUsageToday: {}, profileDefaults: { defaultCount: 3, maxCount: 50 } };
let details = '';

async function api(url, { method = 'GET', body } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
    const response = await fetch(url, { method, body: body === undefined ? undefined : JSON.stringify(body), headers, credentials: 'same-origin', signal: controller.signal });
    let result;
    try { result = await response.json(); }
    catch { throw new Error(`Resposta inválida (HTTP ${response.status}). Confira a URL e o proxy do servidor.`); }
    if (!response.ok || result.ok !== true) {
      if (response.status === 401 && authenticated) {
        authenticated = false;
        csrfToken = '';
        show('dashboard', false);
        show('login', true);
        show('logout', false);
      }
      throw new Error(result.error || `HTTP ${response.status}`);
    }
    return result;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Tempo esgotado. Verifique o servidor e tente novamente.');
    throw error;
  } finally { clearTimeout(timer); }
}

async function bootstrap(expectSession = false) {
  const bootstrapData = await api('/dbmadmin/api/bootstrap');
  authenticated = bootstrapData.authenticated;
  csrfToken = bootstrapData.csrfToken || '';
  show('setup', bootstrapData.needsSetup);
  show('login', !bootstrapData.needsSetup && !bootstrapData.authenticated);
  show('dashboard', bootstrapData.authenticated);
  show('logout', bootstrapData.authenticated);
  if (expectSession && !bootstrapData.authenticated) throw new Error('Senha aceita, mas a sessão não foi mantida. Confira o domínio HTTPS e os cookies.');
  if (authenticated) await loadData();
}

function bindForm(id, feedbackId, action) {
  $(id).addEventListener('submit', async event => {
    event.preventDefault();
    const button = $(id).querySelector('button[type="submit"],button:not([type])');
    const label = button.textContent;
    button.disabled = true;
    button.textContent = 'AGUARDE…';
    feedback(feedbackId, '');
    try { await action(); }
    catch (error) { feedback(feedbackId, error.message); }
    finally { button.disabled = false; button.textContent = label; }
  });
}

bindForm('setupForm', 'setupFb', async () => {
  await api('/dbmadmin/api/setup', { method: 'POST', body: { setupToken: $('setupToken').value, username: $('setupUser').value, password: $('setupPass').value } });
  await bootstrap(true);
  $('setupForm').reset();
});
bindForm('loginForm', 'loginFb', async () => {
  await api('/dbmadmin/api/login', { method: 'POST', body: { username: $('loginUser').value, password: $('loginPass').value } });
  await bootstrap(true);
  $('loginPass').value = '';
  feedback('globalFb', '');
});

$('logout').addEventListener('click', async () => {
  try { await api('/dbmadmin/api/logout', { method: 'POST', body: {} }); }
  catch (error) { feedback('globalFb', error.message); }
  finally {
    csrfToken = '';
    authenticated = false;
    await bootstrap().catch(error => feedback('globalFb', error.message));
  }
});

function resetUser() {
  $('userForm').reset();
  $('userId').value = '';
  $('userTitle').textContent = 'Novo usuário';
  $('userActive').value = 'true';
}

function resetProfile() {
  $('profileForm').reset();
  $('profileUserId').value = '';
  $('profileNumber').value = '';
  show('profileEditor', false);
}

$('cancelUser').addEventListener('click', resetUser);
$('cancelProfile').addEventListener('click', resetProfile);

bindForm('userForm', 'userFb', async () => {
  const id = $('userId').value;
  const body = { username: $('username').value.trim(), password: $('userPass').value, active: $('userActive').value === 'true' };
  if (!id && !body.password) throw new Error('Informe a senha inicial.');
  await api(`/dbmadmin/api/users${id ? `/${encodeURIComponent(id)}` : ''}`, { method: id ? 'PATCH' : 'POST', body });
  resetUser();
  await loadData();
  feedback('userFb', id ? 'Usuário atualizado.' : 'Usuário criado com três perfis.', true);
});

bindForm('profileForm', 'profileFb', async () => {
  const userId = $('profileUserId').value;
  const number = Number($('profileNumber').value);
  const body = {
    name: $('profileName').value,
    enabled: $('profileEnabled').value === 'true',
    googleEmail: $('profileGoogleEmail').value.trim(),
    clientId: $('clearCredentials').checked ? '' : $('profileClientId').value.trim(),
    clientSecret: $('clearCredentials').checked ? '' : $('profileClientSecret').value,
    clearCredentials: $('clearCredentials').checked
  };
  if ((body.clientSecret || body.clearCredentials || data.users.find(user => user.id === userId)?.profiles.find(profile => profile.profileId === number)?.googleEmail !== body.googleEmail) && !confirm(`Alterações de API/Conta Google desconectam somente o Perfil ${number}. Continuar?`)) return;
  await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles/${number}`, { method: 'PATCH', body });
  resetProfile();
  await loadData();
  feedback('globalFb', `Perfil ${number} atualizado.`, true);
});

bindForm('monitorForm', 'monitorFb', async () => {
  const result = await api('/dbmadmin/api/global-monitor', {
    method: 'PATCH',
    body: {
      intervalMinutes: Number($('monitorMinutes').value),
      chatAvailabilityRetrySeconds: Number($('chatRetrySeconds').value)
    }
  });
  renderMonitor(result.monitoring);
  feedback('monitorFb', 'Configurações globais salvas.', true);
});

bindForm('passwordForm', 'passwordFb', async () => {
  await api('/dbmadmin/api/password', { method: 'POST', body: { currentPassword: $('oldAdminPass').value, password: $('newAdminPass').value } });
  $('passwordForm').reset();
  await bootstrap();
  feedback('loginFb', 'Senha alterada. Entre novamente.', true);
});

function statusName(status) { return status === 'running' ? 'RODANDO' : status === 'paused' ? 'PAUSADO' : 'PARADO'; }
function dateTime(value) { return value ? new Date(value).toLocaleString() : '—'; }

function renderMonitor(monitoring = {}) {
  $('monitorMinutes').value = Math.max(1, Math.round((monitoring.intervalSeconds || 180) / 60));
  $('chatRetrySeconds').value = monitoring.chatAvailabilityRetrySeconds || 120;
  $('monitorLast').textContent = dateTime(monitoring.lastGlobalScanAt);
  $('monitorNext').textContent = dateTime(monitoring.nextGlobalScanAt);
  $('monitorDuration').textContent = `${monitoring.globalScanDurationMs || 0} ms`;
  $('monitorChatRetry').textContent = `${monitoring.chatAvailabilityRetrySeconds || 120} s`;
  $('monitorChannels').textContent = monitoring.globalChannelsActive || 0;
  $('monitorScheduled').textContent = monitoring.scheduledLivesCount || 0;
  $('monitorLive').textContent = monitoring.liveLivesCount || 0;
  $('apiRequestsToday').textContent = data.apiUsageToday?.requests || 0;
  $('apiLookupsToday').textContent = data.apiUsageToday?.videosList || 0;
  $('apiInsertsToday').textContent = data.apiUsageToday?.liveChatInsert || 0;
  $('apiFailuresToday').textContent = data.apiUsageToday?.failures || 0;
  $('monitorError').textContent = monitoring.lastGlobalScanError || '';
  show('monitorError', !!monitoring.lastGlobalScanError);
}

function renderUsers(users) {
  $('userCount').textContent = `${users.length} ${users.length === 1 ? 'usuário' : 'usuários'}`;
  $('users').innerHTML = users.map(user => {
    const maxProfiles = data.profileDefaults?.maxCount || 50;
    const atProfileLimit = user.profiles.length >= maxProfiles;
    const profiles = user.profiles.map(profile => `<article class="profile-summary"><div class="profile-head"><div><b>${esc(profile.name)}</b><span class="badge ${profile.status === 'running' ? 'green' : profile.status === 'paused' ? 'yellow' : ''}">${statusName(profile.status)}</span></div><span class="badge ${profile.enabled ? 'green' : 'red'}">${profile.enabled ? 'HABILITADO' : 'DESABILITADO'}</span></div><div class="meta">API: ${profile.apiConfigured ? 'configurada' : 'não configurada'}<br>Google permitido: ${esc(profile.googleEmail || 'livre / não definido')}<br>YouTube: ${profile.oauthConnected ? `conectado • ${esc(profile.oauthEmail)}` : 'não conectado'}<br>Enviadas: ${profile.sent} • Falhas: ${profile.failures} • Chats: ${profile.activeChats || 0}<br>Solicitações API hoje: ${profile.apiUsageToday?.requests || 0}${profile.lastError ? `<br><span class="error-inline">${esc(profile.lastError)}</span>` : ''}</div><div class="actions"><button data-action="profile-edit" data-user-id="${esc(user.id)}" data-profile="${profile.profileId}">CONFIGURAR</button><button class="ghost" data-action="profile-logs" data-user-id="${esc(user.id)}" data-profile="${profile.profileId}">LOGS</button></div></article>`).join('');
    return `<section class="user-card"><div class="user-head"><div><h3>${esc(user.username)}</h3><span class="badge ${user.active ? 'green' : 'red'}">${user.active ? 'ATIVO' : 'BLOQUEADO'}</span><span class="meta">${user.profiles.length} perfis</span></div><div class="actions"><button data-action="profile-add" data-user-id="${esc(user.id)}" ${atProfileLimit ? 'disabled' : ''}>+ ADICIONAR PERFIL</button><button data-action="user-edit" data-user-id="${esc(user.id)}">EDITAR USUÁRIO</button><button class="ghost" data-action="user-toggle" data-user-id="${esc(user.id)}">${user.active ? 'BLOQUEAR' : 'ATIVAR'}</button><button class="ghost" data-action="user-revoke" data-user-id="${esc(user.id)}">ENCERRAR SESSÕES</button><button class="danger" data-action="user-delete" data-user-id="${esc(user.id)}">EXCLUIR</button></div></div><div class="profile-grid">${profiles}</div></section>`;
  }).join('') || '<p>Nenhum usuário cadastrado.</p>';
}

async function loadData() {
  data = await api('/dbmadmin/api/data');
  renderMonitor(data.globalMonitoring);
  renderUsers(data.users);
  $('updatedAt').textContent = `Atualizado às ${new Date().toLocaleTimeString()}`;
}

function editProfile(userId, number) {
  const user = data.users.find(item => item.id === userId);
  const profile = user?.profiles.find(item => item.profileId === number);
  if (!user || !profile) return;
  $('profileUserId').value = user.id;
  $('profileNumber').value = String(number);
  $('profileName').value = profile.name;
  $('profileGoogleEmail').value = profile.googleEmail || '';
  $('profileClientId').value = profile.clientId || '';
  $('profileClientSecret').value = '';
  $('profileEnabled').value = String(profile.enabled);
  $('clearCredentials').checked = false;
  $('profileEditorTitle').textContent = `${user.username} • Perfil ${number}`;
  show('profileEditor', true);
  $('profileEditor').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

document.addEventListener('click', async event => {
  const button = event.target.closest('button[data-action]');
  if (!button) return;
  const userId = button.dataset.userId;
  const action = button.dataset.action;
  const number = Number(button.dataset.profile);
  button.disabled = true;
  try {
    if (action === 'profile-add') {
      const user = data.users.find(item => item.id === userId);
      const nextNumber = Math.max(...user.profiles.map(profile => profile.profileId)) + 1;
      if (!confirm(`Adicionar o Perfil ${nextNumber} para ${user.username}? Será criado somente um perfil novo.`)) return;
      const result = await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles`, { method: 'POST', body: {} });
      await loadData();
      feedback('globalFb', `Perfil ${result.profile.profileId} adicionado para ${user.username}.`, true);
    }
    if (action === 'profile-edit') editProfile(userId, number);
    if (action === 'profile-logs') {
      const result = await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/logs?profileId=${number}`);
      showDetails(`Últimos registros • Perfil ${number}`, result.logs, true);
    }
    if (action === 'user-edit') {
      const user = data.users.find(item => item.id === userId);
      $('userId').value = user.id;
      $('username').value = user.username;
      $('userPass').value = '';
      $('userActive').value = String(user.active);
      $('userTitle').textContent = 'Editar usuário';
      $('userForm').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    if (action === 'user-toggle') {
      const user = data.users.find(item => item.id === userId);
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}`, { method: 'PATCH', body: { active: !user.active } });
      await loadData();
    }
    if (action === 'user-revoke' && confirm('Encerrar as sessões deste usuário? Os perfis em execução continuam.')) {
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/revoke`, { method: 'POST', body: {} });
      feedback('globalFb', 'Sessões encerradas.', true);
    }
    if (action === 'user-delete' && confirm('Excluir o usuário, todos os perfis, canais, configurações e histórico?')) {
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}`, { method: 'DELETE', body: {} });
      await loadData();
    }
  } catch (error) { feedback('globalFb', error.message); }
  finally { button.disabled = false; }
});

function showDetails(title, value, download = false) {
  details = JSON.stringify(value, null, 2);
  $('detailsTitle').textContent = title;
  $('detailsText').textContent = details;
  show('detailsPanel', true);
  show('downloadDetails', download);
  $('detailsPanel').scrollIntoView({ behavior: 'smooth' });
}

$('scanNow').addEventListener('click', async () => {
  $('scanNow').disabled = true;
  try {
    const result = await api('/dbmadmin/api/global-monitor/scan', { method: 'POST', body: {} });
    feedback('monitorFb', result.started ? 'Busca global iniciada.' : 'Já existe uma busca global em andamento.', true);
    setTimeout(() => loadData().catch(error => feedback('globalFb', error.message)), 1800);
  } catch (error) { feedback('monitorFb', error.message); }
  finally { $('scanNow').disabled = false; }
});
$('refreshBtn').addEventListener('click', () => loadData().catch(error => feedback('globalFb', error.message)));
$('diagBtn').addEventListener('click', () => api('/dbmadmin/api/diagnostics').then(result => showDetails('Diagnóstico', result)).catch(error => feedback('globalFb', error.message)));
$('eventsBtn').addEventListener('click', () => api('/dbmadmin/api/global-monitor/events').then(result => showDetails('Eventos do monitor global', result.events, true)).catch(error => feedback('globalFb', error.message)));
$('auditBtn').addEventListener('click', () => api('/dbmadmin/api/audit').then(result => showDetails('Auditoria administrativa', result.events, true)).catch(error => feedback('globalFb', error.message)));
$('downloadDetails').addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob([details], { type: 'application/json' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'Auto_Server_Registros.json';
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

setInterval(() => { if (authenticated && document.visibilityState === 'visible') loadData().catch(error => feedback('globalFb', error.message)); }, 30000);
bootstrap().catch(error => feedback('globalFb', error.message));
