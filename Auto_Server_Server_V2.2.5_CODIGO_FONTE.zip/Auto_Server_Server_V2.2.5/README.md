# Auto Server V2.2.5

Servidor e painel web do Auto Server. A automação permanece na VPS mesmo com o
aplicativo, o painel ou o navegador fechados.

Esta entrega altera somente servidor e painel web. O aplicativo Android não faz
parte deste ZIP.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde: `/health`
- Retorno OAuth: `/oauth/google/callback`

## Perfis e canais

- Cada conta começa com três perfis.
- O administrador pode adicionar um perfil por vez, até 50.
- Os Perfis 1, 2 e 3 são permanentes. Somente perfis adicionais podem ser excluídos pelo administrador.
- Ao excluir um perfil adicional, o menor número livre a partir do 4 é reutilizado na próxima criação.
- Cada perfil aceita exatamente um canal.
- API Google, OAuth, mensagens, intervalo, canal, worker, contadores e logs são
  independentes por perfil.
- Um monitor global consulta um canal apenas uma vez, mesmo quando ele é usado
  por mais de um usuário.

## Descoberta e IDs antigos sem Data API

- A aba pública `/streams` encontra até três transmissões por canal.
- Até quatro IDs antigos são revistos pela página pública `watch?v=...` em cada
  ciclo, sem usar a YouTube Data API.
- Os IDs entram em rotação: depois de conferir quatro, os ainda não conferidos
  passam à frente no ciclo seguinte.
- Um `404 liveChatNotFound` bloqueia imediatamente novos envios, limpa o chat em
  cache e coloca a transmissão em `VERIFYING`.
- Falha de conexão, timeout ou resposta 5xx não marca a live como apagada.
- O número e a data das reverificações públicas ficam no banco e os resultados
  aparecem nos eventos globais.

## Intervalos e lives simultâneas

- PARAR descarta o ciclo de tempo do perfil. Um novo INICIAR deixa o primeiro envio elegível imediatamente e começa a contar somente após o sucesso.
- PAUSAR preserva o ciclo atual. Contadores e posição da lista de mensagens não são zerados ao parar ou iniciar.
- Uma live: usa o intervalo configurado no perfil.
- Duas lives: um envio total a cada 3 minutos, alternando entre elas. Cada live
  recebe uma mensagem aproximadamente a cada 6 minutos.
- Três lives: um envio total a cada 2 minutos e 30 segundos, alternando. Cada
  live recebe uma mensagem aproximadamente a cada 7 minutos e 30 segundos.
- O menor intervalo configurável continua sendo 0 minuto e 1 segundo.
- O antigo campo de milissegundos é aceito para compatibilidade, mas ignorado e
  zerado na migration para não existir atraso oculto.

## Economia da YouTube Data API

- A descoberta e a reverificação usam páginas públicas, não `search.list`.
- O access token é reutilizado até perto do vencimento.
- O `activeLiveChatId` agora é guardado globalmente por vídeo e compartilhado
  entre perfis.
- Consultas simultâneas do mesmo vídeo feitas com a mesma identidade de projeto
  e Conta Google são unificadas em uma única chamada `videos.list`. Identidades
  diferentes ficam isoladas para uma API desativada não pausar outro perfil.
- Se o chat ainda não existe, a espera configurável é gravada na própria live;
  outras lives do perfil continuam funcionando.
- O padrão de nova consulta é 120 segundos. O administrador pode usar de 15 a
  3600 segundos no `/dbmadmin`.
- O ID direto antigo `liveUrl` não é mais usado como fallback. Um perfil precisa
  de um canal cadastrado, evitando consultas infinitas a vídeo apagado.
- O painel do usuário mostra as consultas de chat e tentativas de envio do dia.
  O painel administrativo mostra o total diário do servidor.

Os contadores representam solicitações, não uma estimativa fixa de unidades de
cota. O custo oficial pode mudar e deve ser conferido no Google Cloud Console.

## Isolamento de erros

- Retry e backoff são individuais por live.
- Uma transmissão sem chat, com 429 ou com falha temporária não bloqueia as
  outras lives do perfil.
- O cabeçalho `Retry-After` do Google é respeitado, com limite de uma hora.
- Uma resposta de envio ambígua pausa somente aquela live para evitar mensagem
  duplicada; as demais continuam.
- API desativada, `accessNotConfigured`, permissões insuficientes, OAuth inválido
  e mensagem inválida pausam o perfil com instrução clara.
- Quando a cota diária termina, a nova tentativa é agendada automaticamente para
  depois da virada da cota no horário do Pacífico.
- Uma live só pode ser enviada se ainda estiver `AVAILABLE`, vinculada ao canal
  do perfil e não finalizada.
- Envios do mesmo chat são serializados. Se o primeiro detectar que o chat foi
  apagado, os seguintes são cancelados antes da solicitação.
- Remover ou trocar o canal invalida imediatamente o alvo em andamento.

## Monitor e armazenamento

- Até três canais são consultados em paralelo. Ajuste opcionalmente com
  `GLOBAL_MONITOR_CONCURRENCY` entre 1 e 5.
- As três páginas de vídeo de um canal são resolvidas em paralelo.
- Páginas de consentimento, CAPTCHA ou tráfego incomum geram aviso e não mudam a
  live para encerrada.
- Excluir o último assinante ou o usuário desativa o canal no monitor global.
- Estados finalizados com mais de 180 dias são removidos. Lives finalizadas com
  mais de um ano podem ser limpas, mas as 50 mais recentes de cada canal e todas
  as que estejam em verificação são preservadas.
- Logs de perfil, eventos globais, auditoria e contadores diários possuem
  retenção limitada.

## Segurança e persistência

- Client Secret e tokens nunca são enviados aos painéis.
- Credenciais são criptografadas com AES-256-GCM.
- Cookies HttpOnly/SameSite, CSRF, validação de origem e limite de login
  permanecem ativos.
- OAuth, estado das lives, mensagens, contadores e workers sobrevivem ao reinício.
- Ao trocar realmente para outro e-mail Google, a autorização anterior é
  revogada depois que a nova autorização foi salva.

## Migration automática

A V2.2.5 mantém o schema SQLite 4. A migration continua incremental e transacional:

1. preserva usuários, senhas, perfis, canais, mensagens, OAuth e logs;
2. mantém os três perfis padrão e todos os perfis adicionais;
3. cria cache global do chat e retries individuais por live;
4. cria contadores diários de chamadas da API;
5. adiciona registro e rotação das reverificações públicas;
6. zera somente o antigo campo oculto de milissegundos.

O banco fica em `data/peralta.sqlite`. O arquivo `.env` e a pasta `data/` devem
ser preservados juntos porque `APP_ENCRYPTION_KEY` protege os tokens existentes.

Use `ATUALIZAR_SEM_PERDER_DADOS.sh`. O script cria backup, copia `.env` e
`data/`, inicia a V2.2.5, exige `/health` com schema 4, valida a sintaxe dentro do
contêiner e religa a versão anterior automaticamente se algo falhar.

## Google OAuth por perfil

Cada perfil utiliza um OAuth Client do tipo **Web application**. Cadastre:

`https://SEU-DOMINIO/oauth/google/callback`

Para cotas independentes, use projetos Google Cloud diferentes. Vários Clients
no mesmo projeto compartilham a cota do projeto.

## Desenvolvimento

Requer Node.js 24.14 ou superior na linha 24:

```bash
npm ci
npm run check
npm test
npm start
```

Consulte `CHANGELOG_V2.2.5.txt`, `INSTALAR.txt` e
`ATUALIZAR_SEM_PERDER_DADOS.txt`.
