'use strict';

const $ = id => document.getElementById(id);
const show = (id, on) => $(id).classList.toggle('hidden', !on);
const PROFILE_KEY = 'auto-server-selected-profile';
let csrfToken = '';
let authenticated = false;
let currentState = null;
let currentProfile = Math.min(50, Math.max(1, Number(localStorage.getItem(PROFILE_KEY)) || 1));
let draftVersion = -1;
let dirty = false;
let busy = false;
let serverOffset = 0;

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function feedback(message, ok = false) {
  const element = $('globalFeedback');
  element.textContent = message || '';
  element.className = `feedback ${message && ok ? 'ok' : ''}`;
}

function loginFeedback(message, ok = false) {
  const element = $('loginFeedback');
  element.textContent = message || '';
  element.className = `feedback ${message && ok ? 'ok' : ''}`;
}

function setBusy(on) {
  busy = on;
  document.querySelectorAll('button').forEach(button => { button.disabled = on; });
  syncChannelForm();
}

function syncChannelForm(channels = currentState?.channels || []) {
  const atLimit = channels.length >= 1;
  $('channelInput').disabled = busy || atLimit;
  $('channelSubmit').disabled = busy || atLimit;
  $('channelInput').placeholder = atLimit ? 'Remova o canal atual para cadastrar outro' : '@canal ou https://youtube.com/@canal';
}

async function api(url, { method = 'GET', body } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
      if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
    }
    const response = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
      signal: controller.signal
    });
    let data;
    try { data = await response.json(); }
    catch { throw new ApiError(response.status, `Resposta inválida do servidor (HTTP ${response.status}).`); }
    if (!response.ok || data.ok !== true) throw new ApiError(response.status, data.error || `HTTP ${response.status}`);
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new ApiError(0, 'Tempo de conexão esgotado.');
    throw error;
  } finally { clearTimeout(timer); }
}

function loggedOut(message = '') {
  authenticated = false;
  csrfToken = '';
  currentState = null;
  draftVersion = -1;
  dirty = false;
  show('loginPanel', true);
  show('dashboard', false);
  show('logoutButton', false);
  $('currentUsername').textContent = '';
  if (message) loginFeedback(message);
}

async function bootstrap() {
  const data = await api('/api/web/bootstrap');
  if (!data.authenticated) return loggedOut();
  authenticated = true;
  csrfToken = data.csrfToken;
  if (!(data.user.profiles || []).some(profile => profile.profileId === currentProfile)) {
    currentProfile = data.user.profiles?.[0]?.profileId || 1;
    localStorage.setItem(PROFILE_KEY, String(currentProfile));
  }
  $('currentUsername').textContent = data.user.username || '';
  show('loginPanel', false);
  show('dashboard', true);
  show('logoutButton', true);
  await refreshState(true);
}

function number(id) { return Number($(id).value); }
function configBody() { return { intervalMinutes: number('intervalMinutes'), intervalSeconds: number('intervalSeconds'), messages: $('messages').value, expectedVersion: draftVersion }; }

function countMessages() {
  const count = $('messages').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean).length;
  $('messageCount').textContent = `${count} ${count === 1 ? 'mensagem' : 'mensagens'}`;
}

function markDirty() {
  if (!currentState) return;
  dirty = true;
  $('saveState').textContent = 'Rascunho não salvo';
  countMessages();
}

function fillConfig(config) {
  $('intervalMinutes').value = config.intervalMinutes;
  $('intervalSeconds').value = Math.max(1, Number(config.intervalSeconds) || 1);
  $('messages').value = config.messages || '';
  draftVersion = config.version;
  dirty = false;
  $('saveState').textContent = 'Sincronizado';
  countMessages();
}

function statusName(status) { return status === 'running' ? 'RODANDO' : status === 'paused' ? 'PAUSADO' : 'PARADO'; }
function formatDuration(ms) {
  const total = Math.max(0, Math.round(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return minutes ? `${minutes} min ${String(seconds).padStart(2, '0')} s` : `${seconds} s`;
}
function formatTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function renderProfiles(profiles) {
  const root = $('profileTabs');
  root.replaceChildren();
  for (const profile of profiles) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `profile-tab ${profile.profileId === currentProfile ? 'selected' : ''}`;
    button.dataset.profile = profile.profileId;
    const label = document.createElement('span');
    label.textContent = profile.name || `Perfil ${profile.profileId}`;
    const dot = document.createElement('small');
    dot.className = `dot ${profile.status}`;
    const status = document.createElement('b');
    status.textContent = statusName(profile.status);
    button.append(label, dot, status);
    root.append(button);
  }
}

function renderMonitoring(monitoring = {}) {
  $('monitorStatus').textContent = monitoring.running ? 'Busca em andamento' : monitoring.lastGlobalScanError ? 'Última busca com avisos' : 'Monitor ativo no servidor';
  $('monitorInterval').textContent = `${Math.round((monitoring.intervalSeconds || 180) / 60)} min`;
  $('monitorNext').textContent = formatTime(monitoring.nextGlobalScanAt);
  $('monitorChannels').textContent = monitoring.globalChannelsActive || 0;
  $('monitorLives').textContent = (monitoring.scheduledLivesCount || 0) + (monitoring.liveLivesCount || 0);
}

function renderRuntime(data) {
  const runtime = data.runtime;
  const status = runtime.status || 'stopped';
  const badge = $('statusBadge');
  badge.textContent = statusName(status);
  badge.className = `status ${status}`;
  $('profileEyebrow').textContent = `PERFIL ${data.selectedProfile}`;
  $('controlTitle').textContent = data.profile.name || `Perfil ${data.selectedProfile}`;
  $('statusTitle').textContent = status === 'running' ? 'Automação em execução' : status === 'paused' ? 'Automação pausada' : 'Automação parada';
  $('statusDetail').textContent = status === 'running' && runtime.nextAt
    ? `Próximo envio previsto às ${formatTime(runtime.nextAt)}.`
    : status === 'running' ? 'Aguardando uma live com chat disponível.'
      : status === 'paused' ? 'Este perfil está pausado; os outros continuam independentes.' : 'Inicie quando a conta, os canais e as mensagens estiverem prontos.';
  $('sentCount').textContent = runtime.sent;
  $('failureCount').textContent = runtime.failures;
  $('attemptCount').textContent = runtime.attempts;
  $('activeChatCount').textContent = runtime.activeChats;
  $('apiLookupCount').textContent = runtime.apiUsageToday?.videosList?.attempts || 0;
  $('apiInsertCount').textContent = runtime.apiUsageToday?.liveChatInsert?.attempts || 0;
  $('effectiveDelay').textContent = runtime.activeChats > 1
    ? `Alternância entre ${runtime.activeChats} lives: um envio a cada ${formatDuration(runtime.effectiveDelayMs)}`
    : `Intervalo efetivo: ${formatDuration(runtime.effectiveDelayMs)}`;
  $('accountTitle').textContent = runtime.oauthConnected ? 'YouTube conectado' : 'YouTube não conectado';
  $('accountDetail').textContent = runtime.oauthConnected
    ? `Conta ativa: ${runtime.oauthEmail}`
    : data.profile.googleEmail ? `Conta permitida: ${data.profile.googleEmail}` : 'O administrador ainda não definiu uma conta Google para este perfil.';
  $('oauthButton').textContent = runtime.oauthConnected ? 'TROCAR CONTA GOOGLE' : 'ENTRAR COM GOOGLE';
  show('disconnectButton', runtime.oauthConnected);
  $('lastError').textContent = runtime.lastError || '';
  show('lastError', !!runtime.lastError);
  renderProfiles(data.profiles || []);
  renderMonitoring(data.globalMonitoring);
  renderChannels(data.channels || []);
  renderLives(data.lives || []);
  renderLogs(data.logs || []);
}

function renderChannels(channels) {
  $('channelCount').textContent = `${channels.length} ${channels.length === 1 ? 'canal' : 'canais'}`;
  syncChannelForm(channels);
  const root = $('channels');
  root.replaceChildren();
  if (!channels.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'Nenhum canal cadastrado neste perfil.';
    root.append(empty);
    return;
  }
  for (const channel of channels) {
    const item = document.createElement('article');
    item.className = 'channel-item';
    const info = document.createElement('div');
    const title = document.createElement('strong');
    title.textContent = channel.displayName || channel.handle || channel.channelId || 'Canal do YouTube';
    const url = document.createElement('a');
    url.href = channel.canonicalUrl;
    url.target = '_blank';
    url.rel = 'noopener';
    url.textContent = channel.handle || channel.canonicalUrl;
    const meta = document.createElement('small');
    meta.textContent = channel.lastError ? `Aviso: ${channel.lastError}` : channel.lastCheckedAt ? `Verificado: ${formatTime(channel.lastCheckedAt)}` : 'Aguardando primeira verificação';
    info.append(title, url, meta);
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'secondary remove-channel';
    remove.dataset.channelId = channel.id;
    remove.textContent = 'REMOVER';
    item.append(info, remove);
    root.append(item);
  }
}

function renderLives(lives) {
  const root = $('lives');
  root.replaceChildren();
  const visible = lives.filter(live => live.sendStatus !== 'FINALIZED').slice(0, 5);
  for (const live of visible) {
    const item = document.createElement('div');
    item.className = 'live-pill';
    item.textContent = `${live.channelName || live.handle || 'Canal'} • ${live.title || live.videoId} • ${live.liveStatus}/${live.chatStatus}`;
    root.append(item);
  }
}

function renderLogs(logs) {
  const root = $('logs');
  root.replaceChildren();
  if (!logs.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'Sem atividade recente neste perfil.';
    root.append(empty);
    return;
  }
  for (const entry of logs) {
    const item = document.createElement('article');
    item.className = `log ${entry.status || ''}`;
    const head = document.createElement('div');
    head.className = 'log-head';
    const type = document.createElement('span');
    type.textContent = String(entry.type || 'atividade').toUpperCase();
    const at = document.createElement('time');
    at.dateTime = entry.at || '';
    at.textContent = entry.at ? new Date(entry.at).toLocaleString() : '—';
    head.append(type, at);
    item.append(head);
    if (entry.message) {
      const message = document.createElement('div');
      message.className = 'log-message';
      message.textContent = entry.message;
      item.append(message);
    }
    if (entry.error) {
      const error = document.createElement('div');
      error.className = 'log-error';
      error.textContent = entry.error;
      item.append(error);
    }
    root.append(item);
  }
}

async function refreshState(forceConfig = false) {
  if (!authenticated) return;
  try {
    const data = await api(`/api/profiles/${currentProfile}`);
    serverOffset = Number(data.serverTime || Date.now()) - Date.now();
    currentState = data;
    $('currentUsername').textContent = data.user.username || '';
    if (forceConfig || !dirty) fillConfig(data.config);
    renderRuntime(data);
    feedback('');
  } catch (error) {
    if (error.status === 401) loggedOut('Sua sessão expirou. Entre novamente.');
    else feedback(error.message);
  }
}

async function selectProfile(number) {
  if (number === currentProfile) return;
  if (dirty && !confirm('Trocar de perfil e descartar o rascunho não salvo?')) return;
  currentProfile = number;
  localStorage.setItem(PROFILE_KEY, String(number));
  currentState = null;
  dirty = false;
  await refreshState(true);
}

async function saveConfig() {
  if (!currentState) throw new ApiError(0, 'Aguarde a sincronização do servidor.');
  if (!$('configForm').reportValidity()) throw new ApiError(0, 'Revise os campos destacados.');
  const result = await api(`/api/profiles/${currentProfile}/settings`, { method: 'PUT', body: configBody() });
  currentState.config = result.settings;
  dirty = false;
  $('saveState').textContent = 'Configuração salva';
  await refreshState(true);
}

async function control(action) {
  setBusy(true);
  feedback('');
  try {
    if (action === 'start' && dirty) await saveConfig();
    await api(`/api/profiles/${currentProfile}/${action}`, { method: 'POST', body: {} });
    await refreshState(false);
    feedback(action === 'start' ? `Perfil ${currentProfile} iniciado no servidor.` : action === 'pause' ? `Perfil ${currentProfile} pausado.` : `Perfil ${currentProfile} parado.`, true);
  } catch (error) {
    if (error.status === 401) loggedOut('Sua sessão expirou. Entre novamente.');
    else feedback(error.message);
  } finally { setBusy(false); }
}

$('loginForm').addEventListener('submit', async event => {
  event.preventDefault();
  setBusy(true);
  loginFeedback('Entrando…', true);
  try {
    await api('/api/login', { method: 'POST', body: { username: $('loginUsername').value.trim(), password: $('loginPassword').value, privacyAccepted: $('privacyAccepted').checked } });
    $('loginPassword').value = '';
    await bootstrap();
    feedback('Login concluído.', true);
  } catch (error) { loginFeedback(error.message); }
  finally { setBusy(false); }
});

$('profileTabs').addEventListener('click', event => {
  const button = event.target.closest('button[data-profile]');
  if (button) selectProfile(Number(button.dataset.profile));
});
$('configForm').addEventListener('input', markDirty);
$('configForm').addEventListener('submit', async event => {
  event.preventDefault();
  setBusy(true);
  try { await saveConfig(); feedback(`Configuração do Perfil ${currentProfile} salva.`, true); }
  catch (error) { feedback(error.status === 409 ? 'A configuração mudou em outra sessão. Seu rascunho foi mantido.' : error.message); }
  finally { setBusy(false); }
});
$('reloadButton').addEventListener('click', () => {
  if (dirty && !confirm('Descartar as alterações ainda não salvas?')) return;
  refreshState(true);
});
$('startButton').addEventListener('click', () => control('start'));
$('pauseButton').addEventListener('click', () => control('pause'));
$('stopButton').addEventListener('click', () => control('stop'));
$('refreshButton').addEventListener('click', () => refreshState(false));
$('oauthButton').addEventListener('click', async () => {
  setBusy(true);
  try {
    const result = await api(`/api/profiles/${currentProfile}/oauth/connect?client=web`);
    location.assign(result.url);
  } catch (error) { feedback(error.message); setBusy(false); }
});
$('disconnectButton').addEventListener('click', async () => {
  if (!confirm(`Desconectar o YouTube e pausar somente o Perfil ${currentProfile}?`)) return;
  setBusy(true);
  try {
    const result = await api(`/api/profiles/${currentProfile}/oauth/disconnect`, { method: 'POST', body: {} });
    await refreshState(true);
    feedback(result.warning || `YouTube desconectado do Perfil ${currentProfile}.`, !result.warning);
  } catch (error) { feedback(error.message); }
  finally { setBusy(false); }
});
$('channelForm').addEventListener('submit', async event => {
  event.preventDefault();
  setBusy(true);
  try {
    const result = await api(`/api/profiles/${currentProfile}/channels`, { method: 'POST', body: { channel: $('channelInput').value.trim() } });
    $('channelInput').value = '';
    await refreshState(false);
    feedback(result.warning || 'Canal adicionado ao perfil.', !result.warning);
  } catch (error) { feedback(error.message); }
  finally { setBusy(false); }
});
$('channels').addEventListener('click', async event => {
  const button = event.target.closest('.remove-channel');
  if (!button || !confirm('Remover este canal somente do perfil selecionado?')) return;
  setBusy(true);
  try {
    await api(`/api/profiles/${currentProfile}/channels/${encodeURIComponent(button.dataset.channelId)}`, { method: 'DELETE', body: {} });
    await refreshState(false);
    feedback('Canal removido deste perfil.', true);
  } catch (error) { feedback(error.message); }
  finally { setBusy(false); }
});
$('clearLogsButton').addEventListener('click', async () => {
  if (!confirm(`Limpar os registros recentes somente do Perfil ${currentProfile}?`)) return;
  setBusy(true);
  try {
    await api(`/api/profiles/${currentProfile}/logs/clear`, { method: 'POST', body: {} });
    await refreshState(false);
    feedback('Registros do perfil limpos.', true);
  } catch (error) { feedback(error.message); }
  finally { setBusy(false); }
});
$('logoutButton').addEventListener('click', async () => {
  if (!confirm('Sair do painel? Os perfis em execução continuarão no servidor.')) return;
  setBusy(true);
  try { await api('/api/logout', { method: 'POST', body: {} }); }
  catch (error) { feedback(error.message); }
  finally { setBusy(false); loggedOut('Você saiu. As automações não foram interrompidas.'); }
});
$('deleteAccountButton').addEventListener('click', async () => {
  if (!confirm('Excluir definitivamente a conta, todos os perfis, canais, configurações e histórico?')) return;
  setBusy(true);
  try {
    await api('/api/account', { method: 'DELETE', body: {} });
    loggedOut('Conta e todos os perfis excluídos do servidor.');
  } catch (error) { feedback(error.message); }
  finally { setBusy(false); }
});

const query = new URLSearchParams(location.search);
const oauthResult = query.get('oauth');
const oauthProfile = Number(query.get('profile'));
if (oauthProfile >= 1 && oauthProfile <= 50) {
  currentProfile = oauthProfile;
  localStorage.setItem(PROFILE_KEY, String(oauthProfile));
}
if (oauthResult) {
  feedback(oauthResult === 'ok' ? `Conta Google autorizada no Perfil ${currentProfile}.` : 'A autorização Google não foi concluída.', oauthResult === 'ok');
  history.replaceState({}, '', location.pathname);
}

setInterval(() => { if (authenticated && document.visibilityState === 'visible' && !busy) refreshState(false); }, 5000);
setInterval(() => {
  if (!currentState || currentState.runtime.status !== 'running' || !currentState.runtime.nextAt) return;
  const left = new Date(currentState.runtime.nextAt).getTime() - (Date.now() + serverOffset);
  $('statusDetail').textContent = left > 0 ? `Próximo envio em ${formatDuration(left)} (${formatTime(currentState.runtime.nextAt)}).` : 'Preparando o próximo envio…';
}, 1000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') refreshState(false); });
bootstrap().catch(error => { loggedOut(); loginFeedback(error.message); });
