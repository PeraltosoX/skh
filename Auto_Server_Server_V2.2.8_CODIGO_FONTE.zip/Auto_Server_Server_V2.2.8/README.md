# Auto Server V2.2.8

Servidor e painel web do Auto Server. A automação permanece na VPS mesmo com o
aplicativo, o painel ou o navegador fechados.

Esta entrega altera somente servidor e painel web. O aplicativo Android não faz
parte deste ZIP.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde: `/health`
- Retorno OAuth: `/oauth/google/callback`

## Perfis e canais

- Cada conta começa com três perfis.
- O administrador pode adicionar um perfil por vez, até 50.
- Os Perfis 1, 2 e 3 são permanentes. Somente perfis adicionais podem ser excluídos pelo administrador.
- Ao excluir um perfil adicional, o menor número livre a partir do 4 é reutilizado na próxima criação.
- Cada perfil aceita exatamente um canal.
- API Google, OAuth, mensagens, intervalo, canal, worker, contadores e logs são
  independentes por perfil.
- Um monitor global consulta um canal apenas uma vez, mesmo quando ele é usado
  por mais de um usuário.

## Descoberta e confirmação administrativa

- A aba pública `/streams` encontra até três transmissões por canal.
- A busca de IDs continua usando o método público existente. Esta versão não
  acrescenta busca emergencial por canal na YouTube Data API.
- Até quatro IDs antigos são revistos primeiro pela página pública
  `watch?v=...` em cada ciclo.
- Os IDs entram em rotação: depois de conferir quatro, os ainda não conferidos
  passam à frente no ciclo seguinte.
- Um `404 liveChatNotFound` bloqueia imediatamente novos envios, limpa o chat em
  cache e coloca a transmissão em `VERIFYING`.
- Falha de conexão, timeout ou resposta 5xx não marca a live como apagada.
- `LOGIN_REQUIRED`, “confirme que você não é um bot”, CAPTCHA e outras barreiras
  temporárias do YouTube não confirmam encerramento.
- Quando já existe um ID e a página pública fica bloqueada, inconclusiva ou não
  consegue confirmar o chat, o servidor pode usar uma chave administrativa da
  YouTube Data API. A consulta não usa Client ID, OAuth nem quota dos perfis.
- O `activeLiveChatId` confirmado é guardado globalmente e compartilhado com os
  perfis daquela live. Uma confirmação positiva recente também é reutilizada
  por 30 minutos enquanto a página pública permanece bloqueada.
- Se todas as chaves administrativas falharem, a live é preservada para nova
  tentativa; ela não é encerrada somente por causa do bloqueio público.
- O número e a data das reverificações públicas ficam no banco e os resultados
  aparecem nos eventos globais.

## Chaves administrativas

- O `/dbmadmin` permite adicionar várias chaves, testar, habilitar ou
  desabilitar, tornar principal e excluir com confirmação.
- As chaves são tentadas por prioridade, uma de cada vez. Uma reserva só é
  usada quando as anteriores estão inválidas, sem cota ou indisponíveis.
- As chaves completas são criptografadas com `APP_ENCRYPTION_KEY` e nunca são
  devolvidas ao navegador; o painel mostra somente uma identificação parcial.
- Consultas, sucessos, falhas, último uso, espera de cota e último erro aparecem
  no painel. O teste manual consome uma consulta `videos.list`.
- Chaves do mesmo projeto Google Cloud compartilham a quota. Para reserva de
  quota independente, use projetos diferentes.

## Intervalos e lives simultâneas

- PARAR descarta o ciclo de tempo e zera os contadores gerais de enviadas,
  tentativas, falhas e erros de conexão somente daquele perfil.
- Consultas de chat hoje e envios API hoje permanecem, pois representam o uso
  diário real da API do YouTube.
- PAUSAR preserva o ciclo e os contadores. A posição da lista de mensagens é
  preservada ao pausar, parar ou iniciar.
- Um novo INICIAR após PARAR deixa o primeiro envio elegível imediatamente e
  começa a contar somente após o sucesso.
- Uma live: usa o intervalo configurado no perfil.
- Duas lives: um envio total a cada 3 minutos, alternando entre elas. Cada live
  recebe uma mensagem aproximadamente a cada 6 minutos.
- Três lives: um envio total a cada 2 minutos e 30 segundos, alternando. Cada
  live recebe uma mensagem aproximadamente a cada 7 minutos e 30 segundos.
- O menor intervalo configurável continua sendo 0 minuto e 1 segundo.
- O antigo campo de milissegundos é aceito para compatibilidade, mas ignorado e
  zerado na migration para não existir atraso oculto.

## Economia da YouTube Data API

- A descoberta continua usando páginas públicas e não usa `search.list`.
- A API administrativa usa somente `videos.list` como fallback para IDs já
  encontrados; ela não pesquisa canais nem cria novas lives.
- O access token é reutilizado até perto do vencimento.
- O `activeLiveChatId` agora é guardado globalmente por vídeo e compartilhado
  entre perfis.
- Consultas simultâneas do mesmo vídeo feitas com a mesma identidade de projeto
  e Conta Google são unificadas em uma única chamada `videos.list`. Identidades
  diferentes ficam isoladas para uma API desativada não pausar outro perfil.
- Se o chat ainda não existe, a espera configurável é gravada na própria live;
  outras lives do perfil continuam funcionando.
- O padrão de nova consulta é 120 segundos. O administrador pode usar de 15 a
  3600 segundos no `/dbmadmin`.
- O ID direto antigo `liveUrl` não é mais usado como fallback. Um perfil precisa
  de um canal cadastrado, evitando consultas infinitas a vídeo apagado.
- O painel do usuário mostra as consultas de chat e tentativas de envio do dia.
  O painel administrativo mostra o total diário do servidor.
- As consultas administrativas possuem contadores separados e não são somadas
  aos contadores dos perfis.

Os contadores representam solicitações, não uma estimativa fixa de unidades de
cota. O custo oficial pode mudar e deve ser conferido no Google Cloud Console.

## Isolamento de erros

- Retry e backoff são individuais por live.
- Uma transmissão sem chat, com 429 ou com falha temporária não bloqueia as
  outras lives do perfil.
- O cabeçalho `Retry-After` do Google é respeitado, com limite de uma hora.
- Uma resposta de envio ambígua pausa somente aquela live para evitar mensagem
  duplicada; as demais continuam.
- API desativada, `accessNotConfigured`, permissões insuficientes, OAuth inválido
  e mensagem inválida pausam o perfil com instrução clara.
- Quando a cota diária termina, a nova tentativa é agendada automaticamente para
  depois da virada da cota no horário do Pacífico.
- Uma live só pode ser enviada se ainda estiver `AVAILABLE`, vinculada ao canal
  do perfil e não finalizada.
- Envios do mesmo chat são serializados. Se o primeiro detectar que o chat foi
  apagado, os seguintes são cancelados antes da solicitação.
- Remover ou trocar o canal invalida imediatamente o alvo em andamento.

## Monitor e armazenamento

- Até três canais são consultados em paralelo. Ajuste opcionalmente com
  `GLOBAL_MONITOR_CONCURRENCY` entre 1 e 5.
- As três páginas de vídeo de um canal são resolvidas em paralelo.
- Páginas de consentimento, CAPTCHA ou tráfego incomum geram aviso e não mudam a
  live para encerrada.
- Excluir o último assinante ou o usuário desativa o canal no monitor global.
- Estados finalizados com mais de 180 dias são removidos. Lives finalizadas com
  mais de um ano podem ser limpas, mas as 50 mais recentes de cada canal e todas
  as que estejam em verificação são preservadas.
- Logs de perfil, eventos globais, auditoria e contadores diários possuem
  retenção limitada.

## Segurança e persistência

- Client Secret, tokens e chaves administrativas já salvas nunca são devolvidos
  pelos painéis.
- Credenciais e chaves administrativas são criptografadas com AES-256-GCM.
- Cookies HttpOnly/SameSite, CSRF, validação de origem e limite de login
  permanecem ativos.
- OAuth, estado das lives, mensagens, contadores e workers sobrevivem ao reinício.
- Ao trocar realmente para outro e-mail Google, a autorização anterior é
  revogada depois que a nova autorização foi salva.
- Conectar, trocar ou desconectar a Conta Google conserva perfis parados como
  parados e perfis pausados como pausados. Somente uma execução que estava ativa
  passa para pausada, impedindo troca de credenciais durante um envio.
- Iniciar, pausar, parar, limpar registros e conectar ou desconectar o YouTube
  geram auditoria com perfil, tipo de cliente, identificação não reutilizável da
  sessão, IP e agente do cliente. Tokens, senhas e segredos não são registrados.

## Painel web

- INICIAR, PAUSAR e PARAR exigem confirmação; o aviso de PARAR informa quais
  contadores serão zerados e quais dados permanecerão.
- Respostas antigas são ignoradas ao trocar de perfil ou fazer atualizações
  simultâneas, impedindo que um perfil sobrescreva visualmente outro.
- Estados conhecidos de transmissão e chat aparecem em português.

## Migration automática

A V2.2.8 migra o schema SQLite de 4 para 5 de forma incremental e transacional:

1. preserva usuários, senhas, perfis, canais, mensagens, OAuth e logs;
2. mantém os três perfis padrão e todos os perfis adicionais;
3. cria cache global do chat e retries individuais por live;
4. cria contadores diários de chamadas da API;
5. adiciona registro e rotação das reverificações públicas;
6. zera somente o antigo campo oculto de milissegundos;
7. reabre uma única vez somente lives sem término real que tenham sido
   finalizadas nas versões anteriores pela mensagem explícita de proteção
   anti-bot do YouTube;
8. cria o armazenamento criptografado das chaves administrativas, seus estados
   e contadores diários;
9. registra a última confirmação administrativa de cada live, sem apagar os
   dados existentes.

O banco fica em `data/peralta.sqlite`. O arquivo `.env` e a pasta `data/` devem
ser preservados juntos porque `APP_ENCRYPTION_KEY` protege os tokens existentes.

Use `ATUALIZAR_SEM_PERDER_DADOS.sh`. O script cria backup, copia `.env` e
`data/`, inicia a V2.2.8, exige `/health` com schema 5, valida a sintaxe dentro do
contêiner e religa a versão anterior automaticamente se algo falhar.

## Google OAuth por perfil

Cada perfil utiliza um OAuth Client do tipo **Web application**. Cadastre:

`https://SEU-DOMINIO/oauth/google/callback`

Para cotas independentes, use projetos Google Cloud diferentes. Vários Clients
no mesmo projeto compartilham a cota do projeto.

## Desenvolvimento

Requer Node.js 24.14 ou superior na linha 24:

```bash
npm ci
npm run check
npm test
npm start
```

Consulte `CHANGELOG_V2.2.8.txt`, `INSTALAR.txt` e
`ATUALIZAR_SEM_PERDER_DADOS.txt`.
