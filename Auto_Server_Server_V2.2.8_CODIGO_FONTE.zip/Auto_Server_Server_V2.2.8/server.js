'use strict';

const express = require('express');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const crypto = require('node:crypto');
const path = require('node:path');
const security = require('./lib/security');

if (require.main === module) security.validateEnvironment();

const store = require('./lib/store');
const youtube = require('./lib/youtube');
const workers = require('./lib/workers');
const validation = require('./lib/validation');
const { normalizeChannelInput, resolveChannelInput } = require('./lib/channel-normalizer');
const { createGlobalMonitor } = require('./lib/global-monitor');
const { createAdminLiveVerifier } = require('./lib/admin-live-verifier');

const VERSION = '2.2.8';
const ADMIN_COOKIE = 'auto_server_admin';
const USER_COOKIE = 'auto_server_user';
const base = String(process.env.PUBLIC_BASE_URL || 'http://localhost:8080').replace(/\/$/, '');
const origin = new URL(base);

if (origin.username || origin.password || origin.pathname !== '/' || origin.search || origin.hash) {
  throw new Error('PUBLIC_BASE_URL deve conter apenas https://dominio, sem caminho ou credenciais.');
}
if (origin.protocol !== 'https:' && !(origin.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(origin.hostname) && process.env.NODE_ENV !== 'production')) {
  throw new Error('Use HTTPS em PUBLIC_BASE_URL. HTTP é permitido apenas no desenvolvimento local.');
}

const redirectUri = `${base}/oauth/google/callback`;
const adminLiveVerifier = createAdminLiveVerifier();
const globalMonitor = createGlobalMonitor({
  verifyKnownLive: adminLiveVerifier.verifyKnownLive,
  onProfilesChanged: profiles => {
    for (const item of profiles || []) {
      const profile = store.getUserProfile(item.userId, item.profileNumber);
      if (profile?.config.autoStart && profile.enabled && profile.runtime.status === 'stopped' && profile.api.clientId && profile.api.clientSecretEnc && profile.oauth.refreshTokenEnc && workers.parseMessages(profile.config.messages).length) {
        workers.start(item.userId, item.profileNumber, false);
      } else workers.wake(item.userId, item.profileNumber);
    }
  }
});
const fail = (res, status, error, extra = {}) => res.status(status).json({ ok: false, error, ...extra });
const escape = value => String(value || '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);

function blankOAuth(version = 1) {
  return { email: '', refreshTokenEnc: '', accessTokenEnc: '', accessTokenExpiresAt: 0, scope: '', version };
}

function holdProfileForOAuthChange(profile) {
  if (profile.runtime.status === 'running') {
    profile.runtime.status = 'paused';
    profile.runtime.pausedAt = store.now();
  }
  profile.runtime.epoch++;
  profile.runtime.nextAt = null;
  profile.runtime.retryAt = 0;
  profile.runtime.quotaResumeAt = 0;
  profile.runtime.legacyLiveChatId = '';
  profile.runtime.legacyVideoId = '';
}

function invalidateProfileOAuth(profile, message = 'Conecte a conta do YouTube novamente.') {
  profile.oauth = blankOAuth((profile.oauth?.version || 0) + 1);
  holdProfileForOAuthChange(profile);
  profile.runtime.lastError = message;
}

// Mantido para integrações antigas que importavam esta função. Agora atua somente no Perfil 1.
function invalidateOAuth(user) {
  const profile = store.updateUserProfile(user.id, 1, current => invalidateProfileOAuth(current));
  store.deleteOAuthAttempts(user.id, 1);
  return profile;
}

function readSession(token, kind) {
  const payload = security.verifySession(token || '', kind);
  const user = kind === 'admin' ? store.getAdmin(payload.sub) : store.getUser(payload.sub);
  if (!user || user.active === false || payload.ver !== user.sessionVersion || !store.sessionValid(payload.sid, payload.sub, kind)) {
    throw new Error('Sessão inválida.');
  }
  return { p: payload, user };
}

function requireSession(kind) {
  return (req, res, next) => {
    try {
      const header = String(req.headers.authorization || '');
      const bearer = kind === 'user' && /^Bearer\s+/i.test(header);
      const token = kind === 'admin' ? req.cookies[ADMIN_COOKIE] : bearer ? header.replace(/^Bearer\s+/i, '') : req.cookies[USER_COOKIE];
      const current = readSession(token, kind);
      req.session = current.p;
      req[kind] = current.user;
      req.authSource = bearer ? 'bearer' : 'cookie';
      next();
    } catch {
      return fail(res, 401, 'Sessão inválida ou expirada. Entre novamente.');
    }
  };
}

function issue(res, user, kind) {
  const signed = security.signSession(user.id, kind, user.sessionVersion);
  store.saveSession(signed.session);
  const common = { httpOnly: true, secure: origin.protocol === 'https:', sameSite: 'strict' };
  if (kind === 'admin') res.cookie(ADMIN_COOKIE, signed.token, { ...common, path: '/dbmadmin', maxAge: 43200000 });
  else res.cookie(USER_COOKIE, signed.token, { ...common, path: '/', maxAge: 2592000000 });
  return signed.token;
}

function rateLimit(limit, windowMs, keyFunction) {
  const entries = new Map();
  return (req, res, next) => {
    const currentTime = Date.now();
    if (entries.size > 10000) for (const [key, entry] of entries) if (entry.until <= currentTime) entries.delete(key);
    const key = keyFunction(req);
    let entry = entries.get(key);
    if (!entry || entry.until <= currentTime) {
      entry = { count: 0, until: currentTime + windowMs };
      entries.set(key, entry);
    }
    if (++entry.count > limit) {
      res.set('Retry-After', String(Math.ceil((entry.until - currentTime) / 1000)));
      return fail(res, 429, 'Muitas tentativas. Aguarde e tente novamente.');
    }
    next();
  };
}

function profileNumber(value) {
  return validation.profileNumber(value);
}

function ownedProfile(userId, value) {
  const number = profileNumber(value);
  const profile = store.getUserProfile(userId, number);
  if (!profile) validation.invalid('Perfil não encontrado.', 404);
  return profile;
}

function runtimePayload(profile) {
  const liveStates = store.profileLiveStates(profile.userId, profile.profileNumber, 30);
  const activeChats = liveStates.filter(item => ['ACTIVE', 'FINISHING'].includes(item.sendStatus) && item.chatStatus === 'AVAILABLE').length;
  return {
    status: profile.runtime.status,
    sent: profile.runtime.sent,
    failures: profile.runtime.failures,
    attempts: profile.runtime.attempts,
    connectionErrors: profile.runtime.connectionErrors,
    lastError: profile.runtime.lastError,
    nextAt: profile.runtime.nextAt,
    nextSend: profile.runtime.nextAt,
    oauthConnected: !!profile.oauth.refreshTokenEnc,
    oauthEmail: profile.oauth.email,
    account: profile.oauth.email,
    hourlySent: 0,
    effectiveDelayMs: workers.delayForLiveCount(profile.config, activeChats),
    configuredDelayMs: workers.effectiveDelay(profile.config),
    apiUsageToday: store.apiUsage(profile.userId, profile.profileNumber),
    activeChats,
    startedAt: profile.runtime.startedAt,
    workerActive: workers.hasWorker(profile.userId, profile.profileNumber)
  };
}

function profileState(user, value, logLimit = 15) {
  const profile = ownedProfile(user.id, value);
  return {
    ok: true,
    version: VERSION,
    serverTime: Date.now(),
    user: store.publicUser(user),
    selectedProfile: profile.profileNumber,
    profile: store.publicProfile(profile),
    profiles: store.userProfiles(user.id).map(store.publicProfile),
    config: store.profileConfigForClient(profile),
    runtime: runtimePayload(profile),
    channels: store.profileChannels(user.id, profile.profileNumber),
    lives: store.profileLiveStates(user.id, profile.profileNumber, 30),
    logs: store.logs(user.id, profile.profileNumber, logLimit),
    globalMonitoring: store.monitorSnapshot()
  };
}

function profileCanStart(userId, profile) {
  if (!profile.enabled) validation.invalid('Este perfil está desativado pelo administrador.', 409);
  if (!profile.api.clientId || !profile.api.clientSecretEnc) validation.invalid('Configure a API Google deste perfil no painel administrativo.', 409);
  if (!profile.oauth.refreshTokenEnc) validation.invalid('Conecte a conta do YouTube deste perfil primeiro.', 409);
  if (!workers.parseMessages(profile.config.messages).length) validation.invalid('Configure pelo menos uma mensagem neste perfil.', 409);
  const channels = store.profileChannels(userId, profile.profileNumber);
  if (channels.length > 1) validation.invalid('Este perfil possui mais de um canal. Remova os canais extras; cada perfil aceita somente um canal.', 409);
  if (!channels.length) validation.invalid('Cadastre um canal do YouTube neste perfil.', 409);
}

function updateProfileConfig(userId, number, body) {
  const patch = validation.config(body);
  const expected = validation.integer(body.expectedVersion, 'Versão da configuração', 1, Number.MAX_SAFE_INTEGER);
  const profile = store.updateUserProfile(userId, number, current => {
    if (current.config.version !== expected) validation.invalid('A configuração mudou em outra sessão. Recarregue ou revise seu rascunho.', 409);
    const changed = Object.entries(patch).some(([key, value]) => current.config[key] !== value);
    if (!changed) return;
    if (patch.liveUrl !== undefined && patch.liveUrl !== current.config.liveUrl) {
      current.runtime.legacyLiveChatId = '';
      current.runtime.legacyVideoId = '';
      current.runtime.retryAt = 0;
    }
    if (patch.messages !== undefined && patch.messages !== current.config.messages) current.config.messageIndex = 0;
    Object.assign(current.config, patch);
    current.config.version++;
    current.runtime.lastError = '';
  });
  workers.wake(userId, number);
  return profile;
}

function disableLegacyLiveTarget(userId, number) {
  store.updateUserProfile(userId, number, profile => {
    if (!profile.config.liveUrl && !profile.runtime.legacyLiveChatId && !profile.runtime.legacyVideoId) return;
    profile.config.liveUrl = '';
    profile.config.version++;
    profile.runtime.legacyLiveChatId = '';
    profile.runtime.legacyVideoId = '';
  });
}

function runProfileControl(userId, number, action) {
  const profile = ownedProfile(userId, number);
  if (action === 'start') {
    profileCanStart(userId, profile);
    if (profile.runtime.status !== 'running' && workers.start(userId, number, profile.runtime.status === 'stopped') === false) {
      validation.invalid('Este perfil está sendo removido. Recarregue os perfis.', 409);
    }
  } else if (action === 'pause') workers.pause(userId, number);
  else if (action === 'stop') workers.stop(userId, number);
  else validation.invalid('Comando desconhecido.', 404);
  return store.getUserProfile(userId, number);
}

function oauthClient(req) {
  if (req.query.client === 'web' || req.body?.client === 'web') return 'web';
  if (/^PeraltaChatAndroid\//i.test(String(req.headers['user-agent'] || ''))) return 'legacy';
  return 'app';
}

function cleanAuditValue(value, limit = 180) {
  return String(value || '').replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, limit);
}

function requestAuditTarget(req, profileNumberValue, clientHint = '') {
  const userAgent = cleanAuditValue(req.headers['user-agent'] || 'não informado');
  const client = cleanAuditValue(clientHint) || (req.authSource === 'cookie' ? 'painel-web' : /android/i.test(userAgent) ? 'android' : 'api');
  const session = req.session?.sid
    ? crypto.createHash('sha256').update(String(req.session.sid)).digest('hex').slice(0, 12)
    : 'sem-sessao';
  const ip = cleanAuditValue(req.ip || req.socket?.remoteAddress || 'não informado', 80);
  return `perfil=${profileNumberValue}; cliente=${client}; sessao=${session}; ip=${ip}; agente=${userAgent}`;
}

function auditUserRequest(req, action, profileNumberValue, clientHint = '') {
  store.audit(req.user.id, action, requestAuditTarget(req, profileNumberValue, clientHint));
}

function oauthStart(user, profile, client) {
  if (!profile.enabled || !profile.api.clientId || !profile.api.clientSecretEnc) validation.invalid('API Google não configurada para este perfil.', 409);
  const prefix = client === 'web' ? 'w.' : client === 'legacy' ? 'l.' : 'a.';
  const state = prefix + security.randomState();
  store.saveOAuthAttempt(state, user, profile);
  const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  const parameters = {
    client_id: profile.api.clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: `openid email ${youtube.YOUTUBE_SCOPE}`,
    access_type: 'offline',
    prompt: 'consent select_account',
    include_granted_scopes: 'true',
    state
  };
  for (const [key, value] of Object.entries(parameters)) url.searchParams.set(key, value);
  return { ok: true, url: url.toString(), redirectUri, profileId: profile.profileNumber };
}

function validBefore(value, fallback = Number.MAX_SAFE_INTEGER) {
  if (value === undefined) return fallback;
  const number = Number(value);
  return validation.integer(number, 'Cursor', 1, Number.MAX_SAFE_INTEGER);
}

async function resolveChannel(value) {
  const normalized = normalizeChannelInput(value);
  try {
    return { channel: await resolveChannelInput(value), warning: '' };
  } catch (error) {
    if (!error.networkFailure && (!error.status || error.status < 500)) throw error;
    return { channel: normalized, warning: 'Canal salvo, mas o YouTube não respondeu agora. A identificação será completada na próxima busca global.' };
  }
}

function clientId(value, required = false) {
  const result = validation.string(value, 'Client ID', 300, required);
  if (result && !/^[a-zA-Z\d._-]+\.apps\.googleusercontent\.com$/.test(result)) validation.invalid('Client ID Google inválido.');
  return result;
}

function administrativeApiKey(value) {
  const result = validation.string(value, 'Chave da API', 200);
  if (!/^AIza[A-Za-z0-9_-]{20,100}$/.test(result)) validation.invalid('Informe uma chave válida da API do Google, iniciada por AIza.');
  return result;
}

function administrativeKeyHint(value) {
  return `${value.slice(0, 6)}…${value.slice(-4)}`;
}

function administrativeKeyFingerprint(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function legacyProfileInput(body, old = {}) {
  const name = validation.string(body.name ?? old.name, 'Nome do perfil', 100);
  const id = clientId(body.clientId ?? old.clientId, true);
  const secret = body.clientSecret ? validation.string(body.clientSecret, 'Client Secret', 300) : '';
  if (!secret && !old.clientSecretEnc) validation.invalid('Informe o Client Secret.');
  return {
    ...old,
    name,
    clientId: id,
    clientSecretEnc: secret ? security.encryptText(secret) : old.clientSecretEnc,
    active: body.active === undefined ? old.active !== false : validation.boolean(body.active, 'Status')
  };
}

function oauthHtml(ok, message, client = 'app', number = 1) {
  const web = client === 'web';
  const scheme = client === 'legacy' ? 'peraltachat' : 'autoserver';
  const target = web ? `/painel?oauth=${ok ? 'ok' : 'erro'}&profile=${number}` : `${scheme}://oauth-complete?ok=${ok ? '1' : '0'}&profile=${number}`;
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Autorização YouTube</title><link rel="stylesheet" href="/admin.css"></head><body data-oauth-target="${escape(target)}"><main class="shell card"><h1>${ok ? 'Conta autorizada' : 'Autorização não concluída'}</h1><p>${escape(message)}</p><a class="button" href="${escape(target)}">${web ? 'VOLTAR AO PAINEL' : 'VOLTAR AO APLICATIVO'}</a></main><script src="/oauth-result.js"></script></body></html>`;
}

function createApp() {
  security.validateEnvironment();
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 'loopback, linklocal, uniquelocal');
  app.use((req, res, next) => {
    res.set({
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      'X-Frame-Options': 'DENY',
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
    });
    if (req.path.startsWith('/api/') || req.path.startsWith('/dbmadmin') || req.path.startsWith('/painel') || req.path.startsWith('/oauth/')) res.set('Cache-Control', 'no-store');
    next();
  });
  app.use(express.json({ limit: '128kb' }));
  app.use(cookieParser());
  app.use((req, res, next) => {
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      if (req.headers.origin && req.headers.origin !== origin.origin) return fail(res, 403, 'Origem da solicitação não autorizada.');
      if (!req.is('application/json')) return fail(res, 415, 'Envie JSON nesta operação.');
    }
    next();
  });
  app.use(express.static(path.join(__dirname, 'public'), { index: false, dotfiles: 'deny' }));

  const userAuth = requireSession('user');
  const adminAuth = requireSession('admin');
  const loginLimit = rateLimit(40, 900000, req => req.ip);
  const accountLimit = rateLimit(12, 900000, req => `${req.ip}|${String(req.body?.username || req.body?.email || '').toLowerCase().slice(0, 64)}`);
  const csrf = (req, res, next) => security.equal(req.headers['x-csrf-token'], security.csrf(req.session.sid)) ? next() : fail(res, 403, 'Sessão do painel mudou. Atualize a página.');
  const userCsrf = (req, res, next) => req.authSource === 'bearer' ? next() : csrf(req, res, next);
  const userWrite = [userAuth, userCsrf];
  const adminWrite = [adminAuth, csrf];

  app.get('/health', (_req, res) => {
    try {
      if (!store.health()) return fail(res, 503, 'Instância indisponível.');
      res.json({ ok: true, version: VERSION, schemaVersion: store.schemaVersion(), storage: 'ok', time: store.now() });
    } catch {
      return fail(res, 503, 'Armazenamento indisponível.');
    }
  });
  app.get('/api/info', (_req, res) => res.json({ ok: true, version: VERSION, privacyUrl: `${base}/privacy`, termsUrl: 'https://www.youtube.com/t/terms', panelUrl: `${base}/painel`, minClientVersion: '2.1.0', profiles: store.DEFAULT_PROFILE_COUNT, maxProfiles: store.MAX_PROFILES_PER_USER }));
  app.get('/api/web/bootstrap', (req, res) => {
    try {
      const current = readSession(req.cookies[USER_COOKIE], 'user');
      res.json({ ok: true, authenticated: true, csrfToken: security.csrf(current.p.sid), user: store.publicUser(current.user), version: VERSION });
    } catch {
      res.json({ ok: true, authenticated: false, csrfToken: '', version: VERSION });
    }
  });
  app.post('/api/login', loginLimit, accountLimit, async (req, res) => {
    const username = validation.username(req.body.username ?? req.body.email);
    const password = String(req.body.password || '');
    if (password.length > 200) return fail(res, 401, 'Usuário ou senha inválidos.');
    const old = store.findUserByUsername(username);
    if (!old || !old.active || !await bcrypt.compare(password, old.passwordHash)) return fail(res, 401, 'Usuário ou senha inválidos.');
    const latest = store.getUser(old.id);
    if (!latest?.active || latest.passwordHash !== old.passwordHash) return fail(res, 401, 'Credenciais alteradas. Entre novamente.');
    if (req.body.privacyAccepted !== true) return fail(res, 400, 'Leia e aceite a política de privacidade antes de entrar.');
    store.updateUser(latest.id, user => {
      user.privacyAcceptedAt = store.now();
      user.privacyVersion = '2026-09-13';
    });
    res.json({ ok: true, token: issue(res, latest, 'user'), user: store.publicUser(latest) });
  });
  app.post('/api/logout', ...userWrite, (req, res) => {
    store.revokeSession(req.session.sid);
    res.clearCookie(USER_COOKIE, { path: '/' });
    res.json({ ok: true });
  });
  app.get('/api/me', userAuth, (req, res) => res.json({ ok: true, user: store.publicUser(req.user) }));

  // Compatibilidade: as rotas históricas do Android continuam operando no Perfil 1.
  app.get('/api/state', userAuth, (req, res) => res.json(profileState(req.user, 1)));
  app.get('/api/logs', userAuth, (req, res) => res.json({ ok: true, logs: store.logs(req.user.id, 1, 100, validBefore(req.query.before)) }));
  app.post('/api/logs/clear', ...userWrite, (req, res) => {
    store.clearLogs(req.user.id, 1);
    res.json({ ok: true });
  });
  app.put('/api/config', ...userWrite, (req, res) => {
    const profile = updateProfileConfig(req.user.id, 1, req.body);
    res.json({ ok: true, config: store.profileConfigForClient(profile) });
  });
  app.post('/api/control/:action', ...userWrite, (req, res) => {
    const profile = runProfileControl(req.user.id, 1, req.params.action);
    auditUserRequest(req, `profile_${req.params.action}`, 1);
    res.json({ ok: true, action: req.params.action, profile: store.publicProfile(profile) });
  });
  app.get('/api/oauth/start', userAuth, (req, res) => {
    const client = oauthClient(req);
    const result = oauthStart(req.user, ownedProfile(req.user.id, 1), client);
    auditUserRequest(req, 'youtube_oauth_start', 1, client);
    res.json(result);
  });
  app.post('/api/oauth/disconnect', ...userWrite, async (req, res) => {
    const profile = ownedProfile(req.user.id, 1);
    const token = profile.oauth.refreshTokenEnc;
    store.updateUserProfile(req.user.id, 1, current => invalidateProfileOAuth(current, 'Conta do YouTube desconectada.'));
    store.deleteOAuthAttempts(req.user.id, 1);
    workers.wake(req.user.id, 1);
    auditUserRequest(req, 'youtube_disconnect', 1);
    let warning = '';
    try { await youtube.revoke(token); } catch { warning = 'Acesso removido deste servidor. Confira também as permissões da sua Conta Google.'; }
    res.json({ ok: true, warning });
  });

  app.get('/api/profiles', userAuth, (req, res) => res.json({ ok: true, profiles: store.userProfiles(req.user.id).map(store.publicProfile), globalMonitoring: store.monitorSnapshot() }));
  app.get('/api/profiles/:profileId', userAuth, (req, res) => res.json(profileState(req.user, req.params.profileId)));
  app.get('/api/profiles/:profileId/status', userAuth, (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    res.json({ ok: true, profileId: profile.profileNumber, ...runtimePayload(profile) });
  });
  for (const action of ['start', 'pause', 'stop']) {
    app.post(`/api/profiles/:profileId/${action}`, ...userWrite, (req, res) => {
      const number = profileNumber(req.params.profileId);
      const profile = runProfileControl(req.user.id, number, action);
      auditUserRequest(req, `profile_${action}`, number);
      res.json({ ok: true, action, profile: store.publicProfile(profile) });
    });
  }
  app.get('/api/profiles/:profileId/messages', userAuth, (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    res.json({ ok: true, profileId: profile.profileNumber, messages: profile.config.messages, version: profile.config.version });
  });
  app.put('/api/profiles/:profileId/messages', ...userWrite, (req, res) => {
    const number = profileNumber(req.params.profileId);
    const messages = Array.isArray(req.body.messages) ? req.body.messages.join('\n') : req.body.messages;
    const profile = updateProfileConfig(req.user.id, number, { messages, expectedVersion: req.body.expectedVersion });
    res.json({ ok: true, messages: profile.config.messages, version: profile.config.version });
  });
  app.get('/api/profiles/:profileId/settings', userAuth, (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    res.json({ ok: true, profileId: profile.profileNumber, settings: store.profileConfigForClient(profile) });
  });
  app.put('/api/profiles/:profileId/settings', ...userWrite, (req, res) => {
    const number = profileNumber(req.params.profileId);
    const profile = updateProfileConfig(req.user.id, number, req.body);
    res.json({ ok: true, settings: store.profileConfigForClient(profile) });
  });
  app.get('/api/profiles/:profileId/logs', userAuth, (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    const limit = req.query.limit === undefined ? 20 : validation.integer(Number(req.query.limit), 'Limite', 1, 100);
    res.json({ ok: true, profileId: profile.profileNumber, logs: store.logs(req.user.id, profile.profileNumber, limit, validBefore(req.query.before)) });
  });
  app.post('/api/profiles/:profileId/logs/clear', ...userWrite, (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    store.clearLogs(req.user.id, profile.profileNumber);
    auditUserRequest(req, 'profile_logs_clear', profile.profileNumber);
    res.json({ ok: true });
  });
  app.get('/api/profiles/:profileId/channels', userAuth, (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    res.json({ ok: true, profileId: profile.profileNumber, channels: store.profileChannels(req.user.id, profile.profileNumber) });
  });
  app.post('/api/profiles/:profileId/channels', ...userWrite, async (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    if (store.profileChannels(req.user.id, profile.profileNumber).length >= 1) {
      validation.invalid('Este perfil já possui um canal. Remova o canal atual antes de adicionar outro.', 409);
    }
    const input = validation.string(req.body.channel ?? req.body.channelInput ?? req.body.url, 'Canal', 2048);
    const resolved = await resolveChannel(input);
    const globalChannel = store.upsertGlobalChannel(resolved.channel);
    const subscription = store.subscribeChannel(req.user.id, profile.profileNumber, globalChannel, input);
    disableLegacyLiveTarget(req.user.id, profile.profileNumber);
    workers.invalidateTargets(req.user.id, profile.profileNumber);
    setImmediate(() => globalMonitor.scan({ manual: true }).catch(error => console.error('Busca após cadastro:', error.message)));
    res.status(201).json({ ok: true, channel: subscription, warning: resolved.warning });
  });
  app.put('/api/profiles/:profileId/channels', ...userWrite, async (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    if (!Array.isArray(req.body.channels) || req.body.channels.length > 1) validation.invalid('Informe no máximo um canal por perfil.');
    const inputs = req.body.channels.map(value => validation.string(value, 'Canal', 2048));
    const resolved = [];
    for (const input of inputs) resolved.push({ input, ...(await resolveChannel(input)) });
    const retained = new Set();
    const warnings = [];
    for (const item of resolved) {
      const globalChannel = store.upsertGlobalChannel(item.channel);
      for (const current of store.profileChannels(req.user.id, profile.profileNumber)) {
        if (current.globalChannelId !== globalChannel.id) store.removeSubscription(req.user.id, profile.profileNumber, current.id);
      }
      store.subscribeChannel(req.user.id, profile.profileNumber, globalChannel, item.input);
      retained.add(globalChannel.id);
      if (item.warning) warnings.push(`${item.input}: ${item.warning}`);
    }
    for (const current of store.profileChannels(req.user.id, profile.profileNumber)) if (!retained.has(current.globalChannelId)) store.removeSubscription(req.user.id, profile.profileNumber, current.id);
    if (retained.size) disableLegacyLiveTarget(req.user.id, profile.profileNumber);
    workers.invalidateTargets(req.user.id, profile.profileNumber);
    setImmediate(() => globalMonitor.scan({ manual: true }).catch(error => console.error('Busca após atualização:', error.message)));
    res.json({ ok: true, channels: store.profileChannels(req.user.id, profile.profileNumber), warnings });
  });
  app.delete('/api/profiles/:profileId/channels/:channelId', ...userWrite, (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    if (!store.removeSubscription(req.user.id, profile.profileNumber, req.params.channelId)) return fail(res, 404, 'Canal não encontrado neste perfil.');
    workers.invalidateTargets(req.user.id, profile.profileNumber);
    res.json({ ok: true });
  });
  const profileOauthStart = (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    const client = oauthClient(req);
    const result = oauthStart(req.user, profile, client);
    auditUserRequest(req, 'youtube_oauth_start', profile.profileNumber, client);
    res.json(result);
  };
  app.get('/api/profiles/:profileId/oauth/connect', userAuth, profileOauthStart);
  app.post('/api/profiles/:profileId/oauth/connect', ...userWrite, profileOauthStart);
  app.post('/api/profiles/:profileId/oauth/disconnect', ...userWrite, async (req, res) => {
    const profile = ownedProfile(req.user.id, req.params.profileId);
    const token = profile.oauth.refreshTokenEnc;
    store.updateUserProfile(req.user.id, profile.profileNumber, current => invalidateProfileOAuth(current, 'Conta do YouTube desconectada.'));
    store.deleteOAuthAttempts(req.user.id, profile.profileNumber);
    workers.wake(req.user.id, profile.profileNumber);
    auditUserRequest(req, 'youtube_disconnect', profile.profileNumber);
    let warning = '';
    try { await youtube.revoke(token); } catch { warning = 'Acesso removido deste servidor. Confira também as permissões da sua Conta Google.'; }
    res.json({ ok: true, warning });
  });
  app.get('/api/global-monitor', userAuth, (_req, res) => res.json({ ok: true, monitoring: store.monitorSnapshot() }));
  app.get('/api/global-monitor/settings', userAuth, (_req, res) => res.json({
    ok: true,
    liveDiscoveryIntervalSeconds: store.globalDiscoveryIntervalSeconds(),
    chatAvailabilityRetrySeconds: store.chatAvailabilityRetrySeconds()
  }));
  app.patch(['/api/global-monitor', '/api/global-monitor/settings'], userAuth, (_req, res) => fail(res, 403, 'Somente o administrador pode alterar as configurações globais.'));

  app.get('/oauth/google/callback', async (req, res) => {
    const stateValue = String(req.query.state || '');
    const client = stateValue.startsWith('w.') ? 'web' : stateValue.startsWith('l.') ? 'legacy' : 'app';
    let number = 1;
    try {
      const attempt = store.consumeOAuthAttempt(stateValue);
      if (!attempt) throw new Error('Autorização expirada ou já utilizada. Inicie novamente pelo painel.');
      number = attempt.profile_number;
      if (req.query.error) throw new Error(req.query.error === 'access_denied' ? 'Autorização cancelada. Nenhuma nova conta foi conectada.' : 'Google recusou a autorização. Inicie novamente pelo painel.');
      const user = store.getUser(attempt.user_id);
      const profile = store.getUserProfile(attempt.user_id, attempt.profile_number);
      if (!user?.active || !profile?.enabled || profile.id !== attempt.profile_id || profile.oauth.version !== attempt.version || profile.api.version !== attempt.api_version) {
        throw new Error('Cadastro do perfil alterado. Inicie a autorização novamente.');
      }
      const tokens = await youtube.jsonFetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code: String(req.query.code || ''),
          client_id: profile.api.clientId,
          client_secret: security.decryptText(profile.api.clientSecretEnc),
          redirect_uri: redirectUri,
          grant_type: 'authorization_code'
        })
      });
      const info = await youtube.jsonFetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tokens.access_token}` } });
      if (info.email_verified !== true) throw new Error('A Conta Google não possui e-mail verificado.');
      if (profile.googleEmail && String(info.email || '').toLowerCase() !== profile.googleEmail) throw new Error('Use exatamente a Conta Google autorizada para este perfil.');
      if (!String(tokens.scope || '').split(/\s+/).includes(youtube.YOUTUBE_SCOPE)) throw new Error('Permissão do YouTube não concedida. Refaça a autorização e aceite a permissão solicitada.');
      if (!tokens.refresh_token || !tokens.access_token) throw new Error('Google não retornou autorização offline. Revise o consentimento e tente novamente.');
      const expires = Math.min(86400, Math.max(60, Number(tokens.expires_in) || 3600));
      const previousToken = profile.oauth.refreshTokenEnc;
      const previousEmail = String(profile.oauth.email || '').toLowerCase();
      const updated = store.updateUserProfile(user.id, profile.profileNumber, current => {
        if (!current.enabled || current.id !== attempt.profile_id || current.oauth.version !== attempt.version || current.api.version !== attempt.api_version || current.googleEmail !== profile.googleEmail) {
          validation.invalid('Cadastro alterado durante a autorização. Tente novamente.', 409);
        }
        current.oauth = {
          email: String(info.email || '').toLowerCase(),
          refreshTokenEnc: security.encryptText(tokens.refresh_token),
          accessTokenEnc: security.encryptText(tokens.access_token),
          accessTokenExpiresAt: Date.now() + (expires - 30) * 1000,
          scope: tokens.scope,
          version: current.oauth.version + 1
        };
        holdProfileForOAuthChange(current);
        current.runtime.lastError = '';
        store.appendLog(current, 'oauth', 'Conta YouTube autorizada. Confira os canais e inicie o perfil.', 'success');
      });
      if (!updated) throw new Error('Usuário removido durante a autorização.');
      if (previousToken && previousEmail && previousEmail !== String(info.email || '').toLowerCase()) {
        try { await youtube.revoke(previousToken); }
        catch { store.appendGlobalEvent('oauth', `Perfil ${profile.profileNumber}: autorização anterior substituída, mas a revogação remota não foi confirmada.`, 'error'); }
      }
      store.audit(user.id, 'youtube_oauth_authorized', requestAuditTarget(req, profile.profileNumber, client));
      workers.wake(user.id, profile.profileNumber);
      res.type('html').send(oauthHtml(true, `Conta autorizada no Perfil ${profile.profileNumber}.`, client, profile.profileNumber));
    } catch (error) {
      res.status(400).type('html').send(oauthHtml(false, error.message || 'Falha na autorização.', client, number));
    }
  });

  app.delete('/api/account', ...userWrite, async (req, res) => {
    const tokens = store.userProfiles(req.user.id).map(profile => profile.oauth.refreshTokenEnc).filter(Boolean);
    for (const profile of store.userProfiles(req.user.id)) workers.stop(req.user.id, profile.profileNumber);
    store.audit(req.user.id, 'account_delete', requestAuditTarget(req, 'todos'));
    store.deleteUser(req.user.id);
    res.clearCookie(USER_COOKIE, { path: '/' });
    await Promise.allSettled(tokens.map(token => youtube.revoke(token)));
    res.json({ ok: true });
  });

  app.get('/', (_req, res) => res.redirect(302, '/painel'));
  app.get('/painel', (_req, res) => res.sendFile(path.join(__dirname, 'public/panel.html')));
  app.get('/dbmadmin', (_req, res) => res.sendFile(path.join(__dirname, 'public/admin.html')));

  app.get('/dbmadmin/api/bootstrap', (req, res) => {
    const needsSetup = store.admins().length === 0;
    if (needsSetup) return res.json({ ok: true, needsSetup: true, authenticated: false });
    try {
      const current = readSession(req.cookies[ADMIN_COOKIE], 'admin');
      res.json({ ok: true, needsSetup: false, authenticated: true, csrfToken: security.csrf(current.p.sid), admin: { id: current.user.id, username: current.user.username } });
    } catch {
      res.json({ ok: true, needsSetup: false, authenticated: false });
    }
  });
  app.post('/dbmadmin/api/setup', loginLimit, accountLimit, async (req, res) => {
    if (!security.equal(req.body.setupToken, process.env.SETUP_TOKEN)) return fail(res, 403, 'Código de instalação inválido. Consulte o arquivo ACESSO_INICIAL.txt na VPS.');
    if (store.admins().length) return fail(res, 409, 'Administrador inicial já criado.');
    const username = validation.string(req.body.username, 'Usuário', 64);
    if (username.length < 3) validation.invalid('Usuário deve ter no mínimo 3 caracteres.');
    const hash = await bcrypt.hash(validation.password(req.body.password), 12);
    const admin = { id: store.id('adm'), username, passwordHash: hash, active: true, sessionVersion: 1, createdAt: store.now() };
    if (!store.createFirstAdmin(admin)) return fail(res, 409, 'Administrador inicial já criado.');
    store.audit(admin.id, 'setup');
    issue(res, admin, 'admin');
    res.json({ ok: true });
  });
  app.post('/dbmadmin/api/login', loginLimit, accountLimit, async (req, res) => {
    const admin = store.findAdmin(String(req.body.username || '').trim());
    const password = String(req.body.password || '');
    if (password.length > 200 || !admin?.active || !await bcrypt.compare(password, admin.passwordHash)) return fail(res, 401, 'Usuário ou senha inválidos.');
    const latest = store.getAdmin(admin.id);
    if (!latest?.active || latest.passwordHash !== admin.passwordHash) return fail(res, 401, 'Credenciais alteradas. Entre novamente.');
    issue(res, latest, 'admin');
    store.audit(admin.id, 'login');
    res.json({ ok: true });
  });
  app.post('/dbmadmin/api/logout', ...adminWrite, (req, res) => {
    store.revokeSession(req.session.sid);
    res.clearCookie(ADMIN_COOKIE, { path: '/dbmadmin' });
    res.json({ ok: true });
  });
  app.post('/dbmadmin/api/password', ...adminWrite, async (req, res) => {
    if (!await bcrypt.compare(String(req.body.currentPassword || ''), req.admin.passwordHash)) return fail(res, 401, 'Senha atual incorreta.');
    const hash = await bcrypt.hash(validation.password(req.body.password), 12);
    store.updateAdmin(req.admin.id, admin => {
      if (admin.passwordHash !== req.admin.passwordHash) validation.invalid('Senha já alterada. Entre novamente.', 401);
      admin.passwordHash = hash;
      admin.sessionVersion++;
    });
    store.revokeSessions(req.admin.id);
    store.audit(req.admin.id, 'admin_password');
    res.clearCookie(ADMIN_COOKIE, { path: '/dbmadmin' });
    res.json({ ok: true });
  });
  app.get('/dbmadmin/api/data', adminAuth, (_req, res) => res.json({
    ok: true,
    apiProfiles: store.profiles().map(profile => ({ id: profile.id, name: profile.name, clientId: profile.clientId, active: profile.active, version: profile.version })),
    verificationKeys: store.publicAdminVerificationKeys(),
    verificationUsageToday: store.adminVerificationUsageTotals(),
    users: store.users().map(store.publicUser),
    profileDefaults: { defaultCount: store.DEFAULT_PROFILE_COUNT, maxCount: store.MAX_PROFILES_PER_USER },
    globalMonitoring: store.monitorSnapshot(),
    apiUsageToday: store.apiUsageTotals()
  }));
  app.get('/dbmadmin/api/diagnostics', adminAuth, (_req, res) => res.json({
    ok: true,
    version: VERSION,
    node: process.version,
    storage: store.health() ? 'ok' : 'error',
    schemaVersion: store.schemaVersion(),
    https: origin.protocol === 'https:',
    publicBaseUrl: base,
    redirectUri,
    workers: workers.activeCount(),
    users: store.users().length,
    globalMonitoring: store.monitorSnapshot(),
    apiUsageToday: store.apiUsageTotals(),
    administrativeVerification: {
      keys: store.publicAdminVerificationKeys(),
      usageToday: store.adminVerificationUsageTotals(),
      requestsInFlight: adminLiveVerifier.activeRequests()
    },
    uptimeSeconds: Math.floor(process.uptime())
  }));
  app.get('/dbmadmin/api/audit', adminAuth, (_req, res) => res.json({ ok: true, events: store.auditLog() }));
  app.get('/dbmadmin/api/users/:id/logs', adminAuth, (req, res) => {
    const number = req.query.profileId === undefined ? 1 : profileNumber(req.query.profileId);
    res.json({ ok: true, profileId: number, logs: store.logs(req.params.id, number, 100) });
  });

  app.post('/dbmadmin/api/verification-keys', ...adminWrite, (req, res) => {
    const name = validation.string(req.body.name, 'Nome da chave', 80);
    const apiKey = administrativeApiKey(req.body.apiKey);
    const fingerprint = administrativeKeyFingerprint(apiKey);
    if (store.findAdminVerificationKeyByFingerprint(fingerprint)) validation.invalid('Esta chave administrativa já está cadastrada.', 409);
    const key = store.createAdminVerificationKey({
      name,
      apiKeyEnc: security.encryptText(apiKey),
      keyHint: administrativeKeyHint(apiKey),
      keyFingerprint: fingerprint,
      enabled: req.body.enabled === undefined ? true : validation.boolean(req.body.enabled, 'Status')
    });
    store.audit(req.admin.id, 'admin_verification_key_create', key.id);
    store.appendGlobalEvent('admin-verification', `Chave administrativa ${key.name} cadastrada.`, 'success');
    res.status(201).json({ ok: true, key: store.publicAdminVerificationKey(key), keys: store.publicAdminVerificationKeys() });
  });

  app.patch('/dbmadmin/api/verification-keys/:id', ...adminWrite, (req, res) => {
    const patch = {};
    if (req.body.name !== undefined) patch.name = validation.string(req.body.name, 'Nome da chave', 80);
    if (req.body.enabled !== undefined) patch.enabled = validation.boolean(req.body.enabled, 'Status');
    if (req.body.makePrimary !== undefined) patch.makePrimary = validation.boolean(req.body.makePrimary, 'Chave principal');
    if (!Object.keys(patch).length) validation.invalid('Informe uma alteração para a chave administrativa.');
    const key = store.updateAdminVerificationKey(req.params.id, patch);
    if (!key) return fail(res, 404, 'Chave administrativa não encontrada.');
    store.audit(req.admin.id, 'admin_verification_key_update', key.id);
    store.appendGlobalEvent('admin-verification', `Chave administrativa ${key.name} atualizada.`);
    res.json({ ok: true, key: store.publicAdminVerificationKey(key), keys: store.publicAdminVerificationKeys() });
  });

  app.post('/dbmadmin/api/verification-keys/:id/test', ...adminWrite, async (req, res) => {
    const key = store.getAdminVerificationKey(req.params.id);
    if (!key) return fail(res, 404, 'Chave administrativa não encontrada.');
    const result = await adminLiveVerifier.testKey(key.id);
    store.audit(req.admin.id, 'admin_verification_key_test', key.id);
    if (!result.ok) {
      store.appendGlobalEvent('admin-verification', `Teste da chave ${key.name} falhou: ${result.error}`, 'error');
      return fail(res, 422, result.error || 'A chave não passou no teste.', { keys: store.publicAdminVerificationKeys() });
    }
    store.appendGlobalEvent('admin-verification', `Chave administrativa ${key.name} testada com sucesso.`, 'success');
    res.json({ ok: true, message: 'Chave validada na YouTube Data API.', keys: store.publicAdminVerificationKeys() });
  });

  app.delete('/dbmadmin/api/verification-keys/:id', ...adminWrite, (req, res) => {
    const key = store.deleteAdminVerificationKey(req.params.id);
    if (!key) return fail(res, 404, 'Chave administrativa não encontrada.');
    store.audit(req.admin.id, 'admin_verification_key_delete', key.id);
    store.appendGlobalEvent('admin-verification', `Chave administrativa ${key.name} excluída.`);
    res.json({ ok: true, deletedKey: key.id, keys: store.publicAdminVerificationKeys() });
  });

  app.get('/dbmadmin/api/global-monitor', adminAuth, (_req, res) => res.json({ ok: true, monitoring: store.monitorSnapshot() }));
  app.get('/dbmadmin/api/global-monitor/events', adminAuth, (req, res) => {
    const limit = req.query.limit === undefined ? 100 : validation.integer(Number(req.query.limit), 'Limite', 1, 500);
    res.json({ ok: true, events: store.globalEvents(limit) });
  });
  app.patch('/dbmadmin/api/global-monitor', ...adminWrite, (req, res) => {
    const hasDiscoveryInterval = req.body.liveDiscoveryIntervalSeconds !== undefined || req.body.intervalMinutes !== undefined;
    const hasChatRetry = req.body.chatAvailabilityRetrySeconds !== undefined || req.body.chatRetrySeconds !== undefined;
    if (!hasDiscoveryInterval && !hasChatRetry) validation.invalid('Informe pelo menos uma configuração global.');
    const discoverySeconds = hasDiscoveryInterval
      ? req.body.liveDiscoveryIntervalSeconds !== undefined
        ? validation.integer(req.body.liveDiscoveryIntervalSeconds, 'Intervalo global', 60, 3600)
        : validation.integer(req.body.intervalMinutes, 'Intervalo global em minutos', 1, 60) * 60
      : null;
    const chatRetrySeconds = hasChatRetry
      ? validation.integer(
          req.body.chatAvailabilityRetrySeconds ?? req.body.chatRetrySeconds,
          'Espera para consultar o chat',
          15,
          3600
        )
      : null;
    if (discoverySeconds !== null) {
      store.setGlobalSetting('live_discovery_interval_seconds', discoverySeconds, req.admin.id);
      store.audit(req.admin.id, 'global_monitor_interval', String(discoverySeconds));
      store.appendGlobalEvent('settings', `Intervalo global alterado para ${discoverySeconds} segundos pelo administrador.`);
      globalMonitor.reschedule();
    }
    if (chatRetrySeconds !== null) {
      store.setGlobalSetting('chat_availability_retry_seconds', chatRetrySeconds, req.admin.id);
      store.audit(req.admin.id, 'chat_availability_retry_interval', String(chatRetrySeconds));
      store.appendGlobalEvent('settings', `Espera para consultar o chat alterada para ${chatRetrySeconds} segundos pelo administrador.`);
      workers.rescheduleChatRetries();
    }
    res.json({ ok: true, monitoring: store.monitorSnapshot() });
  });
  app.post('/dbmadmin/api/global-monitor/scan', ...adminWrite, (req, res) => {
    const started = !globalMonitor.isRunning();
    setImmediate(() => globalMonitor.scan({ manual: true }).catch(error => console.error('Busca global manual:', error.message)));
    store.audit(req.admin.id, 'global_monitor_scan');
    res.status(202).json({ ok: true, started });
  });

  // Perfis API globais antigos são preservados para migração e compatibilidade administrativa.
  app.post('/dbmadmin/api/profiles', ...adminWrite, (req, res) => {
    const profile = legacyProfileInput(req.body);
    profile.id = store.id('api');
    profile.version = 1;
    profile.createdAt = store.now();
    store.putProfile(profile);
    store.audit(req.admin.id, 'legacy_api_profile_create', profile.id);
    res.json({ ok: true, id: profile.id });
  });
  app.patch('/dbmadmin/api/profiles/:id', ...adminWrite, (req, res) => {
    const old = store.getProfile(req.params.id);
    if (!old) return fail(res, 404, 'Perfil API legado não encontrado.');
    const profile = legacyProfileInput(req.body, old);
    profile.version = old.version + 1;
    store.putProfile(profile);
    store.audit(req.admin.id, 'legacy_api_profile_update', profile.id);
    res.json({ ok: true });
  });
  app.delete('/dbmadmin/api/profiles/:id', ...adminWrite, (req, res) => {
    if (!store.deleteProfile(req.params.id)) return fail(res, 409, 'Este perfil legado ainda está associado a um cadastro antigo.');
    store.audit(req.admin.id, 'legacy_api_profile_delete', req.params.id);
    res.json({ ok: true });
  });

  app.post('/dbmadmin/api/users', ...adminWrite, async (req, res) => {
    const username = validation.username(req.body.username ?? req.body.email);
    const hash = await bcrypt.hash(validation.password(req.body.password), 12);
    const active = req.body.active === undefined ? true : validation.boolean(req.body.active, 'Status');
    const googleEmail = req.body.googleEmail ? validation.email(req.body.googleEmail) : '';
    const legacy = req.body.apiProfileId ? store.getProfile(String(req.body.apiProfileId)) : null;
    if (req.body.apiProfileId && !legacy) validation.invalid('Perfil API legado não encontrado.');
    const user = store.createUser({ id: store.id('usr'), username, passwordHash: hash, active, sessionVersion: 1, createdAt: store.now() });
    if (googleEmail || legacy) {
      store.updateUserProfile(user.id, 1, profile => {
        if (googleEmail) profile.googleEmail = googleEmail;
        if (legacy) profile.api = { clientId: legacy.clientId, clientSecretEnc: legacy.clientSecretEnc, version: legacy.version || 1 };
      });
    }
    store.audit(req.admin.id, 'user_create', user.id);
    res.status(201).json({ ok: true, id: user.id, user: store.publicUser(store.getUser(user.id)) });
  });
  app.post('/dbmadmin/api/users/:id/profiles', ...adminWrite, (req, res) => {
    const profile = store.addUserProfile(req.params.id);
    if (!profile) return fail(res, 404, 'Usuário não encontrado.');
    store.appendLog(profile, 'system', `Perfil ${profile.profileNumber} adicionado pelo administrador.`, 'success');
    store.audit(req.admin.id, 'user_profile_create', `${req.params.id}:${profile.profileNumber}`);
    res.status(201).json({ ok: true, profile: store.publicProfile(profile), user: store.publicUser(store.getUser(req.params.id)) });
  });
  app.delete('/dbmadmin/api/users/:id/profiles/:profileId', ...adminWrite, async (req, res) => {
    const user = store.getUser(req.params.id);
    if (!user) return fail(res, 404, 'Usuário não encontrado.');
    const number = profileNumber(req.params.profileId);
    if (number <= store.DEFAULT_PROFILE_COUNT) {
      return fail(res, 409, 'Os Perfis 1, 2 e 3 são permanentes e não podem ser excluídos.');
    }
    const profile = store.getUserProfile(user.id, number);
    if (!profile) return fail(res, 404, 'Perfil não encontrado.');
    const token = profile.oauth.refreshTokenEnc;

    let removed;
    try {
      await workers.retireProfile(user.id, number);
      removed = store.deleteUserProfile(user.id, number);
    } finally {
      workers.releaseProfile(user.id, number);
    }
    if (!removed) return fail(res, 404, 'Perfil não encontrado.');

    store.audit(req.admin.id, 'user_profile_delete', `${user.id}:${number}`);
    if (token) {
      try { await youtube.revoke(token); } catch {}
    }
    res.json({
      ok: true,
      deletedProfile: number,
      user: store.publicUser(store.getUser(user.id))
    });
  });
  app.patch('/dbmadmin/api/users/:id', ...adminWrite, async (req, res) => {
    const old = store.getUser(req.params.id);
    if (!old) return fail(res, 404, 'Usuário não encontrado.');
    const patch = {};
    if (req.body.username !== undefined || req.body.email !== undefined) patch.username = validation.username(req.body.username ?? req.body.email);
    if (req.body.active !== undefined) patch.active = validation.boolean(req.body.active, 'Status');
    if (req.body.password) patch.passwordHash = await bcrypt.hash(validation.password(req.body.password), 12);
    const user = store.updateUser(old.id, current => {
      Object.assign(current, patch);
      if (patch.passwordHash || patch.active === false) {
        current.sessionVersion++;
        store.revokeSessions(current.id);
      }
    });
    if (patch.active === false) for (const profile of store.userProfiles(user.id)) workers.stop(user.id, profile.profileNumber, false);
    if (req.body.googleEmail !== undefined || req.body.apiProfileId !== undefined) {
      const profile = store.getUserProfile(user.id, 1);
      const legacy = req.body.apiProfileId !== undefined ? store.getProfile(String(req.body.apiProfileId)) : null;
      const token = profile.oauth.refreshTokenEnc;
      store.updateUserProfile(user.id, 1, current => {
        if (req.body.googleEmail !== undefined) current.googleEmail = req.body.googleEmail ? validation.email(req.body.googleEmail) : '';
        if (legacy) current.api = { clientId: legacy.clientId, clientSecretEnc: legacy.clientSecretEnc, version: (current.api.version || 0) + 1 };
        invalidateProfileOAuth(current, 'Configuração administrativa alterada. Conecte o YouTube novamente.');
      });
      store.deleteOAuthAttempts(user.id, 1);
      workers.wake(user.id, 1);
      try { await youtube.revoke(token); } catch {}
    }
    store.audit(req.admin.id, 'user_update', user.id);
    res.json({ ok: true, user: store.publicUser(store.getUser(user.id)) });
  });
  app.patch('/dbmadmin/api/users/:id/profiles/:profileId', ...adminWrite, async (req, res) => {
    const user = store.getUser(req.params.id);
    if (!user) return fail(res, 404, 'Usuário não encontrado.');
    const number = profileNumber(req.params.profileId);
    const old = ownedProfile(user.id, number);
    const nextName = req.body.name === undefined ? old.name : validation.string(req.body.name, 'Nome do perfil', 100);
    const nextEnabled = req.body.enabled === undefined ? old.enabled : validation.boolean(req.body.enabled, 'Status');
    const nextGoogleEmail = req.body.googleEmail === undefined ? old.googleEmail : req.body.googleEmail ? validation.email(req.body.googleEmail) : '';
    const nextClientId = req.body.clientId === undefined ? old.api.clientId : clientId(req.body.clientId, false);
    const suppliedSecret = req.body.clientSecret ? validation.string(req.body.clientSecret, 'Client Secret', 300) : '';
    const nextSecret = req.body.clearCredentials === true ? '' : suppliedSecret ? security.encryptText(suppliedSecret) : old.api.clientSecretEnc;
    if ((nextClientId && !nextSecret) || (!nextClientId && nextSecret)) validation.invalid('Informe Client ID e Client Secret juntos, ou limpe os dois.');
    const identityChanged = nextGoogleEmail !== old.googleEmail || nextClientId !== old.api.clientId || nextSecret !== old.api.clientSecretEnc;
    const token = old.oauth.refreshTokenEnc;
    const updated = store.updateUserProfile(user.id, number, profile => {
      profile.name = nextName;
      profile.enabled = nextEnabled;
      if (identityChanged) {
        profile.googleEmail = nextGoogleEmail;
        profile.api = { clientId: nextClientId, clientSecretEnc: nextSecret, version: (profile.api.version || 0) + 1 };
        invalidateProfileOAuth(profile, 'API ou Conta Google alterada. Conecte o YouTube novamente.');
      }
      if (!profile.enabled) {
        profile.runtime.status = 'stopped';
        profile.runtime.stoppedAt = store.now();
        profile.runtime.epoch++;
        profile.runtime.nextAt = null;
      }
    });
    if (!nextEnabled) workers.stop(user.id, number, false);
    else workers.wake(user.id, number);
    if (identityChanged) {
      store.deleteOAuthAttempts(user.id, number);
      try { await youtube.revoke(token); } catch {}
    }
    store.audit(req.admin.id, 'user_profile_update', `${user.id}:${number}`);
    res.json({ ok: true, profile: store.publicProfile(updated) });
  });
  app.post('/dbmadmin/api/users/:id/revoke', ...adminWrite, (req, res) => {
    const user = store.updateUser(req.params.id, current => {
      current.sessionVersion++;
      store.revokeSessions(current.id);
    });
    if (!user) return fail(res, 404, 'Usuário não encontrado.');
    store.audit(req.admin.id, 'sessions_revoke', user.id);
    res.json({ ok: true });
  });
  app.delete('/dbmadmin/api/users/:id', ...adminWrite, async (req, res) => {
    const user = store.getUser(req.params.id);
    if (!user) return fail(res, 404, 'Usuário não encontrado.');
    const profiles = store.userProfiles(user.id);
    const tokens = profiles.map(profile => profile.oauth.refreshTokenEnc).filter(Boolean);
    for (const profile of profiles) workers.stop(user.id, profile.profileNumber);
    store.deleteUser(user.id);
    await Promise.allSettled(tokens.map(token => youtube.revoke(token)));
    store.audit(req.admin.id, 'user_delete', user.id);
    res.json({ ok: true });
  });

  app.get('/privacy', (_req, res) => res.type('html').send(`<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Privacidade • Auto Server</title>
  <link rel="stylesheet" href="/admin.css">
</head>
<body>
  <main class="shell card">
    <h1>Privacidade e uso</h1>
    <p>O Auto Server cria três perfis independentes por usuário e permite que o administrador acrescente perfis. Cada perfil pode monitorar um canal, usar sua própria Conta Google e enviar as mensagens configuradas enquanto estiver rodando. Fechar o aplicativo, o painel web ou sair da conta não interrompe os workers: use Pausar ou Parar no perfil desejado.</p>
    <p>Este servidor guarda seu nome de usuário, senha protegida por hash, e-mail Google permitido por perfil, permissões Google criptografadas, canais, configurações, contadores e registros recentes. Para segurança e diagnóstico, a auditoria também registra o tipo de cliente, uma identificação não reutilizável da sessão, o endereço IP e o identificador informado pelo navegador ou aplicativo. Esses registros possuem retenção limitada. O administrador pode administrar o cadastro, as configurações de API de cada perfil e o intervalo do monitoramento global. Não coletamos sua senha Google.</p>
    <p>Google/YouTube recebe as autorizações, consultas e mensagens necessárias ao serviço. Você pode desconectar o YouTube, excluir seus dados ou revogar permissões na Conta Google. Backups do operador podem manter cópias durante a retenção informada por ele.</p>
    <p>Operador/contato: ${escape(process.env.OPERATOR_CONTACT || 'consulte o administrador deste servidor')}.</p>
    <p>Use mensagens pertinentes à transmissão e respeite os limites do YouTube. Ao aceitar, você também concorda com os <a href="https://www.youtube.com/t/terms">Termos do YouTube</a>. Consulte a <a href="https://policies.google.com/privacy">Política de Privacidade Google</a> e <a href="https://myaccount.google.com/permissions">suas permissões</a>.</p>
    <p>Versão da política: 13/09/2026.</p>
  </main>
</body>
</html>`));

  app.use((_req, res) => fail(res, 404, 'Endereço não encontrado.'));
  app.use((error, _req, res, _next) => {
    if (res.headersSent) return;
    if (/UNIQUE constraint failed/i.test(error.message)) return fail(res, 409, 'Já existe um cadastro com esse usuário ou vínculo.');
    const status = Number.isInteger(error.status) && error.status >= 400 && error.status < 500 ? error.status : 500;
    if (status === 500) console.error('Erro interno:', error.code || error.name, error.message);
    fail(res, status, status === 500 ? 'Erro interno. Consulte o diagnóstico do servidor.' : error.message);
  });
  return app;
}

if (require.main === module) {
  const app = createApp();
  store.acquireLease();
  const repairedLives = store.repairProtectionChallengeFinalizations();
  if (repairedLives.length) {
    for (const item of repairedLives) {
      store.refreshProfileActiveChats(item.userId, item.profileNumber);
      const profile = store.getUserProfile(item.userId, item.profileNumber);
      if (profile) store.appendLog(profile, 'live', `A live ${item.videoId} foi restaurada porque o encerramento anterior veio de uma validação anti-bot do YouTube.`, 'success');
    }
    store.appendGlobalEvent('repair', `${repairedLives.length} vínculo(s) de live restaurado(s) após falso encerramento causado por validação anti-bot.`, 'success');
  }
  const server = app.listen(Number(process.env.PORT || 8080), process.env.BIND_HOST || '0.0.0.0', () => {
    console.log(`Auto Server ${VERSION} ativo na porta ${server.address().port}.`);
    workers.resumeAll();
    globalMonitor.start();
  });
  let closing = false;
  const heartbeat = setInterval(() => {
    try { if (!store.renewLease()) shutdown(1); }
    catch { shutdown(1); }
  }, 5000);
  heartbeat.unref();

  async function shutdown(code = 0) {
    if (closing) return;
    closing = true;
    clearInterval(heartbeat);
    globalMonitor.stop();
    server.close();
    const force = setTimeout(() => process.exit(1), 35000);
    force.unref();
    await workers.shutdown();
    store.close();
    clearTimeout(force);
    process.exit(code);
  }

  process.on('SIGTERM', () => shutdown());
  process.on('SIGINT', () => shutdown());
  process.on('unhandledRejection', error => {
    console.error('Falha não tratada:', error?.name || 'Error');
    shutdown(1);
  });
  process.on('uncaughtException', error => {
    console.error('Falha fatal:', error.name);
    shutdown(1);
  });
}

module.exports = { createApp, invalidateOAuth, invalidateProfileOAuth, holdProfileForOAuthChange, globalMonitor, VERSION };
