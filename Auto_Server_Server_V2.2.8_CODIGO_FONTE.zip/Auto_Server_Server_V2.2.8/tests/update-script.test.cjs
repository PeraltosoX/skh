'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {spawnSync}=require('node:child_process');

function fixture(healthOk){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'auto-server-update-')),oldDir=path.join(root,'Auto_Server_Server_V2.2.7'),newDir=path.join(root,'Auto_Server_Server_V2.2.8'),bin=path.join(root,'bin'),log=path.join(root,'docker.log');
  fs.mkdirSync(path.join(oldDir,'data'),{recursive:true});fs.mkdirSync(newDir);fs.mkdirSync(bin);
  fs.writeFileSync(path.join(oldDir,'.env'),'APP_PORT=8080\nPUBLIC_BASE_URL=https://example.invalid\nAPP_ENCRYPTION_KEY='+'1'.repeat(64)+'\nJWT_SECRET='+'a'.repeat(64)+'\nSETUP_TOKEN='+'b'.repeat(48)+'\n');
  fs.writeFileSync(path.join(oldDir,'data','peralta.sqlite'),'dados-preservados');fs.writeFileSync(path.join(oldDir,'docker-compose.yml'),'services: {}\n');fs.writeFileSync(path.join(newDir,'docker-compose.yml'),'services: {}\n');
  fs.copyFileSync(path.join(__dirname,'..','ATUALIZAR_SEM_PERDER_DADOS.sh'),path.join(newDir,'ATUALIZAR_SEM_PERDER_DADOS.sh'));fs.chmodSync(path.join(newDir,'ATUALIZAR_SEM_PERDER_DADOS.sh'),0o755);
  fs.writeFileSync(path.join(bin,'docker'),`#!/bin/sh\nprintf '%s\\n' "$*" >> "${log}"\nexit 0\n`);fs.chmodSync(path.join(bin,'docker'),0o755);
  fs.writeFileSync(path.join(bin,'curl'),healthOk?'#!/bin/sh\nprintf \'{"ok":true,"version":"2.2.8","schemaVersion":5,"storage":"ok"}\'\n':'#!/bin/sh\nexit 1\n');fs.chmodSync(path.join(bin,'curl'),0o755);
  fs.writeFileSync(path.join(bin,'sleep'),'#!/bin/sh\nexit 0\n');fs.chmodSync(path.join(bin,'sleep'),0o755);
  return {root,oldDir,newDir,bin,log};
}

function run(f){return spawnSync('bash',[path.join(f.newDir,'ATUALIZAR_SEM_PERDER_DADOS.sh'),f.oldDir],{env:{...process.env,PATH:f.bin+':'+process.env.PATH},encoding:'utf8'});}

test('atualizador copia .env e banco sem alterar a instalação anterior',{skip:process.getuid?.()!==0},()=>{
  const f=fixture(true);try{const result=run(f);assert.equal(result.status,0,result.stderr+result.stdout);assert.equal(fs.readFileSync(path.join(f.newDir,'data','peralta.sqlite'),'utf8'),'dados-preservados');assert.equal(fs.readFileSync(path.join(f.oldDir,'data','peralta.sqlite'),'utf8'),'dados-preservados');assert.equal(fs.readFileSync(path.join(f.newDir,'.env'),'utf8'),fs.readFileSync(path.join(f.oldDir,'.env'),'utf8'));assert.match(result.stdout,/ATUALIZAÇÃO CONCLUÍDA/);assert.ok(fs.readdirSync(path.join(f.root,'backups')).length===1);}finally{fs.rmSync(f.root,{recursive:true,force:true});}
});

test('atualizador religa a versão anterior quando o health check falha',{skip:process.getuid?.()!==0},()=>{
  const f=fixture(false);try{const result=run(f);assert.notEqual(result.status,0);const calls=fs.readFileSync(f.log,'utf8');assert.match(calls,new RegExp('--project-directory '+f.oldDir.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+' up -d'));assert.match(result.stdout,/Religando automaticamente/);assert.equal(fs.readFileSync(path.join(f.oldDir,'data','peralta.sqlite'),'utf8'),'dados-preservados');}finally{fs.rmSync(f.root,{recursive:true,force:true});}
});
