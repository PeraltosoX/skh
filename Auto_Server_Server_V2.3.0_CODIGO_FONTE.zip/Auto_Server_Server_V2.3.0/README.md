# Auto Server V2.3.0

Servidor e painel web do Auto Server. A automação continua na VPS mesmo com o
aplicativo, o painel ou o navegador fechados.

Esta entrega altera somente servidor e painel web. O aplicativo Android não faz
parte deste ZIP.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde: `/health`
- Retorno OAuth: `/oauth/google/callback`

## Perfis, canais e execução

- Cada conta começa com três perfis permanentes.
- O administrador pode adicionar perfis extras, até 50, e excluir somente os
  perfis a partir do número 4.
- Cada perfil aceita exatamente um canal.
- API Google, OAuth, mensagens, intervalo, canal, worker, contadores e logs são
  independentes por perfil.
- O mesmo canal e a mesma live são monitorados globalmente uma única vez e o
  resultado é compartilhado entre os perfis inscritos.
- INICIAR, PAUSAR e PARAR exigem confirmação no painel.
- PARAR zera os contadores gerais de enviadas, tentativas, falhas e erros de
  conexão daquele perfil. Os contadores de uso diário real da API permanecem.
- PAUSAR preserva os contadores e a posição do ciclo.

## Descoberta pública e live programada

- A página pública `/streams` continua sendo a fonte principal para encontrar
  IDs de lives. Não foi acrescentada busca de lives desconhecidas pela API.
- Lives `SCHEDULED` continuam aptas a enviar mensagens assim que o YouTube
  disponibiliza o chat; não é necessário aguardar o estado `LIVE`.
- Lives `LIVE` e `SCHEDULED` continuam sendo acompanhadas pela página pública.
- Lives `ENDED` ou finalizadas permanecem no histórico, mas são removidas para
  sempre da fila de reverificação e não consomem chave administrativa.
- `LOGIN_REQUIRED`, CAPTCHA, “confirme que você não é um bot”, timeout e falhas
  5xx não encerram uma live por conta própria.

## Chaves administrativas sem consultas repetidas

- A chave administrativa usa somente `videos.list` para um ID de vídeo que já
  foi encontrado. Ela não usa `search.list` nem pesquisa canais.
- A primeira chave disponível é usada; se ela falhar, as reservas são tentadas
  imediatamente por prioridade.
- O resultado público que disparou a confirmação é gravado no banco como uma
  assinatura de estado por vídeo.
- O mesmo estado confirmado não consulta a API de novo, mesmo depois de muitos
  ciclos ou reinício do contêiner.
- Uma mudança real de transmissão ou chat libera imediatamente uma nova
  confirmação. Não é necessário esperar um prazo longo.
- Um chat ativo e confiável é reutilizado sem chamada administrativa. A mudança
  pública de `SCHEDULED` para `LIVE` continua sendo aplicada sem interromper o
  chat.
- Se todas as chaves falharem, a live é preservada e o retry administrativo usa
  1 minuto, depois 2 minutos e, a partir daí, no máximo 5 minutos.
- Qualquer mudança pública relevante ignora a espera de falha e tenta
  imediatamente.
- Um erro terminal do worker (`404`, `liveChatNotFound` ou `liveChatEnded`)
  invalida o estado anterior e permite exatamente uma nova confirmação.
- Chamadas simultâneas para o mesmo vídeo são unificadas. O estado persistente
  também evita novas chamadas do mesmo vídeo em ciclos posteriores e entre
  perfis.
- O botão TESTAR de uma chave é uma ação manual e continua fazendo uma chamada
  real.

## Segurança das chaves

- O `/dbmadmin` permite adicionar, testar, habilitar, desabilitar, priorizar e
  excluir chaves.
- As chaves completas são criptografadas com `APP_ENCRYPTION_KEY` e nunca são
  devolvidas ao navegador.
- Consultas, sucessos, falhas, último uso, espera de cota e último erro aparecem
  no painel administrativo.
- Projetos Google Cloud diferentes são necessários para quotas realmente
  independentes.

## YouTube Data API dos perfis

- O OAuth e a quota de cada perfil continuam separados das chaves
  administrativas.
- O `activeLiveChatId` confirmado é armazenado globalmente e compartilhado com
  os perfis da live.
- Se o chat ainda não existe, o retry configurável do perfil continua gravado
  na própria live. Outras lives continuam funcionando.
- O padrão desse retry de disponibilidade do chat permanece em 120 segundos e
  pode ser configurado de 15 a 3600 segundos no painel administrativo.
- O access token é reutilizado até perto do vencimento.
- Os contadores representam solicitações reais, não uma estimativa fixa de
  unidades de quota.

## Lives simultâneas e intervalo

- Uma live usa o intervalo configurado no perfil.
- Duas lives alternam um envio total a cada 3 minutos.
- Três lives alternam um envio total a cada 2 minutos e 30 segundos.
- O menor intervalo configurável permanece 0 minuto e 1 segundo.
- A posição da lista de mensagens é preservada ao pausar, parar ou iniciar.

## Isolamento e proteção

- Retry e backoff são individuais por live.
- Uma live sem chat, com 429 ou falha temporária não bloqueia as demais.
- Respostas ambíguas de envio pausam somente a live envolvida para evitar
  duplicidade.
- Remover ou trocar o canal invalida imediatamente um alvo em andamento.
- OAuth inválido, API desativada e permissões insuficientes geram mensagens
  específicas sem expor segredos.
- Cookies HttpOnly/SameSite, CSRF, validação de origem, limite de login e
  criptografia AES-256-GCM permanecem ativos.

## Banco e migration

A V2.3.0 usa o schema SQLite 6. A migration é incremental e adiciona à tabela
de lives globais somente os campos necessários para:

1. guardar a assinatura do último estado administrativo;
2. distinguir sucesso de falha;
3. guardar o próximo retry após falha de todas as chaves;
4. guardar a sequência de falhas para o backoff de 1, 2 e 5 minutos.

Usuários, senhas, perfis, mensagens, canais, OAuth, chaves administrativas,
logs, contadores e estados de live existentes são preservados. O banco fica em
`data/peralta.sqlite`; preserve sempre a pasta `data/` junto com o `.env`, pois
`APP_ENCRYPTION_KEY` protege os segredos já gravados.

Use `ATUALIZAR_SEM_PERDER_DADOS.sh`. Ele cria um backup consistente, copia
`.env` e `data/`, inicia a V2.3.0, exige `/health` com schema 6, valida a sintaxe
no contêiner e religa automaticamente a V2.2.9 se houver falha.

## Google OAuth

Cada perfil utiliza um OAuth Client do tipo **Web application**. Cadastre:

`https://SEU-DOMINIO/oauth/google/callback`

## Desenvolvimento

Requer Node.js 24.14 ou superior na linha 24:

```bash
npm ci
npm run check
npm test
npm start
```

Consulte `CHANGELOG_V2.3.0.txt`, `MUDANCAS_V2.3.0.txt`, `INSTALAR.txt` e
`ATUALIZAR_SEM_PERDER_DADOS.txt`.
