#!/usr/bin/env bash
set -Eeuo pipefail

NEW_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
OLD_DIR="${1:-/opt/peralta-chat/Auto_Server_Server_V2.3.2}"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Execute como root: sudo ./ATUALIZAR_SEM_PERDER_DADOS.sh CAMINHO_DA_VERSAO_ANTIGA"
  exit 1
fi

for command in docker curl cp date; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "Comando obrigatório não encontrado: $command"
    exit 1
  fi
done

if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose não foi encontrado."
  exit 1
fi

if [[ ! -d "$OLD_DIR" || ! -f "$OLD_DIR/docker-compose.yml" ]]; then
  echo "Pasta da versão anterior inválida: $OLD_DIR"
  exit 1
fi
if [[ ! -f "$OLD_DIR/.env" ]]; then
  echo "Arquivo essencial ausente: $OLD_DIR/.env"
  exit 1
fi
if [[ ! -f "$OLD_DIR/data/peralta.sqlite" ]]; then
  echo "Banco atual não encontrado: $OLD_DIR/data/peralta.sqlite"
  exit 1
fi
if [[ "$NEW_DIR" == "$(cd -- "$OLD_DIR" && pwd -P)" ]]; then
  echo "Extraia a nova versão em outra pasta; não execute a atualização por cima da pasta atual."
  exit 1
fi
if [[ -e "$NEW_DIR/.env" || -e "$NEW_DIR/data" ]]; then
  echo "A pasta nova já contém .env ou data/. Use uma extração limpa do ZIP V2.3.3."
  exit 1
fi

STAMP="$(date -u +%Y%m%d-%H%M%S)"
BACKUP_DIR="$(dirname -- "$OLD_DIR")/backups/auto-server-antes-v2.3.3-$STAMP"
OLD_STOPPED=0

rollback() {
  code=$?
  trap - ERR
  echo
  echo "A atualização falhou. Religando automaticamente a versão anterior..."
  if [[ "$OLD_STOPPED" -eq 1 ]]; then
    docker compose -f "$NEW_DIR/docker-compose.yml" --project-directory "$NEW_DIR" down >/dev/null 2>&1 || true
    docker compose -f "$OLD_DIR/docker-compose.yml" --project-directory "$OLD_DIR" up -d || true
  fi
  echo "A versão anterior foi preservada em: $OLD_DIR"
  echo "Backup criado em: $BACKUP_DIR"
  exit "$code"
}
trap rollback ERR

echo "[1/6] Validando a instalação atual..."
docker compose -f "$OLD_DIR/docker-compose.yml" --project-directory "$OLD_DIR" config >/dev/null

echo "[2/6] Parando a versão anterior para obter um backup consistente..."
OLD_STOPPED=1
docker compose -f "$OLD_DIR/docker-compose.yml" --project-directory "$OLD_DIR" down

echo "[3/6] Copiando banco e chaves para o backup..."
mkdir -p "$BACKUP_DIR"
cp -a "$OLD_DIR/.env" "$BACKUP_DIR/.env"
cp -a "$OLD_DIR/data" "$BACKUP_DIR/data"
if [[ -f "$OLD_DIR/ACESSO_INICIAL.txt" ]]; then cp -a "$OLD_DIR/ACESSO_INICIAL.txt" "$BACKUP_DIR/ACESSO_INICIAL.txt"; fi

echo "[4/6] Levando os dados existentes para a nova versão..."
cp -a "$OLD_DIR/.env" "$NEW_DIR/.env"
cp -a "$OLD_DIR/data" "$NEW_DIR/data"
if [[ -f "$OLD_DIR/ACESSO_INICIAL.txt" ]]; then cp -a "$OLD_DIR/ACESSO_INICIAL.txt" "$NEW_DIR/ACESSO_INICIAL.txt"; fi
chmod 600 "$NEW_DIR/.env"
chmod 700 "$NEW_DIR/data"
docker compose -f "$NEW_DIR/docker-compose.yml" --project-directory "$NEW_DIR" config >/dev/null

echo "[5/6] Construindo e iniciando o Auto Server V2.3.3..."
docker compose -f "$NEW_DIR/docker-compose.yml" --project-directory "$NEW_DIR" up -d --build

echo "[6/6] Aguardando o teste de saúde..."
APP_PORT="$(sed -n 's/^APP_PORT=//p' "$NEW_DIR/.env" | tail -n 1)"
APP_PORT="${APP_PORT:-8080}"
HEALTH_OK=0
for attempt in $(seq 1 30); do
  if RESPONSE="$(curl -fsS "http://127.0.0.1:${APP_PORT}/health" 2>/dev/null)" \
    && grep -q '"version":"2.3.3"' <<<"$RESPONSE" \
    && grep -q '"schemaVersion":6' <<<"$RESPONSE" \
    && grep -q '"storage":"ok"' <<<"$RESPONSE"; then
    HEALTH_OK=1
    break
  fi
  sleep 2
done
if [[ "$HEALTH_OK" -ne 1 ]]; then
  echo "A nova versão não passou no teste completo de versão, banco e armazenamento."
  false
fi
docker compose -f "$NEW_DIR/docker-compose.yml" --project-directory "$NEW_DIR" exec -T server node scripts/check.cjs >/dev/null

OLD_STOPPED=0
trap - ERR
echo
echo "ATUALIZAÇÃO CONCLUÍDA SEM APAGAR OS DADOS."
echo "Nova versão: $NEW_DIR"
echo "Backup preservado: $BACKUP_DIR"
echo "Painel: $(sed -n 's/^PUBLIC_BASE_URL=//p' "$NEW_DIR/.env" | tail -n 1)/painel"
echo "Não apague a pasta anterior nem o backup até terminar seus testes."
