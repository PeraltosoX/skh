'use strict';

const $ = id => document.getElementById(id);
const show = (id, on) => $(id)?.classList.toggle('hidden', !on);
const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);

const pageMeta = {
  overview: ['PAINEL ADMINISTRATIVO', 'Visão geral', 'Acompanhe o funcionamento do Auto Server.'],
  users: ['CONTAS E PERFIS', 'Usuários e perfis', 'Administre as contas e suas configurações independentes.'],
  'create-user': ['GERENCIAMENTO DE ACESSO', 'Criar usuário', 'Cadastre uma conta ou edite um acesso existente.'],
  keys: ['CONFIRMAÇÃO ADMINISTRATIVA', 'Chaves de verificação', 'Gerencie prioridade, status e consumo das chaves.'],
  activity: ['REGISTROS E SAÚDE', 'Atividade', 'Consulte diagnóstico, eventos e auditoria.'],
  settings: ['SEGURANÇA', 'Configurações', 'Proteja o acesso à administração.']
};

let csrfToken = '';
let authenticated = false;
let activePage = 'overview';
let data = { users: [], globalMonitoring: {}, apiUsageToday: {}, verificationKeys: [], verificationUsageToday: {}, profileDefaults: { defaultCount: 3, maxCount: 50 } };
let details = '';
let loadSequence = 0;
let confirmation = null;
let confirmationPreviousFocus = null;
const dirtyForms = new Set();
const formLocks = new Set();
const pendingActions = new Set();

function feedback(id, message, ok = false) {
  const element = $(id);
  if (!element) return;
  element.textContent = message || '';
  element.className = `${id === 'globalFb' ? 'global-feedback ' : ''}feedback ${message ? ok ? 'ok' : 'err' : ''}`;
}

function markClean(formId) { dirtyForms.delete(formId); }

function setAuthView({ needsSetup = false, loggedIn = false } = {}) {
  show('authArea', !loggedIn);
  show('setup', !loggedIn && needsSetup);
  show('login', !loggedIn && !needsSetup);
  show('dashboard', loggedIn);
  show('logout', loggedIn);
  if (!loggedIn) closeMenu();
}

async function api(url, { method = 'GET', body } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), method === 'DELETE' ? 45000 : 20000);
  try {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
    const response = await fetch(url, {
      method,
      body: body === undefined ? undefined : JSON.stringify(body),
      headers,
      credentials: 'same-origin',
      signal: controller.signal
    });
    let result;
    try { result = await response.json(); }
    catch { throw new Error(`Resposta inválida (HTTP ${response.status}). Confira a URL e o proxy do servidor.`); }
    if (!response.ok || result.ok !== true) {
      if (response.status === 401 && authenticated) {
        authenticated = false;
        csrfToken = '';
        setAuthView({ needsSetup: false, loggedIn: false });
      }
      throw new Error(result.error || `HTTP ${response.status}`);
    }
    return result;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Tempo esgotado. Verifique o servidor e tente novamente.');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function bootstrap(expectSession = false) {
  const bootstrapData = await api('/dbmadmin/api/bootstrap');
  authenticated = bootstrapData.authenticated;
  csrfToken = bootstrapData.csrfToken || '';
  setAuthView({ needsSetup: bootstrapData.needsSetup, loggedIn: authenticated });
  if (expectSession && !authenticated) throw new Error('Senha aceita, mas a sessão não foi mantida. Confira o domínio HTTPS e os cookies.');
  if (authenticated) {
    activatePage(activePage);
    await loadData({ busy: true });
  }
}

function bindForm(id, feedbackId, action) {
  const form = $(id);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (formLocks.has(id)) return;
    const button = form.querySelector('button[type="submit"],button:not([type])');
    const label = button.textContent;
    formLocks.add(id);
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    button.textContent = 'AGUARDE…';
    feedback(feedbackId, '');
    try { await action(); }
    catch (error) { feedback(feedbackId, error.message); }
    finally {
      formLocks.delete(id);
      button.disabled = false;
      button.removeAttribute('aria-busy');
      button.textContent = label;
    }
  });
}

function openMenu() {
  $('sidebar').classList.add('open');
  $('menuToggle').setAttribute('aria-expanded', 'true');
  show('navBackdrop', true);
  document.body.classList.add('menu-open');
}

function closeMenu() {
  $('sidebar')?.classList.remove('open');
  $('menuToggle')?.setAttribute('aria-expanded', 'false');
  show('navBackdrop', false);
  document.body.classList.remove('menu-open');
}

function activatePage(name, { focusHeading = false } = {}) {
  if (!pageMeta[name]) name = 'overview';
  activePage = name;
  for (const page of document.querySelectorAll('[data-page]')) {
    const active = page.dataset.page === name;
    page.classList.toggle('hidden', !active);
    page.classList.toggle('active', active);
  }
  for (const button of document.querySelectorAll('[data-page-target]')) {
    const active = button.dataset.pageTarget === name;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  const [eyebrow, title, subtitle] = pageMeta[name];
  $('pageEyebrow').textContent = eyebrow;
  $('pageTitle').textContent = title;
  $('pageSubtitle').textContent = subtitle;
  closeMenu();
  if (focusHeading) {
    $('pageTitle').setAttribute('tabindex', '-1');
    $('pageTitle').focus({ preventScroll: true });
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resolveConfirmation(result) {
  if (!confirmation) return;
  const resolve = confirmation;
  confirmation = null;
  show('confirmModal', false);
  document.body.classList.remove('menu-open');
  resolve(result);
  if (confirmationPreviousFocus?.focus) confirmationPreviousFocus.focus();
  confirmationPreviousFocus = null;
}

function askConfirmation({ title = 'Confirmar ação', message, confirmLabel = 'CONFIRMAR', danger = false }) {
  if (confirmation) return Promise.resolve(false);
  confirmationPreviousFocus = document.activeElement;
  $('confirmTitle').textContent = title;
  $('confirmMessage').textContent = message;
  $('confirmAccept').textContent = confirmLabel;
  $('confirmAccept').className = `button ${danger ? 'danger' : 'primary'}`;
  $('confirmIcon').textContent = danger ? '!' : '✓';
  document.querySelector('.confirm-dialog').classList.toggle('danger-mode', danger);
  show('confirmModal', true);
  document.body.classList.add('menu-open');
  setTimeout(() => $('confirmCancel').focus(), 0);
  return new Promise(resolve => { confirmation = resolve; });
}

function resetUser() {
  $('userForm').reset();
  $('userId').value = '';
  $('userTitle').textContent = 'Criar usuário';
  $('userFormDescription').textContent = 'A nova conta será criada com três perfis independentes.';
  $('userActive').value = 'true';
  markClean('userForm');
}

function resetProfile() {
  $('profileForm').reset();
  $('profileUserId').value = '';
  $('profileNumber').value = '';
  markClean('profileForm');
  show('profileEditor', false);
}

function statusName(status) {
  return status === 'running' ? 'RODANDO' : status === 'paused' ? 'PAUSADO' : 'PARADO';
}

function dateTime(value) {
  return value ? new Date(value).toLocaleString('pt-BR') : '—';
}

function nextAdditionalProfileNumber(user) {
  const first = (data.profileDefaults?.defaultCount || 3) + 1;
  const maximum = data.profileDefaults?.maxCount || 50;
  const used = new Set((user?.profiles || []).map(profile => profile.profileId));
  for (let number = first; number <= maximum; number++) if (!used.has(number)) return number;
  return null;
}

function actionKey(action, { userId = '', profile = '', keyId = '' } = {}) {
  return [action, userId, profile, keyId].join(':');
}

function actionKeyForButton(button) {
  return actionKey(button.dataset.action, {
    userId: button.dataset.userId || '',
    profile: button.dataset.profile || '',
    keyId: button.dataset.keyId || ''
  });
}

function syncPendingActions() {
  for (const button of document.querySelectorAll('button[data-action]')) {
    const pending = pendingActions.has(actionKeyForButton(button));
    if (pending) {
      button.disabled = true;
      button.dataset.pendingDisabled = 'true';
      button.setAttribute('aria-busy', 'true');
    } else if (button.dataset.pendingDisabled === 'true') {
      button.removeAttribute('data-pending-disabled');
      button.removeAttribute('aria-busy');
      if (button.dataset.staticDisabled !== 'true') button.disabled = false;
    }
  }
}

function renderOverview() {
  const profiles = data.users.flatMap(user => user.profiles || []);
  $('overviewUsers').textContent = data.users.length;
  $('overviewProfiles').textContent = profiles.length;
  $('overviewRunning').textContent = profiles.filter(profile => profile.status === 'running').length;
  $('overviewKeys').textContent = (data.verificationKeys || []).filter(key => key.enabled).length;
}

function renderMonitor(monitoring = {}) {
  if (!dirtyForms.has('monitorForm')) {
    $('monitorMinutes').value = Math.max(1, Math.round((monitoring.intervalSeconds || 180) / 60));
    $('chatRetrySeconds').value = monitoring.chatAvailabilityRetrySeconds || 120;
  }
  $('monitorLast').textContent = dateTime(monitoring.lastGlobalScanAt);
  $('monitorNext').textContent = dateTime(monitoring.nextGlobalScanAt);
  $('monitorDuration').textContent = `${monitoring.globalScanDurationMs || 0} ms`;
  $('monitorChatRetry').textContent = `${monitoring.chatAvailabilityRetrySeconds || 120} s`;
  $('monitorChannels').textContent = monitoring.globalChannelsActive || 0;
  $('monitorScheduled').textContent = monitoring.scheduledLivesCount || 0;
  $('monitorLive').textContent = monitoring.liveLivesCount || 0;
  $('apiRequestsToday').textContent = data.apiUsageToday?.requests || 0;
  $('apiLookupsToday').textContent = data.apiUsageToday?.videosList || 0;
  $('apiInsertsToday').textContent = data.apiUsageToday?.liveChatInsert || 0;
  $('apiFailuresToday').textContent = data.apiUsageToday?.failures || 0;
  $('monitorError').textContent = monitoring.lastGlobalScanError || '';
  show('monitorError', !!monitoring.lastGlobalScanError);
}

function verificationStatus(status) {
  return ({ UNTESTED: 'NÃO TESTADA', ACTIVE: 'ATIVA', QUOTA: 'SEM COTA', INVALID: 'INVÁLIDA', ERROR: 'ERRO' })[status] || status || 'NÃO TESTADA';
}

function renderVerificationKeys(keys = []) {
  $('verificationRequestsToday').textContent = data.verificationUsageToday?.requests || 0;
  $('verificationFailuresToday').textContent = data.verificationUsageToday?.failures || 0;
  $('verificationKeys').innerHTML = keys.map(key => {
    const statusClass = key.status === 'ACTIVE' ? 'green' : ['INVALID', 'ERROR'].includes(key.status) ? 'red' : key.status === 'QUOTA' ? 'yellow' : '';
    const primary = key.priority === 1;
    const usage = key.usageToday || {};
    return `<article class="verification-key"><div class="verification-key-head"><div><b>${esc(key.name)}</b><span class="badge ${primary ? 'green' : ''}">${primary ? 'PRINCIPAL' : `RESERVA ${key.priority - 1}`}</span><span class="badge ${statusClass}">${verificationStatus(key.status)}</span><span class="badge ${key.enabled ? 'green' : 'red'}">${key.enabled ? 'HABILITADA' : 'DESABILITADA'}</span></div><code>${esc(key.keyHint)}</code></div><div class="meta">Consultas hoje: ${usage.attempts || 0} • Sucessos: ${usage.successes || 0} • Falhas: ${usage.failures || 0}<br>Último uso: ${dateTime(key.lastUsedAt)}${key.cooldownUntil ? `<br>Nova tentativa após: ${dateTime(key.cooldownUntil)}` : ''}${key.lastError ? `<br><span class="error-inline">${esc(key.lastError)}</span>` : ''}</div><div class="actions"><button data-action="key-test" data-key-id="${esc(key.id)}">TESTAR</button><button class="secondary" data-action="key-primary" data-key-id="${esc(key.id)}" ${primary ? 'disabled data-static-disabled="true"' : ''}>TORNAR PRINCIPAL</button><button class="secondary" data-action="key-toggle" data-key-id="${esc(key.id)}">${key.enabled ? 'DESABILITAR' : 'HABILITAR'}</button><button class="danger" data-action="key-delete" data-key-id="${esc(key.id)}">EXCLUIR</button></div></article>`;
  }).join('') || '<section class="panel-card"><p class="meta">Nenhuma chave cadastrada. O monitor público e as contas dos perfis continuam funcionando, mas não existe confirmação administrativa de um ID conhecido.</p></section>';
  syncPendingActions();
}

function renderUsers(users) {
  const term = $('userSearch').value.trim().toLocaleLowerCase('pt-BR');
  const filtered = term ? users.filter(user => user.username.toLocaleLowerCase('pt-BR').includes(term) || user.profiles.some(profile => profile.name.toLocaleLowerCase('pt-BR').includes(term))) : users;
  $('userCount').textContent = term ? `${filtered.length} de ${users.length} ${users.length === 1 ? 'usuário' : 'usuários'}` : `${users.length} ${users.length === 1 ? 'usuário' : 'usuários'}`;
  $('users').innerHTML = filtered.map(user => {
    const defaultProfiles = data.profileDefaults?.defaultCount || 3;
    const maxProfiles = data.profileDefaults?.maxCount || 50;
    const atProfileLimit = user.profiles.length >= maxProfiles;
    const profiles = user.profiles.map(profile => {
      const deleteButton = profile.profileId > defaultProfiles
        ? `<button class="danger" data-action="profile-delete" data-user-id="${esc(user.id)}" data-profile="${profile.profileId}">EXCLUIR PERFIL</button>`
        : '';
      return `<article class="profile-summary"><div class="profile-head"><div><b title="${esc(profile.name)}">${esc(profile.name)}</b><span class="badge ${profile.status === 'running' ? 'green' : profile.status === 'paused' ? 'yellow' : ''}">${statusName(profile.status)}</span></div><span class="badge ${profile.enabled ? 'green' : 'red'}">${profile.enabled ? 'HABILITADO' : 'DESABILITADO'}</span></div><div class="meta">API: ${profile.apiConfigured ? 'configurada' : 'não configurada'}<br>Google permitido: ${esc(profile.googleEmail || 'livre / não definido')}<br>YouTube: ${profile.oauthConnected ? `conectado • ${esc(profile.oauthEmail)}` : 'não conectado'}<br>Enviadas: ${profile.sent} • Falhas: ${profile.failures} • Chats: ${profile.activeChats || 0}<br>Solicitações API hoje: ${profile.apiUsageToday?.requests || 0}${profile.lastError ? `<br><span class="error-inline">${esc(profile.lastError)}</span>` : ''}</div><div class="actions"><button data-action="profile-edit" data-user-id="${esc(user.id)}" data-profile="${profile.profileId}">CONFIGURAR</button><button class="secondary" data-action="profile-logs" data-user-id="${esc(user.id)}" data-profile="${profile.profileId}">LOGS</button>${deleteButton}</div></article>`;
    }).join('');
    return `<section class="user-card"><div class="user-head"><div><h3>${esc(user.username)}</h3><span class="badge ${user.active ? 'green' : 'red'}">${user.active ? 'ATIVO' : 'BLOQUEADO'}</span><span class="meta">${user.profiles.length} perfis</span></div><div class="actions"><button data-action="profile-add" data-user-id="${esc(user.id)}" ${atProfileLimit ? 'disabled data-static-disabled="true"' : ''}>+ ADICIONAR PERFIL</button><button data-action="user-edit" data-user-id="${esc(user.id)}">EDITAR USUÁRIO</button><button class="secondary" data-action="user-toggle" data-user-id="${esc(user.id)}">${user.active ? 'BLOQUEAR' : 'ATIVAR'}</button><button class="secondary" data-action="user-revoke" data-user-id="${esc(user.id)}">ENCERRAR SESSÕES</button><button class="danger" data-action="user-delete" data-user-id="${esc(user.id)}">EXCLUIR</button></div></div><div class="profile-grid">${profiles}</div></section>`;
  }).join('') || `<p class="meta">${term ? 'Nenhum usuário ou perfil corresponde à pesquisa.' : 'Nenhum usuário cadastrado.'}</p>`;
  syncPendingActions();
}

async function loadData({ busy = false } = {}) {
  const sequence = ++loadSequence;
  const refresh = $('refreshBtn');
  if (busy) {
    refresh.disabled = true;
    refresh.setAttribute('aria-busy', 'true');
  }
  try {
    const next = await api('/dbmadmin/api/data');
    if (sequence !== loadSequence) return false;
    data = next;
    renderOverview();
    renderMonitor(data.globalMonitoring);
    renderVerificationKeys(data.verificationKeys || []);
    renderUsers(data.users);
    $('updatedAt').textContent = `Atualizado às ${new Date().toLocaleTimeString('pt-BR')}`;
    return true;
  } catch (error) {
    if (sequence !== loadSequence) return false;
    throw error;
  } finally {
    if (busy && sequence === loadSequence) {
      refresh.disabled = false;
      refresh.removeAttribute('aria-busy');
    }
  }
}

function editProfile(userId, number) {
  const user = data.users.find(item => item.id === userId);
  const profile = user?.profiles.find(item => item.profileId === number);
  if (!user || !profile) return;
  activatePage('users');
  $('profileUserId').value = user.id;
  $('profileNumber').value = String(number);
  $('profileName').value = profile.name;
  $('profileGoogleEmail').value = profile.googleEmail || '';
  $('profileClientId').value = profile.clientId || '';
  $('profileClientSecret').value = '';
  $('profileEnabled').value = String(profile.enabled);
  $('clearCredentials').checked = false;
  $('profileEditorTitle').textContent = `${user.username} • Perfil ${number}`;
  markClean('profileForm');
  show('profileEditor', true);
  requestAnimationFrame(() => $('profileEditor').scrollIntoView({ behavior: 'smooth', block: 'start' }));
}

function editUser(userId) {
  const user = data.users.find(item => item.id === userId);
  if (!user) return;
  $('userId').value = user.id;
  $('username').value = user.username;
  $('userPass').value = '';
  $('userActive').value = String(user.active);
  $('userTitle').textContent = 'Editar usuário';
  $('userFormDescription').textContent = `Atualize o acesso de ${user.username}. Deixe a senha vazia para mantê-la.`;
  markClean('userForm');
  activatePage('create-user');
  requestAnimationFrame(() => $('username').focus());
}

function showDetails(title, value, download = false) {
  details = JSON.stringify(value, null, 2);
  $('detailsTitle').textContent = title;
  $('detailsText').textContent = details;
  $('detailsText').classList.remove('details-empty');
  show('downloadDetails', download);
  activatePage('activity');
  requestAnimationFrame(() => $('detailsPanel').scrollIntoView({ behavior: 'smooth', block: 'start' }));
}

bindForm('setupForm', 'setupFb', async () => {
  await api('/dbmadmin/api/setup', { method: 'POST', body: { setupToken: $('setupToken').value, username: $('setupUser').value, password: $('setupPass').value } });
  $('setupForm').reset();
  await bootstrap(true);
});

bindForm('loginForm', 'loginFb', async () => {
  await api('/dbmadmin/api/login', { method: 'POST', body: { username: $('loginUser').value, password: $('loginPass').value } });
  $('loginPass').value = '';
  activePage = 'overview';
  await bootstrap(true);
  feedback('globalFb', '');
});

bindForm('userForm', 'userFb', async () => {
  const id = $('userId').value;
  const body = { username: $('username').value.trim(), password: $('userPass').value, active: $('userActive').value === 'true' };
  if (!id && !body.password) throw new Error('Informe a senha inicial.');
  const oldUser = id ? data.users.find(user => user.id === id) : null;
  if (oldUser && oldUser.active !== body.active) {
    const accepted = await askConfirmation({
      title: body.active ? 'Ativar usuário?' : 'Bloquear usuário?',
      message: body.active ? `${oldUser.username} voltará a acessar o painel.` : `${oldUser.username} perderá o acesso e os perfis em execução serão interrompidos.`,
      confirmLabel: body.active ? 'ATIVAR' : 'BLOQUEAR',
      danger: !body.active
    });
    if (!accepted) return;
  }
  await api(`/dbmadmin/api/users${id ? `/${encodeURIComponent(id)}` : ''}`, { method: id ? 'PATCH' : 'POST', body });
  resetUser();
  await loadData();
  feedback('globalFb', id ? 'Usuário atualizado.' : 'Usuário criado com três perfis.', true);
  activatePage('users');
});

bindForm('profileForm', 'profileFb', async () => {
  const userId = $('profileUserId').value;
  const number = Number($('profileNumber').value);
  const oldProfile = data.users.find(user => user.id === userId)?.profiles.find(profile => profile.profileId === number);
  const body = {
    name: $('profileName').value,
    enabled: $('profileEnabled').value === 'true',
    googleEmail: $('profileGoogleEmail').value.trim(),
    clientId: $('clearCredentials').checked ? '' : $('profileClientId').value.trim(),
    clientSecret: $('clearCredentials').checked ? '' : $('profileClientSecret').value,
    clearCredentials: $('clearCredentials').checked
  };
  const identityChanged = !!(body.clientSecret || body.clearCredentials || oldProfile?.googleEmail !== body.googleEmail || oldProfile?.clientId !== body.clientId);
  const disabling = oldProfile?.enabled && !body.enabled;
  if (identityChanged || disabling) {
    const message = disabling
      ? `Desabilitar o Perfil ${number} interrompe sua execução. As configurações permanecem salvas.${identityChanged ? '\n\nAs alterações de API ou Conta Google também desconectarão o YouTube deste perfil.' : ''}`
      : `Alterações de API ou Conta Google desconectam somente o Perfil ${number}.`;
    const accepted = await askConfirmation({ title: `Confirmar alteração do Perfil ${number}?`, message, confirmLabel: 'SALVAR ALTERAÇÃO', danger: disabling });
    if (!accepted) return;
  }
  await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles/${number}`, { method: 'PATCH', body });
  resetProfile();
  await loadData();
  feedback('globalFb', `Perfil ${number} atualizado.`, true);
});

bindForm('monitorForm', 'monitorFb', async () => {
  const result = await api('/dbmadmin/api/global-monitor', {
    method: 'PATCH',
    body: { intervalMinutes: Number($('monitorMinutes').value), chatAvailabilityRetrySeconds: Number($('chatRetrySeconds').value) }
  });
  markClean('monitorForm');
  data.globalMonitoring = result.monitoring;
  renderMonitor(result.monitoring);
  feedback('monitorFb', 'Configurações globais salvas.', true);
});

bindForm('verificationKeyForm', 'verificationKeyFb', async () => {
  await api('/dbmadmin/api/verification-keys', {
    method: 'POST',
    body: { name: $('verificationKeyName').value.trim(), apiKey: $('verificationApiKey').value.trim() }
  });
  $('verificationKeyForm').reset();
  markClean('verificationKeyForm');
  await loadData();
  feedback('verificationKeyFb', 'Chave adicionada. Use TESTAR para confirmar a configuração.', true);
});

bindForm('passwordForm', 'passwordFb', async () => {
  const accepted = await askConfirmation({
    title: 'Alterar senha administrativa?',
    message: 'A senha será atualizada e todas as sessões administrativas abertas serão encerradas.',
    confirmLabel: 'ALTERAR SENHA',
    danger: true
  });
  if (!accepted) return;
  await api('/dbmadmin/api/password', { method: 'POST', body: { currentPassword: $('oldAdminPass').value, password: $('newAdminPass').value } });
  $('passwordForm').reset();
  markClean('passwordForm');
  await bootstrap();
  feedback('loginFb', 'Senha alterada. Entre novamente.', true);
});

$('logout').addEventListener('click', async () => {
  try { await api('/dbmadmin/api/logout', { method: 'POST', body: {} }); }
  catch (error) { feedback('globalFb', error.message); }
  finally {
    csrfToken = '';
    authenticated = false;
    await bootstrap().catch(error => feedback('loginFb', error.message));
  }
});

$('cancelUser').addEventListener('click', resetUser);
$('cancelProfile').addEventListener('click', resetProfile);
document.querySelector('[data-cancel-profile]').addEventListener('click', resetProfile);
$('menuToggle').addEventListener('click', () => $('sidebar').classList.contains('open') ? closeMenu() : openMenu());
$('navBackdrop').addEventListener('click', closeMenu);
$('confirmCancel').addEventListener('click', () => resolveConfirmation(false));
$('confirmAccept').addEventListener('click', () => resolveConfirmation(true));
document.querySelector('[data-confirm-cancel]').addEventListener('click', () => resolveConfirmation(false));

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    if (confirmation) resolveConfirmation(false);
    else closeMenu();
  }
});

document.addEventListener('click', event => {
  const navigation = event.target.closest('[data-page-target],[data-go-page]');
  if (!navigation) return;
  activatePage(navigation.dataset.pageTarget || navigation.dataset.goPage, { focusHeading: navigation.hasAttribute('data-go-page') });
});

for (const form of document.querySelectorAll('#dashboard form')) {
  const markDirty = event => { if (event.isTrusted) dirtyForms.add(form.id); };
  form.addEventListener('input', markDirty);
  form.addEventListener('change', markDirty);
}

$('userSearch').addEventListener('input', () => renderUsers(data.users));

document.addEventListener('click', async event => {
  const button = event.target.closest('button[data-action]');
  if (!button || button.disabled) return;
  const lockKey = actionKeyForButton(button);
  if (pendingActions.has(lockKey)) return;
  pendingActions.add(lockKey);
  syncPendingActions();
  const userId = button.dataset.userId;
  const action = button.dataset.action;
  const number = Number(button.dataset.profile);
  const keyId = button.dataset.keyId;
  try {
    if (action === 'key-test') {
      const result = await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}/test`, { method: 'POST', body: {} });
      await loadData();
      feedback('verificationKeyFb', result.message, true);
    } else if (action === 'key-primary') {
      const key = data.verificationKeys.find(item => item.id === keyId);
      if (!key || !await askConfirmation({ title: 'Alterar chave principal?', message: `${key?.name || 'Esta chave'} passará a ser a primeira usada nas confirmações administrativas.`, confirmLabel: 'TORNAR PRINCIPAL' })) return;
      await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}`, { method: 'PATCH', body: { makePrimary: true } });
      await loadData();
      feedback('verificationKeyFb', `${key.name} agora é a chave principal.`, true);
    } else if (action === 'key-toggle') {
      const key = data.verificationKeys.find(item => item.id === keyId);
      if (!key) throw new Error('Chave administrativa não encontrada.');
      const nextEnabled = !key.enabled;
      const accepted = await askConfirmation({
        title: nextEnabled ? 'Habilitar chave?' : 'Desabilitar chave?',
        message: nextEnabled ? `${key.name} voltará à rotação administrativa.` : `${key.name} deixará de ser utilizada nas confirmações até ser habilitada novamente.`,
        confirmLabel: nextEnabled ? 'HABILITAR' : 'DESABILITAR',
        danger: !nextEnabled
      });
      if (!accepted) return;
      await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}`, { method: 'PATCH', body: { enabled: nextEnabled } });
      await loadData();
      feedback('verificationKeyFb', `${key.name} foi ${nextEnabled ? 'habilitada' : 'desabilitada'}.`, true);
    } else if (action === 'key-delete') {
      const key = data.verificationKeys.find(item => item.id === keyId);
      if (!key || !await askConfirmation({ title: 'Excluir chave?', message: `${key?.name || 'A chave'} será removida do servidor e não poderá ser recuperada.`, confirmLabel: 'EXCLUIR CHAVE', danger: true })) return;
      await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}`, { method: 'DELETE', body: {} });
      await loadData();
      feedback('verificationKeyFb', `${key.name} foi excluída.`, true);
    } else if (action === 'profile-add') {
      const user = data.users.find(item => item.id === userId);
      const nextNumber = nextAdditionalProfileNumber(user);
      if (!nextNumber) throw new Error('Este usuário já atingiu o limite de perfis.');
      if (!await askConfirmation({ title: 'Adicionar perfil?', message: `Será criado somente o Perfil ${nextNumber} para ${user.username}.`, confirmLabel: 'ADICIONAR PERFIL' })) return;
      const result = await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles`, { method: 'POST', body: {} });
      await loadData();
      feedback('globalFb', `Perfil ${result.profile.profileId} adicionado para ${user.username}.`, true);
    } else if (action === 'profile-edit') {
      editProfile(userId, number);
    } else if (action === 'profile-logs') {
      const result = await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/logs?profileId=${number}`);
      showDetails(`Últimos registros • Perfil ${number}`, result.logs, true);
    } else if (action === 'profile-delete') {
      const user = data.users.find(item => item.id === userId);
      const profile = user?.profiles.find(item => item.profileId === number);
      const defaultProfiles = data.profileDefaults?.defaultCount || 3;
      if (!user || !profile) throw new Error('Perfil não encontrado.');
      if (number <= defaultProfiles) throw new Error('Os Perfis 1, 2 e 3 são permanentes e não podem ser excluídos.');
      const accepted = await askConfirmation({
        title: `Excluir ${profile.name}?`,
        message: `O Perfil ${number} de ${user.username} será parado antes da exclusão. Mensagens, canal, Conta Google, configurações e histórico somente deste perfil serão removidos.`,
        confirmLabel: 'EXCLUIR PERFIL',
        danger: true
      });
      if (!accepted) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles/${number}`, { method: 'DELETE', body: {} });
      resetProfile();
      await loadData();
      feedback('globalFb', `${profile.name} (Perfil ${number}) excluído de ${user.username}.`, true);
    } else if (action === 'user-edit') {
      editUser(userId);
    } else if (action === 'user-toggle') {
      const user = data.users.find(item => item.id === userId);
      if (!user) throw new Error('Usuário não encontrado.');
      const nextActive = !user.active;
      const accepted = await askConfirmation({
        title: nextActive ? 'Ativar usuário?' : 'Bloquear usuário?',
        message: nextActive ? `${user.username} voltará a acessar o painel.` : `${user.username} perderá o acesso e seus perfis em execução serão interrompidos.`,
        confirmLabel: nextActive ? 'ATIVAR' : 'BLOQUEAR',
        danger: !nextActive
      });
      if (!accepted) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}`, { method: 'PATCH', body: { active: nextActive } });
      await loadData();
      feedback('globalFb', `${user.username} foi ${nextActive ? 'ativado' : 'bloqueado'}.`, true);
    } else if (action === 'user-revoke') {
      const user = data.users.find(item => item.id === userId);
      if (!user || !await askConfirmation({ title: 'Encerrar sessões?', message: `As sessões de ${user?.username || 'este usuário'} serão encerradas. Os perfis em execução continuarão funcionando.`, confirmLabel: 'ENCERRAR SESSÕES', danger: true })) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/revoke`, { method: 'POST', body: {} });
      feedback('globalFb', `Sessões de ${user.username} encerradas.`, true);
    } else if (action === 'user-delete') {
      const user = data.users.find(item => item.id === userId);
      if (!user || !await askConfirmation({ title: `Excluir ${user?.username || 'usuário'}?`, message: 'Todos os perfis serão parados. Conta, perfis, canais, configurações, conexões Google e histórico serão removidos.', confirmLabel: 'EXCLUIR USUÁRIO', danger: true })) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}`, { method: 'DELETE', body: {} });
      if ($('userId').value === userId) resetUser();
      resetProfile();
      await loadData();
      feedback('globalFb', `${user.username} foi excluído.`, true);
    }
  } catch (error) {
    if (action.startsWith('key-')) {
      await loadData().catch(() => {});
      feedback('verificationKeyFb', error.message);
    } else {
      feedback('globalFb', error.message);
    }
  } finally {
    pendingActions.delete(lockKey);
    syncPendingActions();
  }
});

$('scanNow').addEventListener('click', async () => {
  if (pendingActions.has('scan-now')) return;
  pendingActions.add('scan-now');
  $('scanNow').disabled = true;
  try {
    const result = await api('/dbmadmin/api/global-monitor/scan', { method: 'POST', body: {} });
    feedback('monitorFb', result.started ? 'Busca global iniciada.' : 'Já existe uma busca global em andamento.', true);
    setTimeout(() => loadData().catch(error => feedback('globalFb', error.message)), 1800);
  } catch (error) {
    feedback('monitorFb', error.message);
  } finally {
    pendingActions.delete('scan-now');
    $('scanNow').disabled = false;
  }
});

$('refreshBtn').addEventListener('click', () => loadData({ busy: true }).catch(error => feedback('globalFb', error.message)));
$('diagBtn').addEventListener('click', () => api('/dbmadmin/api/diagnostics').then(result => showDetails('Diagnóstico', result)).catch(error => feedback('globalFb', error.message)));
$('eventsBtn').addEventListener('click', () => api('/dbmadmin/api/global-monitor/events').then(result => showDetails('Eventos do monitor global', result.events, true)).catch(error => feedback('globalFb', error.message)));
$('auditBtn').addEventListener('click', () => api('/dbmadmin/api/audit').then(result => showDetails('Auditoria do servidor', result.events, true)).catch(error => feedback('globalFb', error.message)));
$('downloadDetails').addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob([details], { type: 'application/json' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'Auto_Server_Registros.json';
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

setInterval(() => {
  if (authenticated && document.visibilityState === 'visible') loadData().catch(error => feedback('globalFb', error.message));
}, 30000);

bootstrap().catch(error => {
  setAuthView({ needsSetup: false, loggedIn: false });
  feedback('loginFb', error.message);
});
