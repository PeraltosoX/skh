'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const adminHtml = fs.readFileSync(path.join(root, 'public', 'admin.html'), 'utf8');
const adminCss = fs.readFileSync(path.join(root, 'public', 'admin.css'), 'utf8');
const adminJs = fs.readFileSync(path.join(root, 'public', 'admin.js'), 'utf8');
const panelHtml = fs.readFileSync(path.join(root, 'public', 'panel.html'), 'utf8');

test('painel administrativo separa as seis áreas aprovadas', () => {
  for (const page of ['overview', 'users', 'create-user', 'keys', 'activity', 'settings']) {
    assert.match(adminHtml, new RegExp(`data-page="${page}"`));
    assert.match(adminHtml, new RegExp(`data-page-target="${page}"`));
  }
  for (const label of ['Visão geral', 'Usuários e perfis', 'Criar usuário', 'Chaves de verificação', 'Atividade', 'Configurações']) {
    assert.match(adminHtml, new RegExp(label));
  }
});

test('painel administrativo não possui IDs duplicados e o JavaScript encontra seus elementos', () => {
  const ids = [...adminHtml.matchAll(/id="([^"]+)"/g)].map(match => match[1]);
  assert.equal(new Set(ids).size, ids.length);
  const references = [...adminJs.matchAll(/\$\('([^']+)'\)/g)].map(match => match[1]);
  for (const reference of references) assert.ok(ids.includes(reference), `ID ausente no HTML: ${reference}`);
});

test('proteções contra atualização atrasada, formulário sobrescrito e ação duplicada estão presentes', () => {
  assert.match(adminJs, /let loadSequence = 0/);
  assert.match(adminJs, /sequence !== loadSequence/);
  assert.match(adminJs, /const dirtyForms = new Set/);
  assert.match(adminJs, /if \(!dirtyForms\.has\('monitorForm'\)\)/);
  assert.match(adminJs, /const pendingActions = new Set/);
  assert.match(adminJs, /if \(pendingActions\.has\(lockKey\)\) return/);
  assert.match(adminJs, /function askConfirmation/);
});

test('tema administrativo é responsivo, leve e não carrega bibliotecas externas', () => {
  assert.match(adminCss, /@media \(max-width: 920px\)/);
  assert.match(adminCss, /@media \(max-width: 560px\)/);
  assert.match(adminCss, /--blue: #2563eb/);
  assert.match(adminCss, /--cyan: #06b6d4/);
  assert.doesNotMatch(adminHtml, /https?:\/\//);
  assert.doesNotMatch(adminCss, /@import|url\(https?:\/\//);
});

test('ícones são separados e painel do usuário não aponta para a administração', () => {
  assert.match(adminHtml, /href="\/admin-icon\.svg"/);
  assert.match(panelHtml, /href="\/panel-icon\.svg"/);
  assert.doesNotMatch(panelHtml, /href="\/dbmadmin"/);
  assert.match(panelHtml, />Privacidade e uso<\/a>/);
  for (const file of ['admin-icon.svg', 'panel-icon.svg']) {
    const svg = fs.readFileSync(path.join(root, 'public', file), 'utf8');
    assert.match(svg, /^<svg/);
    assert.doesNotMatch(svg, /<script|(?:href|src)=["']https?:\/\//i);
  }
});
