'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const adminHtml = fs.readFileSync(path.join(root, 'public', 'admin.html'), 'utf8');
const adminCss = fs.readFileSync(path.join(root, 'public', 'admin.css'), 'utf8');
const adminJs = fs.readFileSync(path.join(root, 'public', 'admin.js'), 'utf8');
const panelHtml = fs.readFileSync(path.join(root, 'public', 'panel.html'), 'utf8');
const panelCss = fs.readFileSync(path.join(root, 'public', 'panel.css'), 'utf8');
const panelJs = fs.readFileSync(path.join(root, 'public', 'panel.js'), 'utf8');

test('painel administrativo separa as seis áreas aprovadas', () => {
  for (const page of ['overview', 'users', 'create-user', 'keys', 'activity', 'settings']) {
    assert.match(adminHtml, new RegExp(`data-page="${page}"`));
    assert.match(adminHtml, new RegExp(`data-page-target="${page}"`));
  }
  for (const label of ['Visão geral', 'Usuários e perfis', 'Criar usuário', 'Chaves de verificação', 'Atividade', 'Configurações']) {
    assert.match(adminHtml, new RegExp(label));
  }
});

test('painel administrativo não possui IDs duplicados e o JavaScript encontra seus elementos', () => {
  const ids = [...adminHtml.matchAll(/id="([^"]+)"/g)].map(match => match[1]);
  assert.equal(new Set(ids).size, ids.length);
  const references = [...adminJs.matchAll(/\$\('([^']+)'\)/g)].map(match => match[1]);
  for (const reference of references) assert.ok(ids.includes(reference), `ID ausente no HTML: ${reference}`);
});

test('proteções contra atualização atrasada, formulário sobrescrito e ação duplicada estão presentes', () => {
  assert.match(adminJs, /let loadSequence = 0/);
  assert.match(adminJs, /sequence !== loadSequence/);
  assert.match(adminJs, /const dirtyForms = new Set/);
  assert.match(adminJs, /if \(!dirtyForms\.has\('monitorForm'\)\)/);
  assert.match(adminJs, /const pendingActions = new Set/);
  assert.match(adminJs, /if \(pendingActions\.has\(lockKey\)\) return/);
  assert.match(adminJs, /function askConfirmation/);
  assert.match(adminJs, /const feedbackTimers = new Map/);
  assert.match(adminJs, /element\.dataset\.feedbackSource/);
  assert.match(adminJs, /event\.key === 'Tab'/);
  assert.match(adminJs, /document\.querySelector\('\.confirm-dialog'\)\.querySelectorAll\('button:not\(\[disabled\]\)'\)/);
  assert.match(adminJs, /\$\('dashboard'\)\.inert = true/);
});

test('tema administrativo é responsivo, leve e não carrega bibliotecas externas', () => {
  assert.match(adminCss, /@media \(max-width: 920px\)/);
  assert.match(adminCss, /@media \(max-width: 560px\)/);
  assert.match(adminCss, /--blue: #2563eb/);
  assert.match(adminCss, /--cyan: #06b6d4/);
  assert.doesNotMatch(adminHtml, /https?:\/\//);
  assert.doesNotMatch(adminCss, /@import|url\(https?:\/\//);
});

test('ícones do fantasma são separados e painel do usuário não aponta para a administração', () => {
  assert.match(adminHtml, /href="\/admin-favicon\.png\?v=3\.0\.0"/);
  assert.match(panelHtml, /href="\/panel-favicon\.png\?v=3\.0\.0"/);
  assert.doesNotMatch(panelHtml, /href="\/dbmadmin"/);
  assert.match(panelHtml, />Privacidade e uso<\/a>/);
  for (const file of ['admin-favicon.png', 'panel-favicon.png']) {
    const png = fs.readFileSync(path.join(root, 'public', file));
    assert.deepEqual([...png.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
  }
});

test('atalho administrativo abre o painel do usuário em nova guia', () => {
  assert.match(adminHtml, /href="\/painel" target="_blank" rel="noopener">Abrir painel do usuário<\/a>/);
});

test('painel do usuário separa as cinco áreas sem IDs ausentes ou duplicados', () => {
  for (const page of ['home', 'account', 'messages', 'activity', 'privacy']) {
    assert.match(panelHtml, new RegExp(`data-page="${page}"`));
    assert.match(panelHtml, new RegExp(`data-page-target="${page}"`));
  }
  const ids = [...panelHtml.matchAll(/id="([^"]+)"/g)].map(match => match[1]);
  assert.equal(new Set(ids).size, ids.length);
  const references = [...panelJs.matchAll(/\$\('([^']+)'\)/g)].map(match => match[1]);
  for (const reference of references) assert.ok(ids.includes(reference), `ID ausente no painel: ${reference}`);
});

test('painel do usuário mantém perfis visíveis e responsivos', () => {
  assert.match(panelHtml, /id="profileTabs" class="profile-tabs"/);
  assert.match(panelCss, /grid-template-columns: repeat\(4, minmax\(0, 1fr\)\)/);
  assert.match(panelCss, /\.profile-tabs\.count-3 \{ grid-template-columns: repeat\(3/);
  assert.match(panelCss, /@media \(max-width: 920px\)/);
  assert.match(panelCss, /\.profile-tabs\.count-1, \.profile-tabs\.count-2, \.profile-tabs\.count-3 \{ grid-template-columns: repeat\(2/);
});

test('confirmações próprias protegem ações e exigem EXCLUIR para apagar a conta', () => {
  assert.match(panelHtml, /id="confirmDialog"/);
  assert.match(panelHtml, /id="confirmTypeGroup"/);
  assert.match(panelJs, /function askConfirmation/);
  assert.match(panelJs, /requireText: 'EXCLUIR'/);
  assert.match(panelJs, /confirmationRequiredText && event\.key === 'Enter'/);
  assert.doesNotMatch(panelJs, /\bconfirm\(/);
});

test('rascunho, comunicação e respostas atrasadas possuem proteção', () => {
  assert.match(panelJs, /sessionStorage\.setItem\(draftKey\(\)/);
  assert.match(panelJs, /beforeunload/);
  assert.match(panelJs, /requestSequence !== stateRequestSequence/);
  assert.match(panelJs, /function markDisconnected/);
  assert.match(panelHtml, /id="updatedAt"/);
  assert.match(panelHtml, /id="connectionBanner"/);
  assert.match(panelJs, /let globalFeedbackTimer = null/);
  assert.match(panelJs, /globalFeedbackSource === 'refresh'/);
  assert.match(panelJs, /setTimeout\(\(\) =>/);
  assert.match(panelJs, /recoverMissingProfile\(requestedProfile\)/);
  assert.match(panelJs, /selecionado automaticamente/);
  assert.doesNotMatch(panelJs, /refreshState\(true, \{ restoreDraft: true, manual: true \}\)/);
});

test('atividade limita três transmissões, ordena as mais recentes e traduz os registros', () => {
  assert.match(panelJs, /scheduledStartTime \|\| left\.live\.startedAt/);
  assert.match(panelJs, /\.slice\(0, 3\)/);
  assert.match(panelJs, /const LOG_TYPE_NAMES = Object\.freeze/);
  assert.match(panelJs, /send: 'ENVIO'/);
  assert.match(panelJs, /oauth: 'CONTA GOOGLE'/);
  assert.match(panelJs, /Token has been expired or revoked/);
  assert.match(panelJs, /=== 'send' \? entry\.message : translateTechnicalText\(entry\.message\)/);
  assert.match(panelJs, /toLocaleString\('pt-BR'\)/);
});

test('exclusão da conta fica isolada em zona de perigo', () => {
  assert.match(panelHtml, /class="danger-panel"/);
  assert.match(panelHtml, /id="deleteAccountButton"/);
  assert.match(panelCss, /\.danger-panel/);
});
