'use strict';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'auto-server-tests-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';

const store = require('../lib/store');
const security = require('../lib/security');
const validation = require('../lib/validation');
const youtube = require('../lib/youtube');
const { normalizeChannelInput, extractChannelMetadata } = require('../lib/channel-normalizer');
const discovery = require('../lib/youtube-discovery');
const { createGlobalMonitor } = require('../lib/global-monitor');
const { createAdminLiveVerifier } = require('../lib/admin-live-verifier');
const { createApp, invalidateProfileOAuth, holdProfileForOAuthChange } = require('../server');
const { createWorkers, DEFAULT_CHAT_AVAILABILITY_RETRY_MS } = require('../lib/workers');

let server;
let base;
let adminCookie;
let adminCsrf;
let userId;
let token;
let userCookie;
let webCsrf;

async function request(route, { method = 'GET', body, admin = false, web = false, bearer = token, csrfOverride, origin, userAgent } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (admin) {
    headers.Cookie = adminCookie;
    headers['X-CSRF-Token'] = csrfOverride ?? adminCsrf;
  } else if (web) {
    headers.Cookie = userCookie;
    if (csrfOverride !== null) headers['X-CSRF-Token'] = csrfOverride ?? webCsrf;
  } else if (bearer) headers.Authorization = `Bearer ${bearer}`;
  if (origin) headers.Origin = origin;
  if (userAgent) headers['User-Agent'] = userAgent;
  const response = await fetch(`${base}${route}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(10000)
  });
  const contentType = response.headers.get('content-type') || '';
  const responseBody = contentType.includes('application/json') ? await response.json() : await response.text();
  return { status: response.status, body: responseBody, cookie: response.headers.get('set-cookie')?.split(';')[0] };
}

before(async () => {
  server = createApp().listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  store.close();
  fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true });
});

test('setup exige código, CSRF e cria apenas um administrador', async () => {
  const denied = await request('/dbmadmin/api/setup', { method: 'POST', body: { setupToken: 'wrong', username: 'admin', password: 'valid-test-password' } });
  assert.equal(denied.status, 403);
  const results = await Promise.all(['admin', 'admin2'].map(username => request('/dbmadmin/api/setup', { method: 'POST', body: { setupToken: process.env.SETUP_TOKEN, username, password: 'valid-test-password' } })));
  assert.deepEqual(results.map(result => result.status).sort(), [200, 409]);
  adminCookie = results.find(result => result.status === 200).cookie;
  const bootstrap = await request('/dbmadmin/api/bootstrap', { admin: true });
  assert.equal(bootstrap.body.authenticated, true);
  adminCsrf = bootstrap.body.csrfToken;
  assert.equal((await request('/dbmadmin/api/global-monitor', { admin: true, csrfOverride: 'bad', method: 'PATCH', body: { intervalMinutes: 3 } })).status, 403);
  assert.equal((await request('/dbmadmin/api/global-monitor', { admin: true, origin: 'https://untrusted.invalid', method: 'PATCH', body: { intervalMinutes: 3 } })).status, 403);
});

test('admin adiciona, prioriza, desabilita e exclui chaves sem expor o segredo', async () => {
  const firstSecret = `AIza${'A'.repeat(35)}`;
  const secondSecret = `AIza${'B'.repeat(35)}`;
  const first = await request('/dbmadmin/api/verification-keys', { admin: true, method: 'POST', body: { name: 'Principal', apiKey: firstSecret } });
  const second = await request('/dbmadmin/api/verification-keys', { admin: true, method: 'POST', body: { name: 'Reserva', apiKey: secondSecret } });
  assert.equal(first.status, 201);
  assert.equal(second.status, 201);
  assert.equal(JSON.stringify(first.body).includes(firstSecret), false);
  assert.equal(JSON.stringify(second.body).includes(secondSecret), false);
  assert.match(first.body.key.keyHint, /^AIzaAA…AAAA$/);
  assert.equal(security.decryptText(store.getAdminVerificationKey(first.body.key.id).api_key_enc), firstSecret);
  assert.equal((await request('/dbmadmin/api/verification-keys', { admin: true, method: 'POST', body: { name: 'Duplicada', apiKey: firstSecret } })).status, 409);

  const promoted = await request(`/dbmadmin/api/verification-keys/${second.body.key.id}`, { admin: true, method: 'PATCH', body: { makePrimary: true } });
  assert.equal(promoted.status, 200);
  assert.equal(promoted.body.keys[0].id, second.body.key.id);
  const disabled = await request(`/dbmadmin/api/verification-keys/${first.body.key.id}`, { admin: true, method: 'PATCH', body: { enabled: false } });
  assert.equal(disabled.body.key.enabled, false);
  const dataResult = await request('/dbmadmin/api/data', { admin: true });
  assert.equal(JSON.stringify(dataResult.body).includes('api_key_enc'), false);
  assert.equal(JSON.stringify(dataResult.body).includes('key_fingerprint'), false);

  assert.equal((await request(`/dbmadmin/api/verification-keys/${second.body.key.id}`, { admin: true, method: 'DELETE', body: {} })).status, 200);
  assert.equal((await request(`/dbmadmin/api/verification-keys/${first.body.key.id}`, { admin: true, method: 'DELETE', body: {} })).status, 200);
  assert.deepEqual(store.publicAdminVerificationKeys(), []);
});

test('cadastro usa nome de usuário sem arroba e cria exatamente três perfis', async () => {
  const body = { username: 'MKZ 01', password: 'valid-user-password', active: true };
  const results = await Promise.all([
    request('/dbmadmin/api/users', { admin: true, method: 'POST', body }),
    request('/dbmadmin/api/users', { admin: true, method: 'POST', body })
  ]);
  assert.deepEqual(results.map(result => result.status).sort(), [201, 409]);
  userId = results.find(result => result.status === 201).body.id;
  const profiles = store.userProfiles(userId);
  assert.deepEqual(profiles.map(profile => profile.profileNumber), [1, 2, 3]);
  assert.equal(new Set(profiles.map(profile => profile.id)).size, 3);
  assert.ok(profiles.every(profile => profile.config.intervalMinutes === 3));
  assert.ok(profiles.every(profile => profile.config.intervalSeconds === 1));
  assert.equal((await request('/dbmadmin/api/users', { admin: true, method: 'POST', body: { username: 'bad@example.com', password: 'valid-user-password' } })).status, 400);
});

test('login por usuário funciona e login por e-mail é recusado', async () => {
  const login = await request('/api/login', { method: 'POST', body: { username: 'mkz 01', password: 'valid-user-password', privacyAccepted: true }, bearer: '' });
  assert.equal(login.status, 200);
  token = login.body.token;
  userCookie = login.cookie;
  assert.match(userCookie, /^auto_server_user=/);
  assert.equal(login.body.user.username, 'MKZ 01');
  assert.equal((await request('/api/login', { method: 'POST', body: { email: 'mkz@example.com', password: 'valid-user-password', privacyAccepted: true }, bearer: '' })).status, 400);
  assert.equal((await request('/dbmadmin/api/data')).status, 401);
});

test('painel web usa cookie HttpOnly, bootstrap e CSRF', async () => {
  const page = await fetch(`${base}/painel`);
  assert.equal(page.status, 200);
  const html = await page.text();
  assert.match(html, /V3\.0\.0/);
  assert.match(html, /id="sendMode"/);
  assert.match(html, /id="renameProfileButton"/);
  assert.match(html, /id="profileNameDialog"/);
  assert.match(html, /maxlength="220000"/);
  assert.match(html, /Perfil 1|PERFIL 1/);
  assert.match(html, /id="intervalSeconds"/);
  assert.match(html, /Cada perfil aceita somente um canal/);
  const bootstrap = await request('/api/web/bootstrap', { web: true });
  assert.equal(bootstrap.body.authenticated, true);
  webCsrf = bootstrap.body.csrfToken;
  assert.ok(webCsrf.length > 20);
  const version = store.getUserProfile(userId, 1).config.version;
  assert.equal((await request('/api/config', { web: true, csrfOverride: null, method: 'PUT', body: { intervalMinutes: 3, expectedVersion: version } })).status, 403);
  assert.equal((await request('/api/config', { web: true, method: 'PUT', body: { intervalMinutes: 3, expectedVersion: version } })).status, 200);
  const script = fs.readFileSync(path.join(__dirname, '..', 'public', 'panel.js'), 'utf8');
  assert.match(script, /confirmControl\('start'\)/);
  assert.match(script, /confirmControl\('pause'\)/);
  assert.match(script, /confirmControl\('stop'\)/);
  assert.match(script, /stateRequestSequence/);
  assert.match(script, /MAX_MESSAGES = 500/);
  assert.match(script, /LIVE:\s*'AO VIVO'/);
  assert.match(script, /SCHEDULED:\s*'PROGRAMADA'/);
  const health = await request('/health', { bearer: '' });
  assert.deepEqual({ ok: health.body.ok, version: health.body.version, schemaVersion: health.body.schemaVersion, storage: health.body.storage }, { ok: true, version: '3.0.0', schemaVersion: 6, storage: 'ok' });
  const info = await request('/api/info', { bearer: '' });
  assert.equal(info.body.maxMessages, 500);
  assert.equal(info.body.maxMessageCharacters, 200);
  const privacy = await fetch(`${base}/privacy`);
  assert.equal(privacy.status, 200);
  const privacyHtml = await privacy.text();
  assert.match(privacyHtml, /identificação não reutilizável da sessão/);
  assert.match(privacyHtml, /Versão da política: 13\/09\/2026/);
});

test('usuário renomeia o próprio perfil pelo painel sem alterar execução ou configuração', async () => {
  const before = store.getUserProfile(userId, 1);
  const snapshot = {
    status: before.runtime.status,
    sent: before.runtime.sent,
    configVersion: before.config.version,
    oauthVersion: before.oauth.version
  };
  const appDenied = await request('/api/profiles/1/name', { method: 'PATCH', body: { name: 'Nome pelo aplicativo' } });
  assert.equal(appDenied.status, 403);
  const missingCsrf = await request('/api/profiles/1/name', { web: true, csrfOverride: null, method: 'PATCH', body: { name: 'Mega' } });
  assert.equal(missingCsrf.status, 403);
  const changed = await request('/api/profiles/1/name', { web: true, method: 'PATCH', body: { name: '  Peraltoso   Mega  ' } });
  assert.equal(changed.status, 200);
  assert.equal(changed.body.profile.name, 'Peraltoso Mega');
  const after = store.getUserProfile(userId, 1);
  assert.equal(after.name, 'Peraltoso Mega');
  assert.deepEqual({
    status: after.runtime.status,
    sent: after.runtime.sent,
    configVersion: after.config.version,
    oauthVersion: after.oauth.version
  }, snapshot);
  assert.equal((await request('/api/profiles/1/name', { web: true, method: 'PATCH', body: { name: '   ' } })).status, 400);
  assert.equal((await request('/api/profiles/1/name', { web: true, method: 'PATCH', body: { name: 'x'.repeat(101) } })).status, 400);
  assert.equal((await request('/api/profiles/50/name', { web: true, method: 'PATCH', body: { name: 'Outro' } })).status, 404);
  assert.ok(store.auditLog().some(entry => entry.action === 'profile_rename' && entry.actor === userId && entry.target.includes('perfil=1')));
});

test('auditoria identifica painel web e aplicativo sem guardar o token da sessão', async () => {
  store.updateUserProfile(userId, 2, profile => {
    profile.runtime.sent = 7;
    profile.runtime.failures = 2;
    profile.runtime.attempts = 9;
    profile.runtime.connectionErrors = 1;
  });
  const webAction = await request('/api/profiles/2/logs/clear', {
    web: true,
    method: 'POST',
    body: {},
    userAgent: 'Mozilla/5.0 Painel-Auditoria-Teste'
  });
  assert.equal(webAction.status, 200);
  const afterClear = store.getUserProfile(userId, 2);
  assert.deepEqual(
    [afterClear.runtime.sent, afterClear.runtime.failures, afterClear.runtime.attempts, afterClear.runtime.connectionErrors],
    [7, 2, 9, 1]
  );

  const appAction = await request('/api/profiles/3/stop', {
    method: 'POST',
    body: {},
    userAgent: 'AutoServerAndroid/2.3.7'
  });
  assert.equal(appAction.status, 200);

  const events = store.auditLog();
  const webEvent = events.find(entry => entry.action === 'profile_logs_clear' && entry.actor === userId);
  const appEvent = events.find(entry => entry.action === 'profile_stop' && entry.actor === userId && entry.target.includes('perfil=3'));
  assert.match(webEvent.target, /perfil=2; cliente=painel-web; sessao=[a-f0-9]{12}; ip=/);
  assert.match(webEvent.target, /agente=Mozilla\/5\.0 Painel-Auditoria-Teste/);
  assert.match(appEvent.target, /cliente=android; sessao=[a-f0-9]{12}; ip=/);
  assert.match(appEvent.target, /agente=AutoServerAndroid\/2\.3\.7/);
  assert.equal(events.some(entry => entry.target.includes(token)), false);
});

test('admin configura API e Conta Google de cada perfil separadamente', async () => {
  for (const number of [1, 2, 3]) {
    const result = await request(`/dbmadmin/api/users/${userId}/profiles/${number}`, {
      admin: true,
      method: 'PATCH',
      body: {
        name: `Operação ${number}`,
        enabled: true,
        googleEmail: `google${number}@example.invalid`,
        clientId: `${number}23-test.apps.googleusercontent.com`,
        clientSecret: `synthetic-secret-${number}`
      }
    });
    assert.equal(result.status, 200);
  }
  const profiles = store.userProfiles(userId);
  assert.deepEqual(profiles.map(profile => profile.googleEmail), ['google1@example.invalid', 'google2@example.invalid', 'google3@example.invalid']);
  assert.equal(security.decryptText(profiles[1].api.clientSecretEnc), 'synthetic-secret-2');
  const data = await request('/dbmadmin/api/data', { admin: true });
  assert.deepEqual(data.body.profileDefaults, { defaultCount: 3, maxCount: 50 });
  assert.equal(JSON.stringify(data.body).includes('synthetic-secret'), false);
  assert.equal(JSON.stringify(data.body).includes('refreshTokenEnc'), false);
});

test('OAuth de cada perfil mostra seletor de contas e estado é consumido uma vez', async () => {
  const result = await request('/api/profiles/2/oauth/connect?client=web');
  assert.equal(result.status, 200);
  const url = new URL(result.body.url);
  assert.equal(url.searchParams.has('login_hint'), false);
  assert.ok(url.searchParams.get('prompt').split(/\s+/).includes('select_account'));
  assert.ok(url.searchParams.get('state').startsWith('w.'));
  const attempt = store.consumeOAuthAttempt(url.searchParams.get('state'));
  assert.equal(attempt.profile_number, 2);
  assert.equal(store.consumeOAuthAttempt(url.searchParams.get('state')), null);
  const legacy = await request('/api/oauth/start', { userAgent: 'PeraltaChatAndroid/2.1.4' });
  assert.equal(legacy.status, 200);
  const legacyUrl = new URL(legacy.body.url);
  assert.ok(legacyUrl.searchParams.get('state').startsWith('l.'));
  assert.equal(store.consumeOAuthAttempt(legacyUrl.searchParams.get('state')).profile_number, 1);
  const failed = await fetch(`${base}/oauth/google/callback?state=w.invalid`);
  assert.equal(failed.status, 400);
  assert.match(await failed.text(), /\/painel\?oauth=erro&amp;profile=1/);
});

test('conectar, trocar ou desconectar Google preserva parado/pausado e pausa somente execução ativa', () => {
  for (const status of ['stopped', 'paused', 'running']) {
    const profile = {
      oauth: { email: 'conta@example.invalid', refreshTokenEnc: 'token', accessTokenEnc: 'access', accessTokenExpiresAt: 123, scope: 'scope', version: 4 },
      runtime: { status, epoch: 7, nextAt: '2026-09-16T00:00:00.000Z', retryAt: 100, quotaResumeAt: 200, legacyLiveChatId: 'chat', legacyVideoId: 'video' }
    };
    holdProfileForOAuthChange(profile);
    assert.equal(profile.runtime.status, status === 'running' ? 'paused' : status);
    assert.equal(profile.runtime.epoch, 8);
    assert.equal(profile.runtime.nextAt, null);

    profile.oauth.refreshTokenEnc = 'token-novo';
    invalidateProfileOAuth(profile, 'Conta desconectada para teste.');
    assert.equal(profile.runtime.status, status === 'running' ? 'paused' : status);
    assert.equal(profile.oauth.refreshTokenEnc, '');
    assert.equal(profile.runtime.lastError, 'Conta desconectada para teste.');
  }
});

test('configurações, mensagens, logs e comandos ficam isolados por perfil', async () => {
  const first = store.getUserProfile(userId, 1);
  const second = store.getUserProfile(userId, 2);
  const fixed = await request('/api/profiles/1/settings', { method: 'PUT', body: { sendMode: 'fixed', intervalMinutes: 0, intervalSeconds: 1, messages: 'Perfil um', expectedVersion: first.config.version } });
  assert.equal(fixed.status, 200);
  assert.equal(fixed.body.settings.sendMode, 'fixed');
  assert.equal(store.getUserProfile(userId, 1).config.sendMode, 'fixed');
  const interval = await request('/api/profiles/1/settings', { method: 'PUT', body: { sendMode: 'interval', expectedVersion: fixed.body.settings.version } });
  assert.equal(interval.status, 200);
  assert.equal((await request('/api/profiles/2/messages', { method: 'PUT', body: { messages: ['Perfil dois A', 'Perfil dois B'], expectedVersion: second.config.version } })).status, 200);
  assert.equal(store.getUserProfile(userId, 1).config.messages, 'Perfil um');
  assert.equal(store.getUserProfile(userId, 1).config.intervalMinutes, 0);
  assert.equal(store.getUserProfile(userId, 1).config.intervalSeconds, 1);
  assert.equal(store.getUserProfile(userId, 1).config.sendMode, 'interval');
  assert.equal(store.getUserProfile(userId, 2).config.messages, 'Perfil dois A\nPerfil dois B');
  assert.equal(store.getUserProfile(userId, 3).config.messages, '');
  store.appendLog(store.getUserProfile(userId, 1), 'test', 'somente um');
  store.appendLog(store.getUserProfile(userId, 2), 'test', 'somente dois');
  assert.ok(store.logs(userId, 1).some(entry => entry.message === 'somente um'));
  assert.ok(!store.logs(userId, 1).some(entry => entry.message === 'somente dois'));
  assert.equal((await request('/api/profiles/4')).status, 404);
});

test('limite de mensagens salva as primeiras 500 e informa as excedentes', async () => {
  const before = store.getUserProfile(userId, 2);
  const lines = Array.from({ length: 503 }, (_, index) => `Mensagem ${String(index + 1).padStart(3, '0')}`);
  const saved = await request('/api/profiles/2/settings', {
    method: 'PUT',
    body: { messages: lines.join('\n'), expectedVersion: before.config.version }
  });
  assert.equal(saved.status, 200);
  assert.deepEqual(saved.body.messageSummary, { received: 503, saved: 500, ignored: 3, limit: 500 });
  const stored = validation.parseMessages(store.getUserProfile(userId, 2).config.messages);
  assert.equal(stored.length, 500);
  assert.equal(stored[0], 'Mensagem 001');
  assert.equal(stored[499], 'Mensagem 500');
  assert.equal(stored.includes('Mensagem 501'), false);

  const current = store.getUserProfile(userId, 2);
  const withInvalidExcess = [...lines.slice(0, 500), 'x'.repeat(201)];
  const ignoredInvalid = await request('/api/profiles/2/messages', {
    method: 'PUT',
    body: { messages: withInvalidExcess, expectedVersion: current.config.version }
  });
  assert.equal(ignoredInvalid.status, 200);
  assert.equal(ignoredInvalid.body.messageSummary.ignored, 1);
  assert.equal(validation.parseMessages(ignoredInvalid.body.messages).length, 500);

  const invalidAccepted = await request('/api/profiles/2/messages', {
    method: 'PUT',
    body: { messages: ['x'.repeat(201)], expectedVersion: ignoredInvalid.body.version }
  });
  assert.equal(invalidAccepted.status, 400);
  assert.equal(validation.parseMessages(store.getUserProfile(userId, 2).config.messages).length, 500);

  const maximum = Array.from({ length: 500 }, () => '🙂'.repeat(200)).join('\n');
  const maximumAccepted = await request('/api/profiles/2/messages', {
    method: 'PUT',
    body: { messages: maximum, expectedVersion: ignoredInvalid.body.version }
  });
  assert.equal(maximumAccepted.status, 200);
  assert.deepEqual(maximumAccepted.body.messageSummary, { received: 500, saved: 500, ignored: 0, limit: 500 });
  assert.equal(validation.parseMessages(maximumAccepted.body.messages).length, 500);
  assert.equal(Array.from(validation.parseMessages(maximumAccepted.body.messages)[0]).length, 200);
});

test('alterar identidade do Perfil 2 não remove OAuth dos Perfis 1 e 3', async () => {
  for (const number of [1, 2, 3]) store.updateUserProfile(userId, number, profile => {
    profile.oauth.refreshTokenEnc = security.encryptText(`token-${number}`);
    profile.oauth.email = `google${number}@example.invalid`;
  });
  const originalRevoke = youtube.revoke;
  youtube.revoke = async () => {};
  try {
    const result = await request(`/dbmadmin/api/users/${userId}/profiles/2`, { admin: true, method: 'PATCH', body: { googleEmail: 'novo2@example.invalid' } });
    assert.equal(result.status, 200);
  } finally { youtube.revoke = originalRevoke; }
  assert.ok(store.getUserProfile(userId, 1).oauth.refreshTokenEnc);
  assert.equal(store.getUserProfile(userId, 2).oauth.refreshTokenEnc, '');
  assert.ok(store.getUserProfile(userId, 3).oauth.refreshTokenEnc);
});

test('administrador adiciona perfis extras um por vez e o padrão continua três', async () => {
  const created = await request('/dbmadmin/api/users', { admin: true, method: 'POST', body: { username: 'Usuário expansível', password: 'valid-expand-password' } });
  assert.equal(created.status, 201);
  const expandedUserId = created.body.id;
  assert.deepEqual(store.userProfiles(expandedUserId).map(profile => profile.profileNumber), [1, 2, 3]);
  const fourth = await request(`/dbmadmin/api/users/${expandedUserId}/profiles`, { admin: true, method: 'POST', body: {} });
  const fifth = await request(`/dbmadmin/api/users/${expandedUserId}/profiles`, { admin: true, method: 'POST', body: {} });
  assert.equal(fourth.status, 201);
  assert.equal(fourth.body.profile.profileId, 4);
  assert.equal(fifth.status, 201);
  assert.equal(fifth.body.profile.profileId, 5);
  assert.deepEqual(store.userProfiles(expandedUserId).map(profile => profile.profileNumber), [1, 2, 3, 4, 5]);
  assert.equal(store.getUserProfile(expandedUserId, 4).config.intervalSeconds, 1);
  assert.equal(store.getUserProfile(expandedUserId, 4).config.sendMode, 'interval');
  assert.equal(store.getUserProfile(expandedUserId, 5).name, 'Perfil 5');
  const expandedLogin = await request('/api/login', { method: 'POST', body: { username: 'Usuário expansível', password: 'valid-expand-password', privacyAccepted: true }, bearer: '' });
  assert.equal(expandedLogin.status, 200);
  assert.equal((await request('/api/profiles/4', { bearer: expandedLogin.body.token })).status, 200);
  assert.ok(store.auditLog().some(entry => entry.action === 'user_profile_create' && entry.target === `${expandedUserId}:5`));
  assert.equal(store.deleteUser(expandedUserId), true);
});

test('somente perfis adicionais podem ser excluídos e números livres são reutilizados', async () => {
  const created = await request('/dbmadmin/api/users', {
    admin: true,
    method: 'POST',
    body: { username: 'Exclusão de perfil', password: 'valid-delete-password' }
  });
  assert.equal(created.status, 201);
  const deleteUserId = created.body.id;
  for (const expected of [4, 5]) {
    const added = await request(`/dbmadmin/api/users/${deleteUserId}/profiles`, { admin: true, method: 'POST', body: {} });
    assert.equal(added.status, 201);
    assert.equal(added.body.profile.profileId, expected);
  }

  const protectedAt = '2026-09-08T10:00:00.000Z';
  store.updateUserProfile(deleteUserId, 1, profile => {
    profile.runtime.status = 'running';
    profile.runtime.lastSentAt = protectedAt;
  });
  for (const number of [1, 2, 3]) {
    const denied = await request(`/dbmadmin/api/users/${deleteUserId}/profiles/${number}`, {
      admin: true,
      method: 'DELETE',
      body: {}
    });
    assert.equal(denied.status, 409);
    assert.match(denied.body.error, /permanentes/i);
    assert.ok(store.getUserProfile(deleteUserId, number));
  }
  assert.equal(store.getUserProfile(deleteUserId, 1).runtime.status, 'running');
  assert.equal(store.getUserProfile(deleteUserId, 1).runtime.lastSentAt, protectedAt);
  assert.throws(() => store.deleteUserProfile(deleteUserId, 3), error => error.status === 409);

  const fourth = store.updateUserProfile(deleteUserId, 4, profile => {
    profile.oauth.refreshTokenEnc = security.encryptText('token-profile-four');
    profile.config.messages = 'Mensagem exclusiva do Perfil 4';
  });
  store.appendLog(fourth, 'test', 'registro exclusivo do Perfil 4');
  store.recordApiCall(deleteUserId, 4, 'videos.list', true, Date.parse('2026-09-08T12:00:00Z'));
  const oauthState = 'delete-profile-oauth-state';
  store.saveOAuthAttempt(oauthState, store.getUser(deleteUserId), fourth);
  const channel = store.upsertGlobalChannel({
    channelId: 'UC4444444444444444444444',
    handle: '@ExcluirPerfilQuatro',
    canonicalUrl: 'https://www.youtube.com/@ExcluirPerfilQuatro',
    displayName: 'Excluir Perfil Quatro',
    originalInput: '@ExcluirPerfilQuatro'
  });
  store.subscribeChannel(deleteUserId, 4, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, {
    videoId: 'P4444444444',
    title: 'Perfil adicional',
    liveStatus: 'SCHEDULED',
    chatStatus: 'AVAILABLE',
    resolved: true
  }).live;
  store.distributeLive(live.id);
  assert.equal(store.profileLiveStates(deleteUserId, 4).length, 1);

  const originalRevoke = youtube.revoke;
  const revoked = [];
  youtube.revoke = async value => { revoked.push(value); };
  try {
    const removed = await request(`/dbmadmin/api/users/${deleteUserId}/profiles/4`, {
      admin: true,
      method: 'DELETE',
      body: {}
    });
    assert.equal(removed.status, 200);
    assert.equal(removed.body.deletedProfile, 4);
  } finally {
    youtube.revoke = originalRevoke;
  }

  assert.equal(revoked.length, 1);
  assert.equal(store.getUserProfile(deleteUserId, 4), null);
  assert.deepEqual(store.userProfiles(deleteUserId).map(profile => profile.profileNumber), [1, 2, 3, 5]);
  assert.deepEqual(store.logs(deleteUserId, 4), []);
  assert.equal(store.profileLiveStates(deleteUserId, 4).length, 0);
  assert.equal(store.consumeOAuthAttempt(oauthState), null);
  assert.equal(store.apiUsage(deleteUserId, 4, Date.parse('2026-09-08T12:00:00Z')).requests, 0);
  store.recordApiCall(deleteUserId, 4, 'videos.list', true, Date.parse('2026-09-08T12:00:00Z'));
  assert.equal(store.apiUsage(deleteUserId, 4, Date.parse('2026-09-08T12:00:00Z')).requests, 0);
  assert.equal(store.globalChannels(true).some(item => item.id === channel.id), false);
  assert.ok(store.auditLog().some(entry => entry.action === 'user_profile_delete' && entry.target === `${deleteUserId}:4`));

  const replacement = await request(`/dbmadmin/api/users/${deleteUserId}/profiles`, {
    admin: true,
    method: 'POST',
    body: {}
  });
  assert.equal(replacement.status, 201);
  assert.equal(replacement.body.profile.profileId, 4);
  assert.deepEqual(store.userProfiles(deleteUserId).map(profile => profile.profileNumber), [1, 2, 3, 4, 5]);
  assert.equal(store.deleteUser(deleteUserId), true);
});

test('excluir uma conta revoga uma vez cada autorização Google', async () => {
  const created = await request('/dbmadmin/api/users', {
    admin: true,
    method: 'POST',
    body: { username: 'Conta para revogar', password: 'valid-revoke-password' }
  });
  assert.equal(created.status, 201);
  const revokeUserId = created.body.id;
  for (const number of [1, 2]) store.updateUserProfile(revokeUserId, number, profile => {
    profile.oauth.refreshTokenEnc = security.encryptText(`refresh-delete-${number}`);
  });
  const login = await request('/api/login', {
    method: 'POST',
    body: { username: 'Conta para revogar', password: 'valid-revoke-password', privacyAccepted: true },
    bearer: ''
  });
  assert.equal(login.status, 200);

  const originalRevoke = youtube.revoke;
  const revoked = [];
  youtube.revoke = async value => { revoked.push(value); };
  try {
    const removed = await request('/api/account', {
      method: 'DELETE',
      body: {},
      bearer: login.body.token,
      userAgent: 'AutoServerAndroid/2.3.7'
    });
    assert.equal(removed.status, 200);
  } finally {
    youtube.revoke = originalRevoke;
  }

  assert.equal(revoked.length, 2);
  assert.equal(new Set(revoked).size, 2);
  assert.equal(store.getUser(revokeUserId), null);
  assert.ok(store.auditLog().some(entry => entry.actor === revokeUserId && entry.action === 'account_delete'));
});

test('normalizador rejeita vídeo e unifica metadados do canal', () => {
  assert.equal(normalizeChannelInput(' youtube.com/@Canal/streams?x=1 ').canonicalUrl, 'https://www.youtube.com/@Canal');
  assert.throws(() => normalizeChannelInput('https://youtube.com/watch?v=AAAAAAAAAAA'), /vídeo/i);
  assert.throws(() => normalizeChannelInput('https://evil.invalid/@Canal'), /youtube\.com/i);
  const normalized = normalizeChannelInput('https://youtube.com/c/CanalAntigo/videos');
  const metadata = extractChannelMetadata('<meta itemprop="channelId" content="UC1234567890123456789012"><link rel="canonical" href="https://www.youtube.com/@CanalNovo"><meta property="og:title" content="Canal Novo">', normalized);
  assert.equal(metadata.channelId, 'UC1234567890123456789012');
  assert.equal(metadata.handle, '@CanalNovo');
  assert.equal(metadata.canonicalUrl, 'https://www.youtube.com/@CanalNovo');
});

test('registro global deduplica canal entre usuários e perfis', () => {
  const other = store.createUser({ id: store.id('usr'), username: 'Outro usuário', active: true, sessionVersion: 1 });
  const first = store.upsertGlobalChannel({ channelId: 'UC1234567890123456789012', handle: '@CanalUnico', canonicalUrl: 'https://www.youtube.com/@CanalUnico', displayName: 'Canal Único', originalInput: '@CanalUnico' });
  store.subscribeChannel(userId, 1, first, '@CanalUnico');
  const same = store.upsertGlobalChannel({ channelId: 'UC1234567890123456789012', handle: '@canalunico', canonicalUrl: 'https://www.youtube.com/@canalunico', displayName: 'Canal Único', originalInput: 'link alternativo' });
  const secondSubscription = store.subscribeChannel(other.id, 2, same, 'https://youtube.com/channel/UC1234567890123456789012');
  assert.equal(first.id, same.id);
  assert.equal(store.globalChannels(true).filter(channel => channel.channel_id === first.channel_id).length, 1);
  const firstSubscription = store.profileChannels(userId, 1).find(channel => channel.globalChannelId === first.id);
  assert.ok(store.removeSubscription(userId, 1, firstSubscription.id));
  assert.ok(store.globalChannels(true).some(channel => channel.id === first.id));
  assert.ok(store.removeSubscription(other.id, 2, secondSubscription.id));
  assert.ok(!store.globalChannels(true).some(channel => channel.id === first.id));
});

test('cada conta mantém um canal independente em cada um dos três perfis', async () => {
  const first = store.upsertGlobalChannel({ channelId: 'UC1111111111111111111111', handle: '@PerfilUm', canonicalUrl: 'https://www.youtube.com/@PerfilUm', displayName: 'Perfil Um', originalInput: '@PerfilUm' });
  const second = store.upsertGlobalChannel({ channelId: 'UC2222222222222222222222', handle: '@PerfilDois', canonicalUrl: 'https://www.youtube.com/@PerfilDois', displayName: 'Perfil Dois', originalInput: '@PerfilDois' });
  const firstSubscription = store.subscribeChannel(userId, 1, first, first.handle);
  assert.throws(
    () => store.subscribeChannel(userId, 1, second, second.handle),
    error => error.status === 409 && /já possui um canal/i.test(error.message)
  );
  const post = await request('/api/profiles/1/channels', { method: 'POST', body: { channel: '@OutroCanal' } });
  assert.equal(post.status, 409);
  const bulk = await request('/api/profiles/1/channels', { method: 'PUT', body: { channels: ['@CanalA', '@CanalB'] } });
  assert.equal(bulk.status, 400);
  const secondSubscription = store.subscribeChannel(userId, 2, second, second.handle);
  assert.equal(store.profileChannels(userId, 1).length, 1);
  assert.equal(store.profileChannels(userId, 2).length, 1);
  assert.equal(store.profileChannels(userId, 3).length, 0);
  store.removeSubscription(userId, 1, firstSubscription.id);
  store.removeSubscription(userId, 2, secondSubscription.id);
});

test('descoberta HTTP prioriza live e separa o estado do chat', () => {
  const initial = { contents: [{ videoRenderer: { videoId: 'AAAAAAAAAAA', title: { simpleText: 'Programada' }, upcomingEventData: { startTime: '2000000000' } } }, { videoRenderer: { videoId: 'BBBBBBBBBBB', title: { simpleText: 'Ao vivo' }, badges: [{ label: 'LIVE' }] } }] };
  const candidates = discovery.extractCandidatesFromStreams(`<script>var ytInitialData = ${JSON.stringify(initial)};</script>`);
  assert.deepEqual(candidates.map(candidate => candidate.videoId), ['BBBBBBBBBBB', 'AAAAAAAAAAA']);
  const player = { videoDetails: { videoId: 'BBBBBBBBBBB', title: 'Ao vivo', isLive: true, isLiveContent: true }, microformat: { playerMicroformatRenderer: { liveBroadcastDetails: { isLiveNow: true, startTimestamp: '2026-09-06T10:00:00Z' } } } };
  const data = { liveChatRenderer: { continuations: [] } };
  const state = discovery.resolveLiveState(`ytInitialPlayerResponse = ${JSON.stringify(player)}; ytInitialData = ${JSON.stringify(data)};`, { videoId: 'BBBBBBBBBBB', hintEnded: true });
  assert.equal(state.liveStatus, 'LIVE');
  assert.equal(state.chatStatus, 'AVAILABLE');
  assert.equal(state.confirmedActive, true);
});

test('descoberta HTTP reconhece lockupViewModel atual e não perde live após programadas', () => {
  const lockup = (videoId, badge, detail) => ({ richItemRenderer: { content: { lockupViewModel: {
    contentId: videoId,
    contentType: 'LOCKUP_CONTENT_TYPE_VIDEO',
    contentImage: { thumbnailViewModel: { overlays: [{ thumbnailBottomOverlayViewModel: { badges: [{ thumbnailBadgeViewModel: { text: badge, badgeStyle: badge === 'AO VIVO' ? 'THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE' : 'THUMBNAIL_OVERLAY_BADGE_STYLE_DEFAULT' } }] } }] } },
    metadata: { lockupMetadataViewModel: { title: { content: `Vídeo ${videoId}` }, metadata: { contentMetadataViewModel: { metadataRows: [{ metadataParts: [{ text: { content: detail } }] }] } } } }
  } } } });
  const initial = { contents: { richGridRenderer: { contents: [
    lockup('CCCCCCCCCCC', 'Em breve', 'Programado para amanhã'),
    lockup('DDDDDDDDDDD', 'Em breve', 'Programado para depois'),
    lockup('EEEEEEEEEEE', 'Em breve', 'Programado para outra data'),
    lockup('FFFFFFFFFFF', 'Em breve', 'Programado para o mês que vem'),
    lockup('GGGGGGGGGGG', 'AO VIVO', '1,2 mil assistindo'),
    lockup('HHHHHHHHHHH', '', 'Transmitido há 2 horas')
  ] } } };
  const candidates = discovery.extractCandidatesFromStreams(`ytInitialData = ${JSON.stringify(initial)};`);
  assert.deepEqual(candidates.map(candidate => candidate.videoId), ['GGGGGGGGGGG', 'CCCCCCCCCCC', 'DDDDDDDDDDD']);
  assert.equal(candidates[0].hintLive, true);
  assert.equal(candidates[1].hintScheduled, true);
  assert.ok(candidates.every(candidate => !candidate.hintEnded));
});

test('página programada não vira encerrada por conter LIVE_STREAM_OFFLINE', () => {
  const player = {
    playabilityStatus: { status: 'LIVE_STREAM_OFFLINE', reason: 'A transmissão começará em breve' },
    videoDetails: { videoId: 'IIIIIIIIIII', title: 'Programada', isLiveContent: true },
    microformat: { playerMicroformatRenderer: { liveBroadcastDetails: { startTimestamp: '2033-05-18T03:33:20Z' } } },
    liveStreamOfflineSlateRenderer: { scheduledStartTime: '2000000000' }
  };
  const data = { liveChatRenderer: { continuations: [] } };
  const state = discovery.resolveLiveState(`ytInitialPlayerResponse = ${JSON.stringify(player)}; ytInitialData = ${JSON.stringify(data)};`, { videoId: 'IIIIIIIIIII', hintScheduled: true }, Date.parse('2033-05-17T00:00:00Z'));
  assert.equal(state.liveStatus, 'SCHEDULED');
  assert.equal(state.chatStatus, 'AVAILABLE');
  assert.equal(state.confirmedActive, true);
});

test('LOGIN_REQUIRED anti-bot é transitório e nunca confirma encerramento da live', async () => {
  const player = {
    playabilityStatus: { status: 'LOGIN_REQUIRED', reason: 'Faça login para confirmar que você não é um bot' }
  };
  const html = `ytInitialPlayerResponse = ${JSON.stringify(player)};`;
  assert.throws(
    () => discovery.resolveLiveState(html, { videoId: 'B1111111111', hintLive: true }),
    error => error.status === 503 && error.protectionChallenge === true && /preservada/i.test(error.message)
  );
  await assert.rejects(
    discovery.recheckLive(
      { video_id: 'B1111111111', title: 'Live protegida', live_status: 'LIVE' },
      { fetchImpl: async () => ({ ok: true, url: 'https://www.youtube.com/watch?v=B1111111111', text: async () => html }) }
    ),
    error => error.status === 503 && error.protectionChallenge === true
  );
});

test('verificador administrativo alterna chaves, compartilha a consulta e não usa credenciais de perfil', async () => {
  const keys = [
    { id: 'key-primary', name: 'Principal', api_key_enc: 'KEY-PRIMARY', enabled: 1, priority: 1, status: 'UNTESTED', cooldown_until: null },
    { id: 'key-reserve', name: 'Reserva', api_key_enc: 'KEY-RESERVE', enabled: 1, priority: 2, status: 'UNTESTED', cooldown_until: null }
  ];
  const calls = [], outcomes = [], marks = [];
  const verifier = createAdminLiveVerifier({
    storage: {
      adminVerificationKeys: () => keys,
      recordAdminVerificationCall: (keyId, succeeded) => outcomes.push({ keyId, succeeded }),
      markAdminVerificationKey: (keyId, patch) => marks.push({ keyId, patch })
    },
    vault: { decryptText: value => value },
    clock: () => Date.parse('2026-09-16T12:00:00Z'),
    fetchImpl: async url => {
      const key = new URL(url).searchParams.get('key');
      calls.push(key);
      if (key === 'KEY-PRIMARY') return {
        ok: false,
        status: 403,
        headers: { get: () => null },
        json: async () => ({ error: { message: 'Quota exceeded', errors: [{ reason: 'quotaExceeded' }] } })
      };
      return {
        ok: true,
        status: 200,
        headers: { get: () => null },
        json: async () => ({ items: [{
          id: 'V8888888888',
          snippet: { title: 'Live confirmada', liveBroadcastContent: 'live' },
          liveStreamingDetails: { actualStartTime: '2026-09-16T11:00:00Z', activeLiveChatId: 'CHAT-ADMINISTRATIVO' }
        }] })
      };
    }
  });
  const [first, second] = await Promise.all([
    verifier.verifyKnownLive('V8888888888'),
    verifier.verifyKnownLive('V8888888888')
  ]);
  assert.equal(first, second);
  assert.deepEqual(calls, ['KEY-PRIMARY', 'KEY-RESERVE']);
  assert.deepEqual(outcomes, [{ keyId: 'key-primary', succeeded: false }, { keyId: 'key-reserve', succeeded: true }]);
  assert.equal(first.keyId, 'key-reserve');
  assert.equal(first.candidate.liveStatus, 'LIVE');
  assert.equal(first.candidate.chatStatus, 'AVAILABLE');
  assert.equal(first.candidate.activeLiveChatId, 'CHAT-ADMINISTRATIVO');
  assert.equal(marks.find(item => item.keyId === 'key-primary').patch.status, 'QUOTA');
  assert.equal(marks.find(item => item.keyId === 'key-reserve').patch.status, 'ACTIVE');
});

test('grade preenchida em formato desconhecido gera erro em vez de falso zero', () => {
  const initial = { contents: { richGridRenderer: { contents: [{ richItemRenderer: { content: { futureVideoModel: { id: 'JJJJJJJJJJJ' } } } }] } } };
  assert.throws(() => discovery.extractCandidatesFromStreams(`ytInitialData = ${JSON.stringify(initial)};`), /formato.*não reconhece/i);
});

test('monitor global não sobrepõe ciclos e distribui uma descoberta', async () => {
  const channel = store.upsertGlobalChannel({ channelId: 'UC9999999999999999999999', handle: '@MonitorTeste', canonicalUrl: 'https://www.youtube.com/@MonitorTeste', displayName: 'Monitor Teste', originalInput: '@MonitorTeste' });
  const subscription1 = store.subscribeChannel(userId, 1, channel, '@MonitorTeste');
  const subscription2 = store.subscribeChannel(userId, 2, channel, '@MonitorTeste');
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  let calls = 0;
  const monitor = createGlobalMonitor({
    discover: async current => {
      calls++;
      await gate;
      return { channelMetadata: { channelId: current.channel_id, handle: current.handle, canonicalUrl: current.canonical_url, displayName: current.display_name }, lives: [{ videoId: 'CCCCCCCCCCC', title: 'Live programada', liveStatus: 'SCHEDULED', chatStatus: 'AVAILABLE', scheduledStartTime: '2026-09-07T10:00:00Z', resolved: true }] };
    }
  });
  const firstScan = monitor.scan({ manual: true });
  await new Promise(resolve => setImmediate(resolve));
  const overlapping = await monitor.scan({ manual: true });
  assert.equal(overlapping.skipped, true);
  release();
  const completed = await firstScan;
  assert.equal(completed.ok, true);
  assert.equal(calls, 1);
  assert.equal(store.getGlobalLiveByVideo('CCCCCCCCCCC').live_status, 'SCHEDULED');
  assert.equal(store.profileLiveStates(userId, 1).find(live => live.videoId === 'CCCCCCCCCCC').sendStatus, 'WAITING');
  assert.equal(store.profileLiveStates(userId, 2).find(live => live.videoId === 'CCCCCCCCCCC').sendStatus, 'WAITING');
  store.removeSubscription(userId, 1, subscription1.id);
  store.removeSubscription(userId, 2, subscription2.id);
});

test('monitor mantém a live quando a página pública exige validação anti-bot', async () => {
  const protectedUser = store.createUser({ id: store.id('usr'), username: 'Proteção anti bot', active: true, sessionVersion: 1 });
  store.updateUserProfile(protectedUser.id, 1, profile => { profile.runtime.status = 'running'; });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1212121212121212121212', handle: '@ProtecaoAntiBot', canonicalUrl: 'https://www.youtube.com/@ProtecaoAntiBot', displayName: 'Proteção Anti Bot', originalInput: '@ProtecaoAntiBot' });
  const subscription = store.subscribeChannel(protectedUser.id, 1, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, { videoId: 'B2222222222', title: 'Live ativa protegida', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', actualStartTime: '2026-09-15T20:00:00.000Z', resolved: true }).live;
  store.distributeLive(live.id);
  const monitor = createGlobalMonitor({
    discover: async () => ({ lives: [] }),
    recheck: async () => {
      const error = new Error('O YouTube solicitou uma validação temporária anti-bot. A transmissão será preservada e verificada novamente.');
      error.status = 503;
      error.protectionChallenge = true;
      throw error;
    }
  });
  const result = await monitor.scan();
  const storedLive = store.getGlobalLive(live.id);
  const state = store.profileLiveStates(protectedUser.id, 1).find(item => item.videoId === live.video_id);
  assert.equal(result.ok, true);
  assert.equal(storedLive.live_status, 'LIVE');
  assert.equal(storedLive.chat_status, 'AVAILABLE');
  assert.equal(storedLive.finalized_at, null);
  assert.equal(state.sendStatus, 'ACTIVE');
  store.removeSubscription(protectedUser.id, 1, subscription.id);
});

test('fallback administrativo confirma o chat de um ID encontrado e compartilha com o perfil', async () => {
  const fallbackUser = store.createUser({ id: store.id('usr'), username: 'Fallback administrativo', active: true, sessionVersion: 1 });
  store.updateUserProfile(fallbackUser.id, 1, profile => { profile.runtime.status = 'running'; });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1414141414141414141414', handle: '@FallbackAdmin', canonicalUrl: 'https://www.youtube.com/@FallbackAdmin', displayName: 'Fallback Admin', originalInput: '@FallbackAdmin' });
  const subscription = store.subscribeChannel(fallbackUser.id, 1, channel, channel.handle);
  let currentTime = Date.parse('2026-09-16T10:00:00Z');
  let calls = 0;
  const monitor = createGlobalMonitor({
    clock: () => currentTime,
    discover: async () => ({ lives: [{
      videoId: 'A4444444444', title: 'Live encontrada', liveStatus: 'LIVE', chatStatus: 'UNKNOWN', resolved: false,
      resolutionError: 'Faça login para confirmar que você não é um bot'
    }] }),
    verifyKnownLive: async videoId => {
      calls++;
      assert.equal(videoId, 'A4444444444');
      return {
        ok: true,
        configured: true,
        attempted: 1,
        keyId: 'key-admin',
        keyName: 'Principal',
        candidate: {
          videoId,
          title: 'Live encontrada',
          liveStatus: 'LIVE',
          chatStatus: 'AVAILABLE',
          activeLiveChatId: 'CHAT-CENTRAL',
          actualStartTime: '2026-09-16T10:00:00Z',
          resolved: true,
          confirmedActive: true,
          unavailable: false
        }
      };
    }
  });
  const result = await monitor.scan();
  currentTime += 31 * 60 * 1000;
  const cachedResult = await monitor.scan();
  const live = store.getGlobalLiveByVideo('A4444444444');
  const state = store.profileLiveStates(fallbackUser.id, 1).find(item => item.videoId === 'A4444444444');
  assert.equal(result.ok, true);
  assert.equal(cachedResult.ok, true);
  assert.equal(calls, 1);
  assert.equal(live.active_live_chat_id, 'CHAT-CENTRAL');
  assert.ok(live.last_admin_verification_at);
  assert.equal(live.chat_status, 'AVAILABLE');
  assert.equal(state.sendStatus, 'ACTIVE');
  assert.equal(store.apiUsage(fallbackUser.id, 1).videosList.attempts, 0);
  store.removeSubscription(fallbackUser.id, 1, subscription.id);
  store.deleteUser(fallbackUser.id);
});

test('chat ativo atravessa bloqueio anti-bot sem consumir API administrativa', async () => {
  const activeUser = store.createUser({ id: store.id('usr'), username: 'Chat ativo sem consulta', active: true, sessionVersion: 1 });
  store.updateUserProfile(activeUser.id, 1, profile => { profile.runtime.status = 'running'; });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1616161616161616161616', handle: '@ChatAtivoSemConsulta', canonicalUrl: 'https://www.youtube.com/@ChatAtivoSemConsulta', displayName: 'Chat Ativo Sem Consulta', originalInput: '@ChatAtivoSemConsulta' });
  const subscription = store.subscribeChannel(activeUser.id, 1, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, {
    videoId: 'A6666666666', title: 'Live já conectada', liveStatus: 'LIVE', chatStatus: 'AVAILABLE',
    actualStartTime: '2026-09-16T10:00:00Z', activeLiveChatId: 'CHAT-EM-USO', resolved: true
  }).live;
  store.distributeLive(live.id);
  let currentTime = Date.parse('2026-09-16T10:05:00Z');
  let calls = 0;
  let unavailableReason = 'Faça login para confirmar que você não é um bot';
  const monitor = createGlobalMonitor({
    clock: () => currentTime,
    discover: async () => ({ lives: [] }),
    recheck: async () => ({
      videoId: live.video_id,
      liveStatus: 'UNKNOWN',
      chatStatus: 'UNKNOWN',
      resolved: true,
      confirmedActive: false,
      unavailable: true,
      unavailableReason
    }),
    verifyKnownLive: async () => {
      calls++;
      throw new Error('A API administrativa não deveria ser consultada para um chat ativo.');
    }
  });
  await monitor.scan();
  const activeState = store.profileLiveStates(activeUser.id, 1).find(item => item.videoId === live.video_id);
  store.updateUserLiveState(activeState.id, state => {
    state.active_live_chat_id = 'CHAT-EM-USO';
    state.last_send_at = new Date(currentTime).toISOString();
    state.last_error = '';
  });
  unavailableReason = 'A página pública não encontrou este vídeo.';
  currentTime += 24 * 60 * 60 * 1000;
  await monitor.scan();
  const stored = store.getGlobalLive(live.id);
  assert.equal(calls, 0);
  assert.equal(stored.live_status, 'LIVE');
  assert.equal(stored.chat_status, 'AVAILABLE');
  assert.equal(stored.active_live_chat_id, 'CHAT-EM-USO');
  assert.equal(stored.last_admin_verification_at, null);
  assert.equal(stored.finalized_at, null);
  store.removeSubscription(activeUser.id, 1, subscription.id);
  store.deleteUser(activeUser.id);
});

test('API administrativa impede falso encerramento quando a página pública rejeita um ID existente', async () => {
  const savedUser = store.createUser({ id: store.id('usr'), username: 'Proteção administrativa', active: true, sessionVersion: 1 });
  store.updateUserProfile(savedUser.id, 1, profile => { profile.runtime.status = 'running'; });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1515151515151515151515', handle: '@ProtecaoAdministrativa', canonicalUrl: 'https://www.youtube.com/@ProtecaoAdministrativa', displayName: 'Proteção Administrativa', originalInput: '@ProtecaoAdministrativa' });
  const subscription = store.subscribeChannel(savedUser.id, 1, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, { videoId: 'A5555555555', title: 'Live preservada', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', actualStartTime: '2026-09-16T10:00:00Z', activeLiveChatId: 'CHAT-ANTIGO', resolved: true }).live;
  store.distributeLive(live.id);
  let calls = 0;
  const monitor = createGlobalMonitor({
    discover: async () => ({ lives: [] }),
    recheck: async () => ({
      videoId: live.video_id, liveStatus: 'UNKNOWN', chatStatus: 'UNKNOWN', resolved: true, confirmedActive: false,
      unavailable: true, unavailableReason: 'A página pública não encontrou este vídeo.'
    }),
    verifyKnownLive: async videoId => {
      calls++;
      return {
        ok: true,
        configured: true,
        attempted: 1,
        keyName: 'Principal',
        candidate: {
          videoId, title: 'Live preservada', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', activeLiveChatId: 'CHAT-NOVO',
          actualStartTime: '2026-09-16T10:00:00Z', resolved: true, confirmedActive: true, unavailable: false
        }
      };
    }
  });
  await monitor.scan();
  const stored = store.getGlobalLive(live.id);
  assert.equal(calls, 1);
  assert.equal(stored.live_status, 'LIVE');
  assert.equal(stored.chat_status, 'AVAILABLE');
  assert.equal(stored.active_live_chat_id, 'CHAT-NOVO');
  assert.equal(stored.finalized_at, null);
  store.removeSubscription(savedUser.id, 1, subscription.id);
  store.deleteUser(savedUser.id);
});

test('estado administrativo persistente limita centenas de ciclos sem atrasar chat programado', async () => {
  const stableUser = store.createUser({ id: store.id('usr'), username: 'Estado administrativo estável', active: true, sessionVersion: 1 });
  store.updateUserProfile(stableUser.id, 1, profile => { profile.runtime.status = 'running'; });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1717171717171717171717', handle: '@EstadoAdminEstavel', canonicalUrl: 'https://www.youtube.com/@EstadoAdminEstavel', displayName: 'Estado Admin Estável', originalInput: '@EstadoAdminEstavel' });
  const subscription = store.subscribeChannel(stableUser.id, 1, channel, channel.handle);
  let publicLiveStatus = 'SCHEDULED';
  let publicChatStatus = 'UNAVAILABLE';
  let adminChatStatus = 'UNAVAILABLE';
  let calls = 0;
  const monitor = createGlobalMonitor({
    discover: async () => ({ lives: [{
      videoId: 'A7777777777', title: 'Live programada estável', liveStatus: publicLiveStatus, chatStatus: publicChatStatus,
      scheduledStartTime: '2026-09-17T12:00:00Z', resolved: true, unavailable: false
    }] }),
    verifyKnownLive: async videoId => {
      calls++;
      return {
        ok: true,
        configured: true,
        attempted: 1,
        keyName: 'Principal',
        candidate: {
          videoId,
          title: 'Live programada estável',
          liveStatus: 'SCHEDULED',
          chatStatus: adminChatStatus,
          activeLiveChatId: adminChatStatus === 'AVAILABLE' ? 'CHAT-PROGRAMADO' : '',
          scheduledStartTime: '2026-09-17T12:00:00Z',
          resolved: true,
          confirmedActive: true,
          unavailable: false
        }
      };
    }
  });

  for (let cycle = 0; cycle < 500; cycle++) await monitor.scan();
  assert.equal(calls, 1);
  assert.equal(store.getGlobalLiveByVideo('A7777777777').admin_state_result, 'SUCCESS');

  publicChatStatus = 'AVAILABLE';
  adminChatStatus = 'AVAILABLE';
  await monitor.scan();
  assert.equal(calls, 2);
  let live = store.getGlobalLiveByVideo('A7777777777');
  assert.equal(live.live_status, 'SCHEDULED');
  assert.equal(live.chat_status, 'AVAILABLE');
  assert.equal(live.active_live_chat_id, 'CHAT-PROGRAMADO');
  assert.equal(store.profileLiveStates(stableUser.id, 1).find(item => item.videoId === live.video_id).sendStatus, 'ACTIVE');

  for (let cycle = 0; cycle < 500; cycle++) await monitor.scan();
  assert.equal(calls, 2);
  live = store.getGlobalLiveByVideo('A7777777777');
  assert.equal(live.live_status, 'SCHEDULED');
  assert.equal(live.active_live_chat_id, 'CHAT-PROGRAMADO');
  publicLiveStatus = 'LIVE';
  await monitor.scan();
  assert.equal(calls, 2);
  assert.equal(store.getGlobalLiveByVideo('A7777777777').live_status, 'LIVE');
  store.removeSubscription(stableUser.id, 1, subscription.id);
  store.deleteUser(stableUser.id);
});

test('falha de todas as chaves usa 1, 2 e 5 minutos e mudança pública tenta imediatamente', async () => {
  const retryUser = store.createUser({ id: store.id('usr'), username: 'Retry administrativo', active: true, sessionVersion: 1 });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1818181818181818181818', handle: '@RetryAdministrativo', canonicalUrl: 'https://www.youtube.com/@RetryAdministrativo', displayName: 'Retry Administrativo', originalInput: '@RetryAdministrativo' });
  const subscription = store.subscribeChannel(retryUser.id, 1, channel, channel.handle);
  let currentTime = Date.parse('2026-09-17T10:00:00Z');
  let liveStatus = 'UNKNOWN';
  let calls = 0;
  const monitor = createGlobalMonitor({
    clock: () => currentTime,
    discover: async () => ({ lives: [{ videoId: 'A8888888888', title: 'Retry', liveStatus, chatStatus: 'UNKNOWN', resolved: false, resolutionError: 'Página inconclusiva' }] }),
    verifyKnownLive: async () => {
      calls++;
      return { ok: false, configured: true, attempted: 2, error: 'Todas as chaves falharam.' };
    }
  });

  await monitor.scan();
  assert.equal(calls, 1);
  assert.equal(store.getGlobalLiveByVideo('A8888888888').admin_next_retry_at, new Date(currentTime + 60000).toISOString());
  currentTime += 30000;
  await monitor.scan();
  assert.equal(calls, 1);

  liveStatus = 'SCHEDULED';
  await monitor.scan();
  assert.equal(calls, 2);
  assert.equal(store.getGlobalLiveByVideo('A8888888888').admin_failure_streak, 1);
  currentTime += 60000;
  await monitor.scan();
  assert.equal(calls, 3);
  assert.equal(store.getGlobalLiveByVideo('A8888888888').admin_next_retry_at, new Date(currentTime + 120000).toISOString());
  currentTime += 119000;
  await monitor.scan();
  assert.equal(calls, 3);
  currentTime += 1000;
  await monitor.scan();
  assert.equal(calls, 4);
  assert.equal(store.getGlobalLiveByVideo('A8888888888').admin_next_retry_at, new Date(currentTime + 300000).toISOString());
  currentTime += 299000;
  await monitor.scan();
  assert.equal(calls, 4);
  currentTime += 1000;
  await monitor.scan();
  assert.equal(calls, 5);
  assert.equal(store.getGlobalLiveByVideo('A8888888888').admin_next_retry_at, new Date(currentTime + 300000).toISOString());
  store.removeSubscription(retryUser.id, 1, subscription.id);
  store.deleteUser(retryUser.id);
});

test('erro terminal confirma uma vez e live encerrada nunca volta à rotação', async () => {
  const endedUser = store.createUser({ id: store.id('usr'), username: 'Terminal administrativo', active: true, sessionVersion: 1 });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1919191919191919191919', handle: '@TerminalAdministrativo', canonicalUrl: 'https://www.youtube.com/@TerminalAdministrativo', displayName: 'Terminal Administrativo', originalInput: '@TerminalAdministrativo' });
  const subscription = store.subscribeChannel(endedUser.id, 1, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, { videoId: 'A9999999999', title: 'Live terminal', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', activeLiveChatId: 'CHAT-ANTIGO', resolved: true }).live;
  store.distributeLive(live.id);
  store.quarantineLive(live.id, 'Erro 404 terminal do chat.');
  let calls = 0;
  let publicChecks = 0;
  const monitor = createGlobalMonitor({
    discover: async () => ({ lives: [] }),
    recheck: async oldLive => {
      publicChecks++;
      return { videoId: oldLive.video_id, title: oldLive.title, liveStatus: 'LIVE', chatStatus: 'UNKNOWN', resolved: false, resolutionError: 'Chat não confirmado' };
    },
    verifyKnownLive: async videoId => {
      calls++;
      return {
        ok: true,
        configured: true,
        attempted: 1,
        keyName: 'Principal',
        candidate: { videoId, title: 'Live terminal', liveStatus: 'ENDED', chatStatus: 'ENDED', actualEndTime: '2026-09-17T10:00:00Z', resolved: true, confirmedActive: false, unavailable: false }
      };
    }
  });

  await monitor.scan();
  assert.equal(calls, 1);
  assert.equal(publicChecks, 1);
  assert.equal(store.getGlobalLive(live.id).live_status, 'ENDED');
  for (let cycle = 0; cycle < 500; cycle++) await monitor.scan();
  assert.equal(calls, 1);
  assert.equal(publicChecks, 1);
  assert.equal(store.livesForPublicRecheck(channel.id, [], 4).length, 0);
  store.removeSubscription(endedUser.id, 1, subscription.id);
  store.deleteUser(endedUser.id);
});

test('atualização restaura uma vez a live falsamente finalizada por anti-bot', () => {
  const repairUser = store.createUser({ id: store.id('usr'), username: 'Reparo anti bot', active: true, sessionVersion: 1 });
  store.updateUserProfile(repairUser.id, 1, profile => { profile.runtime.status = 'running'; });
  const channel = store.upsertGlobalChannel({ channelId: 'UC1313131313131313131313', handle: '@ReparoAntiBot', canonicalUrl: 'https://www.youtube.com/@ReparoAntiBot', displayName: 'Reparo Anti Bot', originalInput: '@ReparoAntiBot' });
  const subscription = store.subscribeChannel(repairUser.id, 1, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, { videoId: 'B3333333333', title: 'Live a restaurar', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', actualStartTime: '2026-09-15T21:00:00.000Z', resolved: true }).live;
  store.distributeLive(live.id);
  const message = 'A página pública confirmou que a live B3333333333 não está mais disponível. Motivo informado: Faça login para confirmar que você não é um bot';
  store.finalizeMissingLive(live.id, message);
  assert.ok(store.getGlobalLive(live.id).finalized_at);

  const restored = store.repairProtectionChallengeFinalizations();
  const storedLive = store.getGlobalLive(live.id);
  const state = store.profileLiveStates(repairUser.id, 1).find(item => item.videoId === live.video_id);
  assert.ok(restored.some(item => item.videoId === live.video_id));
  assert.equal(storedLive.live_status, 'LIVE');
  assert.equal(storedLive.chat_status, 'AVAILABLE');
  assert.equal(storedLive.finalized_at, null);
  assert.equal(state.sendStatus, 'ACTIVE');
  assert.deepEqual(store.repairProtectionChallengeFinalizations(), []);
  store.removeSubscription(repairUser.id, 1, subscription.id);
});

test('falha em um canal não impede os outros canais no mesmo ciclo', async () => {
  const monitorUser = store.createUser({ id: store.id('usr'), username: 'Monitor auxiliar', active: true, sessionVersion: 1 });
  const failing = store.upsertGlobalChannel({ channelId: 'UC7777777777777777777777', handle: '@CanalComErro', canonicalUrl: 'https://www.youtube.com/@CanalComErro', displayName: 'Canal com erro', originalInput: '@CanalComErro' });
  const healthy = store.upsertGlobalChannel({ channelId: 'UC6666666666666666666666', handle: '@CanalSaudavel', canonicalUrl: 'https://www.youtube.com/@CanalSaudavel', displayName: 'Canal saudável', originalInput: '@CanalSaudavel' });
  const failingSubscription = store.subscribeChannel(userId, 3, failing, failing.handle);
  const healthySubscription = store.subscribeChannel(monitorUser.id, 1, healthy, healthy.handle);
  const monitor = createGlobalMonitor({
    discover: async channel => {
      if (channel.id === failing.id) throw new Error('falha temporária simulada');
      return { lives: [{ videoId: 'HHHHHHHHHHH', title: 'Live saudável', liveStatus: 'SCHEDULED', chatStatus: 'UNAVAILABLE', resolved: true }] };
    }
  });
  const result = await monitor.scan();
  assert.equal(result.ok, true);
  assert.equal(result.channels, 2);
  assert.equal(result.errors.length, 1);
  assert.equal(store.getGlobalLiveByVideo('HHHHHHHHHHH').live_status, 'SCHEDULED');
  assert.equal(store.profileLiveStates(userId, 3).some(live => live.videoId === 'HHHHHHHHHHH'), false);
  assert.ok(store.globalChannels(false).find(channel => channel.id === healthy.id).last_checked_at);
  assert.match(store.globalChannels(false).find(channel => channel.id === failing.id).last_error, /simulada/);
  store.removeSubscription(userId, 3, failingSubscription.id);
  store.removeSubscription(monitorUser.id, 1, healthySubscription.id);
});

test('encerramento usa janela de cinco minutos e não reativa live antiga', () => {
  const channel = store.upsertGlobalChannel({ channelId: 'UC8888888888888888888888', handle: '@FinalTeste', canonicalUrl: 'https://www.youtube.com/@FinalTeste', displayName: 'Final Teste', originalInput: '@FinalTeste' });
  const subscription = store.subscribeChannel(userId, 1, channel, '@FinalTeste');
  const live = store.upsertGlobalLive(channel.id, { videoId: 'DDDDDDDDDDD', title: 'Final', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', actualStartTime: '2026-09-06T10:00:00Z', resolved: true }).live;
  store.distributeLive(live.id);
  const endedAt = new Date(Date.now() - 1000).toISOString();
  store.upsertGlobalLive(channel.id, { videoId: 'DDDDDDDDDDD', title: 'Final', liveStatus: 'ENDED', chatStatus: 'ENDED', actualEndTime: endedAt, resolved: true });
  store.transitionLiveEnded(live.id);
  let state = store.profileLiveStates(userId, 1).find(item => item.videoId === 'DDDDDDDDDDD');
  assert.equal(state.sendStatus, 'FINISHING');
  store.finalizeExpiredLives(Date.parse(endedAt) + 299999);
  state = store.profileLiveStates(userId, 1).find(item => item.videoId === 'DDDDDDDDDDD');
  assert.equal(state.sendStatus, 'FINISHING');
  store.finalizeExpiredLives(Date.parse(endedAt) + 300001);
  state = store.profileLiveStates(userId, 1).find(item => item.videoId === 'DDDDDDDDDDD');
  assert.equal(state.sendStatus, 'FINALIZED');
  const old = store.upsertGlobalLive(channel.id, { videoId: 'DDDDDDDDDDD', title: 'Sinal antigo', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  assert.equal(old.live_status, 'ENDED');
  assert.ok(old.finalized_at);

  const falsePositive = store.upsertGlobalLive(channel.id, { videoId: 'KKKKKKKKKKK', title: 'Falso encerramento', liveStatus: 'ENDED', chatStatus: 'ENDED', resolved: true }).live;
  assert.ok(falsePositive.finalized_at);
  const recovered = store.upsertGlobalLive(channel.id, { videoId: 'KKKKKKKKKKK', title: 'Confirmada ao vivo', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', actualStartTime: '2026-09-06T10:00:00Z', resolved: true, confirmedActive: true }).live;
  assert.equal(recovered.live_status, 'LIVE');
  assert.equal(recovered.chat_status, 'AVAILABLE');
  assert.equal(recovered.finalized_at, null);
  store.distributeLive(recovered.id);
  assert.notEqual(store.profileLiveStates(userId, 1).find(item => item.videoId === 'KKKKKKKKKKK').sendStatus, 'FINALIZED');
  store.removeSubscription(userId, 1, subscription.id);
});

test('workers enviam com credenciais próprias e parar um perfil não altera outro', async () => {
  const workerUser = store.createUser({ id: store.id('usr'), username: 'Worker teste', active: true, sessionVersion: 1 });
  for (const number of [1, 2]) store.updateUserProfile(workerUser.id, number, profile => {
    profile.api = { clientId: `${number}23-worker.apps.googleusercontent.com`, clientSecretEnc: security.encryptText(`secret-${number}`), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText(`refresh-${number}`);
    profile.config.messages = `Mensagem perfil ${number}`;
    profile.runtime.status = 'running';
  });
  const channels = [1, 2].map(number => store.upsertGlobalChannel({
    channelId: `UC${String(number).repeat(22)}`, handle: `@Worker${number}`, canonicalUrl: `https://www.youtube.com/@Worker${number}`,
    displayName: `Worker ${number}`, originalInput: `@Worker${number}`
  }));
  const subscriptions = channels.map((channel, index) => store.subscribeChannel(workerUser.id, index + 1, channel, channel.handle));
  for (const [index, videoId] of ['EEEEEEEEEEE', 'FFFFFFFFFFF'].entries()) {
    const live = store.upsertGlobalLive(channels[index].id, { videoId, title: videoId, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
    store.distributeLive(live.id);
  }
  const sent = [];
  const worker = createWorkers({
    api: {
      getActiveLiveChatId: async (profile, api, videoId) => `CHAT-${profile.profileNumber}-${api.clientId.slice(0, 1)}-${videoId}`,
      sendLiveChatMessage: async (profile, _api, chatId, message, options) => { options.beforeSend(); sent.push({ profile: profile.profileNumber, chatId, message }); }
    }
  });
  await worker.step(workerUser.id, 1);
  await worker.step(workerUser.id, 2);
  assert.deepEqual(sent.map(item => item.profile), [1, 2]);
  assert.equal(sent[0].message, 'Mensagem perfil 1');
  assert.equal(sent[1].message, 'Mensagem perfil 2');
  worker.stop(workerUser.id, 1);
  assert.equal(store.getUserProfile(workerUser.id, 1).runtime.status, 'stopped');
  assert.equal(store.getUserProfile(workerUser.id, 2).runtime.status, 'running');
  worker.start(workerUser.id, 2);
  worker.start(workerUser.id, 2);
  assert.equal(worker.hasWorker(workerUser.id, 2), true);
  assert.ok(worker.activeCount() <= 1);
  store.removeSubscription(workerUser.id, 1, subscriptions[0].id);
  store.removeSubscription(workerUser.id, 2, subscriptions[1].id);
  await worker.shutdown();
});

test('modo fixo envia imediatamente, respeita o minuto inteiro e não duplica o slot', async () => {
  const fixedUser = store.createUser({ id: store.id('usr'), username: 'Horários fixos', active: true, sessionVersion: 1 });
  store.updateUserProfile(fixedUser.id, 1, profile => {
    profile.api = { clientId: '123-fixed.apps.googleusercontent.com', clientSecretEnc: security.encryptText('fixed-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('fixed-token');
    profile.config.messages = 'Mensagem fixa A\nMensagem fixa B';
    profile.config.sendMode = 'fixed';
    profile.runtime.status = 'running';
    profile.runtime.immediatePending = true;
  });
  const channel = store.upsertGlobalChannel({
    channelId: 'UC1212121212121212121212', handle: '@HorarioFixo', canonicalUrl: 'https://www.youtube.com/@HorarioFixo',
    displayName: 'Horário Fixo', originalInput: '@HorarioFixo'
  });
  const subscription = store.subscribeChannel(fixedUser.id, 1, channel, channel.handle);

  let at = Date.parse('2026-09-21T21:03:27-03:00');
  const sent = [];
  const worker = createWorkers({
    clock: () => at,
    api: {
      getActiveLiveChatId: async () => { throw new Error('O chat em cache deveria ser reutilizado.'); },
      sendLiveChatMessage: async (_profile, _api, _chatId, message, options) => { options.beforeSend(); sent.push({ at, message }); }
    }
  });

  await worker.step(fixedUser.id, 1);
  let profile = store.getUserProfile(fixedUser.id, 1);
  assert.equal(sent.length, 0);
  assert.equal(profile.runtime.immediatePending, true);

  const live = store.upsertGlobalLive(channel.id, { videoId: 'F1212121212', title: 'Live fixa', liveStatus: 'SCHEDULED', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(live.id);
  store.cacheGlobalLiveChatId(live.id, 'CHAT-FIXO');
  worker.wakeProfiles([{ userId: fixedUser.id, profileNumber: 1 }]);
  await worker.step(fixedUser.id, 1);
  profile = store.getUserProfile(fixedUser.id, 1);
  assert.equal(sent.length, 1);
  assert.equal(profile.runtime.immediatePending, false);
  assert.equal(new Date(worker.nextTarget(profile)).toISOString(), '2026-09-22T00:05:01.000Z');

  at = Date.parse('2026-09-21T21:05:01-03:00');
  await worker.step(fixedUser.id, 1);
  profile = store.getUserProfile(fixedUser.id, 1);
  assert.equal(sent.length, 2);
  assert.match(profile.runtime.fixedLastSlotKey, /21:05/);

  at = Date.parse('2026-09-21T21:05:30-03:00');
  await worker.step(fixedUser.id, 1);
  assert.equal(sent.length, 2);

  at = Date.parse('2026-09-21T21:09:30-03:00');
  await worker.step(fixedUser.id, 1);
  profile = store.getUserProfile(fixedUser.id, 1);
  assert.equal(sent.length, 3);
  assert.match(profile.runtime.fixedLastSlotKey, /21:09/);
  assert.equal(new Date(worker.nextTarget(profile)).toISOString(), '2026-09-22T00:11:01.000Z');

  worker.pause(fixedUser.id, 1);
  const pausedSlot = store.getUserProfile(fixedUser.id, 1).runtime.fixedLastSlotAt;
  assert.equal(worker.start(fixedUser.id, 1, false), true);
  profile = store.getUserProfile(fixedUser.id, 1);
  assert.equal(profile.runtime.immediatePending, false);
  assert.equal(profile.runtime.fixedLastSlotAt, pausedSlot);

  worker.stop(fixedUser.id, 1);
  assert.equal(worker.start(fixedUser.id, 1, true), true);
  profile = store.getUserProfile(fixedUser.id, 1);
  assert.equal(profile.runtime.immediatePending, true);
  assert.equal(profile.runtime.fixedLastSlotAt, null);
  worker.stop(fixedUser.id, 1);
  store.removeSubscription(fixedUser.id, 1, subscription.id);
  await worker.shutdown();
  assert.equal(store.deleteUser(fixedUser.id), true);
});

test('PARAR zera contadores gerais, preserva uso diário e PAUSAR preserva o ciclo', async () => {
  const timerUser = store.createUser({ id: store.id('usr'), username: 'Ciclo limpo', active: true, sessionVersion: 1 });
  const lastSentAt = '2026-09-08T14:00:00.000Z';
  const usageAt = Date.parse('2026-09-08T14:01:00.000Z');
  store.updateUserProfile(timerUser.id, 1, profile => {
    profile.config.messages = 'Mensagem A\nMensagem B\nMensagem C';
    profile.config.messageIndex = 2;
    profile.config.intervalMinutes = 3;
    profile.config.intervalSeconds = 0;
    profile.runtime.status = 'running';
    profile.runtime.sent = 12;
    profile.runtime.failures = 2;
    profile.runtime.attempts = 14;
    profile.runtime.connectionErrors = 3;
    profile.runtime.lastSentAt = lastSentAt;
    profile.runtime.nextAt = '2026-09-08T14:03:00.000Z';
  });
  store.recordApiCall(timerUser.id, 1, 'videos.list', true, usageAt);
  store.recordApiCall(timerUser.id, 1, 'liveChatMessages.insert', true, usageAt);
  const worker = createWorkers({ clock: () => usageAt });

  worker.stop(timerUser.id, 1);
  let profile = store.getUserProfile(timerUser.id, 1);
  assert.equal(profile.runtime.status, 'stopped');
  assert.equal(profile.runtime.lastSentAt, null);
  assert.equal(profile.runtime.nextAt, null);
  assert.deepEqual(
    [profile.runtime.sent, profile.runtime.failures, profile.runtime.attempts, profile.runtime.connectionErrors, profile.config.messageIndex],
    [0, 0, 0, 0, 2]
  );
  assert.deepEqual(store.apiUsage(timerUser.id, 1, usageAt), {
    day: '2026-09-08',
    requests: 2,
    failures: 0,
    videosList: { attempts: 1, successes: 1, failures: 0 },
    liveChatInsert: { attempts: 1, successes: 1, failures: 0 }
  });

  assert.equal(worker.start(timerUser.id, 1, true), true);
  profile = store.getUserProfile(timerUser.id, 1);
  assert.equal(profile.runtime.status, 'running');
  assert.equal(profile.runtime.lastSentAt, null);
  assert.equal(worker.nextTarget(profile), 0);
  assert.deepEqual(
    [profile.runtime.sent, profile.runtime.failures, profile.runtime.attempts, profile.runtime.connectionErrors, profile.config.messageIndex],
    [0, 0, 0, 0, 2]
  );

  store.updateUserProfile(timerUser.id, 1, current => {
    current.runtime.status = 'running';
    current.runtime.sent = 5;
    current.runtime.failures = 1;
    current.runtime.attempts = 6;
    current.runtime.connectionErrors = 2;
    current.runtime.lastSentAt = lastSentAt;
    current.runtime.nextAt = '2026-09-08T14:03:00.000Z';
  });
  worker.pause(timerUser.id, 1);
  profile = store.getUserProfile(timerUser.id, 1);
  assert.equal(profile.runtime.status, 'paused');
  assert.equal(profile.runtime.lastSentAt, lastSentAt);
  assert.deepEqual(
    [profile.runtime.sent, profile.runtime.failures, profile.runtime.attempts, profile.runtime.connectionErrors, profile.config.messageIndex],
    [5, 1, 6, 2, 2]
  );
  worker.start(timerUser.id, 1, false);
  profile = store.getUserProfile(timerUser.id, 1);
  assert.equal(profile.runtime.lastSentAt, lastSentAt);
  assert.deepEqual(
    [profile.runtime.sent, profile.runtime.failures, profile.runtime.attempts, profile.runtime.connectionErrors, profile.config.messageIndex],
    [5, 1, 6, 2, 2]
  );
  assert.equal(worker.nextTarget(profile), Date.parse(lastSentAt) + require('../lib/workers').effectiveDelay(profile.config));

  worker.stop(timerUser.id, 1);
  profile = store.getUserProfile(timerUser.id, 1);
  assert.deepEqual(
    [profile.runtime.sent, profile.runtime.failures, profile.runtime.attempts, profile.runtime.connectionErrors],
    [0, 0, 0, 0]
  );
  assert.equal(store.apiUsage(timerUser.id, 1, usageAt).requests, 2);
  await worker.shutdown();
  assert.equal(store.deleteUser(timerUser.id), true);
});

test('exclusão aguarda o worker em andamento e bloqueia reinício concorrente', async () => {
  const retiringUser = store.createUser({ id: store.id('usr'), username: 'Worker em exclusão', active: true, sessionVersion: 1 });
  const fourth = store.addUserProfile(retiringUser.id);
  store.updateUserProfile(retiringUser.id, fourth.profileNumber, profile => {
    profile.api = { clientId: '123-retire.apps.googleusercontent.com', clientSecretEnc: security.encryptText('retire-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('retire-token');
    profile.config.messages = 'Mensagem já iniciada';
    profile.runtime.status = 'stopped';
  });
  const channel = store.upsertGlobalChannel({
    channelId: 'UC4444444444444444444445',
    handle: '@WorkerEmExclusao',
    canonicalUrl: 'https://www.youtube.com/@WorkerEmExclusao',
    displayName: 'Worker em Exclusão',
    originalInput: '@WorkerEmExclusao'
  });
  store.subscribeChannel(retiringUser.id, 4, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, {
    videoId: 'R4444444444',
    title: 'Envio em andamento',
    liveStatus: 'LIVE',
    chatStatus: 'AVAILABLE',
    resolved: true
  }).live;
  store.distributeLive(live.id);
  store.cacheGlobalLiveChatId(live.id, 'CHAT-RETIRE');

  let releaseSend;
  let signalStarted;
  const sendStarted = new Promise(resolve => { signalStarted = resolve; });
  const sendGate = new Promise(resolve => { releaseSend = resolve; });
  const worker = createWorkers({
    clock: () => Date.parse('2026-09-08T15:00:00.000Z'),
    api: {
      getActiveLiveChatId: async () => 'CHAT-RETIRE',
      sendLiveChatMessage: async (_profile, _api, _chatId, _message, options) => {
        options.beforeSend();
        signalStarted();
        await sendGate;
      }
    }
  });

  assert.equal(worker.start(retiringUser.id, 4, true), true);
  await sendStarted;
  const retiring = worker.retireProfile(retiringUser.id, 4);
  assert.equal(worker.start(retiringUser.id, 4, true), false);
  releaseSend();
  await retiring;
  const stopped = store.getUserProfile(retiringUser.id, 4);
  assert.equal(stopped.runtime.status, 'stopped');
  assert.equal(stopped.runtime.lastSentAt, null);
  assert.equal(stopped.runtime.sent, 0);
  assert.equal(worker.hasWorker(retiringUser.id, 4), false);

  worker.releaseProfile(retiringUser.id, 4);
  assert.ok(store.deleteUserProfile(retiringUser.id, 4));
  await worker.shutdown();
  assert.equal(store.deleteUser(retiringUser.id), true);
});

test('404 do chat bloqueia novos envios e revalida o ID antigo com o monitor global', async () => {
  const staleUser = store.createUser({ id: store.id('usr'), username: 'Live antiga', active: true, sessionVersion: 1 });
  store.updateUserProfile(staleUser.id, 1, profile => {
    profile.api = { clientId: '123-stale.apps.googleusercontent.com', clientSecretEnc: security.encryptText('stale-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('stale-token');
    profile.config.liveUrl = 'MMMMMMMMMMM';
    profile.config.messages = 'Mensagem que não deve repetir';
    profile.runtime.status = 'running';
  });
  const channel = store.upsertGlobalChannel({ channelId: 'UC5555555555555555555555', handle: '@LiveAntiga', canonicalUrl: 'https://www.youtube.com/@LiveAntiga', displayName: 'Live Antiga', originalInput: '@LiveAntiga' });
  const subscription = store.subscribeChannel(staleUser.id, 1, channel, '@LiveAntiga');
  const live = store.upsertGlobalLive(channel.id, { videoId: 'MMMMMMMMMMM', title: 'Live apagada', liveStatus: 'SCHEDULED', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(live.id);
  const stateId = store.profileLiveStates(staleUser.id, 1).find(item => item.videoId === 'MMMMMMMMMMM').id;
  store.updateUserLiveState(stateId, state => { state.active_live_chat_id = 'CHAT-ANTIGO'; });

  const at = Date.parse('2026-09-06T16:00:00Z');
  let insertCalls = 0, dataApiLookups = 0;
  const worker = createWorkers({
    clock: () => at,
    api: {
      getActiveLiveChatId: async () => { dataApiLookups++; return 'CHAT-NOVO'; },
      sendLiveChatMessage: async (_profile, _api, _chatId, _message, options) => {
        options.beforeSend();
        insertCalls++;
        const error = new Error('Requested entity was not found.');
        error.status = 404;
        throw error;
      }
    }
  });
  await worker.step(staleUser.id, 1);
  await worker.step(staleUser.id, 1);
  let storedLive = store.getGlobalLive(live.id);
  let storedState = store.profileLiveStates(staleUser.id, 1).find(item => item.videoId === 'MMMMMMMMMMM');
  assert.equal(insertCalls, 1);
  assert.equal(dataApiLookups, 0);
  assert.equal(storedLive.chat_status, 'VERIFYING');
  assert.equal(storedLive.finalized_at, null);
  assert.equal(storedState.sendStatus, 'WAITING');
  assert.equal(store.getUserProfile(staleUser.id, 1).runtime.retryAt, at + 15000);

  let publicChecks = 0, connectionFailure = true;
  const monitor = createGlobalMonitor({
    clock: () => at + publicChecks * 180000,
    discover: async () => ({ lives: [] }),
    recheck: async () => {
      publicChecks++;
      if (connectionFailure) {
        const error = new Error('falha de conexão simulada');
        error.networkFailure = true;
        throw error;
      }
      return { videoId: 'MMMMMMMMMMM', liveStatus: 'UNKNOWN', chatStatus: 'UNKNOWN', resolved: true, confirmedActive: false, unavailable: true, unavailableReason: 'Vídeo indisponível' };
    }
  });
  await monitor.scan();
  assert.equal(store.getGlobalLive(live.id).chat_status, 'VERIFYING');
  assert.equal(store.getGlobalLive(live.id).finalized_at, null);
  connectionFailure = false;
  await monitor.scan();
  storedLive = store.getGlobalLive(live.id);
  storedState = store.profileLiveStates(staleUser.id, 1).find(item => item.videoId === 'MMMMMMMMMMM');
  assert.equal(publicChecks, 2);
  assert.equal(insertCalls, 1);
  assert.equal(dataApiLookups, 0);
  assert.equal(storedLive.live_status, 'ENDED');
  assert.equal(storedLive.chat_status, 'ENDED');
  assert.ok(storedLive.finalized_at);
  assert.equal(storedState.sendStatus, 'FINALIZED');
  assert.ok(store.logs(staleUser.id, 1, 20).some(entry => /verificação pública adiada/i.test(entry.message)));
  assert.ok(store.logs(staleUser.id, 1, 20).some(entry => /Nenhum novo envio foi tentado/i.test(entry.message)));

  for (const videoId of ['NNNNNNNNNNN', 'OOOOOOOOOOO', 'PPPPPPPPPPP', 'QQQQQQQQQQQ', 'RRRRRRRRRRR']) {
    store.upsertGlobalLive(channel.id, { videoId, title: videoId, liveStatus: 'ENDED', chatStatus: 'ENDED', resolved: true });
  }
  assert.equal(store.livesForPublicRecheck(channel.id, [], 4).length, 0);
  store.removeSubscription(staleUser.id, 1, subscription.id);
  await worker.shutdown();
});

test('live encontrada sem chat usa a espera global, com padrão de 120 segundos', async () => {
  const retryUser = store.createUser({ id: store.id('usr'), username: 'Espera do chat', active: true, sessionVersion: 1 });
  store.updateUserProfile(retryUser.id, 1, profile => {
    profile.api = { clientId: '123-retry.apps.googleusercontent.com', clientSecretEnc: security.encryptText('retry-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('retry-token');
    profile.config.messages = 'Mensagem de teste';
    profile.runtime.status = 'running';
  });
  const channel = store.upsertGlobalChannel({ channelId: 'UC4444444444444444444444', handle: '@EsperaChat', canonicalUrl: 'https://www.youtube.com/@EsperaChat', displayName: 'Espera Chat', originalInput: '@EsperaChat' });
  const subscription = store.subscribeChannel(retryUser.id, 1, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, { videoId: 'LLLLLLLLLLL', title: 'Espera', liveStatus: 'SCHEDULED', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(live.id);
  const at = Date.parse('2026-09-06T15:00:00Z');
  let lookupCalls = 0;
  const worker = createWorkers({
    clock: () => at,
    api: {
      getActiveLiveChatId: async () => { lookupCalls++; return ''; },
      sendLiveChatMessage: async () => { throw new Error('Não deveria enviar sem chat.'); }
    }
  });
  await worker.step(retryUser.id, 1);
  const profile = store.getUserProfile(retryUser.id, 1);
  assert.equal(DEFAULT_CHAT_AVAILABILITY_RETRY_MS, 120000);
  assert.equal(store.chatAvailabilityRetrySeconds(), 120);
  assert.equal(lookupCalls, 1);
  assert.equal(store.getGlobalLive(live.id).chat_lookup_next_at, new Date(at + 120000).toISOString());
  assert.equal(store.profileLiveStates(retryUser.id, 1).find(item => item.id).nextAttemptAt, new Date(at + 120000).toISOString());
  assert.equal(profile.runtime.attempts, 0);
  assert.equal(profile.runtime.connectionErrors, 0);
  store.setGlobalSetting('chat_availability_retry_seconds', 180, 'test');
  store.reschedulePendingChatLookups(at);
  await worker.step(retryUser.id, 1);
  assert.equal(store.getGlobalLive(live.id).chat_lookup_next_at, new Date(at + 180000).toISOString());
  store.setGlobalSetting('chat_availability_retry_seconds', 120, 'test');
  store.removeSubscription(retryUser.id, 1, subscription.id);
  await worker.shutdown();
});

test('duas e três lives usam os intervalos combinados e alternam sem repetir a mesma live', async () => {
  const { delayForLiveCount } = require('../lib/workers');
  const configured = { intervalMinutes: 5, intervalSeconds: 0, intervalMs: 999 };
  assert.equal(delayForLiveCount(configured, 1), 300000);
  assert.equal(delayForLiveCount(configured, 2), 180000);
  assert.equal(delayForLiveCount(configured, 3), 150000);

  const multiUser = store.createUser({ id: store.id('usr'), username: 'Alternância de lives', active: true, sessionVersion: 1 });
  store.updateUserProfile(multiUser.id, 1, profile => {
    profile.api = { clientId: '123-multi.apps.googleusercontent.com', clientSecretEnc: security.encryptText('multi-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('multi-token');
    profile.config.messages = 'Mensagem alternada';
    profile.config.intervalMinutes = 5;
    profile.config.intervalSeconds = 0;
    profile.runtime.status = 'running';
  });
  const channel = store.upsertGlobalChannel({ channelId: 'UC3333333333333333333333', handle: '@Alternancia', canonicalUrl: 'https://www.youtube.com/@Alternancia', displayName: 'Alternância', originalInput: '@Alternancia' });
  const subscription = store.subscribeChannel(multiUser.id, 1, channel, channel.handle);
  for (const videoId of ['S1111111111', 'S2222222222', 'S3333333333']) {
    const live = store.upsertGlobalLive(channel.id, { videoId, title: videoId, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
    store.distributeLive(live.id);
    store.cacheGlobalLiveChatId(live.id, `CHAT-${videoId}`);
  }
  let at = Date.parse('2026-09-07T00:00:00Z');
  const sent = [];
  const worker = createWorkers({
    clock: () => at,
    api: {
      getActiveLiveChatId: async () => { throw new Error('O cache global deveria ser reutilizado.'); },
      sendLiveChatMessage: async (_profile, _api, chatId, _message, options) => { options.beforeSend(); sent.push(chatId.replace('CHAT-', '')); }
    }
  });
  await worker.step(multiUser.id, 1);
  at += 150000;
  await worker.step(multiUser.id, 1);
  at += 150000;
  await worker.step(multiUser.id, 1);
  assert.deepEqual(sent, ['S1111111111', 'S2222222222', 'S3333333333']);
  assert.equal(store.getUserProfile(multiUser.id, 1).runtime.nextAt, new Date(at + 150000).toISOString());
  store.removeSubscription(multiUser.id, 1, subscription.id);
  await worker.shutdown();
});

test('consulta do chat é compartilhada globalmente entre perfis e uma live sem chat não bloqueia outra', async () => {
  const sharedChannel = store.upsertGlobalChannel({ channelId: 'UC5555555555555555555556', handle: '@CacheGlobal', canonicalUrl: 'https://www.youtube.com/@CacheGlobal', displayName: 'Cache Global', originalInput: '@CacheGlobal' });
  const firstUser = store.createUser({ id: store.id('usr'), username: 'Cache global um', active: true, sessionVersion: 1 });
  const secondUser = store.createUser({ id: store.id('usr'), username: 'Cache global dois', active: true, sessionVersion: 1 });
  for (const current of [firstUser, secondUser]) store.updateUserProfile(current.id, 1, profile => {
    profile.api = { clientId: '123-cache.apps.googleusercontent.com', clientSecretEnc: security.encryptText('cache-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('cache-token');
    profile.oauth.email = 'cache@example.com';
    profile.config.messages = 'Mensagem cache';
    profile.runtime.status = 'running';
  });
  const subscriptions = [firstUser, secondUser].map(current => store.subscribeChannel(current.id, 1, sharedChannel, sharedChannel.handle));
  const sharedLive = store.upsertGlobalLive(sharedChannel.id, { videoId: 'C4444444444', title: 'Compartilhada', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(sharedLive.id);
  let lookups = 0, inserts = 0;
  const sharedWorker = createWorkers({
    api: {
      getActiveLiveChatId: async () => { lookups++; await new Promise(resolve => setImmediate(resolve)); return 'CHAT-COMPARTILHADO'; },
      sendLiveChatMessage: async (_profile, _api, _chatId, _message, options) => { options.beforeSend(); inserts++; }
    }
  });
  await Promise.all([sharedWorker.step(firstUser.id, 1), sharedWorker.step(secondUser.id, 1)]);
  assert.equal(lookups, 1);
  assert.equal(inserts, 2);
  assert.equal(store.getGlobalLive(sharedLive.id).active_live_chat_id, 'CHAT-COMPARTILHADO');
  store.removeSubscription(firstUser.id, 1, subscriptions[0].id);
  store.removeSubscription(secondUser.id, 1, subscriptions[1].id);
  await sharedWorker.shutdown();

  const isolationUser = store.createUser({ id: store.id('usr'), username: 'Falha isolada por live', active: true, sessionVersion: 1 });
  store.updateUserProfile(isolationUser.id, 1, profile => {
    profile.api = { clientId: '123-isolated.apps.googleusercontent.com', clientSecretEnc: security.encryptText('isolated-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('isolated-token');
    profile.config.messages = 'Mensagem saudável';
    profile.runtime.status = 'running';
  });
  const isolationSubscription = store.subscribeChannel(isolationUser.id, 1, sharedChannel, sharedChannel.handle);
  const waitingLive = store.upsertGlobalLive(sharedChannel.id, { videoId: 'W5555555555', title: 'Sem chat API', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  const healthyLive = store.upsertGlobalLive(sharedChannel.id, { videoId: 'H6666666666', title: 'Saudável', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(waitingLive.id);
  store.distributeLive(healthyLive.id);
  let sentHealthy = 0;
  const isolationWorker = createWorkers({
    clock: () => Date.parse('2026-09-07T02:00:00Z'),
    api: {
      getActiveLiveChatId: async (_profile, _api, videoId) => videoId === waitingLive.video_id ? '' : 'CHAT-SAUDAVEL',
      sendLiveChatMessage: async (_profile, _api, chatId, _message, options) => { options.beforeSend(); if (chatId === 'CHAT-SAUDAVEL') sentHealthy++; }
    }
  });
  await isolationWorker.step(isolationUser.id, 1);
  await isolationWorker.step(isolationUser.id, 1);
  assert.equal(sentHealthy, 1);
  assert.ok(store.getGlobalLive(waitingLive.id).chat_lookup_next_at);
  store.removeSubscription(isolationUser.id, 1, isolationSubscription.id);
  await isolationWorker.shutdown();

  const brokenUser = store.createUser({ id: store.id('usr'), username: 'Projeto Google quebrado', active: true, sessionVersion: 1 });
  const workingUser = store.createUser({ id: store.id('usr'), username: 'Projeto Google funcional', active: true, sessionVersion: 1 });
  store.updateUserProfile(brokenUser.id, 1, profile => {
    profile.api = { clientId: '123-broken.apps.googleusercontent.com', clientSecretEnc: security.encryptText('broken-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('broken-token');
    profile.oauth.email = 'broken@example.com';
    profile.config.messages = 'Mensagem quebrada';
    profile.runtime.status = 'running';
  });
  store.updateUserProfile(workingUser.id, 1, profile => {
    profile.api = { clientId: '123-working.apps.googleusercontent.com', clientSecretEnc: security.encryptText('working-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('working-token');
    profile.oauth.email = 'working@example.com';
    profile.config.messages = 'Mensagem funcional';
    profile.runtime.status = 'running';
  });
  const credentialSubscriptions = [brokenUser, workingUser].map(current => store.subscribeChannel(current.id, 1, sharedChannel, sharedChannel.handle));
  const credentialLive = store.upsertGlobalLive(sharedChannel.id, { videoId: 'K7777777777', title: 'Credenciais isoladas', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(credentialLive.id);
  let healthyCredentialSends = 0;
  const credentialWorker = createWorkers({
    api: {
      getActiveLiveChatId: async profile => {
        if (profile.userId === brokenUser.id) {
          const error = new Error('YouTube Data API v3 is disabled for this project.');
          error.status = 403;
          error.reason = 'accessNotConfigured';
          throw error;
        }
        return 'CHAT-CREDENCIAL-OK';
      },
      sendLiveChatMessage: async (profile, _api, chatId, _message, options) => {
        options.beforeSend();
        if (profile.userId === workingUser.id && chatId === 'CHAT-CREDENCIAL-OK') healthyCredentialSends++;
      }
    }
  });
  await Promise.all([credentialWorker.step(brokenUser.id, 1), credentialWorker.step(workingUser.id, 1)]);
  assert.equal(store.getUserProfile(brokenUser.id, 1).runtime.status, 'paused');
  assert.equal(store.getUserProfile(workingUser.id, 1).runtime.status, 'running');
  assert.equal(healthyCredentialSends, 1);
  assert.equal(store.getGlobalLive(credentialLive.id).active_live_chat_id, 'CHAT-CREDENCIAL-OK');
  store.removeSubscription(brokenUser.id, 1, credentialSubscriptions[0].id);
  store.removeSubscription(workingUser.id, 1, credentialSubscriptions[1].id);
  await credentialWorker.shutdown();
});

test('ID direto legado não faz consulta, API desativada pausa e cota agenda retomada automática', async () => {
  const legacyUser = store.createUser({ id: store.id('usr'), username: 'Legado sem consumo', active: true, sessionVersion: 1 });
  store.updateUserProfile(legacyUser.id, 1, profile => {
    profile.api = { clientId: '123-legacy.apps.googleusercontent.com', clientSecretEnc: security.encryptText('legacy-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('legacy-token');
    profile.config.liveUrl = 'Z7777777777';
    profile.config.messages = 'Não enviar';
    profile.runtime.status = 'running';
  });
  let legacyCalls = 0;
  const legacyWorker = createWorkers({
    api: {
      getActiveLiveChatId: async () => { legacyCalls++; return ''; },
      sendLiveChatMessage: async () => { legacyCalls++; }
    }
  });
  await legacyWorker.step(legacyUser.id, 1);
  assert.equal(legacyCalls, 0);
  assert.match(store.getUserProfile(legacyUser.id, 1).runtime.lastError, /Cadastre um canal/i);
  await legacyWorker.shutdown();

  const errorUser = store.createUser({ id: store.id('usr'), username: 'Tratamento da API', active: true, sessionVersion: 1 });
  store.updateUserProfile(errorUser.id, 1, profile => {
    profile.api = { clientId: '123-errors.apps.googleusercontent.com', clientSecretEnc: security.encryptText('errors-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('errors-token');
    profile.config.messages = 'Mensagem';
    profile.runtime.status = 'running';
  });
  const channel = store.upsertGlobalChannel({ channelId: 'UC7777777777777777777778', handle: '@ErrosApi', canonicalUrl: 'https://www.youtube.com/@ErrosApi', displayName: 'Erros API', originalInput: '@ErrosApi' });
  const subscription = store.subscribeChannel(errorUser.id, 1, channel, channel.handle);
  const disabledLive = store.upsertGlobalLive(channel.id, { videoId: 'D8888888888', title: 'API desativada', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(disabledLive.id);
  let disabledCalls = 0;
  const disabledWorker = createWorkers({
    api: {
      getActiveLiveChatId: async () => { disabledCalls++; const error = new Error('YouTube Data API v3 has not been used in project or it is disabled.'); error.status = 403; error.reason = 'accessNotConfigured'; throw error; },
      sendLiveChatMessage: async () => {}
    }
  });
  await disabledWorker.step(errorUser.id, 1);
  await disabledWorker.step(errorUser.id, 1);
  assert.equal(disabledCalls, 1);
  assert.equal(store.getUserProfile(errorUser.id, 1).runtime.status, 'paused');
  assert.match(store.getUserProfile(errorUser.id, 1).runtime.lastError, /API está desativada/i);
  await disabledWorker.shutdown();

  store.updateUserProfile(errorUser.id, 1, profile => { profile.runtime.status = 'running'; profile.runtime.epoch++; profile.runtime.lastError = ''; });
  store.activateProfileLives(errorUser.id, 1);
  store.cacheGlobalLiveChatId(disabledLive.id, 'CHAT-COTA');
  const now = Date.parse('2026-09-07T03:00:00Z');
  const quotaWorker = createWorkers({
    clock: () => now,
    api: {
      getActiveLiveChatId: async () => 'CHAT-COTA',
      sendLiveChatMessage: async (_profile, _api, _chatId, _message, options) => { options.beforeSend(); const error = new Error('Quota exceeded'); error.status = 403; error.reason = 'quotaExceeded'; throw error; }
    }
  });
  await quotaWorker.step(errorUser.id, 1);
  const quotaProfile = store.getUserProfile(errorUser.id, 1);
  assert.equal(quotaProfile.runtime.status, 'running');
  assert.ok(quotaProfile.runtime.quotaResumeAt > now);
  assert.equal(quotaProfile.runtime.nextAt, new Date(quotaProfile.runtime.quotaResumeAt).toISOString());
  store.removeSubscription(errorUser.id, 1, subscription.id);
  await quotaWorker.shutdown();
});

test('remoção bloqueia envio pendente, exclusão desativa canal e IDs encerrados saem da rotação', async () => {
  const raceUser = store.createUser({ id: store.id('usr'), username: 'Remoção segura', active: true, sessionVersion: 1 });
  store.updateUserProfile(raceUser.id, 1, profile => {
    profile.api = { clientId: '123-race.apps.googleusercontent.com', clientSecretEnc: security.encryptText('race-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = security.encryptText('race-token');
    profile.config.messages = 'Não deve sair';
    profile.runtime.status = 'running';
  });
  const channel = store.upsertGlobalChannel({ channelId: 'UC8888888888888888888889', handle: '@RemocaoSegura', canonicalUrl: 'https://www.youtube.com/@RemocaoSegura', displayName: 'Remoção Segura', originalInput: '@RemocaoSegura' });
  const subscription = store.subscribeChannel(raceUser.id, 1, channel, channel.handle);
  const live = store.upsertGlobalLive(channel.id, { videoId: 'R9999999999', title: 'Corrida', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(live.id);
  store.cacheGlobalLiveChatId(live.id, 'CHAT-RACE');
  let insertCalls = 0;
  const raceWorker = createWorkers({
    api: {
      getActiveLiveChatId: async () => 'CHAT-RACE',
      sendLiveChatMessage: async (_profile, _api, _chatId, _message, options) => {
        store.removeSubscription(raceUser.id, 1, subscription.id);
        options.beforeSend();
        insertCalls++;
      }
    }
  });
  await raceWorker.step(raceUser.id, 1);
  assert.equal(insertCalls, 0);
  assert.equal(store.getUserProfile(raceUser.id, 1).runtime.attempts, 0);
  assert.equal(store.globalChannels(true).some(item => item.id === channel.id), false);
  await raceWorker.shutdown();

  const deleteUser = store.createUser({ id: store.id('usr'), username: 'Excluir assinatura', active: true, sessionVersion: 1 });
  const deleteChannel = store.upsertGlobalChannel({ channelId: 'UC9999999999999999999990', handle: '@ExcluirAssinatura', canonicalUrl: 'https://www.youtube.com/@ExcluirAssinatura', displayName: 'Excluir', originalInput: '@ExcluirAssinatura' });
  store.subscribeChannel(deleteUser.id, 1, deleteChannel, deleteChannel.handle);
  assert.equal(store.deleteUser(deleteUser.id), true);
  assert.equal(store.globalChannels(true).some(item => item.id === deleteChannel.id), false);

  const rotationUser = store.createUser({ id: store.id('usr'), username: 'Rotação histórica', active: true, sessionVersion: 1 });
  const rotationChannel = store.upsertGlobalChannel({ channelId: 'UC0000000000000000000001', handle: '@RotacaoHistorica', canonicalUrl: 'https://www.youtube.com/@RotacaoHistorica', displayName: 'Rotação', originalInput: '@RotacaoHistorica' });
  const rotationSubscription = store.subscribeChannel(rotationUser.id, 1, rotationChannel, rotationChannel.handle);
  const ids = ['T0000000001', 'T0000000002', 'T0000000003', 'T0000000004', 'T0000000005', 'T0000000006'];
  for (const videoId of ids) store.upsertGlobalLive(rotationChannel.id, { videoId, title: videoId, liveStatus: 'ENDED', chatStatus: 'ENDED', resolved: true });
  assert.deepEqual(store.livesForPublicRecheck(rotationChannel.id, [], 4), []);
  store.removeSubscription(rotationUser.id, 1, rotationSubscription.id);
});

test('contadores registram chamadas da API por perfil e por dia do Pacífico', () => {
  const usageUser = store.createUser({ id: store.id('usr'), username: 'Contador da API', active: true, sessionVersion: 1 });
  const at = Date.parse('2026-09-07T12:00:00Z');
  store.recordApiCall(usageUser.id, 1, 'videos.list', true, at);
  store.recordApiCall(usageUser.id, 1, 'liveChatMessages.insert', true, at);
  store.recordApiCall(usageUser.id, 1, 'liveChatMessages.insert', false, at);
  const usage = store.apiUsage(usageUser.id, 1, at);
  assert.equal(usage.requests, 3);
  assert.equal(usage.failures, 1);
  assert.deepEqual(usage.videosList, { attempts: 1, successes: 1, failures: 0 });
  assert.deepEqual(usage.liveChatInsert, { attempts: 2, successes: 1, failures: 1 });
  store.deleteUser(usageUser.id);
});

test('cliente YouTube sinaliza a chamada real e preserva Retry-After', async () => {
  const originalFetch = global.fetch;
  const account = {
    oauth: {
      accessTokenEnc: security.encryptText('access-token-test'),
      accessTokenExpiresAt: Date.now() + 600000,
      refreshTokenEnc: security.encryptText('refresh-token-test'),
      scope: youtube.YOUTUBE_SCOPE
    }
  };
  const apiProfile = { clientId: '123-http.apps.googleusercontent.com', clientSecretEnc: security.encryptText('http-secret') };
  let apiSignals = 0, beforeSend = 0;
  global.fetch = async (url, options = {}) => {
    if (String(url).includes('/youtube/v3/videos')) {
      return new Response(JSON.stringify({ items: [{ liveStreamingDetails: { activeLiveChatId: 'CHAT-HTTP' } }] }), { status: 200 });
    }
    assert.equal(options.method, 'POST');
    return new Response(JSON.stringify({ error: { message: 'Aguarde', errors: [{ reason: 'rateLimitExceeded' }] } }), {
      status: 429,
      headers: { 'Content-Type': 'application/json', 'Retry-After': '7' }
    });
  };
  try {
    assert.equal(await youtube.getActiveLiveChatId(account, apiProfile, 'Y1111111111', { onApiRequest: () => { apiSignals++; } }), 'CHAT-HTTP');
    await assert.rejects(
      youtube.sendLiveChatMessage(account, apiProfile, 'CHAT-HTTP', 'Mensagem', {
        beforeSend: () => { beforeSend++; },
        onApiRequest: () => { apiSignals++; }
      }),
      error => error.status === 429 && error.reason === 'rateLimitExceeded' && error.retryAfterMs === 7000
    );
    assert.equal(apiSignals, 2);
    assert.equal(beforeSend, 1);
  } finally { global.fetch = originalFetch; }
});

test('modo econômico foi removido e intervalo mínimo é um segundo', () => {
  assert.throws(() => validation.config({ intervalMinutes: -1 }), /0/);
  const output = validation.config({ intervalMinutes: 0, intervalSeconds: 0, economyMode: true, maxPerHour: 10 });
  assert.deepEqual(output, { intervalMinutes: 0, intervalSeconds: 1 });
  assert.deepEqual(validation.config({ intervalMs: 999 }), {});
  assert.deepEqual(validation.config({ sendMode: 'fixed' }), { sendMode: 'fixed' });
  assert.throws(() => validation.config({ sendMode: 'cron' }), /inválido/i);
  assert.equal(require('../lib/workers').effectiveDelay({ intervalMinutes: 0, intervalSeconds: 1, intervalMs: 0 }), 1000);
  assert.equal(require('../lib/workers').effectiveDelay({ intervalMinutes: 0, intervalSeconds: 1, intervalMs: 999 }), 1000);
  store.updateUserProfile(userId, 3, profile => {
    profile.config.economyMode = true;
    profile.config.maxPerHour = 5;
  });
  const profile = store.getUserProfile(userId, 3);
  assert.equal('economyMode' in profile.config, false);
  assert.equal('maxPerHour' in profile.config, false);
});

test('somente admin altera intervalo global; usuário apenas consulta', async () => {
  const initial = (await request('/api/global-monitor/settings')).body;
  assert.equal(initial.liveDiscoveryIntervalSeconds, 180);
  assert.equal(initial.chatAvailabilityRetrySeconds, 120);
  assert.equal((await request('/api/global-monitor/settings', { method: 'PATCH', body: { liveDiscoveryIntervalSeconds: 240 } })).status, 403);
  assert.equal((await request('/dbmadmin/api/global-monitor', { admin: true, method: 'PATCH', body: { intervalMinutes: 4, chatAvailabilityRetrySeconds: 14 } })).status, 400);
  assert.equal(store.globalDiscoveryIntervalSeconds(), 180);
  const changed = await request('/dbmadmin/api/global-monitor', { admin: true, method: 'PATCH', body: { intervalMinutes: 4, chatAvailabilityRetrySeconds: 150 } });
  assert.equal(changed.status, 200);
  assert.equal(changed.body.monitoring.intervalSeconds, 240);
  assert.equal(changed.body.monitoring.chatAvailabilityRetrySeconds, 150);
  const settings = (await request('/api/global-monitor/settings')).body;
  assert.equal(settings.liveDiscoveryIntervalSeconds, 240);
  assert.equal(settings.chatAvailabilityRetrySeconds, 150);
});

test('validação, criptografia e tipos de sessão permanecem protegidos', () => {
  assert.equal(validation.extractVideoId('https://evil.invalid/?v=AAAAAAAAAAA'), null);
  assert.equal(validation.extractVideoId('https://youtu.be/AAAAAAAAAAA'), 'AAAAAAAAAAA');
  assert.throws(() => validation.username('email@example.com'));
  assert.throws(() => validation.config({ messages: 'x'.repeat(201) }));
  assert.throws(() => validation.password('short'));
  const encrypted = security.encryptText('synthetic');
  assert.equal(security.decryptText(encrypted), 'synthetic');
  const parts = encrypted.split('.');
  const tag = Buffer.from(parts[1], 'base64url');
  tag[0] ^= 1;
  parts[1] = tag.toString('base64url');
  assert.throws(() => security.decryptText(parts.join('.')));
  assert.throws(() => security.verifySession(security.signSession('x', 'user', 1).token, 'admin'));
});

test('backup consistente abre e preserva usuários e três perfis', async () => {
  const file = path.join(process.env.DATA_DIR, 'test-backup.sqlite');
  await store.backupTo(file);
  const { DatabaseSync } = require('node:sqlite');
  const copy = new DatabaseSync(file, { readOnly: true });
  assert.equal(copy.prepare('SELECT COUNT(*) AS n FROM users').get().n, store.users().length);
  assert.equal(copy.prepare('SELECT COUNT(*) AS n FROM user_profiles WHERE user_id=?').get(userId).n, 3);
  assert.equal(Object.values(copy.prepare('PRAGMA quick_check').get())[0], 'ok');
  copy.close();
});

test('migration V2.2.9 para schema 6 preserva a live e inicializa o controle administrativo', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'auto-server-migrate-v5-'));
  const file = path.join(directory, 'peralta.sqlite');
  const { DatabaseSync } = require('node:sqlite');
  const old = new DatabaseSync(file);
  old.exec(`
    CREATE TABLE global_channels(
      id TEXT PRIMARY KEY,channel_id TEXT,handle TEXT,canonical_url TEXT NOT NULL,display_name TEXT NOT NULL DEFAULT '',
      original_input_last_seen TEXT NOT NULL DEFAULT '',is_active_global INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,last_checked_at TEXT,last_error TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE global_lives(
      id TEXT PRIMARY KEY,global_channel_id TEXT NOT NULL REFERENCES global_channels(id) ON DELETE CASCADE,video_id TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL DEFAULT '',live_status TEXT NOT NULL DEFAULT 'UNKNOWN',chat_status TEXT NOT NULL DEFAULT 'UNKNOWN',
      scheduled_start_time TEXT,actual_start_time TEXT,actual_end_time TEXT,ended_detected_at TEXT,first_detected_at TEXT NOT NULL,
      last_checked_at TEXT NOT NULL,finalized_at TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
      active_live_chat_id TEXT NOT NULL DEFAULT '',chat_lookup_next_at TEXT,chat_lookup_error TEXT NOT NULL DEFAULT '',
      last_public_recheck_at TEXT,public_recheck_count INTEGER NOT NULL DEFAULT 0,last_admin_verification_at TEXT
    );
    INSERT INTO global_channels VALUES('channel-v5','UC2020202020202020202020','@MigracaoV5','https://www.youtube.com/@MigracaoV5','Migração V5','@MigracaoV5',1,'2026-09-16T00:00:00Z','2026-09-16T00:00:00Z',NULL,'');
    INSERT INTO global_lives VALUES('live-v5','channel-v5','B0000000000','Live preservada','SCHEDULED','UNAVAILABLE','2026-09-18T12:00:00Z',NULL,NULL,NULL,'2026-09-16T00:00:00Z','2026-09-16T00:00:00Z',NULL,'2026-09-16T00:00:00Z','2026-09-16T00:00:00Z','',NULL,'',NULL,7,'2026-09-16T01:00:00Z');
    PRAGMA user_version=5;
  `);
  old.close();
  const code = `const s=require('./lib/store');const live=s.getGlobalLiveByVideo('B0000000000'),version=s.schemaVersion();s.close();console.log(JSON.stringify({version,title:live.title,status:live.live_status,rechecks:live.public_recheck_count,verified:live.last_admin_verification_at,stateKey:live.admin_state_key,stateResult:live.admin_state_result,nextRetry:live.admin_next_retry_at,failures:live.admin_failure_streak}));`;
  const migrated = spawnSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: { ...process.env, DATA_DIR: directory }, encoding: 'utf8' });
  assert.equal(migrated.status, 0, migrated.stderr);
  assert.deepEqual(JSON.parse(migrated.stdout.trim()), {
    version: 6,
    title: 'Live preservada',
    status: 'SCHEDULED',
    rechecks: 7,
    verified: '2026-09-16T01:00:00Z',
    stateKey: '',
    stateResult: '',
    nextRetry: null,
    failures: 0
  });
  fs.rmSync(directory, { recursive: true, force: true });
});

test('migration V2.1 preserva dados no Perfil 1 e cria Perfis 2 e 3', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'auto-server-migrate-'));
  const file = path.join(directory, 'peralta.sqlite');
  const { DatabaseSync } = require('node:sqlite');
  const old = new DatabaseSync(file);
  old.exec('CREATE TABLE profiles(id TEXT PRIMARY KEY,body TEXT NOT NULL); CREATE TABLE users(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE COLLATE NOCASE,body TEXT NOT NULL); CREATE TABLE oauth_states(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,profile_id TEXT NOT NULL,version INTEGER NOT NULL,expires INTEGER NOT NULL); PRAGMA user_version=1;');
  const legacyApi = { id: 'legacy-api', name: 'API antiga', clientId: '123-old.apps.googleusercontent.com', clientSecretEnc: 'encrypted-old', active: true, version: 4 };
  const legacyUser = {
    id: 'existing-user', email: 'saved@example.invalid', googleEmail: 'google@example.invalid', apiProfileId: legacyApi.id, passwordHash: 'hash', active: true, sessionVersion: 1,
    config: { liveUrl: 'GGGGGGGGGGG', intervalMinutes: 5, intervalSeconds: 0, intervalMs: 0, messages: 'Mensagem preservada', version: 7, messageIndex: 1, economyMode: true, maxPerHour: 2 },
    runtime: { status: 'paused', sent: 9, failures: 1, attempts: 10, connectionErrors: 0, lastError: '', nextAt: null, epoch: 3, hourlySends: [1] },
    oauth: { email: 'google@example.invalid', refreshTokenEnc: 'encrypted-refresh', accessTokenEnc: '', accessTokenExpiresAt: 0, scope: '', version: 2 }
  };
  old.prepare('INSERT INTO profiles VALUES(?,?)').run(legacyApi.id, JSON.stringify(legacyApi));
  old.prepare('INSERT INTO users VALUES(?,?,?)').run(legacyUser.id, legacyUser.email, JSON.stringify(legacyUser));
  old.close();
  const code = `const s=require('./lib/store');const u=s.getUser('existing-user'),p=s.userProfiles(u.id),file=s.DB_FILE;s.close();const {DatabaseSync}=require('node:sqlite'),db=new DatabaseSync(file,{readOnly:true}),version=db.prepare('PRAGMA user_version').get().user_version;db.close();console.log(JSON.stringify({username:u.username,count:p.length,messages:p[0].config.messages,minutes:p[0].config.intervalMinutes,seconds:p[0].config.intervalSeconds,mode:p[0].config.sendMode,oauth:p[0].oauth.refreshTokenEnc,api:p[0].api.clientId,economy:'economyMode' in p[0].config,blank:p[1].config.messages,version}));`;
  const migrated = spawnSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: { ...process.env, DATA_DIR: directory }, encoding: 'utf8' });
  assert.equal(migrated.status, 0, migrated.stderr);
  assert.deepEqual(JSON.parse(migrated.stdout.trim()), { username: 'saved', count: 3, messages: 'Mensagem preservada', minutes: 5, seconds: 1, mode: 'interval', oauth: 'encrypted-refresh', api: legacyApi.clientId, economy: false, blank: '', version: 6 });
  fs.rmSync(directory, { recursive: true, force: true });
});

test('banco corrompido provoca falha sem apagar o arquivo', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'auto-server-corrupt-'));
  const file = path.join(directory, 'peralta.sqlite');
  fs.writeFileSync(file, 'invalid-sqlite');
  const result = spawnSync(process.execPath, ['-e', "require('./lib/store')"], { cwd: path.join(__dirname, '..'), env: { ...process.env, DATA_DIR: directory } });
  assert.notEqual(result.status, 0);
  assert.equal(fs.readFileSync(file, 'utf8'), 'invalid-sqlite');
  fs.rmSync(directory, { recursive: true, force: true });
});

test('tentativas excessivas de login recebem 429', async () => {
  let status;
  for (let index = 0; index < 13; index++) status = (await request('/api/login', { method: 'POST', body: { username: 'Usuário ausente', password: 'wrong', privacyAccepted: true }, bearer: '' })).status;
  assert.equal(status, 429);
});
