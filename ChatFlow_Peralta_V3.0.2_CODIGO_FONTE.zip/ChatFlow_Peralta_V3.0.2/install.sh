#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ]; then echo "Execute como root: sudo ./install.sh"; exit 1; fi
BASE_URL="${1:-}"
CONTACT="${2:-consulte o administrador deste servidor}"
if [[ ! "$BASE_URL" =~ ^https://[^/]+$ ]]; then
  echo "Uso: sudo ./install.sh https://SEU-DOMINIO contato@exemplo.com"
  echo "O domínio precisa estar com HTTPS configurado no proxy reverso."
  exit 1
fi
if ! command -v docker >/dev/null 2>&1; then
  echo "[1/4] Instalando Docker..."
  apt-get update -y
  apt-get install -y ca-certificates curl openssl
  curl -fsSL https://get.docker.com | sh
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose não encontrado. Instalando plugin..."
  apt-get update -y
  apt-get install -y docker-compose-plugin || true
fi
if ! docker compose version >/dev/null 2>&1; then echo "Não foi possível instalar Docker Compose."; exit 1; fi
if [ ! -f .env ]; then
  SETUP_TOKEN="$(openssl rand -hex 24)"
  cat > .env <<ENV
APP_PORT=8080
PUBLIC_BASE_URL=${BASE_URL}
JWT_SECRET=$(openssl rand -hex 48)
APP_ENCRYPTION_KEY=$(openssl rand -hex 32)
SETUP_TOKEN=${SETUP_TOKEN}
OPERATOR_CONTACT=${CONTACT}
GLOBAL_MONITOR_CONCURRENCY=3
ENV
  chmod 600 .env
  cat > ACESSO_INICIAL.txt <<ACCESS
Painel: ${BASE_URL}/dbmadmin
Codigo de instalacao: ${SETUP_TOKEN}

Use este codigo somente para criar o primeiro administrador.
Depois guarde este arquivo em local seguro.
ACCESS
  chmod 600 ACESSO_INICIAL.txt
fi
mkdir -p data
chown -R 1000:1000 data
chmod 700 data
echo "[2/4] Validando configuração..."
docker compose config >/dev/null
echo "[3/4] Construindo servidor..."
docker compose build --pull
echo "[4/4] Iniciando em segundo plano..."
docker compose up -d
BASE_URL=$(grep '^PUBLIC_BASE_URL=' .env | cut -d= -f2-)
echo
echo "ChatFlow Peralta instalado e rodando em segundo plano."
echo "Painel do usuário: ${BASE_URL%/}/painel"
echo "Painel administrativo: ${BASE_URL%/}/dbmadmin"
echo "Código do primeiro acesso: $(pwd)/ACESSO_INICIAL.txt"
echo "Para logs: docker compose logs -f server"
echo "Para atualizar depois: docker compose up -d --build"
