'use strict';

const $ = id => document.getElementById(id);
const show = (id, on) => $(id).classList.toggle('hidden', !on);
const PROFILE_KEY = 'auto-server-selected-profile';
const PAGE_KEY = 'auto-server-user-page';
const DRAFT_PREFIX = 'auto-server-config-draft';
const MAX_MESSAGES = 500;
const VALID_PAGES = new Set(['home', 'control', 'account', 'messages', 'activity', 'privacy']);
const pageMeta = {
  home: ['PAINEL DO USUÁRIO', 'Início', 'Acompanhe o resumo do perfil selecionado.'],
  control: ['CONTROLE INDEPENDENTE', 'Controle', 'Inicie, pause ou pare somente o perfil selecionado.'],
  account: ['CONTA E CANAL', 'Conta e canal', 'Gerencie a autorização Google e o canal deste perfil.'],
  messages: ['MENSAGENS E ENVIO', 'Mensagens e envio', 'Configure o conteúdo e o ritmo dos envios.'],
  activity: ['ATIVIDADE', 'Atividade', 'Consulte lives, avisos e registros recentes.'],
  privacy: ['PRIVACIDADE', 'Privacidade', 'Consulte seus dados e as opções da conta.']
};

let csrfToken = '';
let authenticated = false;
let currentState = null;
let currentProfile = Math.min(50, Math.max(1, Number(localStorage.getItem(PROFILE_KEY)) || 1));
let currentUsername = '';
let currentPage = VALID_PAGES.has(localStorage.getItem(PAGE_KEY)) ? localStorage.getItem(PAGE_KEY) : 'home';
let draftVersion = -1;
let dirty = false;
let busy = false;
let serverOffset = 0;
let stateRequestSequence = 0;
let confirmationResolve = null;
let confirmationRequiredText = '';
let globalFeedbackTimer = null;
let globalFeedbackSource = '';
const pendingActions = new Set();

const LIVE_STATUS_NAMES = Object.freeze({
  LIVE: 'AO VIVO',
  SCHEDULED: 'PROGRAMADA',
  ENDED: 'ENCERRADA',
  UNKNOWN: 'ESTADO NÃO CONFIRMADO'
});
const CHAT_STATUS_NAMES = Object.freeze({
  AVAILABLE: 'CHAT DISPONÍVEL',
  VERIFYING: 'VERIFICANDO CHAT',
  UNAVAILABLE: 'CHAT INDISPONÍVEL',
  ENDED: 'CHAT ENCERRADO',
  UNKNOWN: 'CHAT NÃO CONFIRMADO'
});
const LOG_TYPE_NAMES = Object.freeze({
  send: 'ENVIO',
  live: 'TRANSMISSÃO',
  oauth: 'CONTA GOOGLE',
  connection: 'CONEXÃO',
  system: 'SISTEMA',
  chat: 'CHAT',
  recheck: 'VERIFICAÇÃO',
  maintenance: 'MANUTENÇÃO',
  settings: 'CONFIGURAÇÃO'
});

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function feedback(message, ok = false, { source = 'general', autoHide = ok } = {}) {
  const element = $('globalFeedback');
  if (globalFeedbackTimer) clearTimeout(globalFeedbackTimer);
  globalFeedbackTimer = null;
  globalFeedbackSource = message ? source : '';
  element.textContent = message || '';
  element.className = `global-feedback feedback ${message && ok ? 'ok' : ''}`;
  if (message && autoHide) {
    globalFeedbackTimer = setTimeout(() => {
      if (element.textContent !== message || globalFeedbackSource !== source) return;
      element.textContent = '';
      element.className = 'global-feedback feedback';
      globalFeedbackSource = '';
      globalFeedbackTimer = null;
    }, 3000);
  }
}

function loginFeedback(message, ok = false) {
  const element = $('loginFeedback');
  element.textContent = message || '';
  element.className = `feedback ${message && ok ? 'ok' : ''}`;
}

function actionFeedback(id, message, ok = false) {
  const element = $(id);
  element.textContent = message || '';
  element.className = `feedback action-feedback ${message && ok ? 'ok' : ''}`;
}

function targetedFeedback(id, message, ok = false) {
  if (id === 'loginFeedback') return loginFeedback(message, ok);
  if (id === 'profileNameFeedback') {
    const element = $(id);
    element.textContent = message || '';
    element.className = `feedback ${message && ok ? 'ok' : ''}`;
    return;
  }
  actionFeedback(id, message, ok);
}

function clearActionFeedback() {
  for (const id of ['controlFeedback', 'accountFeedback', 'channelFeedback', 'configFeedback', 'activityFeedback', 'privacyFeedback']) actionFeedback(id, '');
}

function setBusy(on) {
  busy = on;
  document.querySelectorAll('button').forEach(button => { button.disabled = on; });
  if (!on) {
    syncChannelForm();
    syncConfirmationInput();
  }
}

async function runAction(key, feedbackId, action) {
  if (pendingActions.has(key)) return;
  pendingActions.add(key);
  setBusy(true);
  if (feedbackId) targetedFeedback(feedbackId, 'Processando…', true);
  try {
    return await action();
  } catch (error) {
    if (error.status === 401) loggedOut('Sua sessão expirou. Entre novamente. O rascunho foi preservado nesta guia.');
    else if (feedbackId) targetedFeedback(feedbackId, error.message);
    else feedback(error.message);
    return undefined;
  } finally {
    pendingActions.delete(key);
    setBusy(false);
  }
}

function syncChannelForm(channels = currentState?.channels || []) {
  const atLimit = channels.length >= 1;
  $('channelInput').disabled = busy || atLimit;
  $('channelSubmit').disabled = busy || atLimit;
  $('channelInput').placeholder = atLimit ? 'Remova o canal atual para cadastrar outro' : '@canal ou https://youtube.com/@canal';
}

async function api(url, { method = 'GET', body } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
      if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
    }
    const response = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
      signal: controller.signal
    });
    let data;
    try { data = await response.json(); }
    catch { throw new ApiError(response.status, `Resposta inválida do servidor (HTTP ${response.status}).`); }
    if (!response.ok || data.ok !== true) throw new ApiError(response.status, data.error || `HTTP ${response.status}`);
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new ApiError(0, 'Tempo de conexão esgotado.');
    if (error.name === 'TypeError') throw new ApiError(0, 'Não foi possível comunicar com o servidor.');
    throw error;
  } finally { clearTimeout(timer); }
}

function openMenu() {
  $('sidebar').classList.add('open');
  show('navBackdrop', true);
  $('menuToggle').setAttribute('aria-expanded', 'true');
}

function closeMenu() {
  $('sidebar').classList.remove('open');
  show('navBackdrop', false);
  $('menuToggle').setAttribute('aria-expanded', 'false');
}

function goPage(page) {
  if (!VALID_PAGES.has(page)) page = 'home';
  currentPage = page;
  localStorage.setItem(PAGE_KEY, page);
  document.querySelectorAll('[data-page]').forEach(section => {
    const active = section.dataset.page === page;
    section.classList.toggle('hidden', !active);
    section.classList.toggle('active', active);
  });
  document.querySelectorAll('[data-page-target]').forEach(button => {
    const active = button.dataset.pageTarget === page;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  const meta = pageMeta[page];
  $('pageEyebrow').textContent = meta[0];
  $('pageTitle').textContent = meta[1];
  $('pageSubtitle').textContent = meta[2];
  closeMenu();
}

function closeDialog(dialog) {
  if (dialog.open && typeof dialog.close === 'function') dialog.close();
  else dialog.removeAttribute('open');
}

function loggedOut(message = '') {
  stateRequestSequence++;
  authenticated = false;
  csrfToken = '';
  currentState = null;
  draftVersion = -1;
  dirty = false;
  closeDialog($('profileNameDialog'));
  closeConfirmation(false);
  show('loginShell', true);
  show('loginPanel', true);
  show('dashboard', false);
  show('logoutButton', false);
  show('connectionBanner', false);
  $('currentUsername').textContent = '';
  if (message) loginFeedback(message);
}

async function bootstrap() {
  const data = await api('/api/web/bootstrap');
  if (!data.authenticated) return loggedOut();
  authenticated = true;
  csrfToken = data.csrfToken;
  currentUsername = data.user.username || '';
  if (!(data.user.profiles || []).some(profile => profile.profileId === currentProfile)) {
    currentProfile = data.user.profiles?.[0]?.profileId || 1;
    localStorage.setItem(PROFILE_KEY, String(currentProfile));
  }
  $('currentUsername').textContent = currentUsername;
  show('loginShell', false);
  show('loginPanel', false);
  show('dashboard', true);
  show('logoutButton', true);
  goPage(currentPage);
  await refreshState(true, { restoreDraft: true });
}

function number(id) { return Number($(id).value); }
function configBody() {
  return {
    sendMode: $('sendMode').value,
    intervalMinutes: number('intervalMinutes'),
    intervalSeconds: number('intervalSeconds'),
    messages: $('messages').value,
    expectedVersion: draftVersion
  };
}

function draftKey(profile = currentProfile) {
  return `${DRAFT_PREFIX}:${encodeURIComponent(currentUsername || 'usuario')}:${profile}`;
}

function persistDraft() {
  if (!currentState || !dirty) return;
  try {
    sessionStorage.setItem(draftKey(), JSON.stringify({
      profile: currentProfile,
      sendMode: $('sendMode').value,
      intervalMinutes: $('intervalMinutes').value,
      intervalSeconds: $('intervalSeconds').value,
      messages: $('messages').value,
      version: draftVersion,
      savedAt: new Date().toISOString()
    }));
  } catch { /* O painel continua funcionando mesmo se o navegador bloquear o armazenamento. */ }
}

function readDraft(profile = currentProfile) {
  try {
    const value = sessionStorage.getItem(draftKey(profile));
    return value ? JSON.parse(value) : null;
  } catch { return null; }
}

function clearDraft(profile = currentProfile) {
  try { sessionStorage.removeItem(draftKey(profile)); }
  catch { /* sem impacto funcional */ }
}

function clearUserDrafts() {
  try {
    const prefix = `${DRAFT_PREFIX}:${encodeURIComponent(currentUsername || 'usuario')}:`;
    for (let index = sessionStorage.length - 1; index >= 0; index--) {
      const key = sessionStorage.key(index);
      if (key?.startsWith(prefix)) sessionStorage.removeItem(key);
    }
  } catch { /* sem impacto funcional */ }
}

function countMessages() {
  const count = $('messages').value.split(/\r?\n/).map(value => value.trim()).filter(Boolean).length;
  const ignored = Math.max(0, count - MAX_MESSAGES);
  $('messageCount').textContent = ignored
    ? `${count} digitadas • ${MAX_MESSAGES} serão salvas • ${ignored} ${ignored === 1 ? 'será ignorada' : 'serão ignoradas'}`
    : `${count}/${MAX_MESSAGES} ${count === 1 ? 'mensagem' : 'mensagens'}`;
  $('messageCount').classList.toggle('limit-warning', ignored > 0);
}

function markDirty() {
  if (!currentState) return;
  dirty = true;
  $('saveState').textContent = 'Rascunho não salvo';
  $('saveState').classList.add('dirty');
  countMessages();
  persistDraft();
}

function applyDraft(saved) {
  if (!saved || saved.profile !== currentProfile) return false;
  $('sendMode').value = saved.sendMode === 'fixed' ? 'fixed' : 'interval';
  $('intervalMinutes').value = saved.intervalMinutes;
  $('intervalSeconds').value = Math.max(1, Number(saved.intervalSeconds) || 1);
  $('messages').value = saved.messages || '';
  draftVersion = Number.isInteger(saved.version) ? saved.version : draftVersion;
  dirty = true;
  $('saveState').textContent = 'Rascunho recuperado';
  $('saveState').classList.add('dirty');
  syncSendModeFields();
  countMessages();
  actionFeedback('configFeedback', 'O rascunho desta guia foi recuperado. Revise e salve quando estiver pronto.', true);
  return true;
}

function fillConfig(config, { restoreDraft = false } = {}) {
  $('sendMode').value = config.sendMode === 'fixed' ? 'fixed' : 'interval';
  $('intervalMinutes').value = config.intervalMinutes;
  $('intervalSeconds').value = Math.max(1, Number(config.intervalSeconds) || 1);
  $('messages').value = config.messages || '';
  draftVersion = config.version;
  dirty = false;
  $('saveState').textContent = 'Sincronizado';
  $('saveState').classList.remove('dirty');
  syncSendModeFields();
  countMessages();
  if (restoreDraft) applyDraft(readDraft());
}

function syncSendModeFields() {
  const fixed = $('sendMode').value === 'fixed';
  show('intervalFields', !fixed);
  show('intervalHelp', !fixed);
  show('fixedScheduleHelp', fixed);
}

function statusName(status) { return status === 'running' ? 'RODANDO' : status === 'paused' ? 'PAUSADO' : 'PARADO'; }
function formatDuration(ms) {
  const total = Math.max(0, Math.round(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return minutes ? `${minutes} min ${String(seconds).padStart(2, '0')} s` : `${seconds} s`;
}
function formatTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function translateTechnicalText(value) {
  let text = String(value || '');
  const replacements = [
    [/Token has been expired or revoked\.?/gi, 'A autorização Google expirou ou foi revogada.'],
    [/NetworkError when attempting to fetch resource\.?/gi, 'Não foi possível comunicar com o servidor.'],
    [/Failed to fetch/gi, 'Não foi possível comunicar com o servidor'],
    [/\binvalid_grant\b/gi, 'autorização inválida ou expirada'],
    [/\bliveChatNotFound\b/g, 'chat não encontrado'],
    [/\bliveChatEnded\b/g, 'chat encerrado'],
    [/\bliveChatDisabled\b/g, 'chat desativado'],
    [/\bSCHEDULED\b/g, 'PROGRAMADA'],
    [/\bAVAILABLE\b/g, 'DISPONÍVEL'],
    [/\bUNAVAILABLE\b/g, 'INDISPONÍVEL'],
    [/\bVERIFYING\b/g, 'EM VERIFICAÇÃO'],
    [/\bFINALIZED\b/g, 'FINALIZADO'],
    [/\bUNKNOWN\b/g, 'NÃO CONFIRMADO'],
    [/\bENDED\b/g, 'ENCERRADA'],
    [/\bLIVE\b/g, 'AO VIVO']
  ];
  for (const [pattern, replacement] of replacements) text = text.replace(pattern, replacement);
  return text;
}

function profileName() { return currentState?.profile?.name || `Perfil ${currentProfile}`; }

function renderProfiles(profiles) {
  const root = $('profileTabs');
  root.replaceChildren();
  root.className = `profile-tabs count-${Math.min(4, profiles.length || 1)}`;
  for (const profile of profiles) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `profile-tab ${profile.profileId === currentProfile ? 'selected' : ''}`;
    button.dataset.profile = profile.profileId;
    button.setAttribute('aria-pressed', profile.profileId === currentProfile ? 'true' : 'false');
    const dot = document.createElement('span');
    dot.className = `dot ${profile.status}`;
    const name = document.createElement('span');
    name.className = 'profile-name';
    name.textContent = profile.name || `Perfil ${profile.profileId}`;
    const status = document.createElement('span');
    status.className = 'profile-status';
    status.textContent = statusName(profile.status);
    const number = document.createElement('span');
    number.className = 'profile-number';
    number.textContent = `PERFIL ${profile.profileId}`;
    button.append(dot, name, status, number);
    root.append(button);
  }
}

function renderMonitoring(monitoring = {}) {
  $('monitorStatus').textContent = monitoring.running ? 'Busca em andamento' : monitoring.lastGlobalScanError ? 'Última busca com avisos' : 'Monitor ativo no servidor';
  $('monitorInterval').textContent = `${Math.round((monitoring.intervalSeconds || 180) / 60)} min`;
  $('monitorNext').textContent = formatTime(monitoring.nextGlobalScanAt);
  $('monitorChannels').textContent = monitoring.globalChannelsActive || 0;
  $('monitorLives').textContent = (monitoring.scheduledLivesCount || 0) + (monitoring.liveLivesCount || 0);
}

function renderRuntime(data) {
  const runtime = data.runtime;
  const status = runtime.status || 'stopped';
  const name = data.profile.name || `Perfil ${data.selectedProfile}`;
  const badge = $('statusBadge');
  badge.className = `status-pill ${status}`;
  badge.querySelector('span').textContent = statusName(status);
  const controlBadge = $('controlStatusBadge');
  controlBadge.className = `status-pill ${status}`;
  $('controlStatusText').textContent = statusName(status);
  $('profileEyebrow').textContent = `PERFIL ${data.selectedProfile}`;
  $('activeProfileName').textContent = name;
  $('profilesTitle').textContent = name;
  $('controlTitle').textContent = name;
  $('accountPageTitle').textContent = `${name} • Conta e canal`;
  $('messagesPageTitle').textContent = `${name} • Mensagens e envio`;
  $('activityPageTitle').textContent = `${name} • Atividade`;
  $('statusDetail').textContent = status === 'running' && runtime.nextAt
    ? `Próximo envio previsto às ${formatTime(runtime.nextAt)}.`
    : status === 'running' ? 'Aguardando uma live com chat disponível.'
      : status === 'paused' ? `${name} está pausado; os outros perfis continuam independentes.` : `Inicie ${name} quando a conta, o canal e as mensagens estiverem prontos.`;
  $('sentCount').textContent = runtime.sent;
  $('failureCount').textContent = runtime.failures;
  $('attemptCount').textContent = runtime.attempts;
  $('activeChatCount').textContent = runtime.activeChats;
  $('apiLookupCount').textContent = runtime.apiUsageToday?.videosList?.attempts || 0;
  $('apiInsertCount').textContent = runtime.apiUsageToday?.liveChatInsert?.attempts || 0;
  $('effectiveDelay').textContent = runtime.sendMode === 'fixed'
    ? `Horários fixos de São Paulo • disparo deste perfil no segundo ${String(runtime.fixedDispatchSecond || 1).padStart(2, '0')}`
    : runtime.activeChats > 1
      ? `Alternância entre ${runtime.activeChats} lives: um envio a cada ${formatDuration(runtime.effectiveDelayMs)}`
      : `Intervalo efetivo: ${formatDuration(runtime.effectiveDelayMs)}`;
  $('accountTitle').textContent = runtime.oauthConnected ? 'YouTube conectado' : 'YouTube não conectado';
  $('accountDetail').textContent = runtime.oauthConnected
    ? `Conta ativa: ${runtime.oauthEmail}`
    : data.profile.googleEmail ? `Conta permitida: ${data.profile.googleEmail}` : 'O administrador ainda não definiu uma conta Google para este perfil.';
  $('oauthButton').textContent = runtime.oauthConnected ? 'TROCAR CONTA GOOGLE' : 'ENTRAR COM GOOGLE';
  show('disconnectButton', runtime.oauthConnected);
  $('lastError').textContent = runtime.lastError || '';
  show('lastError', !!runtime.lastError);
  document.title = `${name} • ChatFlow Peralta`;
  renderProfiles(data.profiles || []);
  renderMonitoring(data.globalMonitoring);
  renderChannels(data.channels || []);
  renderLives(data.lives || []);
  renderLogs(data.logs || []);
}

function renderChannels(channels) {
  $('channelCount').textContent = `${channels.length} ${channels.length === 1 ? 'canal' : 'canais'}`;
  syncChannelForm(channels);
  const root = $('channels');
  root.replaceChildren();
  if (!channels.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'Nenhum canal cadastrado neste perfil.';
    root.append(empty);
    return;
  }
  for (const channel of channels) {
    const item = document.createElement('article');
    item.className = 'channel-item';
    const info = document.createElement('div');
    const title = document.createElement('strong');
    title.textContent = channel.displayName || channel.handle || channel.channelId || 'Canal do YouTube';
    const url = document.createElement('a');
    url.href = channel.canonicalUrl;
    url.target = '_blank';
    url.rel = 'noopener';
    url.textContent = channel.handle || channel.canonicalUrl;
    const meta = document.createElement('small');
    meta.textContent = channel.lastError ? `Aviso: ${channel.lastError}` : channel.lastCheckedAt ? `Verificado: ${formatTime(channel.lastCheckedAt)}` : 'Aguardando primeira verificação';
    info.append(title, url, meta);
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'button secondary compact remove-channel';
    remove.dataset.channelId = channel.id;
    remove.dataset.channelName = channel.displayName || channel.handle || 'este canal';
    remove.disabled = busy;
    remove.textContent = 'REMOVER';
    item.append(info, remove);
    root.append(item);
  }
}

function renderLives(lives) {
  const root = $('lives');
  root.replaceChildren();
  const visible = lives
    .map((live, index) => ({ live, index }))
    .filter(item => item.live.sendStatus !== 'FINALIZED')
    .sort((left, right) => {
      const leftTime = Date.parse(left.live.scheduledStartTime || left.live.startedAt || '') || 0;
      const rightTime = Date.parse(right.live.scheduledStartTime || right.live.startedAt || '') || 0;
      return rightTime - leftTime || left.index - right.index;
    })
    .slice(0, 3)
    .map(item => item.live);
  if (!visible.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'Nenhuma transmissão programada ou ao vivo neste perfil.';
    root.append(empty);
    return;
  }
  for (const live of visible) {
    const item = document.createElement('div');
    item.className = 'live-pill';
    const liveStatus = LIVE_STATUS_NAMES[live.liveStatus] || String(live.liveStatus || 'ESTADO NÃO CONFIRMADO').replaceAll('_', ' ');
    const chatStatus = CHAT_STATUS_NAMES[live.chatStatus] || String(live.chatStatus || 'CHAT NÃO CONFIRMADO').replaceAll('_', ' ');
    item.textContent = `${live.channelName || live.handle || 'Canal'} • ${live.title || live.videoId} • ${liveStatus} • ${chatStatus}`;
    root.append(item);
  }
}

function renderLogs(logs) {
  const root = $('logs');
  root.replaceChildren();
  if (!logs.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'Sem atividade recente neste perfil.';
    root.append(empty);
    return;
  }
  for (const entry of logs) {
    const item = document.createElement('article');
    item.className = `log ${entry.status || ''}`;
    const head = document.createElement('div');
    head.className = 'log-head';
    const type = document.createElement('span');
    type.textContent = LOG_TYPE_NAMES[String(entry.type || '').toLowerCase()] || String(entry.type || 'ATIVIDADE').toUpperCase();
    const at = document.createElement('time');
    at.dateTime = entry.at || '';
    at.textContent = entry.at ? new Date(entry.at).toLocaleString('pt-BR') : '—';
    head.append(type, at);
    item.append(head);
    if (entry.message) {
      const message = document.createElement('div');
      message.className = 'log-message';
      message.textContent = String(entry.type || '').toLowerCase() === 'send' ? entry.message : translateTechnicalText(entry.message);
      item.append(message);
    }
    if (entry.error) {
      const error = document.createElement('div');
      error.className = 'log-error';
      error.textContent = translateTechnicalText(entry.error);
      item.append(error);
    }
    root.append(item);
  }
}

function markConnected() {
  show('connectionBanner', false);
  $('updatedAt').textContent = `Atualizado às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;
}

function markDisconnected(message) {
  $('connectionMessage').textContent = `${message} Os dados exibidos podem estar desatualizados.`;
  $('updatedAt').textContent = 'Falha na atualização';
  show('connectionBanner', true);
}

async function refreshState(forceConfig = false, { restoreDraft = false, manual = false } = {}) {
  if (!authenticated) return false;
  const requestedProfile = currentProfile;
  const requestSequence = ++stateRequestSequence;
  try {
    const data = await api(`/api/profiles/${requestedProfile}`);
    if (!authenticated || requestedProfile !== currentProfile || requestSequence !== stateRequestSequence) return false;
    serverOffset = Number(data.serverTime || Date.now()) - Date.now();
    currentState = data;
    currentUsername = data.user.username || currentUsername;
    $('currentUsername').textContent = currentUsername;
    if (forceConfig || !dirty) fillConfig(data.config, { restoreDraft });
    renderRuntime(data);
    markConnected();
    if (globalFeedbackSource === 'refresh') feedback('');
    if (manual) feedback('Dados atualizados.', true);
    return true;
  } catch (error) {
    if (!authenticated || requestedProfile !== currentProfile || requestSequence !== stateRequestSequence) return false;
    if (error.status === 401) loggedOut('Sua sessão expirou. Entre novamente. O rascunho foi preservado nesta guia.');
    else if (error.status === 404) return recoverMissingProfile(requestedProfile);
    else {
      markDisconnected(error.message);
      if (manual) feedback(error.message, false, { source: 'refresh', autoHide: false });
    }
    return false;
  }
}

async function recoverMissingProfile(missingProfile) {
  try {
    const data = await api('/api/web/bootstrap');
    if (!data.authenticated) {
      loggedOut('Sua sessão expirou. Entre novamente. O rascunho foi preservado nesta guia.');
      return false;
    }
    const profiles = data.user.profiles || [];
    const fallback = profiles[0]?.profileId;
    if (!fallback) {
      loggedOut('Nenhum perfil está disponível para esta conta. Fale com o administrador.');
      return false;
    }
    csrfToken = data.csrfToken;
    currentUsername = data.user.username || currentUsername;
    currentProfile = fallback;
    localStorage.setItem(PROFILE_KEY, String(fallback));
    currentState = null;
    draftVersion = -1;
    dirty = false;
    clearActionFeedback();
    const updated = await refreshState(true, { restoreDraft: true });
    if (updated) feedback(`O Perfil ${missingProfile} não está mais disponível. ${profileName()} foi selecionado automaticamente.`, true);
    return updated;
  } catch (error) {
    if (error.status === 401) loggedOut('Sua sessão expirou. Entre novamente. O rascunho foi preservado nesta guia.');
    else {
      markDisconnected(error.message);
      feedback(error.message, false, { source: 'refresh', autoHide: false });
    }
    return false;
  }
}

async function selectProfile(number) {
  if (number === currentProfile || busy) return;
  if (dirty) {
    const accepted = await askConfirmation({
      title: 'Trocar de perfil?',
      message: `Existe um rascunho não salvo em ${profileName()}.`,
      details: 'Ao continuar, o rascunho desse perfil será descartado.',
      confirmLabel: 'DESCARTAR E TROCAR',
      danger: true
    });
    if (!accepted) return;
    clearDraft(currentProfile);
  }
  currentProfile = number;
  localStorage.setItem(PROFILE_KEY, String(number));
  currentState = null;
  dirty = false;
  clearActionFeedback();
  await refreshState(true, { restoreDraft: true });
}

async function saveConfig() {
  if (!currentState) throw new ApiError(0, 'Aguarde a sincronização do servidor.');
  if (!$('configForm').reportValidity()) throw new ApiError(0, 'Revise os campos destacados.');
  const result = await api(`/api/profiles/${currentProfile}/settings`, { method: 'PUT', body: configBody() });
  currentState.config = result.settings;
  dirty = false;
  clearDraft();
  $('saveState').textContent = 'Configuração salva';
  $('saveState').classList.remove('dirty');
  await refreshState(true);
  return result;
}

function openProfileNameDialog() {
  if (!currentState || busy) return;
  const dialog = $('profileNameDialog');
  $('profileNameInput').value = profileName();
  $('profileNameFeedback').textContent = '';
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else dialog.setAttribute('open', '');
  requestAnimationFrame(() => { $('profileNameInput').focus(); $('profileNameInput').select(); });
}

function closeProfileNameDialog() { closeDialog($('profileNameDialog')); }

async function saveProfileName() {
  if (!currentState) throw new ApiError(0, 'Aguarde a sincronização do servidor.');
  const name = $('profileNameInput').value.trim();
  if (!name) throw new ApiError(0, 'Informe o nome do perfil.');
  const result = await api(`/api/profiles/${currentProfile}/name`, { method: 'PATCH', body: { name } });
  closeProfileNameDialog();
  await refreshState(false);
  return result.profile.name;
}

function syncConfirmationInput() {
  if (!$('confirmDialog').open && !$('confirmDialog').hasAttribute('open')) return;
  $('confirmAccept').disabled = busy || (confirmationRequiredText && $('confirmInput').value.trim().toUpperCase() !== confirmationRequiredText);
}

function closeConfirmation(value) {
  if (!confirmationResolve) {
    closeDialog($('confirmDialog'));
    return;
  }
  const resolve = confirmationResolve;
  confirmationResolve = null;
  confirmationRequiredText = '';
  closeDialog($('confirmDialog'));
  resolve(Boolean(value));
}

function askConfirmation({ title, message, details = '', confirmLabel = 'CONFIRMAR', danger = false, requireText = '' }) {
  if (confirmationResolve) closeConfirmation(false);
  const dialog = $('confirmDialog');
  confirmationRequiredText = String(requireText || '').trim().toUpperCase();
  $('confirmTitle').textContent = title;
  $('confirmMessage').textContent = message;
  $('confirmDetails').textContent = details;
  show('confirmDetails', !!details);
  $('confirmEyebrow').textContent = danger ? 'ATENÇÃO' : 'CONFIRMAÇÃO';
  $('confirmIcon').textContent = danger ? '!' : '?';
  $('confirmAccept').textContent = confirmLabel;
  dialog.classList.toggle('danger-mode', danger);
  show('confirmTypeGroup', !!confirmationRequiredText);
  $('confirmExpected').textContent = confirmationRequiredText || 'EXCLUIR';
  $('confirmInput').value = '';
  $('confirmAccept').disabled = !!confirmationRequiredText;
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else dialog.setAttribute('open', '');
  requestAnimationFrame(() => (confirmationRequiredText ? $('confirmInput') : $('confirmCancel')).focus());
  return new Promise(resolve => { confirmationResolve = resolve; });
}

async function control(action) {
  await runAction(`control-${action}-${currentProfile}`, 'controlFeedback', async () => {
    if (action === 'start' && dirty) await saveConfig();
    const name = profileName();
    await api(`/api/profiles/${currentProfile}/${action}`, { method: 'POST', body: {} });
    await refreshState(false);
    const message = action === 'start'
      ? `${name} foi iniciado no servidor.`
      : action === 'pause' ? `${name} foi pausado.` : `${name} foi parado. Os contadores diários foram zerados.`;
    actionFeedback('controlFeedback', message, true);
  });
}

async function confirmControl(action) {
  const name = profileName();
  const options = action === 'start'
    ? { title: `Iniciar ${name}?`, message: 'O perfil começará a procurar chats e enviar as mensagens configuradas.', details: dirty ? 'O rascunho atual será salvo antes de iniciar.' : '', confirmLabel: 'INICIAR PERFIL' }
    : action === 'pause'
      ? { title: `Pausar ${name}?`, message: 'Os envios serão interrompidos até que o perfil seja iniciado novamente.', details: 'Os contadores e o ciclo atual serão preservados.', confirmLabel: 'PAUSAR PERFIL' }
      : { title: `Parar ${name}?`, message: 'A execução deste perfil será encerrada.', details: 'Enviadas, tentativas, falhas e erros de conexão serão zerados. Uso da API hoje, mensagens, canal, Conta Google e registros recentes serão preservados.', confirmLabel: 'PARAR PERFIL', danger: true };
  if (await askConfirmation(options)) await control(action);
}

$('loginForm').addEventListener('submit', async event => {
  event.preventDefault();
  await runAction('login', 'loginFeedback', async () => {
    loginFeedback('Entrando…', true);
    await api('/api/login', { method: 'POST', body: { username: $('loginUsername').value.trim(), password: $('loginPassword').value, privacyAccepted: $('privacyAccepted').checked } });
    $('loginPassword').value = '';
    await bootstrap();
    feedback('Login concluído.', true);
    loginFeedback('');
  });
});

document.querySelector('.sidebar-nav').addEventListener('click', event => {
  const button = event.target.closest('[data-page-target]');
  if (button) goPage(button.dataset.pageTarget);
});
$('menuToggle').addEventListener('click', () => $('sidebar').classList.contains('open') ? closeMenu() : openMenu());
$('navBackdrop').addEventListener('click', closeMenu);

$('profileTabs').addEventListener('click', event => {
  const button = event.target.closest('button[data-profile]');
  if (button) selectProfile(Number(button.dataset.profile));
});

$('configForm').addEventListener('input', markDirty);
$('sendMode').addEventListener('change', syncSendModeFields);
$('configForm').addEventListener('submit', async event => {
  event.preventDefault();
  await runAction(`save-config-${currentProfile}`, 'configFeedback', async () => {
    const result = await saveConfig();
    const ignored = result.messageSummary?.ignored || 0;
    actionFeedback('configFeedback', ignored
      ? `Configuração salva. As primeiras ${result.messageSummary.saved} mensagens foram mantidas e ${ignored} ${ignored === 1 ? 'excedente foi ignorada' : 'excedentes foram ignoradas'}.`
      : `Configuração de ${profileName()} salva.`, true);
  });
});

$('reloadButton').addEventListener('click', async () => {
  if (dirty && !await askConfirmation({ title: 'Descartar o rascunho?', message: `As alterações ainda não salvas de ${profileName()} serão removidas.`, confirmLabel: 'DESCARTAR RASCUNHO', danger: true })) return;
  clearDraft();
  dirty = false;
  await refreshState(true);
  actionFeedback('configFeedback', 'Rascunho descartado. A configuração do servidor foi recarregada.', true);
});

$('startButton').addEventListener('click', () => confirmControl('start'));
$('pauseButton').addEventListener('click', () => confirmControl('pause'));
$('stopButton').addEventListener('click', () => confirmControl('stop'));
$('refreshButton').addEventListener('click', () => refreshState(false, { manual: true }));
$('retryConnectionButton').addEventListener('click', () => refreshState(false, { manual: true }));

$('renameProfileButton').addEventListener('click', openProfileNameDialog);
$('cancelProfileNameButton').addEventListener('click', closeProfileNameDialog);
$('profileNameDialog').addEventListener('click', event => { if (event.target === $('profileNameDialog')) closeProfileNameDialog(); });
$('profileNameDialog').addEventListener('cancel', event => { event.preventDefault(); closeProfileNameDialog(); });
$('profileNameForm').addEventListener('submit', async event => {
  event.preventDefault();
  await runAction(`rename-${currentProfile}`, 'profileNameFeedback', async () => {
    $('profileNameFeedback').textContent = 'Salvando…';
    const name = await saveProfileName();
    feedback(`Nome do perfil alterado para “${name}”.`, true);
  });
});

$('confirmInput').addEventListener('input', syncConfirmationInput);
$('confirmCancel').addEventListener('click', () => closeConfirmation(false));
$('confirmAccept').addEventListener('click', () => {
  if (confirmationRequiredText && $('confirmInput').value.trim().toUpperCase() !== confirmationRequiredText) return;
  closeConfirmation(true);
});
$('confirmDialog').addEventListener('cancel', event => { event.preventDefault(); closeConfirmation(false); });
$('confirmDialog').addEventListener('click', event => { if (event.target === $('confirmDialog')) closeConfirmation(false); });
$('confirmDialog').addEventListener('keydown', event => {
  if (confirmationRequiredText && event.key === 'Enter') event.preventDefault();
});

$('oauthButton').addEventListener('click', async () => {
  await runAction(`oauth-${currentProfile}`, 'accountFeedback', async () => {
    const result = await api(`/api/profiles/${currentProfile}/oauth/connect?client=web`);
    persistDraft();
    location.assign(result.url);
  });
});

$('disconnectButton').addEventListener('click', async () => {
  const name = profileName();
  if (!await askConfirmation({ title: `Desconectar o YouTube de ${name}?`, message: 'A autorização Google deste perfil será removida.', details: 'Somente este perfil será pausado. Os outros perfis continuarão independentes.', confirmLabel: 'DESCONECTAR GOOGLE', danger: true })) return;
  await runAction(`disconnect-${currentProfile}`, 'accountFeedback', async () => {
    const result = await api(`/api/profiles/${currentProfile}/oauth/disconnect`, { method: 'POST', body: {} });
    await refreshState(true);
    actionFeedback('accountFeedback', result.warning || `YouTube desconectado de ${name}.`, !result.warning);
  });
});

$('channelForm').addEventListener('submit', async event => {
  event.preventDefault();
  await runAction(`add-channel-${currentProfile}`, 'channelFeedback', async () => {
    const result = await api(`/api/profiles/${currentProfile}/channels`, { method: 'POST', body: { channel: $('channelInput').value.trim() } });
    $('channelInput').value = '';
    await refreshState(false);
    actionFeedback('channelFeedback', result.warning || `Canal adicionado a ${profileName()}.`, !result.warning);
  });
});

$('channels').addEventListener('click', async event => {
  const button = event.target.closest('.remove-channel');
  if (!button) return;
  const name = profileName();
  if (!await askConfirmation({ title: `Remover canal de ${name}?`, message: `${button.dataset.channelName} deixará de ser monitorado somente neste perfil.`, confirmLabel: 'REMOVER CANAL', danger: true })) return;
  await runAction(`remove-channel-${currentProfile}`, 'channelFeedback', async () => {
    await api(`/api/profiles/${currentProfile}/channels/${encodeURIComponent(button.dataset.channelId)}`, { method: 'DELETE', body: {} });
    await refreshState(false);
    actionFeedback('channelFeedback', `Canal removido de ${name}.`, true);
  });
});

$('clearLogsButton').addEventListener('click', async () => {
  const name = profileName();
  if (!await askConfirmation({ title: `Limpar registros de ${name}?`, message: 'Somente os registros recentes deste perfil serão removidos.', details: 'Mensagens, canal, Conta Google, contadores e execução não serão alterados.', confirmLabel: 'LIMPAR REGISTROS', danger: true })) return;
  await runAction(`clear-logs-${currentProfile}`, 'activityFeedback', async () => {
    await api(`/api/profiles/${currentProfile}/logs/clear`, { method: 'POST', body: {} });
    await refreshState(false);
    actionFeedback('activityFeedback', `Registros recentes de ${name} foram limpos.`, true);
  });
});

$('logoutButton').addEventListener('click', async () => {
  const accepted = await askConfirmation({
    title: 'Sair do painel?',
    message: 'Os perfis em execução continuarão funcionando normalmente no servidor.',
    details: dirty ? `O rascunho não salvo de ${profileName()} será descartado.` : '',
    confirmLabel: 'SAIR DO PAINEL'
  });
  if (!accepted) return;
  if (dirty) clearDraft();
  await runAction('logout', null, async () => {
    await api('/api/logout', { method: 'POST', body: {} });
    loggedOut('Você saiu. As automações não foram interrompidas.');
  });
});

$('deleteAccountButton').addEventListener('click', async () => {
  const accepted = await askConfirmation({
    title: `Excluir a conta ${currentUsername}?`,
    message: 'Todos os perfis serão parados e a conta será excluída definitivamente.',
    details: 'Perfis, configurações, mensagens, canais, conexões Google e histórico serão removidos. Essa ação não pode ser desfeita.',
    confirmLabel: 'EXCLUIR DEFINITIVAMENTE',
    danger: true,
    requireText: 'EXCLUIR'
  });
  if (!accepted) return;
  await runAction('delete-account', 'privacyFeedback', async () => {
    await api('/api/account', { method: 'DELETE', body: {} });
    clearUserDrafts();
    loggedOut('Conta e todos os perfis foram excluídos do servidor.');
  });
});

window.addEventListener('beforeunload', event => {
  if (!dirty) return;
  persistDraft();
  event.preventDefault();
  event.returnValue = '';
});
window.addEventListener('pagehide', persistDraft);

const query = new URLSearchParams(location.search);
const oauthResult = query.get('oauth');
const oauthProfile = Number(query.get('profile'));
if (oauthProfile >= 1 && oauthProfile <= 50) {
  currentProfile = oauthProfile;
  localStorage.setItem(PROFILE_KEY, String(oauthProfile));
}
if (oauthResult) history.replaceState({}, '', location.pathname);

setInterval(() => { if (authenticated && document.visibilityState === 'visible' && !busy && !confirmationResolve) refreshState(false); }, 5000);
setInterval(() => {
  if (!currentState || currentState.runtime.status !== 'running' || !currentState.runtime.nextAt) return;
  const left = new Date(currentState.runtime.nextAt).getTime() - (Date.now() + serverOffset);
  $('statusDetail').textContent = left > 0 ? `Próximo envio em ${formatDuration(left)} (${formatTime(currentState.runtime.nextAt)}).` : 'Preparando o próximo envio…';
}, 1000);
document.addEventListener('visibilitychange', () => { if (authenticated && document.visibilityState === 'visible' && !busy) refreshState(false); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && $('sidebar').classList.contains('open')) closeMenu(); });

bootstrap().then(() => {
  if (!oauthResult || !authenticated) return;
  goPage('account');
  actionFeedback('accountFeedback', oauthResult === 'ok' ? `Conta Google autorizada em ${profileName()}.` : 'A autorização Google não foi concluída.', oauthResult === 'ok');
}).catch(error => { loggedOut(); loginFeedback(error.message); });
