'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const {
  FIXED_MINUTES,
  TIME_ZONE,
  fixedDispatchSecond,
  currentFixedSlot,
  nextFixedTarget,
  markFixedSlot
} = require('../lib/fixed-scheduler');

function profile(number = 1) {
  return { profileNumber: number, config: { sendMode: 'fixed' }, runtime: { fixedLastSlotKey: '', fixedLastSlotAt: null } };
}

test('grade fixa usa São Paulo e distribui os perfis pelos segundos ímpares', () => {
  assert.equal(TIME_ZONE, 'America/Sao_Paulo');
  assert.deepEqual(FIXED_MINUTES, [1, 5, 9, 11, 15, 19, 21, 25, 29, 31, 35, 39, 41, 45, 49, 51, 55, 59]);
  assert.deepEqual([1, 2, 3, 4, 5, 8, 15, 16].map(fixedDispatchSecond), [1, 3, 5, 7, 9, 15, 29, 1]);

  const at = Date.parse('2026-09-21T21:03:27-03:00');
  assert.equal(new Date(nextFixedTarget(profile(1), at)).toISOString(), '2026-09-22T00:05:01.000Z');
  assert.equal(new Date(nextFixedTarget(profile(2), at)).toISOString(), '2026-09-22T00:05:03.000Z');
});

test('horário atrasado continua válido durante o minuto e nunca repete slot concluído', () => {
  const item = profile(1);
  const delayed = Date.parse('2026-09-21T21:09:30-03:00');
  const slot = currentFixedSlot(item, delayed);
  assert.equal(slot.label, '21:09');
  assert.equal(nextFixedTarget(item, delayed), delayed);

  markFixedSlot(item, slot);
  assert.match(item.runtime.fixedLastSlotKey, /21:09/);
  assert.equal(new Date(nextFixedTarget(item, delayed)).toISOString(), '2026-09-22T00:11:01.000Z');

  const clockMovedBack = Date.parse('2026-09-21T21:05:10-03:00');
  assert.equal(new Date(nextFixedTarget(item, clockMovedBack)).toISOString(), '2026-09-22T00:11:01.000Z');
});

test('virada da hora mantém a sequência 59 para 01', () => {
  const item = profile(3);
  const at = Date.parse('2026-09-21T21:59:40-03:00');
  const slot = currentFixedSlot(item, at);
  assert.equal(slot.label, '21:59');
  markFixedSlot(item, slot);
  assert.equal(new Date(nextFixedTarget(item, at)).toISOString(), '2026-09-22T01:01:05.000Z');
});
