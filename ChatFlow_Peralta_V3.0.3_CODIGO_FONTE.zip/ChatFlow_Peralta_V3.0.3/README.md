# ChatFlow Peralta V3.0.3

Servidor e painel web do ChatFlow Peralta. A automação continua na VPS mesmo com o
aplicativo, o painel ou o navegador fechados.

Esta entrega torna a quantidade de perfis totalmente administrável: uma conta
nova começa somente com o Perfil 1, enquanto contas antigas preservam todos os
perfis existentes. Também corrige a indicação de próximo envio e permite
configurar a busca global em segundos. O aplicativo Android não faz parte deste
ZIP.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde: `/health`
- Retorno OAuth: `/oauth/google/callback`

## Perfis, canais e execução

- Cada conta nova começa somente com o Perfil 1, que é permanente.
- O administrador pode adicionar perfis até o limite de 50 e excluir qualquer
  perfil a partir do número 2.
- A adição reutiliza sempre o primeiro número livre: 2, 3, 4 e assim por diante.
- Contas antigas preservam integralmente todos os perfis que já possuem; a
  atualização nunca exclui Perfil 2, 3 ou qualquer outro automaticamente.
- Cada perfil aceita exatamente um canal.
- O usuário pode renomear o perfil selecionado pelo painel web. O número
  interno, a execução, o OAuth, o canal e as configurações não são alterados.
- API Google, OAuth, mensagens, intervalo, canal, worker, contadores e logs são
  independentes por perfil.
- O mesmo canal e a mesma live são monitorados globalmente uma única vez e o
  resultado é compartilhado entre os perfis inscritos.
- INICIAR, PAUSAR e PARAR exigem confirmação no painel.
- Enviadas, tentativas, falhas e erros de conexão são contadores diários. Eles
  viram junto com o dia da cota da API do YouTube, à meia-noite do Pacífico
  (normalmente 04h ou 05h no horário de Brasília, conforme a época do ano).
- PARAR também zera antecipadamente esses contadores do perfil. Os contadores
  de uso diário real da API permanecem, pois registram consumo efetivo.
- PAUSAR preserva os contadores e a posição do ciclo.
- “Próximo envio” aparece somente quando existe uma live programada ou ao vivo
  com chat disponível. Sem chat elegível, o painel informa que está aguardando.

## Modos de envio

- `interval` mantém integralmente o funcionamento anterior e continua sendo o
  padrão de todos os perfis existentes e novos.
- `fixed` faz uma mensagem imediata ao iniciar um novo ciclo ou ao encontrar o
  primeiro chat desse ciclo. Depois usa os minutos 01, 05, 09, 11, 15, 19, 21,
  25, 29, 31, 35, 39, 41, 45, 49, 51, 55 e 59 em `America/Sao_Paulo`.
- Os perfis são distribuídos nos segundos ímpares de 01 a 29. O minuto inteiro
  continua válido se houver pequeno atraso ou falha temporária.
- Cada slot concluído fica persistido no perfil. Reinício, reconexão, retorno
  de pausa e timers repetidos não repetem o mesmo horário.
- PARAR e depois INICIAR cria um ciclo novo e permite outra mensagem imediata.
  PAUSAR e RETOMAR preserva o ciclo e não cria uma nova mensagem imediata.
- O agendamento usa o mesmo worker já existente; não existe segundo scheduler,
  consulta de horário por mensagem ou consumo de chave administrativa.

## Descoberta pública e live programada

- A página pública `/streams` continua sendo a fonte principal para encontrar
  IDs de lives. Não foi acrescentada busca de lives desconhecidas pela API.
- Lives `SCHEDULED` continuam aptas a enviar mensagens assim que o YouTube
  disponibiliza o chat; não é necessário aguardar o estado `LIVE`.
- Lives `LIVE` e `SCHEDULED` continuam sendo acompanhadas pela página pública.
- Lives `ENDED` ou finalizadas permanecem no histórico, mas são removidas para
  sempre da fila de reverificação e não consomem chave administrativa.
- `LOGIN_REQUIRED`, CAPTCHA, “confirme que você não é um bot”, timeout e falhas
  5xx não encerram uma live por conta própria.

## Chaves administrativas sem consultas repetidas

- A chave administrativa usa somente `videos.list` para um ID de vídeo que já
  foi encontrado. Ela não usa `search.list` nem pesquisa canais.
- A primeira chave disponível é usada; se ela falhar, as reservas são tentadas
  imediatamente por prioridade.
- O resultado público que disparou a confirmação é gravado no banco como uma
  assinatura de estado por vídeo.
- O mesmo estado confirmado não consulta a API de novo, mesmo depois de muitos
  ciclos ou reinício do contêiner.
- Uma mudança real de transmissão ou chat libera imediatamente uma nova
  confirmação. Não é necessário esperar um prazo longo.
- Um chat ativo e confiável é reutilizado sem chamada administrativa. A mudança
  pública de `SCHEDULED` para `LIVE` continua sendo aplicada sem interromper o
  chat.
- Se todas as chaves falharem, a live é preservada e o retry administrativo usa
  1 minuto, depois 2 minutos e, a partir daí, no máximo 5 minutos.
- Qualquer mudança pública relevante ignora a espera de falha e tenta
  imediatamente.
- Um erro terminal do worker (`404`, `liveChatNotFound` ou `liveChatEnded`)
  invalida o estado anterior e permite exatamente uma nova confirmação.
- Chamadas simultâneas para o mesmo vídeo são unificadas. O estado persistente
  também evita novas chamadas do mesmo vídeo em ciclos posteriores e entre
  perfis.
- O botão TESTAR de uma chave é uma ação manual e continua fazendo uma chamada
  real.

## Segurança das chaves

- O `/dbmadmin` permite adicionar, testar, habilitar, desabilitar, priorizar e
  excluir chaves.
- As chaves completas são criptografadas com `APP_ENCRYPTION_KEY` e nunca são
  devolvidas ao navegador.
- Consultas, sucessos, falhas, último uso, espera de cota e último erro aparecem
  no painel administrativo.
- Projetos Google Cloud diferentes são necessários para quotas realmente
  independentes.

## Painel administrativo moderno

- A administração usa tema azul-noturno responsivo, sem bibliotecas externas,
  fontes remotas ou imagens pesadas.
- As áreas foram separadas em Visão geral, Usuários e perfis, Criar usuário,
  Chaves de verificação, Atividade e Configurações.
- Respostas antigas de atualização são descartadas quando uma solicitação mais
  nova já foi iniciada.
- Ações em andamento ficam bloqueadas mesmo se a atualização automática
  reconstruir a lista de botões.
- Campos que o administrador está preenchendo não são sobrescritos pela
  atualização automática de 30 segundos.
- Bloquear usuários, desabilitar chaves, excluir dados e outras ações sensíveis
  usam uma confirmação administrativa padronizada.
- A confirmação administrativa mantém a navegação por teclado dentro da janela
  até confirmar ou cancelar e restaura o foco ao elemento anterior.
- Mensagens administrativas de sucesso desaparecem automaticamente; erros
  permanecem visíveis até uma nova ação ou atualização bem-sucedida.
- A pesquisa de usuários também encontra nomes dos perfis.
- O atalho “Abrir painel do usuário” abre uma nova guia e não interrompe a
  administração.
- O painel administrativo e o painel do usuário usam a mesma identidade visual
  do ChatFlow Peralta. Favicons mostram somente o robô, sem texto ilegível.

## Painel do usuário moderno e protegido

- O tema escuro preserva a identidade amarela do ChatFlow Peralta e não utiliza
  bibliotecas, fontes ou recursos externos.
- Início, Controle, Conta e canal, Mensagens e envio, Atividade e Privacidade
  ficam em áreas separadas. No celular, o menu lateral torna-se recolhível.
- A aba Controle concentra INICIAR, PAUSAR e PARAR, mostra o estado atual e o
  intervalo efetivo e explica o efeito de cada comando.
- A faixa de perfis permanece acima do conteúdo em todas as áreas. Um perfil
  ocupa a largura disponível; dois ou três se distribuem em colunas e, a partir
  do quarto, a grade usa quatro colunas com quebra automática. No celular, um
  perfil ocupa uma coluna e os demais usam até duas.
- Nome real, número e estado do perfil aparecem juntos para reduzir o risco de
  uma ação ser executada no perfil errado.
- INICIAR, PAUSAR, PARAR, desconectar Google, remover canal, limpar registros,
  sair e descartar rascunho usam confirmações próprias do painel.
- A exclusão da conta fica isolada em uma Zona de perigo e exige digitar
  `EXCLUIR` antes de liberar o botão definitivo.
- A janela de confirmação aceita cancelamento por Escape, mantém o foco dentro
  do diálogo e nunca coloca o foco inicial na ação perigosa.
- O painel informa a hora da última atualização e avisa quando os dados podem
  estar desatualizados por falha de comunicação.
- “Dados atualizados” aparece somente em atualização manual e desaparece após
  três segundos. Um erro de atualização é removido quando a comunicação volta.
- Se um perfil removível aberto for excluído pelo administrador, o painel
  seleciona automaticamente o primeiro perfil ainda disponível.
- A área de atividade exibe no máximo as três transmissões programadas ou ao
  vivo mais recentes. Uma transmissão programada para depois pode aparecer
  acima da transmissão que já está ao vivo.
- Tipos de registros, estados de live e erros técnicos conhecidos são exibidos
  em português, sem modificar o texto das mensagens configuradas pelo usuário.
- Rascunhos de mensagens e intervalo são preservados nesta guia após recarga,
  redirecionamento OAuth ou expiração de sessão. A troca confirmada de perfil,
  o descarte e o logout manual removem o rascunho correspondente.
- Respostas atrasadas de um perfil antigo são ignoradas, ações repetidas ficam
  bloqueadas durante o processamento e o resultado aparece junto da área usada.

## YouTube Data API dos perfis

- O OAuth e a quota de cada perfil continuam separados das chaves
  administrativas.
- O `activeLiveChatId` confirmado é armazenado globalmente e compartilhado com
  os perfis da live.
- Se o chat ainda não existe, o retry configurável do perfil continua gravado
  na própria live. Outras lives continuam funcionando.
- O padrão desse retry de disponibilidade do chat permanece em 120 segundos e
  pode ser configurado de 15 a 3600 segundos no painel administrativo.
- A busca global de novas lives permanece em 180 segundos por padrão e agora é
  editada diretamente em segundos, entre 60 e 3600. Valores já salvos são
  preservados: três minutos continuam armazenados e exibidos como 180 segundos.
- O access token é reutilizado até perto do vencimento.
- Os contadores representam solicitações reais, não uma estimativa fixa de
  unidades de quota.

## Lives simultâneas, intervalo e horários fixos

- Uma live usa o intervalo configurado no perfil.
- Duas lives alternam um envio total a cada 3 minutos.
- Três lives alternam um envio total a cada 2 minutos e 30 segundos.
- O menor intervalo configurável permanece 0 minuto e 1 segundo.
- A posição da lista de mensagens é preservada ao pausar, parar ou iniciar.
- Cada perfil aceita até 500 mensagens não vazias, com até 200 caracteres por
  mensagem. Se forem enviadas mais de 500, o servidor preserva as primeiras
  500, ignora somente as excedentes e informa o resultado ao painel.
- No modo fixo, cada slot escolhe a próxima live elegível pela rotação já
  existente. Lives programadas continuam aptas quando o chat está disponível.

## Isolamento e proteção

- Retry e backoff são individuais por live.
- Uma live sem chat, com 429 ou falha temporária não bloqueia as demais.
- Respostas ambíguas de envio pausam somente a live envolvida para evitar
  duplicidade.
- Remover ou trocar o canal invalida imediatamente um alvo em andamento.
- OAuth inválido, API desativada e permissões insuficientes geram mensagens
  específicas sem expor segredos.
- Cookies HttpOnly/SameSite, CSRF, validação de origem, limite de login e
  criptografia AES-256-GCM permanecem ativos.

## Banco e compatibilidade

A V3.0.3 mantém o schema SQLite 6 da V3.0.2. A nova regra de perfis não exige
migração destrutiva: ela afeta apenas contas criadas depois da atualização e
ações manuais de adicionar ou excluir. O modo fixo e seu último slot ficam no
documento persistido de cada perfil, sem recriar tabelas ou apagar dados.
Os campos administrativos acrescentados anteriormente continuam responsáveis
por:

1. guardar a assinatura do último estado administrativo;
2. distinguir sucesso de falha;
3. guardar o próximo retry após falha de todas as chaves;
4. guardar a sequência de falhas para o backoff de 1, 2 e 5 minutos.

Usuários, senhas, perfis, mensagens, canais, OAuth, chaves administrativas,
logs, contadores e estados de live existentes são preservados. O banco fica em
`data/peralta.sqlite`; preserve sempre a pasta `data/` junto com o `.env`, pois
`APP_ENCRYPTION_KEY` protege os segredos já gravados.

Use `ATUALIZAR_SEM_PERDER_DADOS.sh`. Ele cria um backup consistente, copia
`.env` e `data/`, inicia a V3.0.3, exige `/health` com schema 6, valida a sintaxe
no contêiner e religa automaticamente a V3.0.2 se houver falha.

Para manter o relógio da VPS correto, use Chrony ou o sincronizador do próprio
Linux. O ChatFlow Peralta não muda o relógio e não abre NTP dentro do contêiner.
Consulte `CONFIGURAR_HORARIO_VPS.txt`.

## Google OAuth

Cada perfil utiliza um OAuth Client do tipo **Web application**. Cadastre:

`https://SEU-DOMINIO/oauth/google/callback`

## Desenvolvimento

Requer Node.js 24.14 ou superior na linha 24:

```bash
npm ci
npm run check
npm test
npm start
```

Consulte `CHANGELOG_V3.0.3.txt`, `MUDANCAS_V3.0.3.txt`, `INSTALAR.txt` e
`ATUALIZAR_SEM_PERDER_DADOS.txt`.
