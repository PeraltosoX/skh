'use strict';
// Verificação opcional com Playwright/Chromium instalado no ambiente de testes.
// Não usa credenciais reais, Google ou servidor de produção.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const http = require('node:http');
const { chromium } = require('playwright');
const bcrypt = require('bcryptjs');

async function main() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-browser-'));
  process.env.DATA_DIR = directory;
  process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
  process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
  process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
  process.env.NODE_ENV = 'test';
  const server = http.createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const base = `http://127.0.0.1:${server.address().port}`;
  process.env.PUBLIC_BASE_URL = base;
  const store = require('../lib/store');
  const { createApp } = require('../server');
  server.on('request', createApp());
  let browser;
  try {
    const password = crypto.randomBytes(24).toString('hex');
    const account = store.createUser({ id: store.id('usr'), username: 'Teste do painel', passwordHash: await bcrypt.hash(password, 4), active: true, sessionVersion: 1 });
    store.addUserProfile(account.id); store.addUserProfile(account.id);
    for (let i = 0; i < 92; i++) store.recordApiCall(account.id, 1, 'liveChatMessages.insert', true);
    for (let i = 0; i < 12; i++) store.recordApiCall(account.id, 2, 'videos.list', true);
    for (let i = 0; i < 8; i++) store.recordApiCall(account.id, 2, 'liveChatMessages.insert', true);
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
    const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' });
    const errors = [], external = [];
    await context.route('**/*', async route => {
      if (new URL(route.request().url()).origin !== base) { external.push(route.request().url()); return route.abort(); }
      return route.continue();
    });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(`${base}/painel`);
    await page.locator('#loginUsername').fill(account.username);
    await page.locator('#loginPassword').fill(password);
    await page.locator('#privacyAccepted').check();
    await page.locator('#loginForm button[type="submit"]').click();
    async function quota(profile, units) {
      await page.locator('#quotaCard[aria-busy="false"]').waitFor();
      await page.locator('#quotaProfileName').filter({ hasText: new RegExp(`^Perfil ${profile}(?:$| •)`) }).waitFor();
      await page.locator('#quotaUsed').filter({ hasText: new RegExp(`^${units}$`) }).waitFor();
      assert.equal(await page.locator('#quotaUsed').textContent(), units);
    }
    await quota(1, '1.840');
    assert.equal(await page.locator('#quotaRemaining').textContent(), '8.160');
    assert.equal(await page.locator('#quotaRequests').textContent(), '92');
    assert.equal(await page.locator('#quotaMessages').textContent(), '92');
    assert.equal(await page.locator('#quotaPercent').textContent(), '18,4%');
    assert.equal(await page.locator('#quotaQueryCost').textContent(), '1');
    assert.equal(await page.locator('#quotaSendCost').textContent(), '20');
    const position = await page.evaluate(() => ({
      profiles: document.querySelector('.profile-context').getBoundingClientRect().bottom,
      quotaTop: document.querySelector('#quotaCard').getBoundingClientRect().top,
      quotaBottom: document.querySelector('#quotaCard').getBoundingClientRect().bottom,
      welcome: document.querySelector('.welcome-card').getBoundingClientRect().top
    }));
    assert.ok(position.profiles <= position.quotaTop && position.quotaBottom <= position.welcome);
    const output = process.env.PANEL_CHECK_OUTPUT ? path.resolve(process.env.PANEL_CHECK_OUTPUT) : null;
    if (output) { await page.locator('#globalFeedback:empty').waitFor({ state: 'attached' }); fs.mkdirSync(output, { recursive: true }); await page.screenshot({ path: path.join(output, 'painel-inicio-desktop.png'), fullPage: true, animations: 'disabled' }); }
    await page.locator('[data-profile="2"]').click(); await quota(2, '172');
    await page.locator('[data-profile="3"]').click(); await quota(3, '0');
    assert.equal(await page.locator('#quotaRemaining').textContent(), '10.000');
    // A resposta do Perfil 2 chega somente depois que o Perfil 3 já foi exibido.
    let release, started, completed;
    const start = new Promise(resolve => { started = resolve; });
    const complete = new Promise(resolve => { completed = resolve; });
    await page.route('**/api/profiles/2', async route => {
      const response = await route.fetch(); started();
      await new Promise(resolve => { release = resolve; });
      await route.fulfill({ response }); completed();
    });
    await page.locator('[data-profile="2"]').click(); await start;
    assert.equal(await page.locator('#quotaUsed').textContent(), '—');
    assert.equal(await page.locator('#quotaProfileName').textContent(), 'Perfil 2');
    await page.locator('[data-profile="3"]').click(); await quota(3, '0');
    release(); await complete;
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    await quota(3, '0');
    await page.unroute('**/api/profiles/2');
    // Falha na troca também não pode mostrar os números do perfil anterior.
    await page.route('**/api/profiles/2', route => route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ ok: false, error: 'Falha de teste' }) }));
    await page.locator('[data-profile="2"]').click();
    await page.locator('#connectionBanner').waitFor({ state: 'visible' });
    assert.equal(await page.locator('#quotaUsed').textContent(), '—');
    assert.equal(await page.locator('#quotaProfileName').textContent(), 'Perfil 2');
    await page.unroute('**/api/profiles/2');
    await page.locator('#retryConnectionButton').click(); await quota(2, '172');
    // A leitura do painel e a troca de perfis não criam chamadas YouTube.
    assert.equal(store.profileQuotaEstimate(account.id, 1).requests, 92);
    assert.equal(store.profileQuotaEstimate(account.id, 2).requests, 20);
    assert.equal(store.profileQuotaEstimate(account.id, 3).requests, 0);
    const denied = await page.evaluate(async () => {
      const bootstrap = await (await fetch('/api/web/bootstrap')).json();
      return (await fetch('/api/account', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': bootstrap.csrfToken }, body: '{}' })).status;
    });
    assert.equal(denied, 403); assert.ok(store.getUser(account.id));
    await page.locator('[data-page-target="privacy"]').click();
    assert.equal(await page.locator('#deleteAccountButton, .danger-panel').count(), 0);
    assert.equal(await page.locator('#quotaCard').isVisible(), false);
    await page.locator('[data-page-target="activity"]').click();
    assert.equal(await page.locator('#quotaCard').isVisible(), false);
    await page.locator('[data-page-target="home"]').click();
    await page.locator('[data-profile="1"]').click(); await quota(1, '1.840');
    for (const width of [390, 320, 768]) {
      await page.setViewportSize({ width, height: 1000 });
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Rolagem horizontal em ${width}px`);
      assert.equal(await page.locator('#quotaCard').isVisible(), true);
      await page.locator('[data-profile="2"]').click(); await quota(2, '172');
      await page.locator('[data-profile="1"]').click(); await quota(1, '1.840');
      if (width === 390 && output) { await page.locator('#globalFeedback:empty').waitFor({ state: 'attached' }); await page.screenshot({ path: path.join(output, 'painel-inicio-celular.png'), fullPage: true, animations: 'disabled' }); }
    }
    // Controles existentes continuam utilizáveis após remover a zona de perigo.
    await page.setViewportSize({ width: 1440, height: 1100 });
    await page.locator('#renameProfileButton').click();
    await page.locator('#profileNameInput').fill('Perfil de teste');
    await page.locator('#profileNameForm button[type="submit"]').click();
    await page.locator('#quotaProfileName').filter({ hasText: 'Perfil 1 • Perfil de teste' }).waitFor();
    await page.reload(); await quota(1, '1.840');
    assert.deepEqual(errors, []); assert.deepEqual(external, []);
    process.stdout.write('Navegador: login, posição, valores, isolamento, trocas rápidas, falha/reconexão, privacidade, renomeação, recarga e telas 320/390/768/1440px aprovados.\n');
  } finally {
    await browser?.close();
    server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
    store.close(); fs.rmSync(directory, { recursive: true, force: true });
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
