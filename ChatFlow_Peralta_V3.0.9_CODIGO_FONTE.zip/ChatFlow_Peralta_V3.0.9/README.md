# ChatFlow Peralta V3.0.9

Servidor e painel web do ChatFlow Peralta. A automação continua na VPS mesmo com o
aplicativo, o painel ou o navegador fechados.

## Recuperação da V3.0.9

- Uma resposta perdida durante `liveChatMessages.insert` deixa o perfil e a
  live ativos. O servidor confirma novamente o ID do chat e repete a mesma
  mensagem após 5 segundos. Falhas consecutivas usam 10, 20, 40 e até 60
  segundos de espera; o prazo do Google (`Retry-After`) prevalece quando maior.
- A V3.0.8 mantinha essa live pausada por tempo indefinido. Ao atualizar, os
  registros presos especificamente nesse erro voltam à rotação se o perfil
  estava em execução. Pausas manuais continuam respeitadas.
- `HTTP 403/forbidden` fica isolado na live e no perfil afetados, com nova
  confirmação e tentativas após 15, 30, 60, 120 e até 300 segundos. As
  demais lives podem continuar. Erros de quota, autorização revogada, projeto
  Google desativado e texto inválido mantêm a proteção correspondente.
- Erros transitórios HTTP 5xx no envio também reconfirmam o chat e são
  tentados novamente, sem pausar o perfil.
- Falhas temporárias ao consultar o estado da live começam com 5 segundos de
  espera e usam backoff até 60 segundos. Um chat encerrado de fato nunca
  recebe nova mensagem. Quando a resposta do POST se perde, o Google pode
  ter aceitado o envio; por isso uma tentativa posterior pode duplicá-lo.
- Mudança só no servidor e no painel web, sem recompilar os apps Android.

## Correções da V3.0.8

- A descoberta considera as cinco transmissões mais recentes retornadas pela
  página `/streams`, na ordem da página. Até quatro IDs antigos ainda pendentes
  são revistos separadamente para encerrar registros que saíram dessa lista.
- Os IDs que precisam de confirmação são enviados juntos em `videos.list`.
  Cinco IDs cabem em uma chamada de 1 unidade de quota; IDs antigos pendentes
  também podem integrar o mesmo lote. Novas tentativas e chaves de reserva
  representam novas chamadas. A consulta não envia mensagens.
- A confirmação tem validade igual ao intervalo global, limitada entre 60 e
  300 segundos. Um estado antigo ou um envio bem-sucedido de ontem não comprova
  que o chat está aberto agora. Uma mudança pública pode antecipar a consulta.
- O worker confirma o chat antes de enviar. Usa o resultado global recente;
  quando necessário, verifica até cinco IDs em lote pelo OAuth do próprio
  perfil. Somente essa chamada OAuth entra na cota do perfil que a realizou.
  As chamadas administrativas continuam em seu contador separado.
- Uma transmissão encerrada ou sem chat confirmado sai dos destinos de envio.
  Falha de rede e bloqueio anti-bot mantêm o vídeo para nova verificação, sem
  declarar um falso encerramento nem liberar um chat com confirmação vencida.
- Uma recusa 403/forbidden no envio fica restrita àquela live e àquele perfil.
  Invalida a confirmação anterior e aguarda 10 minutos antes de tentar de novo
  naquele chat. Os demais destinos continuam. Erros reais de OAuth, de projeto
  e de quota mantêm seus tratamentos próprios; a referência visual de 10.000
  unidades continua sem interromper a execução.
- Logs incluem o status HTTP e o motivo técnico quando fornecidos pelo Google.
- No administrador, Visão geral > Busca única de lives, o botão LIMPAR CACHE E
  VERIFICAR descarta todos os IDs de chat salvos e solicita nova confirmação.
  Exige confirmação e afeta o cache compartilhado por todos os usuários.
  Contas, OAuth, mensagens, contadores, cota e histórico de envios permanecem.
  Registros encerrados continuam identificados no histórico, fora da rotação.
- Respostas de consultas iniciadas antes da limpeza são descartadas. Uma busca
  já em andamento termina antes da nova busca, sem ciclos simultâneos.
- O painel identifica `AutoServerWebAndroid/` no aplicativo WebView entregue
  anteriormente. Só nele deixa de somar novamente o inset já reservado pelo
  Android. Navegadores Android/iPhone preservam a área segura, e o computador
  conserva sua navegação. Não é necessário gerar novo APK.

O cartão mantido da V3.0.7 identifica o canal autorizado de cada perfil na aba Conta e canal:
foto à esquerda, no espaço de 48px com bordas arredondadas, título CONTA YOUTUBE
amarelo, Conectado · @canal em verde e Conta ativa com o mesmo e-mail. Sem
identificação aparece Não identificado em branco; sem autorização, Não conectado.
Se a API não devolver um @, usa o nome real retornado, sem inventar um handle.
Uma imagem indisponível conserva o ícone de play como alternativa.

A identificação usa channels.list com mine=true, pelo OAuth do próprio perfil.
Os metadados e a URL da foto ficam no banco SQLite por perfil. O cache é atualizado
uma vez por hora, inclusive com o painel fechado e o envio parado/pausado, enquanto
a conta do usuário e o perfil estiverem ativos, configurados e autorizados.
A primeira consulta ocorre na conexão Google; perfis já conectados são consultados
na inicialização da nova versão. O servidor verifica os prazos a cada minuto, com
no máximo três consultas de identificação simultâneas na varredura.

Cada tentativa de channels.list entra na estimativa com 1 unidade: normalmente
24 por 24 horas de funcionamento por perfil. Reconexões podem acrescentar
consultas; desligamentos e perfis desativados podem reduzir o consumo. Uma consulta
continua contando quando não há mudança. A abertura do painel e a troca de abas
usam o cache; imagens são carregadas do CDN do Google com cache do navegador.
Não é criada nenhuma busca extra com a API geral. Falhas aguardam o próximo prazo
de uma hora e preservam o último resultado, o e-mail e os controles de execução.
O cache é descartado ao trocar/desconectar OAuth e separado por usuário e perfil.

O campo do canal monitorado agora se chama Canal do YouTube para iniciar a automação.
Esse canal de destino continua separado do canal conectado à conta Google.

A barra mobile (até 920 pixels CSS) fica encostada ao rodapé, com a área segura
integrada ao fundo da barra. Os botões permanecem acima da área de gestos, sem os
8px extras de margem externa. O conteúdo mantém espaço para não ficar encoberto.
As cinco abas e seus ícones continuam na mesma ordem; Privacidade fica no menu
superior. No computador a navegação lateral é preservada. As alterações do cartão
da conta e do texto do canal aparecem tanto no celular quanto no computador.
O WebView carrega o painel do servidor; basta recarregá-lo após atualizar a VPS.
Não há novo APK. O app Android nativo e o código do WebView não foram alterados.

As versões padrão de retorno foram preservadas separadamente: servidor V3.0.5,
Android nativo V2.4.2 e WebView V1.0.2. Consulte VERSOES_PADRAO.txt.
A entrega do ZIP não instala a V3.0.9 na VPS automaticamente.

## Cota diária por perfil

- Apenas as chamadas YouTube Data API feitas com OAuth por este servidor para
  o perfil selecionado entram na estimativa; usuários e perfis ficam separados.
- `videos.list` e `channels.list`: 1 unidade por tentativa; `liveChatMessages.insert`: 20 unidades estimadas
  por tentativa. Mensagens enviadas contam apenas respostas de sucesso.
- O valor 20 é uma calibração baseada no caso informado pelo operador:
  92 envios e 1.840 unidades de uso diário no Google Cloud. Não representa
  uma confirmação de mudança do custo oficial para todos os projetos.
- A referência é 10.000 unidades por dia. O saldo exibido é uma estimativa do
  uso local, não uma consulta ao saldo oficial do Google Cloud. O limite real
  é do projeto Google, que pode compartilhar cota entre vários clientes OAuth.
- Tentativas com erro ou sem resposta usam o mesmo custo estimado do método como
  estimativa conservadora. Uma falha de rede pode ocorrer antes de o Google
  receber a chamada; erros podem ter cobrança diferente. Não há promessa de
  precisão exata nem limite de envios imposto por este novo quadro.
- A renovação do token OAuth, leitura do painel, troca de perfil, descoberta
  pública e chamadas com chaves administrativas ficam fora da estimativa.
- Consultas compartilhadas ou resultados em cache não são cobrados novamente
  no quadro: a chamada entra somente no perfil que realmente a iniciou.
- A tentativa é persistida no SQLite antes da requisição; a conclusão atualiza
  o dia de início mesmo se a resposta chegar depois da meia-noite do Pacífico.
  Uma interrupção pode deixar o resultado não confirmado, mas conserva a
  tentativa e não inventa uma mensagem enviada com sucesso.
- A virada diária segue `America/Los_Angeles`, incluindo horário de verão.
- Parar o perfil, limpar logs, reconectar Google ou alterar credenciais não
  apagam as chamadas feitas por esse perfil no mesmo dia. Se o projeto for
  trocado, a estimativa continua sendo o histórico diário do perfil.
- Usa o histórico diário que já existia no servidor. Não reconstrói consumo
  antigo ausente do banco, nem consumo de outros programas no mesmo projeto.
- Campos antigos da API continuam disponíveis; `runtime.quotaEstimateToday`
  e o equivalente em `/api/profiles/:profileId/status` são campos adicionais.
- A V3.0.5 mantinha o schema 6; versões seguintes fazem migrações aditivas.

A tabela pública consultada em 08/10/2026 informa 20 para insert, valor que
também coincide com a calibração observada. A divergência real deve ser
comparada no mesmo projeto/dia:

https://developers.google.com/youtube/v3/determine_quota_cost

## Privacidade e administração

O usuário pode desconectar o YouTube e consultar a política de privacidade.
A zona de perigo e a opção de autoexclusão foram removidas. A rota antiga
`DELETE /api/account` retorna 403 para sessões autenticadas sem remover dados,
parar perfis ou revogar tokens. A exclusão pelo administrador permanece.
Solicitações sobre dados e cadastro são encaminhadas ao operador do servidor.

## Endereços

- Painel do usuário: `/painel`
- Administração: `/dbmadmin`
- Saúde: `/health`
- Retorno OAuth: `/oauth/google/callback`

## Perfis, canais e execução

- Cada conta nova começa somente com o Perfil 1, que é permanente.
- O administrador pode adicionar perfis até o limite de 50 e excluir qualquer
  perfil a partir do número 2.
- A adição reutiliza sempre o primeiro número livre: 2, 3, 4 e assim por diante.
- Contas antigas preservam integralmente todos os perfis que já possuem; a
  atualização nunca exclui Perfil 2, 3 ou qualquer outro automaticamente.
- Cada perfil aceita exatamente um canal.
- O usuário pode renomear o perfil selecionado pelo painel web. O número
  interno, a execução, o OAuth, o canal e as configurações não são alterados.
- API Google, OAuth, mensagens, intervalo, canal, worker, contadores e logs são
  independentes por perfil.
- O mesmo canal e a mesma live são monitorados globalmente uma única vez e o
  resultado é compartilhado entre os perfis inscritos.
- INICIAR, PAUSAR e PARAR exigem confirmação no painel.
- Enviadas, tentativas, falhas e erros de conexão são contadores diários. Eles
  viram junto com o dia da cota da API do YouTube, à meia-noite do Pacífico
  (normalmente 04h ou 05h no horário de Brasília, conforme a época do ano).
- PARAR também zera antecipadamente esses contadores do perfil. Os contadores
  de uso diário real da API permanecem, pois registram consumo efetivo.
- PAUSAR preserva os contadores e a posição do ciclo.
- “Próximo envio” aparece somente quando existe uma live programada ou ao vivo
  com chat disponível. Sem chat elegível, o painel informa que está aguardando.

## Modos de envio

- `interval` mantém integralmente o funcionamento anterior e continua sendo o
  padrão de todos os perfis existentes e novos.
- `fixed` faz uma mensagem imediata ao iniciar um novo ciclo ou ao encontrar o
  primeiro chat desse ciclo. Depois usa os minutos 01, 05, 09, 11, 15, 19, 21,
  25, 29, 31, 35, 39, 41, 45, 49, 51, 55 e 59 em `America/Sao_Paulo`.
- Os perfis são distribuídos nos segundos ímpares de 01 a 29. O minuto inteiro
  continua válido se houver pequeno atraso ou falha temporária.
- Cada slot concluído fica persistido no perfil. Reinício, reconexão, retorno
  de pausa e timers repetidos não repetem o mesmo horário.
- PARAR e depois INICIAR cria um ciclo novo e permite outra mensagem imediata.
  PAUSAR e RETOMAR preserva o ciclo e não cria uma nova mensagem imediata.
- O agendamento usa o mesmo worker já existente; não existe segundo scheduler,
  consulta de horário por mensagem ou consumo de chave administrativa.

## Descoberta pública e live programada

- A página pública `/streams` continua sendo a fonte principal para encontrar
  IDs de lives. Não foi acrescentada busca de lives desconhecidas pela API.
- Lives `SCHEDULED` continuam aptas a enviar mensagens assim que o YouTube
  disponibiliza o chat; não é necessário aguardar o estado `LIVE`.
- Lives `LIVE` e `SCHEDULED` continuam sendo acompanhadas pela página pública.
- Lives `ENDED` ou finalizadas permanecem no histórico, mas são removidas para
  sempre da fila de reverificação e não consomem chave administrativa.
- `LOGIN_REQUIRED`, CAPTCHA, “confirme que você não é um bot”, timeout e falhas
  5xx não encerram uma live por conta própria.

## Confirmação administrativa em lote

- A chave administrativa usa `videos.list` somente para IDs já encontrados;
  não usa `search.list` nem pesquisa canais.
- A primeira chave disponível é usada. Falhas permitem tentar uma reserva,
  respeitando a indisponibilidade e a cota informadas pelo Google.
- A assinatura pública e o horário de confirmação ficam persistidos no banco.
  O resultado é compartilhado durante sua validade, inclusive após reinício.
- Resultados positivos expiram em 60 a 300 segundos, conforme o intervalo
  global. Isso substitui o reaproveitamento sem prazo das versões anteriores.
- Se as chaves falham, a nova tentativa usa 1, 2 e depois 5 minutos. Mudanças
  relevantes do estado público antecipam a confirmação.
- O encerramento confirmado retira o ID dos envios. Um chat ausente, recusado
  ou invalidado não é reutilizado por causa de um resultado antigo em cache.
- Chamadas simultâneas com o mesmo lote e geração de cache são unificadas.
- O botão TESTAR de uma chave faz uma chamada real e continua separado.

## Segurança das chaves

- O `/dbmadmin` permite adicionar, testar, habilitar, desabilitar, priorizar e
  excluir chaves.
- As chaves completas são criptografadas com `APP_ENCRYPTION_KEY` e nunca são
  devolvidas ao navegador.
- Consultas, sucessos, falhas, último uso, espera de cota e último erro aparecem
  no painel administrativo.
- Projetos Google Cloud diferentes são necessários para quotas realmente
  independentes.

## Painel administrativo moderno

- A administração usa tema azul-noturno responsivo, sem bibliotecas externas,
  fontes remotas ou imagens pesadas.
- As áreas foram separadas em Visão geral, Usuários e perfis, Criar usuário,
  Chaves de verificação, Atividade e Configurações.
- Respostas antigas de atualização são descartadas quando uma solicitação mais
  nova já foi iniciada.
- Ações em andamento ficam bloqueadas mesmo se a atualização automática
  reconstruir a lista de botões.
- Campos que o administrador está preenchendo não são sobrescritos pela
  atualização automática de 30 segundos.
- Bloquear usuários, desabilitar chaves, excluir dados e outras ações sensíveis
  usam uma confirmação administrativa padronizada.
- A confirmação administrativa mantém a navegação por teclado dentro da janela
  até confirmar ou cancelar e restaura o foco ao elemento anterior.
- Mensagens administrativas de sucesso desaparecem automaticamente; erros
  permanecem visíveis até uma nova ação ou atualização bem-sucedida.
- A pesquisa de usuários também encontra nomes dos perfis.
- O atalho “Abrir painel do usuário” abre uma nova guia e não interrompe a
  administração.
- O painel administrativo e o painel do usuário usam a mesma identidade visual
  do ChatFlow Peralta. Favicons mostram somente o robô, sem texto ilegível.

## Painel do usuário moderno e protegido

- O tema escuro preserva a identidade amarela do ChatFlow Peralta e não utiliza
  bibliotecas, fontes ou recursos externos.
- Início, Controle, Conta e canal, Mensagens e envio, Atividade e Privacidade
  ficam em áreas separadas. No celular, as cinco primeiras ficam no rodapé;
  Privacidade permanece no menu superior recolhível.
- A aba Controle concentra INICIAR, PAUSAR e PARAR, mostra o estado atual e o
  intervalo efetivo e explica o efeito de cada comando.
- A faixa de perfis permanece acima do conteúdo em todas as áreas. Um perfil
  ocupa a largura disponível; dois ou três se distribuem em colunas e, a partir
  do quarto, a grade usa quatro colunas com quebra automática. No celular, um
  perfil ocupa uma coluna e os demais usam até duas.
- Nome real, número e estado do perfil aparecem juntos para reduzir o risco de
  uma ação ser executada no perfil errado.
- INICIAR, PAUSAR, PARAR, desconectar Google, remover canal, limpar registros,
  sair e descartar rascunho usam confirmações próprias do painel.
- A exclusão da própria conta não é oferecida; a administração mantém o controle
  de exclusão. A desconexão do YouTube continua disponível.
- A janela de confirmação aceita cancelamento por Escape, mantém o foco dentro
  do diálogo e nunca coloca o foco inicial na ação perigosa.
- O painel informa a hora da última atualização e avisa quando os dados podem
  estar desatualizados por falha de comunicação.
- “Dados atualizados” aparece somente em atualização manual e desaparece após
  três segundos. Um erro de atualização é removido quando a comunicação volta.
- Se um perfil removível aberto for excluído pelo administrador, o painel
  seleciona automaticamente o primeiro perfil ainda disponível.
- A área de atividade exibe no máximo as três transmissões programadas ou ao
  vivo mais recentes. Uma transmissão programada para depois pode aparecer
  acima da transmissão que já está ao vivo.
- Tipos de registros, estados de live e erros técnicos conhecidos são exibidos
  em português, sem modificar o texto das mensagens configuradas pelo usuário.
- Rascunhos de mensagens e intervalo são preservados nesta guia após recarga,
  redirecionamento OAuth ou expiração de sessão. A troca confirmada de perfil,
  o descarte e o logout manual removem o rascunho correspondente.
- Respostas atrasadas de um perfil antigo são ignoradas, ações repetidas ficam
  bloqueadas durante o processamento e o resultado aparece junto da área usada.

## YouTube Data API dos perfis

- O OAuth e a quota de cada perfil continuam separados das chaves
  administrativas.
- O `activeLiveChatId` confirmado é armazenado globalmente e compartilhado com
  os perfis da live enquanto a confirmação estiver válida.
- Se o chat ainda não existe, o retry configurável do perfil continua gravado
  na própria live. Outras lives continuam funcionando.
- O padrão desse retry de disponibilidade do chat permanece em 120 segundos e
  pode ser configurado de 15 a 3600 segundos no painel administrativo.
- A busca global de novas lives permanece em 180 segundos por padrão e agora é
  editada diretamente em segundos, entre 60 e 3600. Valores já salvos são
  preservados: três minutos continuam armazenados e exibidos como 180 segundos.
- O access token é reutilizado até perto do vencimento.
- Os contadores representam solicitações reais, não uma estimativa fixa de
  unidades de quota.

## Lives simultâneas, intervalo e horários fixos

- Uma live usa o intervalo configurado no perfil.
- Duas lives alternam um envio total a cada 3 minutos.
- Três lives alternam um envio total a cada 2 minutos e 30 segundos.
- O menor intervalo configurável permanece 0 minuto e 1 segundo.
- A posição da lista de mensagens é preservada ao pausar, parar ou iniciar.
- Cada perfil aceita até 500 mensagens não vazias, com até 200 caracteres por
  mensagem. Se forem enviadas mais de 500, o servidor preserva as primeiras
  500, ignora somente as excedentes e informa o resultado ao painel.
- No modo fixo, cada slot escolhe a próxima live elegível pela rotação já
  existente. Lives programadas continuam aptas quando o chat está disponível.

## Isolamento e proteção

- Retry e backoff são individuais por live.
- Uma live sem chat, com 429 ou falha temporária não bloqueia as demais.
- Respostas ambíguas são registradas e geram nova verificação e tentativa
  automática para a live envolvida.
- Remover ou trocar o canal invalida imediatamente um alvo em andamento.
- OAuth inválido, API desativada e permissões insuficientes geram mensagens
  específicas sem expor segredos.
- Cookies HttpOnly/SameSite, CSRF, validação de origem, limite de login e
  criptografia AES-256-GCM permanecem ativos.

## Banco e compatibilidade

A V3.0.8 migrou o banco para schema SQLite 7, acrescentando o horário de
confirmação do chat e a revisão que protege contra respostas atrasadas. IDs
legados exigem nova confirmação. A cota usa a tabela diária existente,
sem apagar o histórico e sem uma migração destrutiva. As regras de
criação e exclusão de perfis da V3.0.3 permanecem. O modo fixo e seu último slot
continuam no documento persistido de cada perfil.
A V3.0.9 usa schema 8 para reativar os envios desconhecidos da V3.0.8.
Os campos administrativos acrescentados anteriormente continuam responsáveis
por:

1. guardar a assinatura do último estado administrativo;
2. distinguir sucesso de falha;
3. guardar o próximo retry após falha de todas as chaves;
4. guardar a sequência de falhas para o backoff de 1, 2 e 5 minutos.

Usuários, senhas, perfis, mensagens, canais, OAuth, chaves administrativas,
logs, contadores e estados de live existentes são preservados. O banco fica em
`data/peralta.sqlite`; preserve sempre a pasta `data/` junto com o `.env`, pois
`APP_ENCRYPTION_KEY` protege os segredos já gravados.

Use `ATUALIZAR_SEM_PERDER_DADOS.sh`. Ele cria um backup consistente, copia
`.env` e `data/`, inicia a V3.0.9, exige `/health` com schema 8, valida a sintaxe
no contêiner e religa automaticamente a versão anterior se houver falha.

Para manter o relógio da VPS correto, use Chrony ou o sincronizador do próprio
Linux. O ChatFlow Peralta não muda o relógio e não abre NTP dentro do contêiner.
Consulte `CONFIGURAR_HORARIO_VPS.txt`.

## Google OAuth

Cada perfil utiliza um OAuth Client do tipo **Web application**. Cadastre:

`https://SEU-DOMINIO/oauth/google/callback`

## Desenvolvimento

Requer Node.js 24.14 ou superior na linha 24:

```bash
npm ci
npm run check
npm test
npm start
```

Consulte `CHANGELOG.txt`, `VERIFICACAO_V3.0.9.txt`, `INSTALAR.txt` e
`ATUALIZAR_SEM_PERDER_DADOS.txt`.

Teste opcional de navegador: `node scripts/check-panel-browser.cjs`, com
Playwright e Chromium instalados no ambiente de desenvolvimento. Ele usa
apenas conta/banco temporários e HTTP local. Defina `PANEL_CHECK_OUTPUT` para
salvar capturas. Não é necessário instalar Playwright na VPS de produção.

Defina PANEL_BASELINE_DIR com a pasta V3.0.7 para comparar os pixels das cinco
abas de desktop sem mudanças solicitadas (Conta e canal é verificada à parte). PANEL_CHROMIUM_PATH permite usar um Chromium
local já instalado. São opções exclusivas da verificação de desenvolvimento.
