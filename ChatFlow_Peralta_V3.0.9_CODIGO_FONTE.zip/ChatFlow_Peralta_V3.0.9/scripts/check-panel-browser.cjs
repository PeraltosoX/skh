'use strict';
// Verificação opcional com Playwright/Chromium instalado no ambiente de testes.
// Não usa credenciais reais, Google ou servidor de produção.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const http = require('node:http');
const { chromium } = require('playwright');
const bcrypt = require('bcryptjs');

async function main() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-browser-'));
  process.env.DATA_DIR = directory;
  process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
  process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
  process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
  process.env.NODE_ENV = 'test';
  const server = http.createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const base = `http://127.0.0.1:${server.address().port}`;
  process.env.PUBLIC_BASE_URL = base;
    const store = require('../lib/store');
  const { createApp } = require('../server');
  server.on('request', createApp());
  let browser;
  try {
    const password = crypto.randomBytes(24).toString('hex');
    const account = store.createUser({ id: store.id('usr'), username: 'Teste do painel', passwordHash: await bcrypt.hash(password, 4), active: true, sessionVersion: 1 });
    store.addUserProfile(account.id); store.addUserProfile(account.id);
    for (const number of [1, 2, 3]) store.updateUserProfile(account.id, number, profile => {
      profile.oauth.refreshTokenEnc = 'autorizacao-de-teste-sem-uso-externo';
      profile.oauth.email = `conta${number}@example.invalid`;
      if (number < 3) profile.oauth.channel = {
        apiVersion: profile.api.version, id: `UCteste${number}`, title: `Canal ${number}`, handle: `@canal${number}`,
        thumbnailUrl: `https://yt3.ggpht.com/chatflow-test-${number}`, fetchedAt: new Date().toISOString()
      };
    });
    for (let i = 0; i < 92; i++) store.recordApiCall(account.id, 1, 'liveChatMessages.insert', true);
    for (let i = 0; i < 12; i++) store.recordApiCall(account.id, 2, 'videos.list', true);
    for (let i = 0; i < 8; i++) store.recordApiCall(account.id, 2, 'liveChatMessages.insert', true);
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'], ...(process.env.PANEL_CHROMIUM_PATH ? { executablePath: process.env.PANEL_CHROMIUM_PATH } : {}) });
    const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' });
    const errors = [], external = [];
    await context.route('**/*', async route => {
      const url = new URL(route.request().url());
      if (url.origin === 'https://yt3.ggpht.com' && url.pathname.startsWith('/chatflow-test-')) {
        if (url.pathname.endsWith('-2')) return route.fulfill({ status: 404, body: '' });
        return route.fulfill({ status: 200, contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88" viewBox="0 0 88 88"><rect width="88" height="88" fill="#2563eb"/><circle cx="44" cy="31" r="15" fill="#bfdbfe"/><path d="M14 85v-9a30 30 0 0 1 60 0v9" fill="#bfdbfe"/></svg>' });
      }
      if (new URL(route.request().url()).origin !== base) { external.push(route.request().url()); return route.abort(); }
      return route.continue();
    });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(`${base}/painel`);
    assert.equal(await page.locator('#mobileBottomNav').isVisible(), false);
    await page.locator('#loginUsername').fill(account.username);
    await page.locator('#loginPassword').fill(password);
    await page.locator('#privacyAccepted').check();
    await page.locator('#loginForm button[type="submit"]').click();
    async function quota(profile, units) {
      await page.locator('#quotaCard[aria-busy="false"]').waitFor({ state: 'attached' });
      await page.locator('#quotaProfileName').filter({ hasText: new RegExp(`^Perfil ${profile}(?:$| •)`) }).waitFor({ state: 'attached' });
      await page.locator('#quotaUsed').filter({ hasText: new RegExp(`^${units}$`) }).waitFor({ state: 'attached' });
      assert.equal(await page.locator('#quotaUsed').textContent(), units);
    }
    await quota(1, '1.840');
    assert.equal(await page.locator('#quotaRemaining').textContent(), '8.160');
    assert.equal(await page.locator('#quotaRequests').textContent(), '92');
    assert.equal(await page.locator('#quotaMessages').textContent(), '92');
    assert.equal(await page.locator('#quotaPercent').textContent(), '18,4%');
    assert.equal(await page.locator('#quotaQueryCost').textContent(), '1');
    assert.equal(await page.locator('#quotaSendCost').textContent(), '20');
    const position = await page.evaluate(() => ({
      profiles: document.querySelector('.profile-context').getBoundingClientRect().bottom,
      quotaTop: document.querySelector('#quotaCard').getBoundingClientRect().top,
      quotaBottom: document.querySelector('#quotaCard').getBoundingClientRect().bottom,
      welcome: document.querySelector('.welcome-card').getBoundingClientRect().top
    }));
    assert.ok(position.profiles <= position.quotaTop && position.quotaBottom <= position.welcome);
    const output = process.env.PANEL_CHECK_OUTPUT ? path.resolve(process.env.PANEL_CHECK_OUTPUT) : null;
    if (output) { await page.locator('#globalFeedback:empty').waitFor({ state: 'attached' }); fs.mkdirSync(output, { recursive: true }); await page.screenshot({ path: path.join(output, 'painel-inicio-desktop.png'), fullPage: true, animations: 'disabled' }); }
    // Compare os pixels com o painel padrão, usando a mesma conta e o mesmo
    // navegador. Só a versão no rodapé e o horário de atualização são ocultados.
    const baseline = process.env.PANEL_BASELINE_DIR;
    if (baseline) {
      const reference = await context.newPage();
      reference.on('pageerror', error => errors.push(error.message));
      await reference.route('**/*', async route => {
        const pathname = new URL(route.request().url()).pathname;
        const filename = { '/painel': 'panel.html', '/panel.css': 'panel.css', '/panel.js': 'panel.js' }[pathname];
        if (!filename) return route.fallback();
        const contentType = filename.endsWith('.css') ? 'text/css' : filename.endsWith('.js') ? 'application/javascript' : 'text/html';
        return route.fulfill({ status: 200, contentType, body: fs.readFileSync(path.join(baseline, 'public', filename)) });
      });
      await reference.goto(`${base}/painel`);
      await reference.locator('#quotaUsed').filter({ hasText: '1.840' }).waitFor();
      await page.locator('#globalFeedback:empty').waitFor({ state: 'attached' });
      for (const width of [1440, 1024, 921]) {
        await page.setViewportSize({ width, height: 1100 });
        await reference.setViewportSize({ width, height: 1100 });
        assert.equal(await page.locator('#mobileBottomNav').isVisible(), false);
        for (const area of ['home', 'control', 'messages', 'activity', 'privacy']) {
          await page.locator(`.sidebar-nav [data-page-target="${area}"]`).click();
          await reference.locator(`.sidebar-nav [data-page-target="${area}"]`).click();
          const shot = async target => {
            await target.mouse.move(width - 1, 1);
            return target.screenshot({ fullPage: true, animations: 'disabled', mask: [target.locator('#updatedAt'), target.locator('.sidebar-footer span')] });
          };
          const original = await shot(reference), current = await shot(page);
          // O Chromium pode variar um nível RGB no antialiasing de um círculo.
          // Compara os pixels decodificados, sem tolerância a mudança geométrica.
          const same = original.equals(current) || await page.evaluate(async ({ before, after }) => {
            const decoded = await Promise.all([before, after].map(bytes => createImageBitmap(new Blob([new Uint8Array(bytes)], { type: 'image/png' }))));
            if (decoded[0].width !== decoded[1].width || decoded[0].height !== decoded[1].height) return false;
            const canvas = document.createElement('canvas');
            canvas.width = decoded[0].width; canvas.height = decoded[0].height;
            const context = canvas.getContext('2d', { willReadFrequently: true });
            const pixels = decoded.map(bitmap => {
              context.clearRect(0, 0, canvas.width, canvas.height); context.drawImage(bitmap, 0, 0); bitmap.close();
              return context.getImageData(0, 0, canvas.width, canvas.height).data;
            });
            return pixels[0].every((value, index) => Math.abs(value - pixels[1][index]) <= 1);
          }, { before: [...original], after: [...current] });
          if (!same && output) {
            fs.writeFileSync(path.join(output, `desktop-padrao-${width}-${area}.png`), original);
            fs.writeFileSync(path.join(output, `desktop-novo-${width}-${area}.png`), current);
          }
          assert.ok(same, `Desktop alterado em ${width}px, aba ${area}`);
        }
      }
      await reference.close();
      await page.setViewportSize({ width: 1440, height: 1100 });
      await page.locator('.sidebar-nav [data-page-target="home"]').click();
      process.stdout.write('Desktop: cinco abas preservadas em 921/1024/1440px (máscaras de versão/horário e tolerância RGB de 1/255); Conta e canal tem as alterações solicitadas.\n');
    }
    await page.locator('[data-profile="2"]').click(); await quota(2, '172');
    await page.locator('[data-profile="3"]').click(); await quota(3, '0');
    assert.equal(await page.locator('#quotaRemaining').textContent(), '10.000');
    // A resposta do Perfil 2 chega somente depois que o Perfil 3 já foi exibido.
    let release, started, completed;
    const start = new Promise(resolve => { started = resolve; });
    const complete = new Promise(resolve => { completed = resolve; });
    await page.route('**/api/profiles/2', async route => {
      const response = await route.fetch(); started();
      await new Promise(resolve => { release = resolve; });
      await route.fulfill({ response }); completed();
    });
    await page.locator('[data-profile="2"]').click(); await start;
    assert.equal(await page.locator('#quotaUsed').textContent(), '—');
    assert.equal(await page.locator('#quotaProfileName').textContent(), 'Perfil 2');
    await page.locator('[data-profile="3"]').click(); await quota(3, '0');
    release(); await complete;
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    await quota(3, '0');
    assert.equal(await page.locator('#accountTitle').textContent(), 'Não identificado');
    assert.equal(await page.locator('#accountDetail').textContent(), 'Conta ativa: conta3@example.invalid');
    await page.unroute('**/api/profiles/2');
    // Falha na troca também não pode mostrar os números do perfil anterior.
    await page.route('**/api/profiles/2', route => route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ ok: false, error: 'Falha de teste' }) }));
    await page.locator('[data-profile="2"]').click();
    await page.locator('#connectionBanner').waitFor({ state: 'visible' });
    assert.equal(await page.locator('#quotaUsed').textContent(), '—');
    assert.equal(await page.locator('#quotaProfileName').textContent(), 'Perfil 2');
    await page.unroute('**/api/profiles/2');
    await page.locator('#retryConnectionButton').click(); await quota(2, '172');
    // A leitura do painel e a troca de perfis não criam chamadas YouTube.
    assert.equal(store.profileQuotaEstimate(account.id, 1).requests, 92);
    assert.equal(store.profileQuotaEstimate(account.id, 2).requests, 20);
    assert.equal(store.profileQuotaEstimate(account.id, 3).requests, 0);
    const denied = await page.evaluate(async () => {
      const bootstrap = await (await fetch('/api/web/bootstrap')).json();
      return (await fetch('/api/account', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': bootstrap.csrfToken }, body: '{}' })).status;
    });
    assert.equal(denied, 403); assert.ok(store.getUser(account.id));
    await page.locator('.sidebar-nav [data-page-target="privacy"]').click();
    assert.equal(await page.locator('#deleteAccountButton, .danger-panel').count(), 0);
    assert.equal(await page.locator('#quotaCard').isVisible(), false);
    await page.locator('.sidebar-nav [data-page-target="activity"]').click();
    assert.equal(await page.locator('#quotaCard').isVisible(), false);
    await page.locator('.sidebar-nav [data-page-target="home"]').click();
    await page.locator('[data-profile="1"]').click(); await quota(1, '1.840');
    await page.locator('.sidebar-nav [data-page-target="account"]').click();
    await page.locator('#accountPhoto').waitFor({ state: 'visible' });
    assert.equal(await page.locator('#accountTitle').textContent(), 'Conectado · @canal1');
    assert.equal(await page.locator('#accountTitle').evaluate(e => getComputedStyle(e).color), 'rgb(34, 197, 94)');
    assert.equal(await page.locator('.account-copy .eyebrow').evaluate(e => getComputedStyle(e).color), 'rgb(250, 204, 21)');
    assert.equal(await page.locator('#accountDetail').textContent(), 'Conta ativa: conta1@example.invalid');
    assert.equal(await page.locator('#accountPhoto').evaluate(e => getComputedStyle(e).objectFit), 'cover');
    assert.equal(await page.locator('.account-icon').evaluate(e => getComputedStyle(e).borderRadius), '14px');
    assert.equal(await page.locator('#accountIconFallback').isVisible(), false);
    assert.equal(await page.getByRole('heading', { name: 'Canal do YouTube para iniciar a automação', exact: true }).count(), 1);
    if (output) await page.screenshot({ path: path.join(output, 'painel-conta-desktop.png'), animations: 'disabled' });
    await page.locator('[data-profile="2"]').click(); await quota(2, '172');
    await page.waitForFunction(() => document.getElementById('accountPhoto').complete);
    assert.equal(await page.locator('#accountPhoto').isVisible(), false);
    assert.equal(await page.locator('#accountIconFallback').isVisible(), true);
    assert.equal(await page.locator('#accountTitle').textContent(), 'Conectado · @canal2');
    await page.locator('[data-profile="3"]').click(); await quota(3, '0');
    assert.equal(await page.locator('#accountTitle').textContent(), 'Não identificado');
    assert.equal(await page.locator('#accountTitle').evaluate(e => getComputedStyle(e).color), 'rgb(255, 255, 255)');
    assert.equal(await page.locator('#accountPhoto').getAttribute('src'), null);
    await page.locator('[data-profile="1"]').click(); await quota(1, '1.840');
    const mobileNav = page.locator('#mobileBottomNav');
    const mobilePages = ['home', 'control', 'account', 'messages', 'activity'];
    assert.deepEqual(await mobileNav.locator('[data-page-target]').evaluateAll(buttons => buttons.map(button => button.dataset.pageTarget)), mobilePages);
    for (const area of mobilePages) {
      assert.equal(await mobileNav.locator(`[data-page-target="${area}"] path`).getAttribute('d'), await page.locator(`.sidebar-nav [data-page-target="${area}"] path`).getAttribute('d'), `Ícone alterado: ${area}`);
    }
    for (const width of [390, 320, 360, 768, 920]) {
      await page.setViewportSize({ width, height: 844 });
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Rolagem horizontal em ${width}px`);
      assert.equal(await mobileNav.isVisible(), true);
      const bar = await mobileNav.boundingBox();
      assert.ok(bar.height <= 76 && bar.y + bar.height === 844, `Barra fora do rodapé ou com folga em ${width}px`);
      for (const area of mobilePages) {
        const button = mobileNav.locator(`[data-page-target="${area}"]`);
        const box = await button.boundingBox();
        assert.ok(box.height >= 44 && box.width >= 44, `Alvo de toque pequeno: ${area}, ${width}px`);
        await button.click();
        assert.equal(await page.locator(`[data-page="${area}"]`).isVisible(), true);
        assert.equal(await button.getAttribute('aria-current'), 'page');
        assert.equal(await mobileNav.locator('[aria-current="page"]').count(), 1);
        assert.equal(await page.evaluate(() => scrollY), 0);
        await page.evaluate(() => scrollTo(0, document.documentElement.scrollHeight));
        const after = await mobileNav.boundingBox();
        assert.equal(after.y, bar.y, `Barra moveu com a rolagem: ${area}`);
        assert.ok(await page.locator(`[data-page="${area}"]`).evaluate((element, navTop) => element.getBoundingClientRect().bottom <= navTop, after.y), `Conteúdo coberto pela barra: ${area}`);
      }
      await mobileNav.locator('[data-page-target="home"]').click();
      assert.equal(await page.locator('#quotaCard').isVisible(), true);
      await page.locator('[data-profile="2"]').click(); await quota(2, '172');
      await page.locator('[data-profile="1"]').click(); await quota(1, '1.840');
      if (width === 390 && output) { await page.locator('#globalFeedback:empty').waitFor({ state: 'attached' }); await page.screenshot({ path: path.join(output, 'painel-inicio-celular.png'), animations: 'disabled' }); }
    }
    await page.setViewportSize({ width: 390, height: 844 });
    await mobileNav.locator('[data-page-target="account"]').click();
    await page.evaluate(() => scrollTo(0, scrollY + document.querySelector('.account-card').getBoundingClientRect().top - 125));
    if (output) await page.screenshot({ path: path.join(output, 'painel-conta-celular.png'), animations: 'disabled' });
    // Emula a área de gestos; não substitui um teste em Safari/iPhone físico.
    const cdp = await context.newCDPSession(page);
    let stylesheetInsets = false;
    try {
      await cdp.send('Emulation.setSafeAreaInsetsOverride', { insets: { bottom: 34, left: 0, right: 0, top: 0 } });
    } catch (error) {
      if (!error.message.includes("wasn't found")) throw error;
      // Chromium antigo: simula apenas o valor de env() na resposta CSS do
      // teste local. Não altera o arquivo de produção nem valida o Safari.
      stylesheetInsets = true;
      await page.route('**/panel.css*', route => route.fulfill({ status: 200, contentType: 'text/css', body: fs.readFileSync(path.join(__dirname, '../public/panel.css'), 'utf8').replaceAll('env(safe-area-inset-bottom, 0px)', '34px') }));
      await page.reload();
      await mobileNav.waitFor({ state: 'visible' });
      await page.locator('#accountPhoto').waitFor({ state: 'visible' });
      await page.evaluate(() => scrollTo(0, scrollY + document.querySelector('.account-card').getBoundingClientRect().top - 125));
    }
    const safe = await mobileNav.boundingBox();
    const safeButton = await mobileNav.locator('button').first().boundingBox();
    assert.equal(Math.round(safe.y + safe.height), 844);
    assert.ok(safeButton.y + safeButton.height <= 844 - 34);
    assert.equal(await mobileNav.evaluate(e => getComputedStyle(e).paddingBottom), '39px');
    if (output) await page.screenshot({ path: path.join(output, 'painel-conta-area-segura.png'), animations: 'disabled' });
    if (stylesheetInsets) { await page.unroute('**/panel.css*'); await page.reload(); await mobileNav.waitFor({ state: 'visible' }); }
    else await cdp.send('Emulation.setSafeAreaInsetsOverride', { insets: { bottom: 0, left: 0, right: 0, top: 0 } });
    process.stdout.write(`Área segura de 34px: ${stylesheetInsets ? 'valor simulado na resposta CSS local (Chromium sem override de insets)' : 'emulação nativa pelo CDP'}.\n`);
    await cdp.detach();
    // A identificação do app deve afetar apenas o WebView com insets nativos.
    for (const [label, userAgent, expectedPadding] of [
      ['webview-android', 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/134.0 Mobile Safari/537.36 AutoServerWebAndroid/1.0.2', '5px'],
      ['android-navegador', 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/134.0 Mobile Safari/537.36', '39px'],
      ['iphone-navegador', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile Safari/604.1', '39px']
    ]) {
      const phoneContext = await browser.newContext({ viewport: { width: 390, height: 844 }, userAgent, storageState: await context.storageState() });
      await phoneContext.route('**/*', route => new URL(route.request().url()).origin === base ? route.continue() : route.abort());
      await phoneContext.route('**/panel.css*', route => route.fulfill({ status: 200, contentType: 'text/css', body: fs.readFileSync(path.join(__dirname, '../public/panel.css'), 'utf8').replaceAll('env(safe-area-inset-bottom, 0px)', '34px') }));
      const phone = await phoneContext.newPage();
      phone.on('pageerror', error => errors.push(error.message));
      await phone.goto(`${base}/painel`);
      const nav = phone.locator('#mobileBottomNav'); await nav.waitFor({ state: 'visible' });
      assert.equal(await nav.evaluate(element => getComputedStyle(element).paddingBottom), expectedPadding, label);
      assert.equal(await phone.locator('html').evaluate(element => element.classList.contains('android-insets-managed')), label === 'webview-android');
      const box = await nav.boundingBox(); assert.equal(Math.round(box.y + box.height), 844, label);
      if (label === 'webview-android') {
        await nav.locator('[data-page-target="control"]').click();
        if (output) await phone.screenshot({ path: path.join(output, 'painel-webview-android.png'), animations: 'disabled' });
        await phone.setViewportSize({ width: 1024, height: 900 });
        assert.equal(await nav.isVisible(), false);
        assert.equal(await phone.locator('.sidebar-nav [data-page-target]:visible').count(), 6);
      }
      await phoneContext.close();
    }
    process.stdout.write('WebView Android: inset duplicado removido somente no identificador do app; navegadores Android/iPhone preservam a área segura simulada.\n');

    await page.locator('#menuToggle').click();
    assert.equal(await page.locator('#menuToggle').getAttribute('aria-expanded'), 'true');
    assert.deepEqual(await page.locator('.sidebar-nav [data-page-target]:visible').evaluateAll(buttons => buttons.map(button => button.dataset.pageTarget)), ['privacy']);
    await page.locator('.sidebar-nav [data-page-target="privacy"]').click();
    assert.equal(await page.locator('[data-page="privacy"]').isVisible(), true);
    assert.equal(await mobileNav.locator('[aria-current="page"]').count(), 0);
    assert.equal(await page.locator('#navBackdrop').isVisible(), false);
    await mobileNav.locator('[data-page-target="messages"]').click();
    const savedMessages = await page.locator('#messages').inputValue();
    await page.locator('#messages').fill('Rascunho preservado ao navegar pelo rodapé.');
    await page.setViewportSize({ width: 390, height: 450 });
    assert.equal(await mobileNav.isVisible(), true);
    await mobileNav.locator('[data-page-target="activity"]').click();
    await mobileNav.locator('[data-page-target="messages"]').click();
    assert.equal(await page.locator('#messages').inputValue(), 'Rascunho preservado ao navegar pelo rodapé.');
    await page.locator('#messages').fill(savedMessages);
    await page.setViewportSize({ width: 390, height: 844 });
    await mobileNav.locator('[data-page-target="control"]').click();
    if (output) await page.screenshot({ path: path.join(output, 'painel-controle-celular.png'), animations: 'disabled' });
    await page.reload();
    await mobileNav.locator('[data-page-target="control"][aria-current="page"]').waitFor();
    assert.equal(await page.locator('[data-page="control"]').isVisible(), true);
    await page.locator('#renameProfileButton').click();
    await page.locator('#profileNameDialog[open]').waitFor();
    assert.equal(await mobileNav.evaluate(nav => {
      const rect = nav.getBoundingClientRect();
      return nav.contains(document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2));
    }), false, 'A barra não pode ficar acima de uma confirmação');
    await page.locator('#cancelProfileNameButton').click();
    await page.locator('#menuToggle').click();
    await page.setViewportSize({ width: 1440, height: 1100 });
    await page.waitForFunction(() => document.getElementById('menuToggle').getAttribute('aria-expanded') === 'false');
    assert.equal(await page.locator('#menuToggle').getAttribute('aria-expanded'), 'false');
    assert.equal(await page.locator('#navBackdrop').isVisible(), false);
    assert.equal(await mobileNav.isVisible(), false);
    assert.equal(await page.locator('.sidebar-nav [data-page-target]:visible').count(), 6);
    await page.locator('.sidebar-nav [data-page-target="home"]').click();
    // Controles existentes continuam utilizáveis após remover a zona de perigo.
    await page.setViewportSize({ width: 1440, height: 1100 });
    await page.locator('#renameProfileButton').click();
    await page.locator('#profileNameInput').fill('Perfil de teste');
    await page.locator('#profileNameForm button[type="submit"]').click();
    await page.locator('#quotaProfileName').filter({ hasText: 'Perfil 1 • Perfil de teste' }).waitFor();
    await page.reload(); await quota(1, '1.840');
    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator('#logoutButton').click();
    await page.locator('#confirmAccept').click();
    await page.locator('#loginPanel').waitFor({ state: 'visible' });
    assert.equal(await mobileNav.isVisible(), false);
    // Fluxo administrativo real: cancelar não altera nada; confirmar limpa e agenda nova busca.
    const setup = await context.request.post(`${base}/dbmadmin/api/setup`, { data: { setupToken: process.env.SETUP_TOKEN, username: 'Admin de teste', password } });
    assert.equal(setup.status(), 200);
    const admin = await context.newPage(); admin.on('pageerror', error => errors.push(error.message));
    await admin.goto(`${base}/dbmadmin`);
    await admin.locator('#clearLiveCache').waitFor({ state: 'visible' });
    const generation = store.liveCacheGeneration();
    await admin.locator('#clearLiveCache').click(); await admin.locator('#confirmCancel').click();
    assert.equal(store.liveCacheGeneration(), generation);
    await admin.locator('#clearLiveCache').click();
    const clearedResponse = admin.waitForResponse(response => response.url().endsWith('/global-monitor/clear-cache'));
    await admin.locator('#confirmAccept').click(); assert.equal((await clearedResponse).status(), 202);
    await admin.locator('#monitorFb').filter({ hasText: 'Cache limpo' }).waitFor();
    assert.equal(store.liveCacheGeneration(), generation + 1);
    assert.equal(store.profileQuotaEstimate(account.id, 1).requests, 92);
    for (const width of [360, 1440]) {
      await admin.setViewportSize({ width, height: 1000 });
      assert.equal(await admin.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1), false);
    }
    if (output) await admin.screenshot({ path: path.join(output, 'admin-limpar-cache.png'), animations: 'disabled' });
    await admin.close();
    process.stdout.write('Administrador: botão limpar cache, cancelamento, confirmação, resposta 202, preservação da cota e layout em 360/1440px aprovados.\n');
    assert.deepEqual(errors, []); assert.deepEqual(external, []);
    process.stdout.write('Navegador: cinco abas mobile, ícones originais, rodapé fixo, conteúdo acessível, privacidade no menu, rascunho, recarga, diálogo, login/saída e transição desktop aprovados em 320/360/390/768/920px.\n');
    process.stdout.write('Cota: posição, valores, isolamento, trocas rápidas, falha/reconexão e preservação das contagens aprovados.\n');
    process.stdout.write('Conta: foto arredondada, verde/branco, título amarelo, e-mail preservado, fallback de imagem e área segura de 34px aprovados.\n');
  } finally {
    await browser?.close();
    server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
    store.close(); fs.rmSync(directory, { recursive: true, force: true });
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
