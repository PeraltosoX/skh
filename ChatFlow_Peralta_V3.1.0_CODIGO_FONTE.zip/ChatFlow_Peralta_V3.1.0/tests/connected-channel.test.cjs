'use strict';
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-channel-'));
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
const store = require('../lib/store');
const youtube = require('../lib/youtube');
const { encryptText } = require('../lib/security');
const { createConnectedChannelCache, publicConnectedChannel, channelInfo, resolveDisplayedHandle, REFRESH_MS } = require('../lib/connected-channel');
let serial = 0;
const start = Date.parse('2026-10-05T07:00:00Z');
function account(count = 1) {
  const user = store.createUser({ id: store.id('usr'), username: `Canal ${++serial}`, active: true, sessionVersion: 1 });
  for (let i = 1; i < count; i++) store.addUserProfile(user.id);
  for (let n = 1; n <= count; n++) store.updateUserProfile(user.id, n, profile => {
    profile.api = { clientId: `test-${n}.apps.googleusercontent.com`, clientSecretEnc: encryptText('secret-test'), version: 2 };
    profile.oauth = { version: 3, email: `conta${n}@example.invalid`, refreshTokenEnc: encryptText('refresh-test'), accessTokenEnc: encryptText(`access-${n}`), accessTokenExpiresAt: Date.now() + 600000 };
    profile.config.messages = 'Mensagem preservada';
    profile.runtime.status = 'running';
  });
  return user;
}
const item = (suffix = '1') => ({ id: `UC${suffix.padStart(22, '0')}`, snippet: { title: `Canal ${suffix}`, customUrl: `@canal${suffix}`, thumbnails: { default: { url: `https://yt3.ggpht.com/avatar-${suffix}` } } } });
const readyApi = (onCall = () => {}) => ({ getConnectedChannel: async (profile, _api, options) => { options.onApiRequest(); onCall(profile); return item(String(profile.profileNumber)); } });
after(() => { store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); });

test('channels.list usa mine=true, OAuth do perfil e uma única consulta para nome/foto', async () => {
  const user = account(), profile = store.getUserProfile(user.id, 1);
  const original = global.fetch;
  let calls = 0, accounted = 0;
  global.fetch = async (input, options) => {
    calls++;
    const url = new URL(input);
    assert.equal(url.pathname, '/youtube/v3/channels');
    assert.equal(url.searchParams.get('mine'), 'true');
    assert.equal(url.searchParams.get('part'), 'snippet');
    assert.equal(url.searchParams.has('key'), false);
    assert.equal(url.searchParams.has('id'), false);
    assert.equal(options.headers.Authorization, 'Bearer access-1');
    return new Response(JSON.stringify({ items: [item()] }));
  };
  try { assert.deepEqual(await youtube.getConnectedChannel(profile, profile.api, { onApiRequest: () => accounted++ }), item()); }
  finally { global.fetch = original; }
  assert.equal(calls, 1); assert.equal(accounted, 1);
});

test('grafia pública do @ é aceita somente quando o ID do canal confere', async () => {
  const channel = item();
  const html = id => `<meta itemprop="channelId" content="${id}"><link rel="canonical" href="https://www.youtube.com/@CanalMaIusCuLo">`;
  const handle = await resolveDisplayedHandle(channel, { fetchImpl: async () => new Response(html(channel.id)) });
  assert.equal(handle, '@CanalMaIusCuLo');
  const wrong = await resolveDisplayedHandle(channel, { fetchImpl: async () => new Response(html('UC9999999999999999999999')) });
  assert.equal(wrong, '');
});

test('cache horário preserva grafia confirmada mesmo quando API normaliza o @', async () => {
  const user = account(); let at = start, calls = 0;
  const service = createConnectedChannelCache({ clock: () => at, api: readyApi(() => calls++), resolveHandle: async () => '@Canal1' });
  await service.refresh(user.id, 1);
  assert.equal(publicConnectedChannel(store.getUserProfile(user.id, 1)).handle, '@Canal1');
  at += REFRESH_MS - 1;
  await service.refresh(user.id, 1);
  assert.equal(calls, 1);
  at++;
  await service.refresh(user.id, 1);
  assert.equal(calls, 2);
  assert.equal(publicConnectedChannel(store.getUserProfile(user.id, 1)).handle, '@Canal1');
  await service.shutdown();
});

test('concorrência e cache persistido não geram consultas extras antes de uma hora', async () => {
  const user = account(); let at = start, calls = 0;
  const api = readyApi(() => calls++);
  const service = createConnectedChannelCache({ clock: () => at, api });
  await Promise.all(Array.from({ length: 20 }, () => service.refresh(user.id, 1)));
  assert.equal(calls, 1);
  at += REFRESH_MS - 1;
  await service.refresh(user.id, 1);
  const restarted = createConnectedChannelCache({ clock: () => at, api });
  await restarted.refresh(user.id, 1);
  assert.equal(calls, 1);
  const code = `const s=require('./lib/store'); console.log(JSON.stringify(s.getUserProfile(${JSON.stringify(user.id)},1).oauth.channel)); s.close();`;
  const child = spawnSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: process.env, encoding: 'utf8' });
  assert.equal(child.status, 0, child.stderr);
  assert.equal(JSON.parse(child.stdout).handle, '@canal1');
  assert.equal(JSON.parse(child.stdout).nextRefreshAt, start + REFRESH_MS);
  at++;
  await restarted.refresh(user.id, 1);
  assert.equal(calls, 2);
  assert.equal(store.profileQuotaEstimate(user.id, 1, at).unitsUsed, 2);
  assert.equal(store.profileQuotaEstimate(user.id, 1, at).unconfirmedRequests, 0);
  await service.shutdown(); await restarted.shutdown();
});

test('24 horas de rotina produzem 24 consultas por perfil, mesmo com várias leituras', async () => {
  const user = account(2); let at = start, calls = 0;
  const service = createConnectedChannelCache({ clock: () => at, api: readyApi(() => calls++) });
  for (let hour = 0; hour < 24; hour++) {
    at = start + hour * REFRESH_MS;
    await Promise.all([service.refresh(user.id, 1), service.refresh(user.id, 2)]);
    for (let n = 0; n < 4; n++) await service.refresh(user.id, 1);
  }
  assert.equal(calls, 48);
  for (const n of [1, 2]) {
    const q = store.profileQuotaEstimate(user.id, n, at);
    assert.equal(q.unitsUsed, 24); assert.equal(q.channelQueries, 24);
    assert.equal(q.messagesSent, 0); assert.equal(q.failures, 0);
    assert.equal(store.apiUsage(user.id, n, at).liveChatInsert.attempts, 0);
    assert.equal(publicConnectedChannel(store.getUserProfile(user.id, n)).handle, `@canal${n}`);
  }
  await service.shutdown();
});

test('falha HTTP conta uma unidade, conserva dados anteriores e não altera envios/e-mail', async () => {
  const user = account(); let at = start;
  const service = createConnectedChannelCache({ clock: () => at, api: {
    getConnectedChannel: async (_p, _a, options) => { options.onApiRequest(); if (at > start) throw new Error('Falha simulada'); return item(); }
  } });
  await service.refresh(user.id, 1); at += REFRESH_MS;
  const before = store.getUserProfile(user.id, 1);
  await service.refresh(user.id, 1); await service.refresh(user.id, 1);
  const after = store.getUserProfile(user.id, 1);
  assert.equal(publicConnectedChannel(after).handle, '@canal1');
  assert.equal(after.oauth.email, before.oauth.email);
  assert.deepEqual(after.runtime, before.runtime);
  assert.deepEqual(after.config, before.config);
  const q = store.profileQuotaEstimate(user.id, 1, at);
  assert.equal(q.unitsUsed, 2); assert.equal(q.failures, 1);
  await service.shutdown();
});

test('falha de OAuth antes da consulta não conta Data API e espera uma hora', async () => {
  const user = account(); let calls = 0;
  const service = createConnectedChannelCache({ clock: () => start, api: { getConnectedChannel: async () => { calls++; throw new Error('OAuth indisponível'); } } });
  await service.refresh(user.id, 1); await service.refresh(user.id, 1);
  assert.equal(calls, 1); assert.equal(store.profileQuotaEstimate(user.id, 1, start).unitsUsed, 0);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  await service.shutdown();
});

test('conectar outra conta durante a consulta descarta foto antiga sem bloquear a nova', async () => {
  const user = account(); let release;
  const service = createConnectedChannelCache({ clock: () => start, api: { getConnectedChannel: async (profile, _api, options) => {
    options.onApiRequest();
    if (profile.oauth.version === 3) { await new Promise(resolve => { release = resolve; }); return item('antigo'); }
    return item('novo');
  } } });
  const previous = service.refresh(user.id, 1);
  store.updateUserProfile(user.id, 1, p => { p.oauth.version++; p.oauth.channel = undefined; p.oauth.email = 'nova@example.invalid'; });
  await service.refresh(user.id, 1);
  release(); await previous;
  const current = store.getUserProfile(user.id, 1);
  assert.equal(publicConnectedChannel(current).handle, '@canalnovo');
  assert.equal(current.oauth.email, 'nova@example.invalid');
  assert.equal(store.profileQuotaEstimate(user.id, 1, start).unitsUsed, 2);
  await service.shutdown();
});

test('desconectar ou excluir/recriar um perfil impede gravar a resposta antiga', async () => {
  for (const deleted of [false, true]) {
    const user = account(2); let release;
    const service = createConnectedChannelCache({ clock: () => start, api: { getConnectedChannel: async (_p, _a, options) => {
      options.onApiRequest(); await new Promise(resolve => { release = resolve; }); return item();
    } } });
    const pending = service.refresh(user.id, 2);
    if (deleted) { store.deleteUserProfile(user.id, 2); store.addUserProfile(user.id); }
    else store.updateUserProfile(user.id, 2, p => { p.oauth = { version: p.oauth.version + 1 }; });
    release(); await pending;
    assert.equal(publicConnectedChannel(store.getUserProfile(user.id, 2)), null);
    assert.equal(store.profileQuotaEstimate(user.id, 1, start).unitsUsed, 0);
    await service.shutdown();
  }
});

test('mudança de credenciais durante renovação bloqueia a chamada antes de gastar cota', async () => {
  const user = account();
  const service = createConnectedChannelCache({ clock: () => start, api: { getConnectedChannel: async (_p, _a, options) => {
    store.updateUserProfile(user.id, 1, p => { p.api.version++; });
    options.onApiRequest(); assert.fail('Não deve chegar à API com credenciais antigas');
  } } });
  await service.refresh(user.id, 1);
  assert.equal(store.profileQuotaEstimate(user.id, 1, start).unitsUsed, 0);
  assert.equal(publicConnectedChannel(store.getUserProfile(user.id, 1)), null);
  await service.shutdown();
});

test('conta sem canal e falha na foto mantêm fallback, sem inventar arroba ou URL insegura', async () => {
  assert.equal(channelInfo({ id: 'UC1', snippet: { customUrl: 'apelido-antigo', title: 'Nome real' } }).handle, '');
  for (const url of ['javascript:alert(1)', 'http://yt3.ggpht.com/a', 'https://yt3.ggpht.com.evil.invalid/a', 'https://user:pass@yt3.ggpht.com/a', 'https://127.0.0.1/a']) {
    assert.equal(channelInfo({ id: 'UC1', snippet: { thumbnails: { default: { url } } } }).thumbnailUrl, '');
  }
  const user = account(); let calls = 0;
  const service = createConnectedChannelCache({ clock: () => start, api: { getConnectedChannel: async (_p, _a, options) => { options.onApiRequest(); calls++; return null; } } });
  await service.refresh(user.id, 1); await service.refresh(user.id, 1);
  const profile = store.getUserProfile(user.id, 1);
  assert.equal(publicConnectedChannel(profile).id, '');
  assert.equal(profile.oauth.email, 'conta1@example.invalid');
  assert.equal(calls, 1);
  await service.shutdown();
});

test('varredura só consulta perfis autorizados e ativos, com no máximo três chamadas simultâneas', async () => {
  // Os demais usuários criados nos testes já têm cache no mesmo instante.
  for (const previous of store.users()) store.updateUser(previous.id, u => { u.active = false; });
  const user = account(5); let count = 0, current = 0, peak = 0;
  store.updateUserProfile(user.id, 4, p => { p.enabled = false; });
  store.updateUserProfile(user.id, 5, p => { p.oauth.refreshTokenEnc = ''; });
  const service = createConnectedChannelCache({ clock: () => start, api: { getConnectedChannel: async (p, _a, options) => {
    options.onApiRequest(); count++; current++; peak = Math.max(peak, current);
    await new Promise(resolve => setImmediate(resolve)); current--; return item(String(p.profileNumber));
  } } });
  await Promise.all([service.sweep(), service.sweep()]);
  assert.equal(count, 3); assert.ok(peak <= 3);
  await service.shutdown();
  await service.refresh(user.id, 1); assert.equal(count, 3);
});

test('callback identifica na conexão; falha da identificação não faz o login falhar', async () => {
  const { createApp } = require('../server');
  const server = createApp().listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const original = global.fetch;
  try {
    for (const failPhoto of [false, true]) {
      const user = account(), profile = store.getUserProfile(user.id, 1);
      const state = `w.${crypto.randomUUID()}`;
      store.saveOAuthAttempt(state, user, profile);
      global.fetch = async (input, options) => {
        const url = new URL(input);
        if (url.hostname === '127.0.0.1') return original(input, options);
        if (url.hostname === 'oauth2.googleapis.com') return new Response(JSON.stringify({ access_token: 'new-access', refresh_token: 'new-refresh', scope: youtube.YOUTUBE_SCOPE, expires_in: 3600 }));
        if (url.hostname === 'openidconnect.googleapis.com') return new Response(JSON.stringify({ email: 'conta1@example.invalid', email_verified: true }));
        assert.equal(url.pathname, '/youtube/v3/channels');
        return new Response(JSON.stringify(failPhoto ? { error: { message: 'Falha simulada' } } : { items: [item()] }), { status: failPhoto ? 503 : 200 });
      };
      const response = await fetch(`http://127.0.0.1:${server.address().port}/oauth/google/callback?state=${state}&code=teste`);
      assert.equal(response.status, 200);
      const updated = store.getUserProfile(user.id, 1);
      assert.equal(updated.oauth.email, 'conta1@example.invalid');
      assert.equal(publicConnectedChannel(updated).handle, failPhoto ? '' : '@canal1');
      assert.equal(store.apiUsage(user.id, 1).channelsList.attempts, 1);
    }
  } finally {
    global.fetch = original;
    server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
  }
});
