'use strict';
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-live-verification-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';
const store = require('../lib/store');
const security = require('../lib/security');
const youtube = require('../lib/youtube');
const discovery = require('../lib/youtube-discovery');
const { candidateFromVideo } = require('../lib/live-state');
const { createAdminLiveVerifier } = require('../lib/admin-live-verifier');
const { createGlobalMonitor } = require('../lib/global-monitor');
const { createWorkers } = require('../lib/workers');
const { createApp } = require('../server');
let sequence = 0;
function video(videoId, ended = false) {
  return { id: videoId, snippet: { title: videoId, liveBroadcastContent: ended ? 'none' : 'live' }, liveStreamingDetails: {
    actualStartTime: '2026-10-05T12:00:00Z', ...(ended ? { actualEndTime: '2026-10-05T13:00:00Z' } : { activeLiveChatId: `CHAT-${videoId}` })
  } };
}
function fixture(t, count = 2) {
  const serial = ++sequence;
  const user = store.createUser({ id: store.id('usr'), username: `Verificação ${serial}`, active: true, sessionVersion: 1 });
  store.updateUserProfile(user.id, 1, profile => {
    profile.api = { clientId: `client-${serial}`, clientSecretEnc: security.encryptText('test-secret'), version: 1 };
    profile.oauth.refreshTokenEnc = security.encryptText('test-refresh');
    profile.oauth.accessTokenEnc = security.encryptText('test-access');
    profile.oauth.accessTokenExpiresAt = Date.now() + 3600000;
    profile.oauth.email = `test-${serial}@example.invalid`;
    profile.config.messages = 'Mensagem de teste'; profile.runtime.status = 'running';
  });
  const channel = store.upsertGlobalChannel({ channelId: `UC${String(serial).padStart(22, '0')}`, handle: `@Verificacao${serial}`, canonicalUrl: `https://www.youtube.com/@Verificacao${serial}` });
  const subscription = store.subscribeChannel(user.id, 1, channel, channel.handle);
  const lives = Array.from({ length: count }, (_, i) => {
    const videoId = `V${String(serial * 10 + i).padStart(10, '0')}`;
    const live = store.upsertGlobalLive(channel.id, { videoId, title: videoId, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', activeLiveChatId: `STALE-${videoId}`, resolved: true }).live;
    store.distributeLive(live.id);
    return live;
  });
  t.after(() => { store.removeSubscription(user.id, 1, subscription.id); store.deleteUser(user.id); });
  return { user, channel, lives };
}
function batchApi({ onLookup = () => {}, onSend = () => {}, result = ids => ids.map(id => candidateFromVideo(video(id), id)) } = {}) {
  return {
    getLiveStates: async (_profile, _api, ids, options) => { options.onApiRequest(); onLookup(ids); return result(ids); },
    getActiveLiveChatId: async () => { throw new Error('Não deveria fazer consulta individual após o lote.'); },
    sendLiveChatMessage: async (_profile, _api, chatId, message, options) => { options.beforeSend(); options.onApiRequest(); return onSend(chatId, message); }
  };
}

test('limpeza global exige administrador, CSRF e confirmação; aceita uma limpeza autorizada', async () => {
  const server = createApp().listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const route = '/dbmadmin/api/global-monitor/clear-cache';
  const post = (url, body, headers = {}) => fetch(base + url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });
  try {
    assert.equal((await post(route, { confirm: true })).status, 401);
    const setup = await post('/dbmadmin/api/setup', { setupToken: process.env.SETUP_TOKEN, username: 'Administrador', password: 'test-password-only' });
    assert.equal(setup.status, 200);
    const cookie = setup.headers.get('set-cookie').split(';')[0];
    const bootstrap = await (await fetch(base + '/dbmadmin/api/bootstrap', { headers: { Cookie: cookie } })).json();
    assert.equal((await post(route, { confirm: true }, { Cookie: cookie })).status, 403);
    const headers = { Cookie: cookie, 'X-CSRF-Token': bootstrap.csrfToken };
    assert.equal((await post(route, {}, headers)).status, 400);
    const result = await post(route, { confirm: true }, headers);
    assert.equal(result.status, 202);
    assert.equal((await result.json()).cleared, 0);
    await new Promise(resolve => setImmediate(resolve));
  } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
});

test('cinco IDs usam uma chamada administrativa; ordem da resposta não mistura vídeos e ausência não vira chat ativo', async () => {
  const ids = Array.from({ length: 5 }, (_, i) => `A${String(i).padStart(10, '0')}`);
  let calls = 0, counted = 0;
  const verifier = createAdminLiveVerifier({
    storage: { adminVerificationKeys: () => [{ id: 'key', enabled: true, status: 'ACTIVE', api_key_enc: 'test-key' }], recordAdminVerificationCall: (_id, ok) => { assert.equal(ok, true); counted++; }, markAdminVerificationKey: () => {} },
    vault: { decryptText: value => value },
    fetchImpl: async url => {
      calls++; assert.deepEqual(new URL(url).searchParams.get('id').split(','), ids);
      return { ok: true, status: 200, json: async () => ({ items: [video(ids[3]), video(ids[1], true), video(ids[0]), video(ids[2])] }) };
    }
  });
  const [one, two] = await Promise.all([verifier.verifyKnownLives(ids), verifier.verifyKnownLives([...ids].reverse())]);
  assert.equal(one, two); assert.equal(calls, 1); assert.equal(counted, 1);
  assert.equal(one.candidates[1].chatStatus, 'ENDED');
  assert.equal(one.candidates[3].activeLiveChatId, `CHAT-${ids[3]}`);
  assert.equal(one.candidates[4].unavailable, true);
  assert.equal((await verifier.verifyKnownLives(['bad-id'])).ok, false);
  assert.equal(calls, 1);
});

test('OAuth consulta cinco IDs em uma requisição e usa somente as credenciais daquele perfil', async t => {
  const { user, lives } = fixture(t, 5);
  const previous = global.fetch;
  let calls = 0, tracked = 0;
  global.fetch = async (url, options) => {
    calls++; const parsed = new URL(url);
    assert.equal(parsed.pathname, '/youtube/v3/videos'); assert.equal(parsed.searchParams.has('key'), false);
    assert.equal(options.headers.Authorization, 'Bearer test-access');
    assert.equal(parsed.searchParams.get('id').split(',').length, 5);
    return new Response(JSON.stringify({ items: [...lives].reverse().map(live => video(live.video_id)) }), { status: 200 });
  };
  try {
    const profile = store.getUserProfile(user.id, 1);
    const states = await youtube.getLiveStates(profile, profile.api, lives.map(live => live.video_id), { onApiRequest: () => tracked++ });
    assert.equal(calls, 1); assert.equal(tracked, 1);
    assert.deepEqual(states.map(state => state.videoId), lives.map(live => live.video_id));
  } finally { global.fetch = previous; }
});

test('timeout real de POST sem resposta é classificado como envio de resultado desconhecido', async t => {
  const { user } = fixture(t, 0);
  const previous = global.fetch;
  let attempted = 0;
  global.fetch = async () => { throw new DOMException('The operation was aborted', 'AbortError'); };
  try {
    const profile = store.getUserProfile(user.id, 1);
    await assert.rejects(() => youtube.sendLiveChatMessage(profile, profile.api, 'CHAT-ATIVO', 'Texto', {
      beforeSend: () => {}, onApiRequest: () => { attempted++; }
    }), error => error.ambiguousWrite === true && error.networkFailure === true);
    assert.equal(attempted, 1);
  } finally { global.fetch = previous; }
});

test('dupla verificação confirma cinco IDs, remove a encerrada e não cobra a API administrativa do perfil', async t => {
  const { user, channel, lives } = fixture(t, 5);
  let at = Date.now(), batches = 0;
  const monitor = createGlobalMonitor({ clock: () => at, discover: async () => ({ lives: lives.map(live => ({ videoId: live.video_id, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true })) }), verifyKnownLives: async ids => {
    batches++; assert.equal(ids.length, 5);
    return { ok: true, configured: true, attempted: 1, candidates: ids.map(id => candidateFromVideo(video(id, id === lives[0].video_id), id)) };
  } });
  const first = await monitor.scan(); assert.equal(first.ok, true); assert.equal(batches, 1);
  assert.equal(store.getGlobalLive(lives[0].id).chat_status, 'ENDED');
  assert.equal(store.getGlobalLive(lives[0].id).active_live_chat_id, '');
  assert.equal(store.activeLiveCount(user.id, 1), 4);
  assert.equal(store.apiUsage(user.id, 1).videosList.attempts, 0);
  await monitor.scan(); assert.equal(batches, 1);
  // Cache tem validade: estado público repetido não evita uma confirmação futura.
  at += store.liveVerificationTtlMs() + 1;
  await monitor.scan(); assert.equal(batches, 2);
  assert.equal(store.globalChannels(true).some(row => row.id === channel.id), true);
});

test('worker nunca envia ao chat encerrado mesmo com ID antigo marcado como disponível', async t => {
  const { user, lives } = fixture(t);
  let lookups = 0; const sent = [];
  const worker = createWorkers({ api: batchApi({ onLookup: ids => { lookups++; assert.equal(ids.length, 2); }, result: ids => ids.map(id => candidateFromVideo(video(id, id === lives[0].video_id), id)), onSend: id => sent.push(id) }) });
  await worker.step(user.id, 1);
  assert.deepEqual(sent, [`CHAT-${lives[1].video_id}`]); assert.equal(lookups, 1);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.equal(store.apiUsage(user.id, 1).videosList.attempts, 1);
  assert.equal(store.apiUsage(user.id, 1).liveChatInsert.attempts, 1);
  await worker.shutdown();
});

test('403 de um chat mantém o perfil ativo e respeita o intervalo antes de enviar na outra live', async t => {
  const { user, lives } = fixture(t);
  let at = Date.now();
  for (const live of lives) store.applyLiveVerification(live.id, candidateFromVideo(video(live.video_id), live.video_id), live.verification_revision);
  const states = store.profileLiveStates(user.id, 1);
  store.updateUserLiveState(states.find(state => state.videoId === lives[1].video_id).id, state => { state.last_send_at = '2026-01-01T00:00:00Z'; });
  const attempts = [];
  const worker = createWorkers({ clock: () => at, api: batchApi({ onSend: id => {
    attempts.push(id);
    if (id === `CHAT-${lives[0].video_id}`) { const error = new Error('The caller does not have permission'); error.status = 403; error.reason = 'forbidden'; throw error; }
  } }) });
  await worker.step(user.id, 1);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.match(store.logs(user.id, 1, 10)[0].error, /HTTP 403.*forbidden/);
  await worker.step(user.id, 1);
  assert.deepEqual(attempts, [`CHAT-${lives[0].video_id}`]);
  at += 180000;
  await worker.step(user.id, 1);
  assert.deepEqual(attempts, [`CHAT-${lives[0].video_id}`, `CHAT-${lives[1].video_id}`]);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  await worker.shutdown();
});

test('limpeza durante consulta OAuth descarta resposta antiga e preserva configurações, envios e cota', async t => {
  const { user, lives } = fixture(t);
  const before = store.getUserProfile(user.id, 1);
  store.recordApiCall(user.id, 1, 'liveChatMessages.insert', true);
  let release, entered;
  const gate = new Promise(resolve => release = resolve), started = new Promise(resolve => entered = resolve);
  let sent = 0;
  const worker = createWorkers({ api: batchApi({ result: async ids => { entered(); await gate; return ids.map(id => candidateFromVideo(video(id), id)); }, onSend: () => sent++ }) });
  const pending = worker.step(user.id, 1); await started;
  const cleared = store.clearLiveCache(); assert.ok(cleared.count >= lives.length);
  release(); await pending;
  assert.equal(sent, 0);
  for (const live of lives) { assert.equal(store.getGlobalLive(live.id).active_live_chat_id, ''); assert.equal(store.getGlobalLive(live.id).chat_status, 'VERIFYING'); }
  const after = store.getUserProfile(user.id, 1);
  assert.deepEqual(after.config, before.config); assert.deepEqual(after.oauth, before.oauth);
  assert.equal(store.apiUsage(user.id, 1).liveChatInsert.attempts, 1);
  assert.equal(store.apiUsage(user.id, 1).videosList.attempts, 1);
  await worker.shutdown();
});

test('limpeza durante lote administrativo impede que a resposta restaure o cache descartado', async t => {
  const { lives } = fixture(t);
  let release, entered;
  const gate = new Promise(resolve => release = resolve), started = new Promise(resolve => entered = resolve);
  const monitor = createGlobalMonitor({ discover: async () => ({ lives: lives.map(live => ({ videoId: live.video_id, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true })) }), verifyKnownLives: async ids => { entered(); await gate; return { ok: true, configured: true, candidates: ids.map(id => candidateFromVideo(video(id), id)) }; } });
  const scan = monitor.scan(); await started; store.clearLiveCache(); release();
  assert.equal((await scan).obsolete, true);
  assert.ok(lives.every(live => store.getGlobalLive(live.id).chat_status === 'VERIFYING'));
});

test('falha temporária da verificação não transforma uma live em encerrada nem permite envio ao cache vencido', async t => {
  const { user, lives } = fixture(t);
  let sends = 0;
  const worker = createWorkers({ api: batchApi({ result: () => { throw new Error('Falha de conexão simulada'); }, onSend: () => sends++ }) });
  await worker.step(user.id, 1);
  assert.equal(sends, 0); assert.equal(store.getGlobalLive(lives[0].id).live_status, 'LIVE');
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.equal(store.apiUsage(user.id, 1).videosList.failures, 1);
  assert.ok(store.getUserProfile(user.id, 1).runtime.retryAt >= Date.now() + 4900);
  await worker.shutdown();
});

test('resultado desconhecido reconfirma a live e tenta a mesma mensagem sem pausa manual', async t => {
  const { user, lives } = fixture(t, 1);
  let at = Date.now(), calls = 0, checks = 0;
  const worker = createWorkers({ clock: () => at, api: batchApi({
    onLookup: () => { checks++; },
    onSend: (_id, message) => {
      calls++;
      assert.equal(message, 'Mensagem de teste');
      if (calls === 1) { const error = new Error('Resposta do envio perdida'); error.ambiguousWrite = true; throw error; }
    }
  }) });
  await worker.step(user.id, 1);
  const retry = store.profileLiveStates(user.id, 1)[0];
  assert.equal(retry.sendStatus, 'ACTIVE');
  assert.equal(Date.parse(retry.nextAttemptAt), at + 5000);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.equal(store.getUserProfile(user.id, 1).runtime.sendRecoveryPending, true);
  assert.equal(store.getGlobalLive(lives[0].id).chat_verified_at, null);
  store.distributeLive(lives[0].id);
  assert.equal(store.profileLiveStates(user.id, 1)[0].nextAttemptAt, retry.nextAttemptAt);
  at += 1000;
  await worker.step(user.id, 1);
  assert.equal(calls, 1);
  at += 4000;
  await worker.step(user.id, 1);
  assert.equal(calls, 2);
  assert.equal(checks, 2);
  assert.equal(store.profileLiveStates(user.id, 1)[0].nextAttemptAt, null);
  assert.equal(store.getUserProfile(user.id, 1).runtime.sent, 1);
  assert.equal(store.getUserProfile(user.id, 1).runtime.sendRecoveryPending, false);
  assert.equal(store.apiUsage(user.id, 1).liveChatInsert.attempts, 2);
  await worker.shutdown();
});

test('timeouts consecutivos usam espera crescente e só repetem em chat confirmado', async t => {
  const { user, lives } = fixture(t, 1);
  let at = Date.now(), calls = 0, checks = 0;
  const worker = createWorkers({ clock: () => at, api: batchApi({
    onLookup: () => { checks++; },
    onSend: () => { calls++; const error = new Error('Timeout'); error.ambiguousWrite = true; throw error; }
  }) });
  for (const seconds of [5, 10, 20]) {
    await worker.step(user.id, 1);
    const state = store.profileLiveStates(user.id, 1)[0];
    assert.equal(state.sendStatus, 'ACTIVE');
    assert.equal(state.errorStreak, calls);
    assert.equal(Date.parse(state.nextAttemptAt), at + seconds * 1000);
    assert.equal(store.getGlobalLive(lives[0].id).chat_verified_at, null);
    at += seconds * 1000;
  }
  assert.equal(calls, 3);
  assert.equal(checks, 3);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  await worker.shutdown();
});

test('erro 403 tenta no intervalo normal, mantém a mesma mensagem e registra a retomada', async t => {
  const { user } = fixture(t, 1);
  let at = Date.now(), attempts = 0;
  const worker = createWorkers({ clock: () => at, api: batchApi({ onSend: () => {
    attempts++; const error = new Error('The caller does not have permission'); error.status = 403; error.reason = 'forbidden'; throw error;
  } }) });
  const interval = 181000;
  await worker.step(user.id, 1);
  assert.equal(Date.parse(store.profileLiveStates(user.id, 1)[0].nextAttemptAt), at + interval);
  assert.equal(worker.nextTarget(store.getUserProfile(user.id, 1)), at + interval);
  at += interval - 1;
  await worker.step(user.id, 1);
  assert.equal(attempts, 1);
  at++;
  await worker.step(user.id, 1);
  assert.equal(Date.parse(store.profileLiveStates(user.id, 1)[0].nextAttemptAt), at + interval);
  assert.equal(attempts, 2);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.equal(store.profileErrors(user.id, 1).length, 2);
  assert.equal(store.profileErrors(user.id, 1)[0].videoId, store.profileLiveStates(user.id, 1)[0].videoId);
  await worker.shutdown();
});

test('erros permanecem por perfil após limpar atividade e após recuperar o envio', t => {
  const { user, lives } = fixture(t, 1);
  store.addUserProfile(user.id);
  const first = store.getUserProfile(user.id, 1);
  const second = store.getUserProfile(user.id, 2);
  store.appendLog(first, 'send', `${lives[0].video_id} • Mensagem`, 'error', 'HTTP 403 · forbidden');
  store.appendLog(second, 'connection', 'Outra conta', 'error', 'Falha exclusiva do Perfil 2');
  assert.equal(store.profileErrors(user.id, 1).length, 1);
  assert.equal(store.profileErrors(user.id, 2).length, 1);
  store.clearLogs(user.id, 1);
  assert.equal(store.logs(user.id, 1).length, 0);
  assert.equal(store.profileErrors(user.id, 1).length, 1);
  store.recoverProfileErrors(user.id, 1, lives[0].video_id);
  assert.equal(store.profileErrors(user.id, 1)[0].state, 'recovered');
  assert.equal(store.profileErrors(user.id, 2)[0].state, 'waiting');
});

test('insufficientPermissions no POST não desliga o OAuth; scopes inválidos ainda exigem correção', async t => {
  const { user, lives } = fixture(t, 1);
  let at = Date.now(), attempts = 0;
  const worker = createWorkers({ clock: () => at, api: batchApi({ onSend: () => {
    attempts++;
    const error = new Error('The caller does not have permission');
    error.status = 403; error.reason = 'insufficientPermissions'; throw error;
  } }) });
  await worker.step(user.id, 1);
  const profile = store.getUserProfile(user.id, 1);
  assert.equal(profile.runtime.status, 'running');
  assert.ok(profile.oauth.refreshTokenEnc);
  assert.equal(Date.parse(store.profileLiveStates(user.id, 1)[0].nextAttemptAt), at + 181000);
  at += 181000;
  await worker.step(user.id, 1);
  assert.equal(attempts, 2);
  assert.equal(store.getGlobalLive(lives[0].id).chat_status, 'AVAILABLE');
  await worker.shutdown();
});

test('permissão negada em horário fixo espera o próximo horário e não repete no mesmo minuto', async t => {
  const { user } = fixture(t, 1);
  let at = Date.parse('2026-10-08T23:01:55Z'), attempts = 0;
  store.updateUserProfile(user.id, 1, profile => { profile.config.sendMode = 'fixed'; profile.config.version++; });
  const worker = createWorkers({ clock: () => at, api: batchApi({ onSend: () => {
    attempts++;
    const error = new Error('Permission denied'); error.status = 403; error.reason = 'forbidden'; throw error;
  } }) });
  await worker.step(user.id, 1);
  const next = Date.parse('2026-10-08T23:05:01Z');
  assert.equal(Date.parse(store.profileLiveStates(user.id, 1)[0].nextAttemptAt), next);
  assert.equal(worker.nextTarget(store.getUserProfile(user.id, 1)), next);
  at = Date.parse('2026-10-08T23:02:01Z');
  await worker.step(user.id, 1);
  assert.equal(attempts, 1);
  at = next;
  await worker.step(user.id, 1);
  assert.equal(attempts, 2);
  await worker.shutdown();
});

test('mensagem inválida é isolada; a próxima válida é enviada sem pausar o perfil', async t => {
  const { user } = fixture(t, 1);
  let at = Date.now(); const sent = [];
  store.updateUserProfile(user.id, 1, profile => { profile.config.messages = 'Inválida\nMensagem válida'; profile.config.version++; });
  const worker = createWorkers({ clock: () => at, api: batchApi({ onSend: (_chat, message) => {
    sent.push(message);
    if (message === 'Inválida') {
      const error = new Error('Texto rejeitado'); error.status = 400; error.reason = 'messageTextInvalid'; throw error;
    }
  } }) });
  await worker.step(user.id, 1);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.deepEqual(store.getUserProfile(user.id, 1).runtime.invalidMessageIndexes, [0]);
  at += 181000;
  await worker.step(user.id, 1);
  assert.deepEqual(sent, ['Inválida', 'Mensagem válida']);
  assert.equal(store.getUserProfile(user.id, 1).runtime.sent, 1);
  assert.equal(store.profileErrors(user.id, 1)[0].state, 'attention');
  await worker.shutdown();
});

test('erro na primeira live não adianta envio na outra; retry rápido prioriza a própria live', async t => {
  const { user, lives } = fixture(t, 2);
  let at = Date.now(); const attempts = [];
  const worker = createWorkers({ clock: () => at, api: batchApi({ onSend: chatId => {
    attempts.push(chatId);
    if (attempts.length === 1) { const error = new Error('Falha temporária'); error.status = 500; throw error; }
  } }) });
  await worker.step(user.id, 1);
  assert.equal(worker.nextTarget(store.getUserProfile(user.id, 1)), at + 5000);
  await worker.step(user.id, 1);
  assert.equal(attempts.length, 1);
  at += 5000;
  await worker.step(user.id, 1);
  assert.deepEqual(attempts, [`CHAT-${lives[0].video_id}`, `CHAT-${lives[0].video_id}`]);
  assert.equal(store.profileErrors(user.id, 1)[0].state, 'recovered');
  assert.equal(worker.nextTarget(store.getUserProfile(user.id, 1)), at + 180000);
  await worker.shutdown();
});

test('worker retoma sozinho após bloqueio temporário realista do SQLite', async t => {
  const { user } = fixture(t, 1);
  let blocked = true;
  const storage = new Proxy(store, { get(target, key) {
    if (key === 'profileChannels') return (...args) => {
      if (blocked) {
        blocked = false;
        const error = new Error('database is locked');
        error.code = 'ERR_SQLITE_ERROR'; error.errcode = 5;
        throw error;
      }
      return target.profileChannels(...args);
    };
    return target[key];
  } });
  const worker = createWorkers({ storage, api: batchApi() });
  worker.start(user.id, 1);
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline && store.getUserProfile(user.id, 1).runtime.sent === 0) {
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.equal(store.getUserProfile(user.id, 1).runtime.sent, 1);
  assert.ok(store.profileErrors(user.id, 1).some(entry => /Falha temporária interna/.test(entry.error)));
  await worker.shutdown();
});

test('HTTP 500 transitório não pausa o perfil e só repete depois de reconfirmar o chat', async t => {
  const { user, lives } = fixture(t, 1);
  let at = Date.now(), attempts = 0, checks = 0;
  const worker = createWorkers({ clock: () => at, api: batchApi({
    onLookup: () => { checks++; },
    onSend: () => {
      attempts++;
      if (attempts === 1) { const error = new Error('Falha temporária'); error.status = 500; throw error; }
    }
  }) });
  await worker.step(user.id, 1);
  assert.equal(store.getUserProfile(user.id, 1).runtime.status, 'running');
  assert.equal(store.getGlobalLive(lives[0].id).chat_verified_at, null);
  assert.equal(Date.parse(store.profileLiveStates(user.id, 1)[0].nextAttemptAt), at + 5000);
  at += 5000;
  await worker.step(user.id, 1);
  assert.equal(attempts, 2);
  assert.equal(checks, 2);
  assert.equal(store.getUserProfile(user.id, 1).runtime.sent, 1);
  await worker.shutdown();
});

test('modo fixo recupera envio sem esperar o próximo horário programado', async t => {
  const { user } = fixture(t, 1);
  let at = Date.parse('2026-10-08T23:01:55Z'), attempts = 0;
  store.updateUserProfile(user.id, 1, profile => { profile.config.sendMode = 'fixed'; profile.config.version++; });
  const worker = createWorkers({ clock: () => at, api: batchApi({ onSend: () => {
    attempts++;
    if (attempts === 1) { const error = new Error('Timeout'); error.ambiguousWrite = true; throw error; }
  } }) });
  await worker.step(user.id, 1);
  at += 6000; // Já passou a virada do minuto: próximo slot normal seria 20:05.
  await worker.step(user.id, 1);
  assert.equal(attempts, 2);
  assert.equal(store.getUserProfile(user.id, 1).runtime.sent, 1);
  assert.equal(store.getUserProfile(user.id, 1).runtime.sendRecoveryPending, false);
  await worker.shutdown();
});

test('migração reativa só envios desconhecidos da V3.0.8 e preserva a pausa manual', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-recover-paused-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const create = `const s=require('./lib/store');const u=s.createUser({id:'legacy-user',username:'Legado',active:true,sessionVersion:1});
    s.updateUserProfile(u.id,1,p=>{p.runtime.status='running';p.runtime.lastError='Não foi possível confirmar o envio em uma live.';p.config.messages='Texto guardado';});
    const c=s.upsertGlobalChannel({channelId:'UC7777777777777777777788',handle:'@Legado',canonicalUrl:'https://www.youtube.com/@Legado'});
    s.subscribeChannel(u.id,1,c,c.handle);
    for(const id of ['R0000000001','R0000000002']){const l=s.upsertGlobalLive(c.id,{videoId:id,liveStatus:'LIVE',chatStatus:'AVAILABLE',activeLiveChatId:'CHAT-'+id,resolved:true}).live;
      s.distributeLive(l.id);s.cacheGlobalLiveChatId(l.id,'CHAT-'+id);}s.close();`;
  const env = { ...process.env, DATA_DIR: directory };
  const created = spawnSync(process.execPath, ['-e', create], { cwd: path.join(__dirname, '..'), env, encoding: 'utf8' });
  assert.equal(created.status, 0, created.stderr);
  const db = new DatabaseSync(path.join(directory, 'peralta.sqlite'));
  db.prepare(`UPDATE user_live_state SET send_status='PAUSED',last_error='Resultado do envio desconhecido. Esta live foi pausada para evitar mensagem duplicada.'
    WHERE global_live_id=(SELECT id FROM global_lives WHERE video_id='R0000000001')`).run();
  db.prepare(`UPDATE user_live_state SET send_status='PAUSED',last_error='Pausa manual.'
    WHERE global_live_id=(SELECT id FROM global_lives WHERE video_id='R0000000002')`).run();
  db.exec('PRAGMA user_version=7');
  db.close();
  const output = path.join(directory, 'migration-result.json');
  const check = `const fs=require('node:fs');const s=require('./lib/store');const p=s.getUserProfile('legacy-user',1);
    fs.writeFileSync(${JSON.stringify(output)},JSON.stringify({schema:s.schemaVersion(),profile:p.runtime,messages:p.config.messages,states:s.profileLiveStates('legacy-user',1),fresh:s.chatVerificationFresh(s.getGlobalLiveByVideo('R0000000001'))}));s.close();`;
  const migrated = spawnSync(process.execPath, ['-e', check], { cwd: path.join(__dirname, '..'), env, encoding: 'utf8' });
  assert.equal(migrated.status, 0, migrated.stderr);
  const result = JSON.parse(fs.readFileSync(output, 'utf8'));
  assert.equal(result.schema, 9);
  assert.equal(result.states.find(row => row.videoId === 'R0000000001').sendStatus, 'ACTIVE');
  assert.equal(result.states.find(row => row.videoId === 'R0000000002').sendStatus, 'PAUSED');
  assert.equal(result.profile.sendRecoveryPending, true);
  assert.equal(result.fresh, false);
  assert.equal(result.messages, 'Texto guardado');
});

test('encerramento do servidor aguarda a consulta e cancela a reverificação que estava na fila', async t => {
  const { lives } = fixture(t, 1);
  let release, entered, batches = 0;
  const gate = new Promise(resolve => release = resolve), started = new Promise(resolve => entered = resolve);
  const monitor = createGlobalMonitor({ discover: async () => ({ lives: lives.map(live => ({ videoId: live.video_id, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true })) }), verifyKnownLives: async ids => { batches++; entered(); await gate; return { ok: true, configured: true, candidates: ids.map(id => candidateFromVideo(video(id), id)) }; } });
  const pending = monitor.scan(); await started; monitor.requestScan();
  const stopped = monitor.stop(); release(); await Promise.all([pending, stopped]);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(batches, 1); assert.equal(monitor.isRunning(), false);
  assert.equal((await monitor.scan()).reason, 'stopped');
});

test('replay e horário real de término vencem sinais antigos de live/programação', () => {
  const html = `ytInitialPlayerResponse = ${JSON.stringify({ videoDetails: { videoId: 'A0000000000', isLive: true, isLiveContent: true }, microformat: { playerMicroformatRenderer: { liveBroadcastDetails: { isLiveNow: true, endTimestamp: '2026-10-05T12:00:00Z' } } } })}; ytInitialData = {"liveChatReplayRenderer":{}};`;
  const candidate = discovery.resolveLiveState(html, { videoId: 'A0000000000', hintLive: true, hintScheduled: true });
  assert.equal(candidate.liveStatus, 'ENDED'); assert.equal(candidate.chatStatus, 'ENDED');
});

after(() => { store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); });
