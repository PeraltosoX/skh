'use strict';
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-quota-'));
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
const store = require('../lib/store');
const { encryptText } = require('../lib/security');
const { createWorkers, nextPacificQuotaReset } = require('../lib/workers');
const { pacificDay, nextPacificMidnight } = require('../lib/quota');
const at = Date.parse('2026-10-02T15:00:00Z');
let serial = 0;
function user(profiles = 1) {
  const result = store.createUser({ id: store.id('usr'), username: `Cota ${++serial}`, active: true, sessionVersion: 1 });
  for (let i = 1; i < profiles; i++) store.addUserProfile(result.id);
  return result;
}
function channel() {
  const key = String(++serial).padStart(22, '0');
  return store.upsertGlobalChannel({ channelId: `UC${key}`, handle: `@quota${serial}`, canonicalUrl: `https://www.youtube.com/@quota${serial}`, displayName: 'Cota', originalInput: `@quota${serial}` });
}
function ready(account, number, ch) {
  store.updateUserProfile(account.id, number, profile => {
    profile.api = { clientId: `test-${number}.apps.googleusercontent.com`, clientSecretEnc: encryptText('test-secret'), version: 2 };
    profile.oauth.refreshTokenEnc = encryptText('test-refresh');
    profile.oauth.accessTokenEnc = encryptText('test-access');
    profile.oauth.accessTokenExpiresAt = Date.now() + 600000;
    profile.oauth.email = `test-${number}@example.invalid`;
    profile.config.messages = 'Mensagem de teste';
    profile.runtime.status = 'running';
  });
  store.subscribeChannel(account.id, number, ch, ch.handle);
}
function live(ch, cached = false) {
  const result = store.upsertGlobalLive(ch.id, { videoId: `Q${String(++serial).padStart(10, '0')}`, title: 'Teste local', liveStatus: 'LIVE', chatStatus: 'AVAILABLE', resolved: true }).live;
  store.distributeLive(result.id);
  if (cached) store.cacheGlobalLiveChatId(result.id, 'CHAT-TEST');
  return result;
}
after(() => { store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); });

test('reinício do Pacífico cobre inverno, verão e dias de 23/25 horas', () => {
  for (const [input, day, next] of [
    ['2026-01-10T07:59:59Z', '2026-01-09', '2026-01-10T08:00:00.000Z'],
    ['2026-07-10T06:59:59Z', '2026-07-09', '2026-07-10T07:00:00.000Z'],
    ['2026-03-08T08:00:00Z', '2026-03-08', '2026-03-09T07:00:00.000Z'],
    ['2026-11-01T07:00:00Z', '2026-11-01', '2026-11-02T08:00:00.000Z']
  ]) {
    assert.equal(pacificDay(Date.parse(input)), day);
    assert.equal(new Date(nextPacificMidnight(Date.parse(input))).toISOString(), next);
  }
});

test('worker recomeça cinco minutos após a virada real da cota também no verão', () => {
  assert.equal(new Date(nextPacificQuotaReset(Date.parse('2026-07-10T06:59:59Z'))).toISOString(), '2026-07-10T07:05:00.000Z');
  assert.equal(new Date(nextPacificQuotaReset(Date.parse('2026-01-10T07:59:59Z'))).toISOString(), '2026-01-10T08:05:00.000Z');
});

test('custos estimados 1/20 isolados por usuário e perfil incluem falhas, mas não OAuth', () => {
  const a = user(3), b = user();
  store.recordApiCall(a.id, 1, 'videos.list', true, at);
  store.recordApiCall(a.id, 1, 'liveChatMessages.insert', true, at);
  store.recordApiCall(a.id, 1, 'liveChatMessages.insert', false, at);
  store.recordApiCall(a.id, 2, 'videos.list', false, at);
  store.recordApiCall(b.id, 1, 'liveChatMessages.insert', true, at);
  const q = store.profileQuotaEstimate(a.id, 1, at);
  assert.equal(q.unitsUsed, 41);
  assert.equal(q.unitsRemaining, 9959);
  assert.equal(q.percentUsed, 0.41);
  assert.equal(q.requests, 3);
  assert.equal(q.messagesSent, 1);
  assert.equal(q.failures, 1);
  assert.equal(q.unconfirmedRequests, 0);
  assert.equal(store.profileQuotaEstimate(a.id, 2, at).unitsUsed, 1);
  assert.equal(store.profileQuotaEstimate(a.id, 3, at).unitsUsed, 0);
  assert.equal(store.profileQuotaEstimate(b.id, 1, at).unitsUsed, 20);
  for (const method of ['oauth.refresh', 'userinfo']) store.recordApiCall(a.id, 1, method, true, at);
  assert.equal(store.profileQuotaEstimate(a.id, 1, at).unitsUsed, 41);
});

test('API administrativa não incrementa a cota dos perfis', () => {
  const a = user(2);
  const key = store.createAdminVerificationKey({ id: store.id('key'), name: 'Teste', apiKeyEnc: encryptText('test-global-key'), keyHint: 'teste', keyFingerprint: crypto.randomUUID() });
  store.recordAdminVerificationCall(key.id, true, at);
  store.recordAdminVerificationCall(key.id, false, at);
  assert.equal(store.adminVerificationKeyUsage(key.id, at).attempts, 2);
  for (const n of [1, 2]) assert.equal(store.profileQuotaEstimate(a.id, n, at).unitsUsed, 0);
});

test('chamada pendente já fica persistida; conclusão idempotente usa o dia de início', () => {
  const a = user(), start = Date.parse('2026-10-03T06:59:59Z');
  const finish = store.beginApiCall(a.id, 1, 'liveChatMessages.insert', start);
  assert.equal(store.profileQuotaEstimate(a.id, 1, start).unitsUsed, 20);
  assert.equal(store.profileQuotaEstimate(a.id, 1, start).unconfirmedRequests, 1);
  const code = `const s=require('./lib/store'); console.log(JSON.stringify(s.profileQuotaEstimate(${JSON.stringify(a.id)},1,${start}))); s.close();`;
  const child = spawnSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: process.env, encoding: 'utf8' });
  assert.equal(child.status, 0, child.stderr);
  assert.equal(JSON.parse(child.stdout).unitsUsed, 20);
  finish(true); finish(false);
  const q = store.profileQuotaEstimate(a.id, 1, start);
  assert.equal(q.requests, 1); assert.equal(q.messagesSent, 1);
  assert.equal(q.failures, 0); assert.equal(q.unconfirmedRequests, 0);
  assert.equal(store.profileQuotaEstimate(a.id, 1, start + 2000).unitsUsed, 0);
});

test('interrupção do processo preserva a tentativa sem inventar mensagem enviada', () => {
  const a = user();
  const code = `const s=require('./lib/store'); s.beginApiCall(${JSON.stringify(a.id)},1,'liveChatMessages.insert',${at}); process.exit(0);`;
  const child = spawnSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: process.env, encoding: 'utf8' });
  assert.equal(child.status, 0, child.stderr);
  const q = store.profileQuotaEstimate(a.id, 1, at);
  assert.equal(q.unitsUsed, 20); assert.equal(q.unconfirmedRequests, 1); assert.equal(q.messagesSent, 0);
});

test('parar, limpar logs e alterar credenciais não zeram o histórico diário', async () => {
  const a = user(), worker = createWorkers({ clock: () => at });
  store.recordApiCall(a.id, 1, 'liveChatMessages.insert', true, at);
  worker.stop(a.id, 1); store.clearLogs(a.id, 1);
  store.updateUserProfile(a.id, 1, p => { p.api.clientId = 'new.apps.googleusercontent.com'; p.api.version++; });
  assert.equal(store.profileQuotaEstimate(a.id, 1, at).unitsUsed, 20);
  await worker.shutdown();
});

test('resposta antiga não contamina perfil excluído e recriado com mesmo número', () => {
  const a = user(2), oldFinish = store.beginApiCall(a.id, 2, 'liveChatMessages.insert', at);
  store.deleteUserProfile(a.id, 2);
  assert.equal(store.addUserProfile(a.id).profileNumber, 2);
  store.recordApiCall(a.id, 2, 'liveChatMessages.insert', false, at);
  oldFinish(true);
  const q = store.profileQuotaEstimate(a.id, 2, at);
  assert.equal(q.requests, 1); assert.equal(q.failures, 1); assert.equal(q.messagesSent, 0);
});

test('referência de 10 mil não produz saldo negativo nem esconde excesso', () => {
  const a = user();
  for (let i = 0; i < 501; i++) store.recordApiCall(a.id, 1, 'liveChatMessages.insert', true, at);
  const q = store.profileQuotaEstimate(a.id, 1, at);
  assert.equal(q.unitsUsed, 10020); assert.equal(q.unitsRemaining, 0); assert.equal(q.percentUsed, 100.2);
});

test('worker registra antes da resposta e conserva dia de início', async () => {
  const a = user(), ch = channel(); ready(a, 1, ch); live(ch);
  let clock = Date.parse('2026-10-03T06:59:59Z'); const beginning = clock;
  const worker = createWorkers({ clock: () => clock, api: {
    getActiveLiveChatId: async (_p, _api, _video, o) => {
      o.onApiRequest(); assert.equal(store.profileQuotaEstimate(a.id, 1, clock).unitsUsed, 1);
      clock += 2000; return 'CHAT-NEXT-DAY';
    },
    sendLiveChatMessage: async (_p, _api, _chat, _message, o) => {
      o.beforeSend(); o.onApiRequest(); assert.equal(store.profileQuotaEstimate(a.id, 1, clock).unitsUsed, 20);
      throw Object.assign(new Error('Teste de falha HTTP'), { status: 500 });
    }
  } });
  await worker.step(a.id, 1);
  assert.equal(store.profileQuotaEstimate(a.id, 1, beginning).unitsUsed, 1);
  const q = store.profileQuotaEstimate(a.id, 1, clock);
  assert.equal(q.unitsUsed, 20); assert.equal(q.failures, 1); assert.equal(q.messagesSent, 0);
  await worker.shutdown();
});

test('OAuth rejeitado antes da Data API não gasta cota no painel', async () => {
  const a = user(), ch = channel(); ready(a, 1, ch); live(ch);
  store.updateUserProfile(a.id, 1, p => { p.oauth.accessTokenEnc = ''; p.oauth.accessTokenExpiresAt = 0; });
  const originalFetch = global.fetch; let calls = 0;
  global.fetch = async url => {
    assert.equal(String(url), 'https://oauth2.googleapis.com/token'); calls++;
    return new Response(JSON.stringify({ error: 'invalid_grant' }), { status: 400 });
  };
  const worker = createWorkers({ clock: () => at });
  try { await worker.step(a.id, 1); } finally { global.fetch = originalFetch; await worker.shutdown(); }
  assert.equal(calls, 1); assert.equal(store.profileQuotaEstimate(a.id, 1, at).unitsUsed, 0);
});

test('bloqueio antes do envio não conta chamada da API', async () => {
  const a = user(), ch = channel(); ready(a, 1, ch); live(ch, true);
  const worker = createWorkers({ clock: () => at, api: {
    sendLiveChatMessage: async (_p, _api, _chat, _message, o) => {
      store.updateUserProfile(a.id, 1, p => { p.runtime.epoch++; });
      o.beforeSend(); o.onApiRequest(); assert.fail('Envio obsoleto deveria ter sido bloqueado');
    }
  } });
  await worker.step(a.id, 1);
  assert.equal(store.profileQuotaEstimate(a.id, 1, at).unitsUsed, 0);
  await worker.shutdown();
});

test('consulta compartilhada conta uma vez e cada perfil tem apenas seus envios', async () => {
  const a = user(2), ch = channel();
  for (const n of [1, 2]) {
    ready(a, n, ch);
    store.updateUserProfile(a.id, n, p => { p.api.clientId = 'shared.apps.googleusercontent.com'; p.oauth.email = 'shared@example.invalid'; });
  }
  live(ch); let lookups = 0;
  const worker = createWorkers({ clock: () => at, api: {
    getActiveLiveChatId: async (_p, _api, _video, o) => { o.onApiRequest(); lookups++; await new Promise(r => setImmediate(r)); return 'SHARED'; },
    sendLiveChatMessage: async (_p, _api, _chat, _message, o) => { o.beforeSend(); o.onApiRequest(); return {}; }
  } });
  await Promise.all([worker.step(a.id, 1), worker.step(a.id, 2)]);
  assert.equal(lookups, 1);
  const usage = [1, 2].map(n => store.profileQuotaEstimate(a.id, n, at));
  assert.deepEqual(usage.map(q => q.unitsUsed).sort((a, b) => a - b), [20, 21]);
  assert.deepEqual(usage.map(q => q.messagesSent), [1, 1]);
  await worker.shutdown();
});

test('HTTP 500 reconfirma o chat, contabiliza a consulta e cada nova tentativa de envio', async () => {
  const a = user(), ch = channel(); ready(a, 1, ch); live(ch, true);
  let clock = at, sends = 0, lookups = 0;
  const worker = createWorkers({ clock: () => clock, api: {
    getActiveLiveChatId: async (_p, _api, _video, o) => { o.onApiRequest(); lookups++; return 'CHAT-TEST'; },
    sendLiveChatMessage: async (_p, _api, _chat, _message, o) => {
      o.beforeSend(); o.onApiRequest(); sends++;
      if (sends === 1) throw Object.assign(new Error('Falha temporária'), { status: 500 });
      return {};
    }
  } });
  await worker.step(a.id, 1); clock += 3600000; await worker.step(a.id, 1);
  const q = store.profileQuotaEstimate(a.id, 1, clock);
  assert.equal(sends, 2); assert.equal(lookups, 1); assert.equal(q.queries, 1); assert.equal(q.unitsUsed, 41);
  assert.equal(q.messagesSent, 1); assert.equal(q.failures, 1);
  await worker.shutdown();
});

test('caso informado: 92 envios estimam 1.840 unidades, 18,4% e saldo 8.160', () => {
  const a = user();
  for (let i = 0; i < 92; i++) store.recordApiCall(a.id, 1, 'liveChatMessages.insert', true, at);
  let q = store.profileQuotaEstimate(a.id, 1, at);
  assert.equal(q.unitsUsed, 1840);
  assert.equal(q.unitsRemaining, 8160);
  assert.equal(q.percentUsed, 18.4);
  assert.equal(q.requests, 92);
  assert.equal(q.messagesSent, 92);
  assert.equal(q.queries, 0);
  assert.equal(q.unitCosts['videos.list'], 1);
  assert.equal(q.unitCosts['liveChatMessages.insert'], 20);
  assert.equal(q.calculationBasis, 'observed-calibration-2026-10-02');
  // Uma consulta é uma unidade adicional, não outro envio de 20 unidades.
  store.recordApiCall(a.id, 1, 'videos.list', true, at);
  q = store.profileQuotaEstimate(a.id, 1, at);
  assert.equal(q.unitsUsed, 1841);
  assert.equal(q.requests, 93);
  assert.equal(q.messagesSent, 92);
});

test('histórico no formato da V3.0.4 é recalculado sem reescrever registros', () => {
  const { DatabaseSync } = require('node:sqlite');
  const a = user(2), day = pacificDay(at);
  const db = new DatabaseSync(path.join(process.env.DATA_DIR, 'peralta.sqlite'));
  try {
    // A versão anterior persistia quantidades, não o custo multiplicado por 50.
    db.prepare(`INSERT INTO api_usage_daily(day,user_id,profile_number,method,attempts,successes,failures,updated_at)
      VALUES(?,?,1,'liveChatMessages.insert',92,92,0,?)`).run(day, a.id, new Date(at).toISOString());
    const select = db.prepare('SELECT * FROM api_usage_daily WHERE user_id=? ORDER BY profile_number,method');
    const before = select.all(a.id);
    const profilesBefore = db.prepare('SELECT body FROM user_profiles WHERE user_id=? ORDER BY profile_number').all(a.id);
    assert.equal(store.schemaVersion(), 9);
    assert.equal(store.profileQuotaEstimate(a.id, 1, at).unitsUsed, 1840);
    assert.equal(store.profileQuotaEstimate(a.id, 2, at).unitsUsed, 0);
    assert.equal(store.apiUsage(a.id, 1, at).requests, 92);
    assert.deepEqual(select.all(a.id), before);
    assert.deepEqual(db.prepare('SELECT body FROM user_profiles WHERE user_id=? ORDER BY profile_number').all(a.id), profilesBefore);
  } finally { db.close(); }
});
