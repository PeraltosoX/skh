'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-admin-access-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';
const store = require('../lib/store');
const security = require('../lib/security');
const youtube = require('../lib/youtube');
const { createApp } = require('../server');
const admin = { id: store.id('adm'), username: 'Administrador de teste', passwordHash: 'test-only', active: true, sessionVersion: 1 };
store.createFirstAdmin(admin);
let server, base, sequence = 0;
before(async () => { server = createApp().listen(0, '127.0.0.1'); await new Promise(resolve => server.once('listening', resolve)); base = `http://127.0.0.1:${server.address().port}`; });
function account(t, active = true) {
  const user = store.createUser({ id: store.id('usr'), username: `Conta ${++sequence}`, active, sessionVersion: 1 });
  store.addUserProfile(user.id);
  t.after(() => store.deleteUser(user.id)); return user;
}
function session(subject, kind) {
  const signed = security.signSession(subject.id, kind, subject.sessionVersion);
  store.saveSession(signed.session);
  return { ...signed, cookie: `auto_server_${kind}=${signed.token}` };
}
const adminSession = () => session(store.getAdmin(admin.id), 'admin');
const panelPath = user => `/dbmadmin/painel/${user.id}`;
async function request(url, cookie = '', method = 'GET', body, csrf, origin) {
  const headers = { Cookie: cookie };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (csrf) headers['X-CSRF-Token'] = csrf;
  if (origin) headers.Origin = origin;
  return fetch(base + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), redirect: 'manual' });
}
async function bootstrap(user, signed) {
  return (await request(panelPath(user) + '/api/web/bootstrap', signed.cookie)).json();
}

test('atalho exige administrador e não aceita sessão comum ou cabeçalho Bearer', async t => {
  const user = account(t), ordinary = session(user, 'user');
  const entry = await request(panelPath(user));
  assert.equal(entry.status, 302); assert.equal(entry.headers.get('location'), '/dbmadmin');
  assert.equal((await request(panelPath(user) + '/api/me', ordinary.cookie)).status, 401);
  assert.equal((await fetch(base + panelPath(user) + '/api/me', { headers: { Authorization: `Bearer ${ordinary.token}` } })).status, 401);
  assert.equal((await bootstrap(user, ordinary)).authenticated, false);
});

test('duas contas administrativas ficam independentes e o login comum é preservado', async t => {
  const first = account(t), second = account(t), normal = account(t), signed = adminSession();
  const ordinary = session(normal, 'user'), cookie = `${signed.cookie}; ${ordinary.cookie}`;
  const response = await request(panelPath(first) + '?profile=2', cookie);
  assert.equal(response.status, 200); assert.equal(response.headers.get('set-cookie'), null);
  assert.match(await response.text(), /adminAccessBanner/);
  const a = await bootstrap(first, signed), b = await bootstrap(second, signed);
  assert.equal(a.user.id, first.id); assert.equal(b.user.id, second.id);
  assert.equal(a.adminAccess, true); assert.notEqual(a.csrfToken, b.csrfToken);
  const original = await (await request('/api/web/bootstrap', cookie)).json();
  assert.equal(original.user.id, normal.id); assert.equal(original.adminAccess, false);
  assert.ok(store.auditLog().some(event => event.actor === admin.id && event.action === 'admin_panel_open' && event.target === first.id));
});

test('edição administrativa exige CSRF da conta, respeita origem e altera somente o perfil escolhido', async t => {
  const first = account(t), second = account(t), signed = adminSession();
  const a = await bootstrap(first, signed), b = await bootstrap(second, signed);
  const route = panelPath(first) + '/api/profiles/2/name';
  assert.equal((await request(route, signed.cookie, 'PATCH', { name: 'Novo nome' })).status, 403);
  assert.equal((await request(route, signed.cookie, 'PATCH', { name: 'Novo nome' }, b.csrfToken)).status, 403);
  assert.equal((await request(route, signed.cookie, 'PATCH', { name: 'Novo nome' }, a.csrfToken, 'https://external.invalid')).status, 403);
  assert.equal((await request(route, signed.cookie, 'PATCH', { name: 'Novo nome' }, a.csrfToken)).status, 200);
  assert.equal(store.getUserProfile(first.id, 2).name, 'Novo nome');
  assert.equal(store.getUserProfile(first.id, 1).name, 'Perfil 1');
  assert.equal(store.getUserProfile(second.id, 2).name, 'Perfil 2');
  assert.ok(store.auditLog().some(event => event.actor === admin.id && event.action === 'admin_panel_action' && event.target.includes(first.id)));
  const exit = await request(panelPath(first) + '/api/logout', signed.cookie, 'POST', {}, a.csrfToken);
  assert.equal((await exit.json()).returnTo, '/dbmadmin'); assert.equal(exit.headers.get('set-cookie'), null);
  assert.equal((await request('/dbmadmin/api/data', signed.cookie)).status, 200);
});

test('logout do administrador invalida imediatamente todos os painéis abertos', async t => {
  const user = account(t), signed = adminSession();
  const old = await bootstrap(user, signed); assert.equal(old.authenticated, true);
  const adminBootstrap = await (await request('/dbmadmin/api/bootstrap', signed.cookie)).json();
  assert.equal((await request('/dbmadmin/api/logout', signed.cookie, 'POST', {}, adminBootstrap.csrfToken)).status, 200);
  assert.equal((await request(panelPath(user) + '/api/me', signed.cookie)).status, 401);
  assert.equal((await bootstrap(user, signed)).authenticated, false);
});

test('bloqueio do usuário e troca da senha administrativa invalidam acesso', async t => {
  const user = account(t), signed = adminSession();
  const initial = await bootstrap(user, signed);
  store.updateUser(user.id, current => { current.active = false; });
  assert.equal((await request(panelPath(user), signed.cookie)).status, 409);
  assert.equal((await request(panelPath(user) + '/api/me', signed.cookie)).status, 401);
  store.updateUser(user.id, current => { current.active = true; current.sessionVersion++; });
  assert.equal((await request(panelPath(user) + '/api/profiles/1/name', signed.cookie, 'PATCH', { name: 'Inválido' }, initial.csrfToken)).status, 403);
  store.updateAdmin(admin.id, current => { current.sessionVersion++; });
  assert.equal((await request(panelPath(user) + '/api/me', signed.cookie)).status, 401);
});

test('OAuth retorna ao painel administrativo da conta correta e não cria token de login', async t => {
  const user = account(t), signed = adminSession();
  store.updateUserProfile(user.id, 2, profile => {
    profile.api = { clientId: 'test-client', clientSecretEnc: security.encryptText('test-secret'), version: 1 };
  });
  const result = await (await request(panelPath(user) + '/api/profiles/2/oauth/connect?client=web', signed.cookie)).json();
  const state = new URL(result.url).searchParams.get('state');
  assert.ok(state.startsWith('m.'));
  assert.throws(() => security.verifySession(state.slice(2), 'admin'));
  const previousFetch = youtube.jsonFetch, previousChannel = youtube.getConnectedChannel;
  youtube.jsonFetch = async url => String(url).includes('userinfo')
    ? { email: 'test@example.invalid', email_verified: true }
    : { access_token: 'test-access', refresh_token: 'test-refresh', scope: youtube.YOUTUBE_SCOPE, expires_in: 3600 };
  youtube.getConnectedChannel = async () => null;
  try {
    const callback = await request('/oauth/google/callback?code=fake&state=' + encodeURIComponent(state));
    const html = await callback.text();
    assert.equal(callback.status, 200, html);
    assert.ok(html.includes(panelPath(user) + '?oauth=ok&amp;profile=2'));
    assert.equal(store.getUserProfile(user.id, 2).oauth.email, 'test@example.invalid');
    assert.equal(store.getUserProfile(user.id, 1).oauth.email, '');
    assert.equal((await request('/oauth/google/callback?code=fake&state=' + encodeURIComponent(state))).status, 400);
  } finally { youtube.jsonFetch = previousFetch; youtube.getConnectedChannel = previousChannel; }
});

test('OAuth administrativo pendente não conclui depois de revogar a sessão', async t => {
  const user = account(t), signed = adminSession();
  store.updateUserProfile(user.id, 1, profile => { profile.api = { clientId: 'test-client', clientSecretEnc: security.encryptText('test-secret'), version: 1 }; });
  const result = await (await request(panelPath(user) + '/api/profiles/1/oauth/connect?client=web', signed.cookie)).json();
  const state = new URL(result.url).searchParams.get('state');
  store.revokeSession(signed.session.id);
  const callback = await request('/oauth/google/callback?code=fake&state=' + encodeURIComponent(state));
  assert.equal(callback.status, 400); assert.match(await callback.text(), /Acesso administrativo expirado/);
  assert.equal(store.getUserProfile(user.id, 1).oauth.refreshTokenEnc, '');
});
after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); });
