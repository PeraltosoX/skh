'use strict';

const $ = id => document.getElementById(id);
const show = (id, on) => $(id)?.classList.toggle('hidden', !on);
const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);

const pageMeta = {
  overview: ['PAINEL ADMINISTRATIVO', 'Visão geral', 'Acompanhe o funcionamento do ChatFlow Peralta.'],
  users: ['CONTAS E PERFIS', 'Usuários e perfis', 'Administre as contas e suas configurações independentes.'],
  'create-user': ['GERENCIAMENTO DE ACESSO', 'Criar usuário', 'Cadastre uma conta ou edite um acesso existente.'],
  keys: ['CONFIRMAÇÃO ADMINISTRATIVA', 'Chaves de verificação', 'Gerencie prioridade, status e consumo das chaves.'],
  activity: ['REGISTROS E SAÚDE', 'Atividade', 'Consulte diagnóstico, eventos e auditoria.'],
  settings: ['SEGURANÇA', 'Configurações', 'Proteja o acesso à administração.']
};

let csrfToken = '';
let authenticated = false;
let activePage = 'overview';
let data = { users: [], globalMonitoring: {}, apiUsageToday: {}, verificationKeys: [], verificationUsageToday: {}, profileDefaults: { defaultCount: 1, maxCount: 50 } };
let details = '';
let loadSequence = 0;
let confirmation = null;
let confirmationPreviousFocus = null;
let selectedUserId = '';
let selectedProfileNumber = 1;
const dirtyForms = new Set();
const formLocks = new Set();
const pendingActions = new Set();
const feedbackTimers = new Map();

function feedback(id, message, ok = false, { source = 'general', autoHide = ok && id !== 'loginFb' } = {}) {
  const element = $(id);
  if (!element) return;
  if (feedbackTimers.has(id)) clearTimeout(feedbackTimers.get(id));
  feedbackTimers.delete(id);
  element.textContent = message || '';
  element.className = `${id === 'globalFb' ? 'global-feedback ' : ''}feedback ${message ? ok ? 'ok' : 'err' : ''}`;
  element.dataset.feedbackSource = message ? source : '';
  if (message && autoHide) {
    const timer = setTimeout(() => {
      if (element.textContent !== message || element.dataset.feedbackSource !== source) return;
      element.textContent = '';
      element.className = `${id === 'globalFb' ? 'global-feedback ' : ''}feedback `;
      element.dataset.feedbackSource = '';
      feedbackTimers.delete(id);
    }, 4000);
    feedbackTimers.set(id, timer);
  }
}

function markClean(formId) {
  dirtyForms.delete(formId);
  if (formId === 'profileForm') $('profileSaveState').textContent = 'Sem alterações pendentes';
}

function setAuthView({ needsSetup = false, loggedIn = false } = {}) {
  show('authArea', !loggedIn);
  show('setup', !loggedIn && needsSetup);
  show('login', !loggedIn && !needsSetup);
  show('dashboard', loggedIn);
  show('logout', loggedIn);
  if (!loggedIn) closeMenu();
}

async function api(url, { method = 'GET', body } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), method === 'DELETE' ? 45000 : 20000);
  try {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
    const response = await fetch(url, {
      method,
      body: body === undefined ? undefined : JSON.stringify(body),
      headers,
      credentials: 'same-origin',
      signal: controller.signal
    });
    let result;
    try { result = await response.json(); }
    catch { throw new Error(`Resposta inválida (HTTP ${response.status}). Confira a URL e o proxy do servidor.`); }
    if (!response.ok || result.ok !== true) {
      if (response.status === 401 && authenticated) {
        authenticated = false;
        csrfToken = '';
        setAuthView({ needsSetup: false, loggedIn: false });
      }
      throw new Error(result.error || `HTTP ${response.status}`);
    }
    return result;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Tempo esgotado. Verifique o servidor e tente novamente.');
    if (error.name === 'TypeError') throw new Error('Não foi possível comunicar com o servidor.');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function bootstrap(expectSession = false) {
  const bootstrapData = await api('/dbmadmin/api/bootstrap');
  authenticated = bootstrapData.authenticated;
  csrfToken = bootstrapData.csrfToken || '';
  setAuthView({ needsSetup: bootstrapData.needsSetup, loggedIn: authenticated });
  if (expectSession && !authenticated) throw new Error('Senha aceita, mas a sessão não foi mantida. Confira o domínio HTTPS e os cookies.');
  if (authenticated) {
    activatePage(activePage);
    await loadData({ busy: true });
  }
}

function bindForm(id, feedbackId, action) {
  const form = $(id);
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (formLocks.has(id)) return;
    const controls = [...form.querySelectorAll('input,select,button')].map(element => ({ element, disabled: element.disabled }));
    const buttons = [...form.querySelectorAll('button[type="submit"],button:not([type])')].map(element => ({ element, label: element.textContent }));
    formLocks.add(id);
    controls.forEach(({ element }) => { element.disabled = true; });
    buttons.forEach(({ element }) => { element.setAttribute('aria-busy', 'true'); element.textContent = 'Aguarde…'; });
    feedback(feedbackId, '');
    try { await action(); }
    catch (error) { feedback(feedbackId, error.message); }
    finally {
      formLocks.delete(id);
      controls.forEach(({ element, disabled }) => { element.disabled = disabled; });
      buttons.forEach(({ element, label }) => { element.removeAttribute('aria-busy'); element.textContent = label; });
      syncPendingActions();
    }
  });
}

function openMenu() {
  $('sidebar').classList.add('open');
  $('menuToggle').setAttribute('aria-expanded', 'true');
  show('navBackdrop', true);
  document.body.classList.add('menu-open');
}

function closeMenu() {
  $('sidebar')?.classList.remove('open');
  $('menuToggle')?.setAttribute('aria-expanded', 'false');
  show('navBackdrop', false);
  document.body.classList.remove('menu-open');
}

function activatePage(name, { focusHeading = false } = {}) {
  if (!pageMeta[name]) name = 'overview';
  activePage = name;
  for (const page of document.querySelectorAll('[data-page]')) {
    const active = page.dataset.page === name;
    page.classList.toggle('hidden', !active);
    page.classList.toggle('active', active);
  }
  for (const button of document.querySelectorAll('[data-page-target]')) {
    const active = button.dataset.pageTarget === name;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  const [eyebrow, title, subtitle] = pageMeta[name];
  $('pageEyebrow').textContent = eyebrow;
  $('pageTitle').textContent = title;
  $('pageSubtitle').textContent = subtitle;
  closeMenu();
  if (focusHeading) {
    $('pageTitle').setAttribute('tabindex', '-1');
    $('pageTitle').focus({ preventScroll: true });
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resolveConfirmation(result) {
  if (!confirmation) return;
  const resolve = confirmation;
  confirmation = null;
  show('confirmModal', false);
  $('dashboard').inert = false;
  document.body.classList.remove('menu-open');
  resolve(result);
  if (confirmationPreviousFocus?.focus) confirmationPreviousFocus.focus();
  confirmationPreviousFocus = null;
}

function askConfirmation({ title = 'Confirmar ação', message, confirmLabel = 'CONFIRMAR', danger = false }) {
  if (confirmation) return Promise.resolve(false);
  confirmationPreviousFocus = document.activeElement;
  $('confirmTitle').textContent = title;
  $('confirmMessage').textContent = message;
  $('confirmAccept').textContent = confirmLabel;
  $('confirmAccept').className = `button ${danger ? 'danger' : 'primary'}`;
  $('confirmIcon').textContent = danger ? '!' : '✓';
  document.querySelector('.confirm-dialog').classList.toggle('danger-mode', danger);
  show('confirmModal', true);
  $('dashboard').inert = true;
  document.body.classList.add('menu-open');
  setTimeout(() => $('confirmCancel').focus(), 0);
  return new Promise(resolve => { confirmation = resolve; });
}

function resetUser() {
  $('userForm').reset();
  $('userId').value = '';
  $('userTitle').textContent = 'Criar usuário';
  $('userFormDescription').textContent = 'A nova conta será criada com o Perfil 1. Outros perfis podem ser adicionados depois.';
  $('userActive').value = 'true';
  markClean('userForm');
}

function resetProfile() {
  $('profileForm').reset();
  $('profileUserId').value = '';
  $('profileNumber').value = '';
  markClean('profileForm');
  feedback('profileFb', '');
  renderUserWorkspace({ fill: true });
}

function statusName(status) {
  return status === 'running' ? 'RODANDO' : status === 'paused' ? 'PAUSADO' : 'PARADO';
}

function dateTime(value) {
  return value ? new Date(value).toLocaleString('pt-BR') : '—';
}

function nextAdditionalProfileNumber(user) {
  const first = (data.profileDefaults?.defaultCount || 1) + 1;
  const maximum = data.profileDefaults?.maxCount || 50;
  const used = new Set((user?.profiles || []).map(profile => profile.profileId));
  for (let number = first; number <= maximum; number++) if (!used.has(number)) return number;
  return null;
}

function actionKey(action, { userId = '', profile = '', keyId = '' } = {}) {
  return [action, userId, profile, keyId].join(':');
}

function actionKeyForButton(button) {
  return actionKey(button.dataset.action, {
    userId: button.dataset.userId || '',
    profile: button.dataset.profile || '',
    keyId: button.dataset.keyId || ''
  });
}

function syncPendingActions() {
  for (const button of document.querySelectorAll('button[data-action]')) {
    const pending = pendingActions.has(actionKeyForButton(button));
    if (pending) {
      button.disabled = true;
      button.dataset.pendingDisabled = 'true';
      button.setAttribute('aria-busy', 'true');
    } else if (button.dataset.pendingDisabled === 'true') {
      button.removeAttribute('data-pending-disabled');
      button.removeAttribute('aria-busy');
      if (button.dataset.staticDisabled !== 'true') button.disabled = false;
    }
  }
}

function renderOverview() {
  const profiles = data.users.flatMap(user => user.profiles || []);
  $('overviewUsers').textContent = data.users.length;
  $('overviewProfiles').textContent = profiles.length;
  $('overviewRunning').textContent = profiles.filter(profile => profile.status === 'running').length;
  $('overviewKeys').textContent = (data.verificationKeys || []).filter(key => key.enabled).length;
}

function renderMonitor(monitoring = {}) {
  if (!dirtyForms.has('monitorForm')) {
    $('monitorSeconds').value = monitoring.intervalSeconds || 180;
    $('chatRetrySeconds').value = monitoring.chatAvailabilityRetrySeconds || 120;
  }
  $('monitorLast').textContent = dateTime(monitoring.lastGlobalScanAt);
  $('monitorNext').textContent = dateTime(monitoring.nextGlobalScanAt);
  $('monitorDuration').textContent = `${monitoring.globalScanDurationMs || 0} ms`;
  $('monitorChatRetry').textContent = `${monitoring.chatAvailabilityRetrySeconds || 120} s`;
  $('monitorChannels').textContent = monitoring.globalChannelsActive || 0;
  $('monitorScheduled').textContent = monitoring.scheduledLivesCount || 0;
  $('monitorLive').textContent = monitoring.liveLivesCount || 0;
  $('apiRequestsToday').textContent = data.apiUsageToday?.requests || 0;
  $('apiLookupsToday').textContent = data.apiUsageToday?.videosList || 0;
  $('apiInsertsToday').textContent = data.apiUsageToday?.liveChatInsert || 0;
  $('apiFailuresToday').textContent = data.apiUsageToday?.failures || 0;
  $('monitorError').textContent = monitoring.lastGlobalScanError || '';
  show('monitorError', !!monitoring.lastGlobalScanError);
}

function verificationStatus(status) {
  return ({ UNTESTED: 'NÃO TESTADA', ACTIVE: 'ATIVA', QUOTA: 'SEM COTA', INVALID: 'INVÁLIDA', ERROR: 'ERRO' })[status] || status || 'NÃO TESTADA';
}

function renderVerificationKeys(keys = []) {
  $('verificationRequestsToday').textContent = data.verificationUsageToday?.requests || 0;
  $('verificationFailuresToday').textContent = data.verificationUsageToday?.failures || 0;
  $('verificationKeys').innerHTML = keys.map(key => {
    const statusClass = key.status === 'ACTIVE' ? 'green' : ['INVALID', 'ERROR'].includes(key.status) ? 'red' : key.status === 'QUOTA' ? 'yellow' : '';
    const primary = key.priority === 1;
    const usage = key.usageToday || {};
    return `<article class="verification-key"><div class="verification-key-head"><div><b>${esc(key.name)}</b><span class="badge ${primary ? 'green' : ''}">${primary ? 'PRINCIPAL' : `RESERVA ${key.priority - 1}`}</span><span class="badge ${statusClass}">${verificationStatus(key.status)}</span><span class="badge ${key.enabled ? 'green' : 'red'}">${key.enabled ? 'HABILITADA' : 'DESABILITADA'}</span></div><code>${esc(key.keyHint)}</code></div><div class="meta">Consultas hoje: ${usage.attempts || 0} • Sucessos: ${usage.successes || 0} • Falhas: ${usage.failures || 0}<br>Último uso: ${dateTime(key.lastUsedAt)}${key.cooldownUntil ? `<br>Nova tentativa após: ${dateTime(key.cooldownUntil)}` : ''}${key.lastError ? `<br><span class="error-inline">${esc(key.lastError)}</span>` : ''}</div><div class="actions"><button data-action="key-test" data-key-id="${esc(key.id)}">TESTAR</button><button class="secondary" data-action="key-primary" data-key-id="${esc(key.id)}" ${primary ? 'disabled data-static-disabled="true"' : ''}>TORNAR PRINCIPAL</button><button class="secondary" data-action="key-toggle" data-key-id="${esc(key.id)}">${key.enabled ? 'DESABILITAR' : 'HABILITAR'}</button><button class="danger" data-action="key-delete" data-key-id="${esc(key.id)}">EXCLUIR</button></div></article>`;
  }).join('') || '<section class="panel-card"><p class="meta">Nenhuma chave cadastrada. O monitor público e as contas dos perfis continuam funcionando, mas não existe confirmação administrativa de um ID conhecido.</p></section>';
  syncPendingActions();
}

function panelLink(user, number = 1, label = 'Abrir painel ↗') {
  return user.active
    ? `<a class="button secondary" href="/dbmadmin/painel/${encodeURIComponent(user.id)}?profile=${number}" target="_blank" rel="noopener">${label}</a>`
    : '<button class="button secondary" disabled data-static-disabled="true" title="Ative o usuário para abrir o painel">Conta bloqueada</button>';
}

function renderUsers(users) {
  const term = $('userSearch').value.trim().toLocaleLowerCase('pt-BR');
  const filtered = term ? users.filter(user => user.username.toLocaleLowerCase('pt-BR').includes(term) || user.profiles.some(profile => profile.name.toLocaleLowerCase('pt-BR').includes(term))) : users;
  $('userCount').textContent = term ? `${filtered.length} de ${users.length} usuários` : `${users.length} ${users.length === 1 ? 'usuário' : 'usuários'}`;
  $('users').innerHTML = filtered.map(user => {
    const running = user.profiles.filter(profile => profile.status === 'running').length;
    return `<button type="button" class="user-overview-row" data-action="user-open" data-user-id="${esc(user.id)}"><span class="user-avatar">${esc(user.username.slice(0, 2).toLocaleUpperCase('pt-BR'))}</span><span class="user-row-info"><strong>${esc(user.username)}</strong><small>${user.profiles.length} ${user.profiles.length === 1 ? 'perfil' : 'perfis'} · ${running} em execução</small></span><span class="badge ${user.active ? 'green' : 'red'}">${user.active ? 'ATIVO' : 'BLOQUEADO'}</span><span class="user-row-detail">Ver usuário e perfis <span class="user-row-chevron">›</span></span></button>`;
  }).join('') || `<p class="meta">${term ? 'Nenhum usuário ou perfil corresponde à pesquisa.' : 'Nenhum usuário cadastrado.'}</p>`;
  renderUserWorkspace();
  syncPendingActions();
}

function selectProfileTab(name) {
  const panels = { general: 'profileGeneral', google: 'profileGoogle', status: 'profileStatus' };
  if (!panels[name]) return;
  for (const [key, id] of Object.entries(panels)) show(id, key === name);
  for (const tab of document.querySelectorAll('.editor-tabs [data-profile-tab]')) {
    const active = tab.dataset.profileTab === name;
    tab.setAttribute('aria-selected', String(active));
    tab.tabIndex = active ? 0 : -1;
  }
}

function fillProfileForm(user, profile) {
  $('profileUserId').value = user.id;
  $('profileNumber').value = String(profile.profileId);
  $('profileName').value = profile.name;
  $('profileGoogleEmail').value = profile.googleEmail || '';
  $('profileClientId').value = profile.clientId || '';
  $('profileClientSecret').value = '';
  $('profileEnabled').value = String(profile.enabled);
  $('clearCredentials').checked = false;
  markClean('profileForm');
}

function renderUserWorkspace({ fill = false } = {}) {
  const user = data.users.find(item => item.id === selectedUserId);
  show('userListPane', !user);
  show('userWorkspace', !!user);
  if (!user) {
    selectedUserId = '';
    $('profileForm').reset();
    $('profileUserId').value = '';
    $('profileNumber').value = '';
    markClean('profileForm');
    show('profileEditor', false);
    return;
  }
  let profile = user.profiles.find(item => item.profileId === selectedProfileNumber);
  if (!profile) {
    profile = user.profiles[0];
    selectedProfileNumber = profile?.profileId || 1;
    markClean('profileForm');
    fill = true;
  }
  $('selectedUserCrumb').textContent = user.username;
  const atLimit = user.profiles.length >= (data.profileDefaults?.maxCount || 50);
  $('selectedUserHeader').innerHTML = `<div class="selected-user-identity"><span class="user-avatar">${esc(user.username.slice(0, 2).toLocaleUpperCase('pt-BR'))}</span><div><span class="eyebrow">CONTA DO USUÁRIO</span><h2>${esc(user.username)}</h2><span class="badge ${user.active ? 'green' : 'red'}">${user.active ? 'ATIVO' : 'BLOQUEADO'}</span><span class="meta"> ${user.profiles.length} ${user.profiles.length === 1 ? 'perfil' : 'perfis'}</span></div></div><div class="user-header-actions">${panelLink(user)}<button type="button" class="button primary compact" data-action="profile-add" data-user-id="${esc(user.id)}" ${atLimit ? 'disabled data-static-disabled="true"' : ''}>+ Adicionar perfil</button><details class="user-more"><summary class="button secondary compact">Mais ações</summary><div class="actions"><button type="button" data-action="user-edit" data-user-id="${esc(user.id)}">Editar conta e senha</button><button type="button" data-action="user-toggle" data-user-id="${esc(user.id)}">${user.active ? 'Bloquear usuário' : 'Ativar usuário'}</button><button type="button" data-action="user-revoke" data-user-id="${esc(user.id)}">Encerrar sessões</button><button type="button" class="danger" data-action="user-delete" data-user-id="${esc(user.id)}">Excluir usuário</button></div></details></div>`;
  $('profilePicker').innerHTML = user.profiles.map(item => `<button type="button" class="profile-pick" data-action="profile-edit" data-user-id="${esc(user.id)}" data-profile="${item.profileId}" aria-pressed="${item.profileId === selectedProfileNumber}"><small>PERFIL ${item.profileId}</small><strong>${esc(item.name)}</strong><span class="badge ${!item.enabled ? 'red' : item.status === 'running' ? 'green' : item.status === 'paused' ? 'yellow' : ''}">${item.enabled ? statusName(item.status) : 'DESABILITADO'}</span></button>`).join('');
  $('profileQuickSelect').innerHTML = user.profiles.map(item => `<option value="${item.profileId}">${esc(item.name)} · Perfil ${item.profileId}</option>`).join('');
  $('profileQuickSelect').value = String(selectedProfileNumber);
  show('profileEditor', !!profile);
  if (!profile) return;
  $('profileContext').textContent = `${user.username} · PERFIL ${profile.profileId}`;
  $('profileEditorTitle').textContent = profile.name;
  if (fill || (!dirtyForms.has('profileForm') && !formLocks.has('profileForm'))) fillProfileForm(user, profile);
  $('profileConnection').innerHTML = `<span class="connection-symbol" aria-hidden="true">G</span><div class="connection-info"><strong>${profile.oauthConnected ? 'YouTube conectado' : 'YouTube não conectado'}</strong><span>${esc(profile.oauthConnected ? profile.oauthEmail || 'Conta autorizada' : 'Abra o painel deste perfil para conectar sua conta.')}</span></div><button type="button" class="text-button" data-profile-tab="google">Ver Google e API</button>`;
  const fields = [
    ['Execução', statusName(profile.status)], ['Perfil', profile.enabled ? 'Habilitado' : 'Desabilitado'],
    ['API OAuth', profile.apiConfigured ? 'Configurada' : 'Não configurada'], ['Google permitido', profile.googleEmail || 'Livre / não definido'],
    ['YouTube', profile.oauthConnected ? `Conectado · ${profile.oauthEmail || 'Conta autorizada'}` : 'Não conectado'],
    ['Mensagens enviadas', profile.sent || 0], ['Falhas', profile.failures || 0], ['Chats ativos', profile.activeChats || 0],
    ['Solicitações API hoje', profile.apiUsageToday?.requests || 0]
  ];
  $('profileSummary').innerHTML = `<dl class="profile-data-grid">${fields.map(([label, value]) => `<div><dt>${esc(label)}</dt><dd>${esc(value)}</dd></div>`).join('')}<div class="wide"><dt>Último erro</dt><dd class="${profile.lastError ? 'error-inline' : ''}">${esc(profile.lastError || 'Nenhum erro registrado')}</dd></div></dl>`;
  $('profilePanelLink').href = `/dbmadmin/painel/${encodeURIComponent(user.id)}?profile=${profile.profileId}`;
  show('profilePanelLink', user.active);
  for (const id of ['profileLogsButton', 'profileDeleteButton']) {
    $(id).dataset.userId = user.id;
    $(id).dataset.profile = String(profile.profileId);
  }
  const permanent = profile.profileId <= (data.profileDefaults?.defaultCount || 1);
  show('profileDeleteButton', !permanent);
  show('permanentProfileNotice', permanent);
  syncPendingActions();
}

async function mayLeaveProfile() {
  if (formLocks.has('profileForm')) {
    feedback('globalFb', 'Aguarde o perfil terminar de salvar.');
    return false;
  }
  if (!dirtyForms.has('profileForm')) return true;
  const accepted = await askConfirmation({ title: 'Descartar alterações?', message: 'Este perfil tem alterações que ainda não foram salvas. Deseja descartá-las para continuar?', confirmLabel: 'DESCARTAR ALTERAÇÕES', danger: true });
  if (accepted) resetProfile();
  return accepted;
}

async function editProfile(userId, number = 1) {
  const user = data.users.find(item => item.id === userId);
  const profile = user?.profiles.find(item => item.profileId === number) || user?.profiles[0];
  if (!profile) return;
  if (selectedUserId === userId && selectedProfileNumber === profile.profileId) return;
  if (!await mayLeaveProfile()) { $('profileQuickSelect').value = String(selectedProfileNumber); return; }
  selectedUserId = userId;
  selectedProfileNumber = profile.profileId;
  markClean('profileForm');
  feedback('profileFb', '');
  selectProfileTab('general');
  renderUserWorkspace({ fill: true });
  activatePage('users');
}

async function loadData({ busy = false } = {}) {
  const sequence = ++loadSequence;
  const refresh = $('refreshBtn');
  if (busy) {
    refresh.disabled = true;
    refresh.setAttribute('aria-busy', 'true');
  }
  try {
    const next = await api('/dbmadmin/api/data');
    if (sequence !== loadSequence) return false;
    data = next;
    renderOverview();
    renderMonitor(data.globalMonitoring);
    renderVerificationKeys(data.verificationKeys || []);
    renderUsers(data.users);
    $('updatedAt').textContent = `Atualizado às ${new Date().toLocaleTimeString('pt-BR')}`;
    if ($('globalFb').dataset.feedbackSource === 'refresh') feedback('globalFb', '');
    return true;
  } catch (error) {
    if (sequence !== loadSequence) return false;
    throw error;
  } finally {
    if (busy && sequence === loadSequence) {
      refresh.disabled = false;
      refresh.removeAttribute('aria-busy');
    }
  }
}

function editUser(userId) {
  const user = data.users.find(item => item.id === userId);
  if (!user) return;
  $('userId').value = user.id;
  $('username').value = user.username;
  $('userPass').value = '';
  $('userActive').value = String(user.active);
  $('userTitle').textContent = 'Editar usuário';
  $('userFormDescription').textContent = `Atualize o acesso de ${user.username}. Deixe a senha vazia para mantê-la.`;
  markClean('userForm');
  activatePage('create-user');
  requestAnimationFrame(() => $('username').focus());
}

const recordLabels = {
  ok: 'Resposta válida', version: 'Versão', node: 'Node.js', storage: 'Armazenamento', schemaVersion: 'Versão do banco',
  https: 'HTTPS', publicBaseUrl: 'Endereço do servidor', redirectUri: 'Retorno Google', workers: 'Perfis em execução',
  users: 'Usuários', globalMonitoring: 'Monitoramento global', apiUsageToday: 'Consumo API hoje',
  administrativeVerification: 'Verificação administrativa', uptimeSeconds: 'Tempo ativo (segundos)',
  actor: 'Responsável', target: 'Alvo', type: 'Tipo', status: 'Status', error: 'Erro', action: 'Ação',
  channel_id: 'Canal', video_id: 'Vídeo', detail: 'Detalhe', details: 'Detalhes', seq: 'Sequência', id: 'Identificador',
  user_id: 'Usuário', profile_id: 'Perfil', profile_number: 'Número do perfil', profileId: 'Perfil'
};
function recordValue(key, item) {
  if (key === 'status') return ({ success: 'Sucesso', info: 'Informação', error: 'Erro', warning: 'Atenção' })[item] || item;
  if (key === 'type') return ({ system: 'Sistema', send: 'Envio', oauth: 'Conta Google', error: 'Erro' })[item] || item;
  return item;
}
function recordFields(value) {
  return `<dl class="record-fields">${Object.entries(value).map(([key, item]) => `<dt>${esc(recordLabels[key] || key)}</dt><dd>${esc(item === null || item === undefined || item === '' ? '—' : typeof item === 'object' ? JSON.stringify(item, null, 2) : typeof item === 'boolean' ? item ? 'Sim' : 'Não' : recordValue(key, item))}</dd>`).join('')}</dl>`;
}
function renderDetails(value) {
  if (!Array.isArray(value)) return recordFields(value);
  if (!value.length) return '<p class="meta">Nenhum registro encontrado.</p>';
  const typeNames = { system: 'Sistema', send: 'Envio de mensagem', oauth: 'Conta Google', error: 'Erro', login: 'Entrada administrativa', user_create: 'Usuário criado', user_update: 'Usuário atualizado', user_profile_update: 'Perfil atualizado', admin_panel_open: 'Painel do usuário aberto' };
  return value.map(entry => {
    const { at, message, ...fields } = entry;
    const type = entry.action || entry.type || 'Registro';
    return `<article class="record-item"><h3>${esc(typeNames[type] || type)}</h3>${at ? `<small>${esc(dateTime(at))}</small>` : ''}${message ? `<p>${esc(message)}</p>` : ''}${recordFields(fields)}</article>`;
  }).join('');
}

function showDetails(title, value, download = false) {
  details = JSON.stringify(value, null, 2);
  $('detailsTitle').textContent = title;
  $('detailsText').textContent = details;
  $('detailsSummary').innerHTML = renderDetails(value);
  $('detailsText').classList.remove('details-empty');
  show('downloadDetails', download);
  activatePage('activity');
  requestAnimationFrame(() => $('detailsPanel').scrollIntoView({ behavior: 'smooth', block: 'start' }));
}

bindForm('setupForm', 'setupFb', async () => {
  await api('/dbmadmin/api/setup', { method: 'POST', body: { setupToken: $('setupToken').value, username: $('setupUser').value, password: $('setupPass').value } });
  $('setupForm').reset();
  await bootstrap(true);
});

bindForm('loginForm', 'loginFb', async () => {
  await api('/dbmadmin/api/login', { method: 'POST', body: { username: $('loginUser').value, password: $('loginPass').value } });
  $('loginPass').value = '';
  activePage = 'overview';
  await bootstrap(true);
  feedback('globalFb', '');
});

bindForm('userForm', 'userFb', async () => {
  const id = $('userId').value;
  const body = { username: $('username').value.trim(), password: $('userPass').value, active: $('userActive').value === 'true' };
  if (!id && !body.password) throw new Error('Informe a senha inicial.');
  const oldUser = id ? data.users.find(user => user.id === id) : null;
  if (oldUser && oldUser.active !== body.active) {
    const accepted = await askConfirmation({
      title: body.active ? 'Ativar usuário?' : 'Bloquear usuário?',
      message: body.active ? `${oldUser.username} voltará a acessar o painel.` : `${oldUser.username} perderá o acesso e os perfis em execução serão interrompidos.`,
      confirmLabel: body.active ? 'ATIVAR' : 'BLOQUEAR',
      danger: !body.active
    });
    if (!accepted) return;
  }
  const result = await api(`/dbmadmin/api/users${id ? `/${encodeURIComponent(id)}` : ''}`, { method: id ? 'PATCH' : 'POST', body });
  resetUser();
  await loadData();
  feedback('globalFb', id ? 'Usuário atualizado.' : 'Usuário criado com o Perfil 1.', true);
  await editProfile(id || result.user.id);
  activatePage('users');
});

bindForm('profileForm', 'profileFb', async () => {
  const userId = $('profileUserId').value;
  const number = Number($('profileNumber').value);
  const oldProfile = data.users.find(user => user.id === userId)?.profiles.find(profile => profile.profileId === number);
  const body = {
    name: $('profileName').value,
    enabled: $('profileEnabled').value === 'true',
    googleEmail: $('profileGoogleEmail').value.trim(),
    clientId: $('clearCredentials').checked ? '' : $('profileClientId').value.trim(),
    clientSecret: $('clearCredentials').checked ? '' : $('profileClientSecret').value,
    clearCredentials: $('clearCredentials').checked
  };
  const identityChanged = !!(body.clientSecret || body.clearCredentials || oldProfile?.googleEmail !== body.googleEmail || oldProfile?.clientId !== body.clientId);
  const disabling = oldProfile?.enabled && !body.enabled;
  if (identityChanged || disabling) {
    const message = disabling
      ? `Desabilitar o Perfil ${number} interrompe sua execução. As configurações permanecem salvas.${identityChanged ? '\n\nAs alterações de API ou Conta Google também desconectarão o YouTube deste perfil.' : ''}`
      : `Alterações de API ou Conta Google desconectam somente o Perfil ${number}.`;
    const accepted = await askConfirmation({ title: `Confirmar alteração do Perfil ${number}?`, message, confirmLabel: 'SALVAR ALTERAÇÃO', danger: disabling });
    if (!accepted) return;
  }
  await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles/${number}`, { method: 'PATCH', body });
  markClean('profileForm');
  $('profileClientSecret').value = '';
  if (await loadData()) renderUserWorkspace({ fill: true });
  feedback('globalFb', `Perfil ${number} atualizado.`, true);
});

bindForm('monitorForm', 'monitorFb', async () => {
  const result = await api('/dbmadmin/api/global-monitor', {
    method: 'PATCH',
    body: { liveDiscoveryIntervalSeconds: Number($('monitorSeconds').value), chatAvailabilityRetrySeconds: Number($('chatRetrySeconds').value) }
  });
  markClean('monitorForm');
  data.globalMonitoring = result.monitoring;
  renderMonitor(result.monitoring);
  feedback('monitorFb', 'Configurações globais salvas.', true);
});

bindForm('verificationKeyForm', 'verificationKeyFb', async () => {
  await api('/dbmadmin/api/verification-keys', {
    method: 'POST',
    body: { name: $('verificationKeyName').value.trim(), apiKey: $('verificationApiKey').value.trim() }
  });
  $('verificationKeyForm').reset();
  markClean('verificationKeyForm');
  await loadData();
  feedback('verificationKeyFb', 'Chave adicionada. Use TESTAR para confirmar a configuração.', true);
});

bindForm('passwordForm', 'passwordFb', async () => {
  const accepted = await askConfirmation({
    title: 'Alterar senha administrativa?',
    message: 'A senha será atualizada e todas as sessões administrativas abertas serão encerradas.',
    confirmLabel: 'ALTERAR SENHA',
    danger: true
  });
  if (!accepted) return;
  await api('/dbmadmin/api/password', { method: 'POST', body: { currentPassword: $('oldAdminPass').value, password: $('newAdminPass').value } });
  $('passwordForm').reset();
  dirtyForms.clear();
  resetUser();
  selectedUserId = '';
  resetProfile();
  await bootstrap();
  feedback('loginFb', 'Senha alterada. Entre novamente.', true);
});

$('logout').addEventListener('click', async () => {
  try { await api('/dbmadmin/api/logout', { method: 'POST', body: {} }); }
  catch (error) { feedback('globalFb', error.message); }
  finally {
    csrfToken = '';
    authenticated = false;
    dirtyForms.clear();
    resetUser();
    selectedUserId = '';
    resetProfile();
    await bootstrap().catch(error => feedback('loginFb', error.message));
  }
});

$('cancelUser').addEventListener('click', resetUser);
$('cancelProfile').addEventListener('click', () => mayLeaveProfile());
$('backToUsers').addEventListener('click', async () => {
  if (!await mayLeaveProfile()) return;
  selectedUserId = '';
  renderUsers(data.users);
});
$('profileQuickSelect').addEventListener('change', () => editProfile(selectedUserId, Number($('profileQuickSelect').value)));
$('profileForm').addEventListener('invalid', event => {
  if (event.target.closest('#profileGoogle')) selectProfileTab('google');
  if (event.target.closest('#profileGeneral')) selectProfileTab('general');
}, true);
document.addEventListener('click', event => {
  const tab = event.target.closest('[data-profile-tab]');
  if (tab) selectProfileTab(tab.dataset.profileTab);
});
document.querySelector('.editor-tabs').addEventListener('keydown', event => {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
  const tabs = [...document.querySelectorAll('.editor-tabs [role="tab"]')];
  const current = tabs.indexOf(document.activeElement);
  if (current < 0) return;
  event.preventDefault();
  const index = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (current + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
  selectProfileTab(tabs[index].dataset.profileTab);
  tabs[index].focus();
});
window.addEventListener('beforeunload', event => {
  if (!dirtyForms.size && !formLocks.size) return;
  event.preventDefault();
  event.returnValue = '';
});
$('menuToggle').addEventListener('click', () => $('sidebar').classList.contains('open') ? closeMenu() : openMenu());
$('navBackdrop').addEventListener('click', closeMenu);
$('confirmCancel').addEventListener('click', () => resolveConfirmation(false));
$('confirmAccept').addEventListener('click', () => resolveConfirmation(true));
document.querySelector('[data-confirm-cancel]').addEventListener('click', () => resolveConfirmation(false));

document.addEventListener('keydown', event => {
  if (confirmation && event.key === 'Tab') {
    const focusable = [...document.querySelector('.confirm-dialog').querySelectorAll('button:not([disabled])')];
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
    return;
  }
  if (event.key === 'Escape') {
    if (confirmation) resolveConfirmation(false);
    else closeMenu();
  }
});

document.addEventListener('click', event => {
  const navigation = event.target.closest('[data-page-target],[data-go-page]');
  if (!navigation) return;
  activatePage(navigation.dataset.pageTarget || navigation.dataset.goPage, { focusHeading: navigation.hasAttribute('data-go-page') });
});

for (const form of document.querySelectorAll('#dashboard form')) {
  const markDirty = event => {
    if (!event.isTrusted) return;
    dirtyForms.add(form.id);
    if (form.id === 'profileForm') $('profileSaveState').textContent = 'Alterações não salvas';
  };
  form.addEventListener('input', markDirty);
  form.addEventListener('change', markDirty);
}

$('userSearch').addEventListener('input', () => renderUsers(data.users));

document.addEventListener('click', async event => {
  const button = event.target.closest('button[data-action]');
  if (!button || button.disabled) return;
  if (formLocks.has('profileForm') && /^(profile|user)-/.test(button.dataset.action)) return;
  const lockKey = actionKeyForButton(button);
  if (pendingActions.has(lockKey)) return;
  pendingActions.add(lockKey);
  syncPendingActions();
  const userId = button.dataset.userId;
  const action = button.dataset.action;
  const number = Number(button.dataset.profile);
  const keyId = button.dataset.keyId;
  try {
    if (action === 'user-open') {
      await editProfile(userId);
    } else if (action === 'key-test') {
      const result = await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}/test`, { method: 'POST', body: {} });
      await loadData();
      feedback('verificationKeyFb', result.message, true);
    } else if (action === 'key-primary') {
      const key = data.verificationKeys.find(item => item.id === keyId);
      if (!key || !await askConfirmation({ title: 'Alterar chave principal?', message: `${key?.name || 'Esta chave'} passará a ser a primeira usada nas confirmações administrativas.`, confirmLabel: 'TORNAR PRINCIPAL' })) return;
      await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}`, { method: 'PATCH', body: { makePrimary: true } });
      await loadData();
      feedback('verificationKeyFb', `${key.name} agora é a chave principal.`, true);
    } else if (action === 'key-toggle') {
      const key = data.verificationKeys.find(item => item.id === keyId);
      if (!key) throw new Error('Chave administrativa não encontrada.');
      const nextEnabled = !key.enabled;
      const accepted = await askConfirmation({
        title: nextEnabled ? 'Habilitar chave?' : 'Desabilitar chave?',
        message: nextEnabled ? `${key.name} voltará à rotação administrativa.` : `${key.name} deixará de ser utilizada nas confirmações até ser habilitada novamente.`,
        confirmLabel: nextEnabled ? 'HABILITAR' : 'DESABILITAR',
        danger: !nextEnabled
      });
      if (!accepted) return;
      await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}`, { method: 'PATCH', body: { enabled: nextEnabled } });
      await loadData();
      feedback('verificationKeyFb', `${key.name} foi ${nextEnabled ? 'habilitada' : 'desabilitada'}.`, true);
    } else if (action === 'key-delete') {
      const key = data.verificationKeys.find(item => item.id === keyId);
      if (!key || !await askConfirmation({ title: 'Excluir chave?', message: `${key?.name || 'A chave'} será removida do servidor e não poderá ser recuperada.`, confirmLabel: 'EXCLUIR CHAVE', danger: true })) return;
      await api(`/dbmadmin/api/verification-keys/${encodeURIComponent(keyId)}`, { method: 'DELETE', body: {} });
      await loadData();
      feedback('verificationKeyFb', `${key.name} foi excluída.`, true);
    } else if (action === 'profile-add') {
      const user = data.users.find(item => item.id === userId);
      const nextNumber = nextAdditionalProfileNumber(user);
      if (!nextNumber) throw new Error('Este usuário já atingiu o limite de perfis.');
      if (!await mayLeaveProfile()) return;
      if (!await askConfirmation({ title: 'Adicionar perfil?', message: `Será criado somente o Perfil ${nextNumber} para ${user.username}.`, confirmLabel: 'ADICIONAR PERFIL' })) return;
      const result = await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles`, { method: 'POST', body: {} });
      await loadData();
      await editProfile(userId, result.profile.profileId);
      feedback('globalFb', `Perfil ${result.profile.profileId} adicionado para ${user.username}.`, true);
    } else if (action === 'profile-edit') {
      await editProfile(userId, number);
    } else if (action === 'profile-logs') {
      const result = await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/logs?profileId=${number}`);
      showDetails(`Últimos registros • Perfil ${number}`, result.logs, true);
    } else if (action === 'profile-delete') {
      const user = data.users.find(item => item.id === userId);
      const profile = user?.profiles.find(item => item.profileId === number);
      const defaultProfiles = data.profileDefaults?.defaultCount || 1;
      if (!user || !profile) throw new Error('Perfil não encontrado.');
      if (number <= defaultProfiles) throw new Error('O Perfil 1 é permanente e não pode ser excluído.');
      const accepted = await askConfirmation({
        title: `Excluir ${profile.name}?`,
        message: `O Perfil ${number} de ${user.username} será parado antes da exclusão. Mensagens, canal, Conta Google, configurações e histórico somente deste perfil serão removidos.`,
        confirmLabel: 'EXCLUIR PERFIL',
        danger: true
      });
      if (!accepted) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/profiles/${number}`, { method: 'DELETE', body: {} });
      markClean('profileForm');
      await loadData();
      feedback('globalFb', `${profile.name} (Perfil ${number}) excluído de ${user.username}.`, true);
    } else if (action === 'user-edit') {
      if (dirtyForms.has('userForm') && !await askConfirmation({ title: 'Descartar edição da conta?', message: 'A conta em edição tem alterações não salvas. Deseja abrir outra edição?', confirmLabel: 'DESCARTAR ALTERAÇÕES', danger: true })) return;
      editUser(userId);
    } else if (action === 'user-toggle') {
      const user = data.users.find(item => item.id === userId);
      if (!user) throw new Error('Usuário não encontrado.');
      const nextActive = !user.active;
      const accepted = await askConfirmation({
        title: nextActive ? 'Ativar usuário?' : 'Bloquear usuário?',
        message: nextActive ? `${user.username} voltará a acessar o painel.` : `${user.username} perderá o acesso e seus perfis em execução serão interrompidos.`,
        confirmLabel: nextActive ? 'ATIVAR' : 'BLOQUEAR',
        danger: !nextActive
      });
      if (!accepted) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}`, { method: 'PATCH', body: { active: nextActive } });
      await loadData();
      feedback('globalFb', `${user.username} foi ${nextActive ? 'ativado' : 'bloqueado'}.`, true);
    } else if (action === 'user-revoke') {
      const user = data.users.find(item => item.id === userId);
      if (!user || !await askConfirmation({ title: 'Encerrar sessões?', message: `As sessões de ${user?.username || 'este usuário'} serão encerradas. Os perfis em execução continuarão funcionando.`, confirmLabel: 'ENCERRAR SESSÕES', danger: true })) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}/revoke`, { method: 'POST', body: {} });
      feedback('globalFb', `Sessões de ${user.username} encerradas.`, true);
    } else if (action === 'user-delete') {
      const user = data.users.find(item => item.id === userId);
      if (!user || !await askConfirmation({ title: `Excluir ${user?.username || 'usuário'}?`, message: 'Todos os perfis serão parados. Conta, perfis, canais, configurações, conexões Google e histórico serão removidos.', confirmLabel: 'EXCLUIR USUÁRIO', danger: true })) return;
      await api(`/dbmadmin/api/users/${encodeURIComponent(userId)}`, { method: 'DELETE', body: {} });
      if ($('userId').value === userId) resetUser();
      markClean('profileForm');
      await loadData();
      feedback('globalFb', `${user.username} foi excluído.`, true);
    }
  } catch (error) {
    if (action.startsWith('key-')) {
      await loadData().catch(() => {});
      feedback('verificationKeyFb', error.message);
    } else {
      feedback('globalFb', error.message);
    }
  } finally {
    pendingActions.delete(lockKey);
    syncPendingActions();
  }
});

$('scanNow').addEventListener('click', async () => {
  if (pendingActions.has('scan-now')) return;
  pendingActions.add('scan-now');
  $('scanNow').disabled = true;
  try {
    const result = await api('/dbmadmin/api/global-monitor/scan', { method: 'POST', body: {} });
    feedback('monitorFb', result.started ? 'Busca global iniciada.' : 'Já existe uma busca global em andamento.', true);
    setTimeout(() => loadData().catch(error => feedback('globalFb', error.message)), 1800);
  } catch (error) {
    feedback('monitorFb', error.message);
  } finally {
    pendingActions.delete('scan-now');
    $('scanNow').disabled = false;
  }
});

$('clearLiveCache').addEventListener('click', async () => {
  if (pendingActions.has('clear-live-cache')) return;
  pendingActions.add('clear-live-cache');
  $('clearLiveCache').disabled = true;
  try {
    const accepted = await askConfirmation({
      title: 'Limpar cache de lives?',
      message: 'Os IDs de chat salvos serão descartados para todos os usuários. O servidor verificará novamente as transmissões antes dos próximos envios. Contas, mensagens, histórico e cotas serão preservados.',
      confirmLabel: 'LIMPAR E VERIFICAR'
    });
    if (!accepted) return;
    const result = await api('/dbmadmin/api/global-monitor/clear-cache', { method: 'POST', body: { confirm: true } });
    feedback('monitorFb', `Cache limpo. ${result.queued ? 'A nova verificação começará após a busca em andamento.' : 'Nova verificação iniciada.'}`, true);
    await loadData();
  } catch (error) { feedback('monitorFb', error.message); }
  finally { pendingActions.delete('clear-live-cache'); $('clearLiveCache').disabled = false; }
});

$('refreshBtn').addEventListener('click', () => loadData({ busy: true }).catch(error => feedback('globalFb', error.message, false, { source: 'refresh', autoHide: false })));
$('diagBtn').addEventListener('click', () => api('/dbmadmin/api/diagnostics').then(result => showDetails('Diagnóstico', result, true)).catch(error => feedback('globalFb', error.message)));
$('eventsBtn').addEventListener('click', () => api('/dbmadmin/api/global-monitor/events').then(result => showDetails('Eventos do monitor global', result.events, true)).catch(error => feedback('globalFb', error.message)));
$('auditBtn').addEventListener('click', () => api('/dbmadmin/api/audit').then(result => showDetails('Auditoria do servidor', result.events, true)).catch(error => feedback('globalFb', error.message)));
$('downloadDetails').addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob([details], { type: 'application/json' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'ChatFlow_Peralta_Registros.json';
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

setInterval(() => {
  if (authenticated && document.visibilityState === 'visible') loadData().catch(error => feedback('globalFb', error.message, false, { source: 'refresh', autoHide: false }));
}, 30000);

bootstrap().catch(error => {
  setAuthView({ needsSetup: false, loggedIn: false });
  feedback('loginFb', error.message);
});
