'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const { chromium } = require('playwright');
// Roteiro opcional: requer Playwright e Chromium; usa apenas dados temporários.
const root = path.resolve(__dirname, '..');
const out = process.env.PANEL_SCREENSHOT_DIR ? path.resolve(process.env.PANEL_SCREENSHOT_DIR) : null;
if (out) fs.mkdirSync(out,{recursive:true});
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-ui-test-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';
const store = require(root + '/lib/store'), security = require(root + '/lib/security');
const bcrypt = require('bcryptjs');
const admin = { id: store.id('adm'), username: 'Admin Teste', passwordHash: bcrypt.hashSync('SenhaTeste2026',4), active: true, sessionVersion: 1 };
store.createFirstAdmin(admin);
const user = store.createUser({ id: store.id('usr'), username: 'Equipe Peralta', active: true, sessionVersion: 1, passwordHash: bcrypt.hashSync('SenhaTeste2026',4) });
store.addUserProfile(user.id); store.addUserProfile(user.id);
store.updateUserProfile(user.id, 1, p => { p.name='Perfil principal'; p.googleEmail='principal@example.invalid'; });
store.updateUserProfile(user.id, 2, p => { p.name='Lives da tarde'; p.googleEmail='tarde@example.invalid'; p.api = { clientId:'test-client.apps.googleusercontent.com', clientSecretEnc:security.encryptText('fake-test-secret'), version:1 }; });
store.updateUserProfile(user.id, 3, p => { p.name='Transmissões especiais'; p.enabled=false; });
const other = store.createUser({ id:store.id('usr'),username:'Equipe de apoio',active:false,sessionVersion:1 });
store.appendLog(store.getUserProfile(user.id,2),'system','Perfil preparado para verificação do painel.','success');
store.appendGlobalEvent('discovery','Consulta de teste concluída: canais atualizados.','success');
store.createAdminVerificationKey({name:'Chave principal de teste',apiKeyEnc:security.encryptText('test-key'),keyHint:'AIza...teste',keyFingerprint:crypto.randomBytes(16).toString('hex')});
const server=require('node:http').createServer().listen(0,'127.0.0.1');
(async()=>{
 await new Promise(resolve=>server.once('listening',resolve));
 const base=`http://127.0.0.1:${server.address().port}`;
 process.env.PUBLIC_BASE_URL=base;
 server.on('request',require(root+'/server').createApp());
 const browser=await chromium.launch({headless:true,...(process.env.PANEL_CHROMIUM_PATH ? {executablePath:process.env.PANEL_CHROMIUM_PATH} : {}),args:['--no-sandbox','--disable-dev-shm-usage','--no-zygote','--single-process','--disable-gpu']});
 const context=await browser.newContext({viewport:{width:1440,height:1050},locale:'pt-BR'});
 await context.route('**/*',route=>new URL(route.request().url()).origin===base ? route.continue() : route.abort());
 const page=await context.newPage();
 const errors=[]; page.on('pageerror',e=>errors.push(e.message)); const checks=[];
 const visible = async selector => assert.equal(await page.locator(selector).isVisible(),true,selector);
 const clean = async label => { const sizes=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth})); assert.ok(sizes.scroll<=sizes.width,`${label}: overflow ${JSON.stringify(sizes)}`); checks.push(label); };
 const snap=async name=>{if (!out) return; await page.screenshot({path:path.join(out,name+'.png'),fullPage:true,animations:'disabled'});};
 const nav = async name => { if(await page.locator('#menuToggle').isVisible()) await page.locator('#menuToggle').click(); await page.locator(`[data-page-target="${name}"]`).click(); };
 try {
 await page.goto(base+'/dbmadmin'); await visible('#login');
 await page.locator('#loginUser').fill('Admin Teste'); await page.locator('#loginPass').fill('SenhaTeste2026'); await page.locator('#loginForm button[type=submit]').click();
 await page.waitForFunction(()=>document.getElementById('overviewUsers').textContent==='2'); await clean('Desktop: visão geral'); await snap('01-visao-geral');
 await nav('users'); await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click(); await visible('#profileEditor'); await clean('Desktop: usuário e perfis'); await snap('02-edicao-perfil');
 await page.locator('[data-action="profile-edit"][data-profile="2"]').click();
 assert.equal(await page.locator('#profileName').inputValue(),'Lives da tarde');
 await page.locator('#profileName').fill('Título em edição');
 await page.locator('#refreshBtn').click(); await page.waitForFunction(()=>!document.getElementById('refreshBtn').disabled);
 assert.equal(await page.locator('#profileName').inputValue(),'Título em edição'); checks.push('Atualização preserva rascunho');
 await page.locator('[data-action="profile-edit"][data-profile="1"]').click(); await visible('#confirmModal'); await page.locator('#confirmCancel').click();
 assert.equal(await page.locator('#profileNumber').inputValue(),'2'); assert.equal(await page.locator('#profileName').inputValue(),'Título em edição'); checks.push('Troca de perfil pode ser cancelada sem perder edição');
 await page.locator('#profileForm button[type=submit]').first().click();
 await page.waitForFunction(()=>document.getElementById('profileSaveState').textContent==='Sem alterações pendentes'&&!document.querySelector('#profileForm button[type=submit]').disabled);
 assert.equal(store.getUserProfile(user.id,2).name,'Título em edição'); assert.equal(store.getUserProfile(user.id,1).name,'Perfil principal'); checks.push('Salvar altera somente o perfil selecionado');
 await page.locator('#profileTabGoogle').click(); await visible('#profileClientId'); assert.equal(await page.locator('#profileClientSecret').inputValue(),''); await snap('03-google-api');
 await page.locator('#profileGoogleEmail').fill('novo@example.invalid'); await page.locator('#profileForm button[type=submit]').first().click(); await visible('#confirmModal'); await page.locator('#confirmCancel').click();
 assert.equal(store.getUserProfile(user.id,2).googleEmail,'tarde@example.invalid'); await page.locator('#cancelProfile').click(); await page.locator('#confirmAccept').click(); assert.equal(await page.locator('#profileGoogleEmail').inputValue(),'tarde@example.invalid'); checks.push('Alterar Google exige confirmação e descartar restaura os dados');
 await page.locator('#profileTabStatus').click(); await visible('#profileSummary'); assert.equal(await page.locator('#profilePanelLink').getAttribute('href'),`/dbmadmin/painel/${user.id}?profile=2`);
 await page.locator('#profileLogsButton').click(); await page.waitForFunction(()=>document.getElementById('detailsSummary').textContent.includes('Perfil preparado')); await snap('04-registros'); checks.push('Registros correspondem ao perfil escolhido');
 await nav('overview'); await page.locator('#monitorSeconds').fill('240'); await page.locator('#monitorForm button[type=submit]').click(); await page.waitForFunction(()=>document.getElementById('monitorFb').textContent.includes('salvas')); assert.equal(store.globalDiscoveryIntervalSeconds(),240); checks.push('Formulário global salva os intervalos existentes');
 await nav('create-user'); await page.locator('#username').fill('Conta criada pelo teste'); await page.locator('#userPass').fill('SenhaInicial2026'); await page.locator('#userForm button[type=submit]').click(); await page.waitForFunction(()=>document.getElementById('selectedUserCrumb').textContent==='Conta criada pelo teste'); assert.equal(await page.locator('#profileNumber').inputValue(),'1'); checks.push('Criar usuário abre sua conta com um perfil');
 await page.locator('.user-more summary').click(); await page.locator('[data-action="user-edit"]').click(); await page.locator('#username').fill('Conta revisada'); await page.locator('#userForm button[type=submit]').click(); await page.waitForFunction(()=>document.getElementById('selectedUserCrumb').textContent==='Conta revisada'); checks.push('Editar conta mantém seus perfis');
 await page.locator('#backToUsers').click(); await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click();
 await nav('keys'); await clean('Desktop: chaves'); await snap('05-chaves'); assert.ok((await page.locator('#verificationKeys').textContent()).includes('Chave principal de teste'));
 await nav('activity'); await page.locator('#diagBtn').click(); await page.waitForFunction(()=>document.getElementById('detailsSummary').textContent.includes('3.1.2-test.1')); await clean('Desktop: atividade');
 await page.locator('#eventsBtn').click(); await page.waitForFunction(()=>document.getElementById('detailsSummary').textContent.includes('Consulta de teste concluída'));
 await page.locator('#auditBtn').click(); await page.waitForFunction(()=>document.getElementById('detailsText').textContent.includes('user_profile_update'));
 await nav('settings'); await clean('Desktop: configurações'); await snap('06-configuracoes');
 await nav('users'); await page.locator('#backToUsers').click(); await page.locator(`[data-action="user-open"][data-user-id="${other.id}"]`).click(); assert.equal(await page.locator('#selectedUserHeader a').count(),0); checks.push('Usuário bloqueado não tem atalho de acesso ativo');
 await page.locator('#backToUsers').click(); await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click(); await page.locator('[data-action="profile-add"]').click(); await page.locator('#confirmAccept').click(); await page.waitForFunction(()=>document.getElementById('profileNumber').value==='4'); checks.push('Adicionar perfil abre sua edição');
 await page.locator('#profileTabStatus').click(); await page.locator('#profileDeleteButton').click(); await page.locator('#confirmAccept').click(); await page.waitForFunction(()=>document.getElementById('profileNumber').value==='1'); assert.equal(store.userProfiles(user.id).length,3); assert.equal(await page.locator('#profileDeleteButton').isVisible(),false); checks.push('Excluir perfil adicional preserva Perfil 1');
 for (const width of [1024,390]) {
   await page.setViewportSize({width,height:1000});
   for (const area of ['overview','users','create-user','keys','activity','settings']) { await nav(area); await clean(`${width}px: ${area}`); if(area==='users') await snap('07-perfil-'+width); }
 }
 await nav('users'); await page.locator('#profileQuickSelect').selectOption('2'); assert.equal(await page.locator('#profileNumber').inputValue(),'2'); checks.push('Seletor de perfil funciona no celular');
 await page.setViewportSize({width:1440,height:1050});
 await page.locator('.trial-banner a').click(); await page.waitForURL('**/dbmadmin/classico'); await page.waitForFunction(()=>!document.getElementById('dashboard').classList.contains('hidden')); assert.equal(await page.locator('script[src^="/admin.js"]').count(),1);
 await nav('users'); assert.ok((await page.locator('#users').textContent()).includes('Título em edição'));
 await page.goto(base+'/dbmadmin'); assert.equal(await page.locator('script[src^="/admin.js"]').count(),1); checks.push('Clássico mantém sessão, dados editados e preferência');
 await page.locator('a[href="/dbmadmin/teste"]').click(); await page.waitForURL('**/dbmadmin/teste'); await page.waitForFunction(()=>!document.getElementById('dashboard').classList.contains('hidden')); checks.push('Retorno à versão teste sem novo login');
 await nav('users'); await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click(); await page.locator('#profileName').fill('Rascunho preservado');
 let unloadType=''; page.once('dialog',async dialog=>{unloadType=dialog.type(); await dialog.dismiss();}); await page.locator('.trial-banner a').click({noWaitAfter:true}); assert.equal(unloadType,'beforeunload'); assert.equal(await page.locator('#profileName').inputValue(),'Rascunho preservado'); checks.push('Troca de visual avisa sobre formulário não salvo');
 await page.locator('#cancelProfile').click(); await page.locator('#confirmAccept').click();

 assert.deepEqual(errors,[]); checks.push('Sem erros JavaScript');
 if (out) fs.writeFileSync(path.join(out,'result.json'),JSON.stringify({ok:true,checks,errors},null,2)); console.log(JSON.stringify({ok:true,checks:checks.length}));
 } catch(e) { await snap('failure').catch(()=>{}); if (out) fs.writeFileSync(path.join(out,'result.json'),JSON.stringify({ok:false,error:e.stack,checks,errors},null,2)); throw e; }
 finally { await browser.close(); server.closeAllConnections(); await new Promise(resolve=>server.close(resolve)); store.close(); fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true}); }
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
