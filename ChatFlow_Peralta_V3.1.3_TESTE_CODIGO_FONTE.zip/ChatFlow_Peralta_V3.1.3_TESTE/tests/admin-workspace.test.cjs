'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(),'chatflow-workspace-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';
const store = require('../lib/store'), security = require('../lib/security'), workspace = require('../lib/admin-workspace');
const { createApp, globalMonitor } = require('../server');
const admin = {id:store.id('adm'),username:'Administrador teste',passwordHash:'test-only',active:true,sessionVersion:1};
store.createFirstAdmin(admin);
const signed=security.signSession(admin.id,'admin',1);store.saveSession(signed.session);
const cookie=`auto_server_admin=${signed.token}`,csrf=security.csrf(signed.session.id);
const realFetch=global.fetch, realScan=globalMonitor.scan;
globalMonitor.scan=async()=>({ok:true});
let server,base,sequence=0,outbound=async()=>new Response('<meta property="og:title" content="Canal simulado">',{status:200});
global.fetch=(url,options)=>String(url).startsWith(base+'/')?realFetch(url,options):outbound(url,options);
before(async()=>{server=createApp().listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));base=`http://127.0.0.1:${server.address().port}`;});
after(async()=>{global.fetch=realFetch;globalMonitor.scan=realScan;server.closeAllConnections();await new Promise(r=>server.close(r));store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});
function account(t){const u=store.createUser({id:store.id('usr'),username:`Teste ${++sequence}`,active:true,sessionVersion:1});store.addUserProfile(u.id);t.after(()=>store.deleteUser(u.id));return u;}
function profile(u,n=2){return workspace.publicProfile(store.getUser(u.id),store.getUserProfile(u.id,n));}
function payload(u,n=2,changes={}){const p=profile(u,n);return {expectedEditVersion:p.editVersion,name:p.name,enabled:p.enabled,googleEmail:p.googleEmail,clientId:p.clientId,clientSecret:'',clearCredentials:false,channelInput:p.channels[0]?.channelInput||'',config:{messages:'Mensagem de teste',sendMode:'interval',intervalMinutes:2,intervalSeconds:5,autoStart:false},...changes};}
const route=(u,n=2)=>`/dbmadmin/api/users/${u.id}/profiles/${n}/workspace`;
async function request(url,{method='GET',body,auth=cookie,token=csrf}={}){return fetch(base+url,{method,headers:{Cookie:auth,'Content-Type':'application/json',...(token?{'X-CSRF-Token':token}:{})},body:body===undefined?undefined:JSON.stringify(body)});}
const save=(u,body,options={})=>request(route(u),{method:'PUT',body,...options});
function channel(u,n,handle){const c=store.upsertGlobalChannel({handle,canonicalUrl:`https://www.youtube.com/${handle}`,originalInput:handle,displayName:'Canal de teste'});store.subscribeChannel(u.id,n,c,handle);return c;}

test('editor completo exige sessão administrativa e CSRF',async t=>{
 const u=account(t),body=payload(u);
 assert.equal((await save(u,body,{auth:''})).status,401);
 assert.equal((await save(u,body,{token:''})).status,403);
 const ordinary=security.signSession(u.id,'user',1);store.saveSession(ordinary.session);
 assert.equal((await save(u,body,{auth:`auto_server_user=${ordinary.token}`})).status,401);
 assert.equal((await request('/dbmadmin/api/activity',{auth:''})).status,401);
 assert.equal(store.getUserProfile(u.id,2).name,'Perfil 2');
});
test('salvar nome, mensagens, horários e canal afeta somente o perfil escolhido',async t=>{
 const u=account(t),other=account(t),first=store.getUserProfile(u.id,1),untouched=store.getUserProfile(other.id,2);
 channel(u,2,'@canalantigo');
 const result=await save(u,payload(u,2,{name:'Edição completa',channelInput:'@canalnovo'}));
 assert.equal(result.status,200,await result.clone().text());
 const p=store.getUserProfile(u.id,2);assert.equal(p.name,'Edição completa');assert.equal(p.config.messages,'Mensagem de teste');assert.equal(p.config.intervalMinutes,2);assert.equal(p.config.intervalSeconds,5);assert.equal(p.runtime.status,'stopped');
 assert.equal(store.profileChannels(u.id,2).length,1);assert.equal(store.profileChannels(u.id,2)[0].channelInput,'@canalnovo');
 assert.deepEqual(store.getUserProfile(u.id,1),first);assert.deepEqual(store.getUserProfile(other.id,2),untouched);
 assert.equal((await result.json()).profile.editVersion,profile(u).editVersion);
});
test('validações rejeitam a edição inteira antes de alterar os dados',async t=>{
 const u=account(t),before=store.getUserProfile(u.id,2);
 for(const changes of [{config:{messages:'a'.repeat(201)}},{channelInput:'https://example.invalid/canal'},{clientId:'fake.apps.googleusercontent.com',clientSecret:''}]){
  const r=await save(u,payload(u,2,{name:'Não deve salvar',...changes}));assert.equal(r.status,400,await r.text());assert.deepEqual(store.getUserProfile(u.id,2),before);
 }
});
test('falha ao trocar canal reverte nome, configurações e inscrição anterior',async t=>{
 const u=account(t);channel(u,2,'@anterior');const before=store.getUserProfile(u.id,2),subs=store.profileChannels(u.id,2);
 const original=store.subscribeChannel;store.subscribeChannel=()=>{const e=new Error('Falha simulada');e.status=409;throw e;};
 try{const r=await save(u,payload(u,2,{name:'Não salvar parcialmente',channelInput:'@substituto'}));assert.equal(r.status,409);}finally{store.subscribeChannel=original;}
 assert.deepEqual(store.getUserProfile(u.id,2),before);assert.deepEqual(store.profileChannels(u.id,2),subs);
 assert.equal((await save(u,payload(u,2,{name:'Transação recuperada'}))).status,200);
});
test('duas guias não sobrescrevem configurações nem mudanças de identidade',async t=>{
 const u=account(t),old=payload(u);
 assert.equal((await save(u,{...old,name:'Primeira guia'})).status,200);
 const r=await save(u,{...old,name:'Segunda guia'});assert.equal(r.status,409);assert.equal(store.getUserProfile(u.id,2).name,'Primeira guia');
 const newer=payload(u);store.updateUserProfile(u.id,2,p=>{p.name='Alterado pelo clássico';});
 assert.equal((await save(u,newer)).status,409);
});
test('contadores em tempo real não invalidam o rascunho do administrador',async t=>{
 const u=account(t),body=payload(u);store.updateUserProfile(u.id,2,p=>{p.runtime.sent=7;p.runtime.nextAt=store.now();});
 assert.equal((await save(u,body)).status,200);assert.equal(store.getUserProfile(u.id,2).runtime.sent,7);
});
test('conflito durante consulta assíncrona de canal também preserva a edição mais nova',async t=>{
 const u=account(t);let release,entered;const ready=new Promise(r=>entered=r),original=outbound;
 outbound=async()=>{entered();await new Promise(r=>release=r);return new Response('<html></html>',{status:200});};
 const pending=save(u,payload(u,2,{name:'Consulta antiga',channelInput:'@canaldemorado'}));
 try{await ready;store.updateUserProfile(u.id,2,p=>{p.name='Nova edição';});release();const r=await pending;assert.equal(r.status,409);assert.equal(store.getUserProfile(u.id,2).name,'Nova edição');assert.equal(store.profileChannels(u.id,2).length,0);}finally{outbound=original;release?.();}
});
test('atividade filtra no banco antes do limite e identifica corretamente conta e perfil',async t=>{
 const u=account(t),other=account(t),p=store.getUserProfile(u.id,2);
 store.appendLog(p,'send','Registro exclusivo','error','Falha simulada');
 for(let i=0;i<505;i++)store.appendLog(store.getUserProfile(other.id,1),'system','Registro de outra conta');
 const result=await (await request(`/dbmadmin/api/activity?source=profiles&userId=${u.id}&profileId=2&status=error&search=exclusivo`)).json();
 assert.equal(result.events.length,1);assert.equal(result.events[0].username,u.username);assert.equal(result.events[0].profileName,'Perfil 2');assert.equal(result.truncated,false);
 store.audit(admin.id,'user_profile_update',`${u.id}:2`);
 const audit=await (await request(`/dbmadmin/api/activity?source=audit&userId=${u.id}&profileId=2`)).json();assert.equal(audit.events.length,1);assert.equal(audit.events[0].actorName,admin.username);
 const all=await (await request('/dbmadmin/api/activity')).json();assert.equal(all.events.length,500);assert.equal(all.truncated,true);
 const future=await (await request(`/dbmadmin/api/activity?userId=${u.id}&from=2099-01-01`)).json();assert.equal(future.events.length,0);
 assert.equal((await request('/dbmadmin/api/activity?from=2099-01-01&to=2000-01-01')).status,400);
 assert.equal((await request('/dbmadmin/api/activity?profileId=2')).status,400);
});
test('histórico de chaves distingue teste manual, consulta e último sucesso sem revelar chave',async t=>{
 const secret='AIza'+crypto.randomBytes(24).toString('hex');
 const key=store.createAdminVerificationKey({name:'Chave simulada',apiKeyEnc:security.encryptText(secret),keyHint:'AIza...simulada',keyFingerprint:crypto.randomBytes(20).toString('hex')});
 t.after(()=>store.deleteAdminVerificationKey(key.id));const original=outbound;
 try{
  outbound=async()=>new Response(JSON.stringify({items:[]}),{status:200});
  assert.equal((await request(`/dbmadmin/api/verification-keys/${key.id}/test`,{method:'POST',body:{}})).status,200);
  let body=await (await request(`/dbmadmin/api/verification-keys/${key.id}/history`)).json();assert.equal(body.key.lastTest.status,'ACTIVE');assert.ok(body.key.lastSuccessAt);const success=body.key.lastSuccessAt;
  outbound=async()=>new Response(JSON.stringify({error:{message:'Quota simulada',errors:[{reason:'quotaExceeded'}]}}),{status:403});
  assert.equal((await request(`/dbmadmin/api/verification-keys/${key.id}/test`,{method:'POST',body:{}})).status,422);
  body=await (await request(`/dbmadmin/api/verification-keys/${key.id}/history`)).json();assert.equal(body.key.lastTest.status,'QUOTA');assert.equal(body.key.lastSuccessAt,success);assert.equal(body.events.filter(e=>e.kind==='test').length,2);assert.ok(body.events.some(e=>e.kind==='verification'));assert.ok(!JSON.stringify(body).includes(secret));
  for(let i=0;i<205;i++)store.recordAdminKeyCheck(key.id,'verification','ACTIVE');
  assert.equal(store.publicAdminVerificationKey(store.getAdminVerificationKey(key.id)).lastTest.status,'QUOTA');assert.equal(store.adminKeyHistory(key.id).length,50);
 }finally{outbound=original;}
});
test('visão geral relata pendências reais sem expor segredos nem mudar execução',async t=>{
 const u=account(t);assert.equal(profile(u).operation.code,'setup');
 store.updateUserProfile(u.id,2,p=>{p.api={clientId:'client.apps.googleusercontent.com',clientSecretEnc:security.encryptText('segredo'),version:1};});assert.equal(profile(u).operation.code,'google');
 store.updateUserProfile(u.id,2,p=>{p.oauth.refreshTokenEnc=security.encryptText('token');p.config.messages='Olá';});assert.equal(profile(u).operation.code,'channel');
 channel(u,2,'@pendencias');assert.equal(profile(u).operation.code,'stopped');
 store.updateUserProfile(u.id,2,p=>{p.runtime.status='running';});assert.equal(profile(u).operation.code,'live');
 store.updateUserProfile(u.id,2,p=>{p.runtime.sendRecoveryPending=true;});assert.equal(profile(u).operation.code,'recovery');
 const current=store.getUserProfile(u.id,2),body=await (await request('/dbmadmin/api/data')).json();
 assert.deepEqual(store.getUserProfile(u.id,2),current);assert.ok(!JSON.stringify(body).includes(current.oauth.refreshTokenEnc));assert.ok(!JSON.stringify(body).includes(current.api.clientSecretEnc));
});
