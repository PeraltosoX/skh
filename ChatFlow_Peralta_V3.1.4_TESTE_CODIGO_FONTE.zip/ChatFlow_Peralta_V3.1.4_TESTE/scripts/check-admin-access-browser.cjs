'use strict';
// Teste opcional com Playwright e Chromium. Só dados sintéticos e servidor local.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const http = require('node:http');
const { chromium } = require('playwright');

async function main() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-admin-browser-'));
  process.env.DATA_DIR = directory;
  process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
  process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
  process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
  process.env.NODE_ENV = 'test';
  const server = http.createServer();
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  process.env.PUBLIC_BASE_URL = base;
  const store = require('../lib/store');
  const security = require('../lib/security');
  server.on('request', require('../server').createApp());
  let browser;
  try {
    const admin = { id: store.id('adm'), username: 'Administrador teste', active: true, sessionVersion: 1, passwordHash: 'test-only' };
    store.createFirstAdmin(admin);
    const users = ['Usuário 1', 'Usuário 2', 'Login comum'].map(username => store.createUser({ id: store.id('usr'), username, active: true, sessionVersion: 1 }));
    store.addUserProfile(users[0].id);
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'], ...(process.env.PANEL_CHROMIUM_PATH ? { executablePath: process.env.PANEL_CHROMIUM_PATH } : {}) });
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, locale: 'pt-BR' });
    const errors = [];
    context.on('page', page => page.on('pageerror', error => errors.push(error.message)));
    await context.route('**/*', route => new URL(route.request().url()).origin === base ? route.continue() : route.abort());
    for (const [subject, kind] of [[admin, 'admin'], [users[2], 'user']]) {
      const signed = security.signSession(subject.id, kind, subject.sessionVersion); store.saveSession(signed.session);
      await context.addCookies([{ name: `auto_server_${kind}`, value: signed.token, domain: '127.0.0.1', path: kind === 'admin' ? '/dbmadmin' : '/', httpOnly: true, sameSite: 'Strict' }]);
    }
    const page = await context.newPage();
    await page.goto(base + '/dbmadmin/classico');
    await page.locator('button[data-page-target="users"]').click();
    const firstCard = page.locator('.user-card').filter({ has: page.locator('h3', { hasText: 'Usuário 1' }) });
    const popupPromise = context.waitForEvent('page');
    await firstCard.locator('a').filter({ hasText: /^ABRIR PAINEL$/ }).click();
    const first = await popupPromise;
    await first.locator('#adminAccessBanner').waitFor({ state: 'visible' });
    assert.equal(await first.locator('#currentUsername').textContent(), 'Usuário 1');
    assert.equal(await first.locator('#loginPanel').isVisible(), false);
    const secondCard = page.locator('.user-card').filter({ has: page.locator('h3', { hasText: 'Usuário 2' }) });
    const nextPopup = context.waitForEvent('page');
    await secondCard.locator('a').filter({ hasText: /^ABRIR PAINEL$/ }).click();
    const second = await nextPopup;
    await second.locator('#adminAccessBanner').waitFor({ state: 'visible' });
    assert.equal(await second.locator('#currentUsername').textContent(), 'Usuário 2');
    await first.locator('#refreshButton').click();
    assert.equal(await first.locator('#currentUsername').textContent(), 'Usuário 1');
    const profilePopup = context.waitForEvent('page');
    await firstCard.locator('a[href$="profile=2"]').click();
    const profile = await profilePopup;
    await profile.locator('#quotaProfileName').filter({ hasText: 'Perfil 2' }).waitFor();
    await profile.locator('#renameProfileButton').click();
    await profile.locator('#profileNameInput').fill('Perfil revisado pelo admin');
    await profile.locator('#profileNameForm button[type="submit"]').click();
    await profile.locator('#quotaProfileName').filter({ hasText: 'Perfil revisado pelo admin' }).waitFor();
    assert.equal(store.getUserProfile(users[0].id, 2).name, 'Perfil revisado pelo admin');
    assert.equal(store.getUserProfile(users[1].id, 1).name, 'Perfil 1');
    const normal = await context.newPage(); await normal.goto(base + '/painel');
    await normal.locator('#dashboard').waitFor({ state: 'visible' });
    assert.equal(await normal.locator('#currentUsername').textContent(), 'Login comum');
    assert.equal(await normal.locator('#adminAccessBanner').isVisible(), false);
    console.log('OK: atalhos por usuário/perfil, edição isolada, abas simultâneas e login comum preservado.');
    if (process.env.PANEL_SCREENSHOT_DIR) {
      fs.mkdirSync(process.env.PANEL_SCREENSHOT_DIR, { recursive: true });
      await page.screenshot({ path: path.join(process.env.PANEL_SCREENSHOT_DIR, 'admin-atalhos-desktop.png'), fullPage: true });
      await first.screenshot({ path: path.join(process.env.PANEL_SCREENSHOT_DIR, 'painel-acesso-admin-desktop.png'), fullPage: true });
    }
    await first.setViewportSize({ width: 390, height: 844 });
    assert.ok(await first.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await first.locator('#adminReturnButton').isVisible(), true);
    await page.setViewportSize({ width: 390, height: 844 });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    if (process.env.PANEL_SCREENSHOT_DIR) await first.screenshot({ path: path.join(process.env.PANEL_SCREENSHOT_DIR, 'painel-acesso-admin-mobile.png'), fullPage: true });
    await first.locator('#adminReturnButton').click();
    await first.waitForURL(base + '/dbmadmin');
    console.log('OK: desktop/celular sem rolagem horizontal e retorno ao administrativo.');
    // Revogação do administrador alcança todas as abas, sem apagar a sessão comum.
    store.revokeSessions(admin.id);
    assert.equal((await second.request.get(base + `/dbmadmin/painel/${users[1].id}/api/me`)).status(), 401);
    assert.equal((await normal.request.get(base + '/api/me')).status(), 200);
    assert.deepEqual(errors, []);
    console.log('OK: revogação imediata, sem erros JavaScript.');
  } finally {
    await browser?.close(); server.closeAllConnections();
    await new Promise(resolve => server.close(resolve)); store.close();
    fs.rmSync(directory, { recursive: true, force: true });
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
