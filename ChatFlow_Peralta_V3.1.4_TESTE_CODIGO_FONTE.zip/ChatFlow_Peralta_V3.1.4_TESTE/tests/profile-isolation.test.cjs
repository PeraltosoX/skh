'use strict';
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-isolation-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
const store = require('../lib/store');
const { createWorkers } = require('../lib/workers');
let sequence = 0;
function fixture(t, count = 2) {
  const serial = ++sequence;
  const user = store.createUser({ id: store.id('usr'), username: `Isolamento ${serial}`, active: true, sessionVersion: 1 });
  const channel = store.upsertGlobalChannel({ channelId: `UC${String(serial).padStart(22, '0')}`, handle: `@Isolation${serial}`, canonicalUrl: `https://www.youtube.com/@Isolation${serial}` });
  for (let number = 1; number <= count; number++) {
    if (number > 1) store.addUserProfile(user.id);
    store.updateUserProfile(user.id, number, profile => {
      profile.api = { clientId: `client-${number}`, clientSecretEnc: 'test-only', version: 1 };
      profile.oauth.refreshTokenEnc = 'test-only';
      profile.oauth.email = `profile${number}@example.invalid`;
      profile.config.messages = `Mensagem ${number}`;
      profile.runtime.status = 'running';
    });
    store.subscribeChannel(user.id, number, channel, channel.handle);
  }
  const live = store.upsertGlobalLive(channel.id, { videoId: `I${String(serial).padStart(10, '0')}`, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', activeLiveChatId: 'CHAT-OK', resolved: true, chatVerifiedAt: new Date().toISOString() }).live;
  store.distributeLive(live.id);
  t.after(() => store.deleteUser(user.id));
  return { user, live };
}
const turn = () => new Promise(resolve => setImmediate(resolve));
function deferred() { let resolve; const promise = new Promise(done => { resolve = done; }); return { promise, resolve }; }
function api(send, lookup = () => {}) {
  return {
    async getLiveStates(_profile, _api, ids, options) {
      options.onApiRequest(); lookup();
      return ids.map(videoId => ({ videoId, liveStatus: 'LIVE', chatStatus: 'AVAILABLE', activeLiveChatId: 'CHAT-OK', resolved: true }));
    },
    sendLiveChatMessage: send
  };
}

test('perfil lento não impede outro perfil de enviar na mesma live', async t => {
  const { user } = fixture(t);
  const blocked = deferred(), entered = deferred(), sent = [];
  const worker = createWorkers({ api: api(async (profile, _api, _chat, _message, options) => {
    if (profile.profileNumber === 1) { entered.resolve(); await blocked.promise; }
    options.beforeSend(); options.onApiRequest(); sent.push(profile.profileNumber);
  }) });
  const first = worker.step(user.id, 1);
  await entered.promise;
  const second = worker.step(user.id, 2);
  await turn();
  const healthySentBeforeRelease = sent.includes(2);
  blocked.resolve(); await Promise.all([first, second]); await worker.shutdown();
  assert.equal(healthySentBeforeRelease, true);
  assert.deepEqual([...sent].sort(), [1, 2]);
});

test('403 de um perfil não cancela envio saudável aguardando o token e só ele reconfirma', async t => {
  const { user, live } = fixture(t);
  const blocked = deferred(); let at = Date.now(), checks = 0;
  const sent = [];
  const worker = createWorkers({ clock: () => at, api: api(async (profile, _api, _chat, _message, options) => {
    if (profile.profileNumber === 2) await blocked.promise;
    options.beforeSend(); options.onApiRequest();
    if (profile.profileNumber === 1) throw Object.assign(new Error('Permission denied'), { status: 403, reason: 'forbidden' });
    sent.push(profile.profileNumber);
  }, () => checks++) });
  const first = worker.step(user.id, 1), second = worker.step(user.id, 2);
  await first; blocked.resolve(); await second;
  const freshAfterError = store.chatVerificationFresh(store.getGlobalLive(live.id), at);
  const failures = store.getUserProfile(user.id, 1).runtime.failures;
  at += 181000;
  // Mantém o cache global fresco para provar que a reconfirmação é do perfil.
  store.cacheGlobalLiveChatId(live.id, 'CHAT-OK', at);
  await worker.step(user.id, 1); await worker.shutdown();
  assert.deepEqual(sent, [2]);
  assert.equal(freshAfterError, true);
  assert.equal(failures, 1);
  assert.equal(checks, 1);
});

test('50 perfis usam credenciais e mensagens próprias em uma live', async t => {
  const { user } = fixture(t, 50); const sent = [];
  const worker = createWorkers({ api: api(async (profile, credentials, _chat, message, options) => {
    options.beforeSend(); options.onApiRequest();
    assert.equal(credentials.clientId, `client-${profile.profileNumber}`);
    assert.equal(message, `Mensagem ${profile.profileNumber}`);
    sent.push(profile.profileNumber);
  }) });
  await Promise.all(Array.from({ length: 50 }, (_, i) => worker.step(user.id, i + 1)));
  await worker.shutdown();
  assert.equal(new Set(sent).size, 50);
  for (let number = 1; number <= 50; number++) assert.equal(store.getUserProfile(user.id, number).runtime.sent, 1);
});

test('passos concorrentes do mesmo perfil não repetem a mensagem', async t => {
  const { user } = fixture(t, 1); let sent = 0;
  const worker = createWorkers({ api: api(async (_profile, _api, _chat, _message, options) => {
    options.beforeSend(); options.onApiRequest(); await turn(); sent++;
  }) });
  await Promise.all([worker.step(user.id, 1), worker.step(user.id, 1)]);
  await worker.shutdown(); assert.equal(sent, 1);
});
after(() => { store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); });
