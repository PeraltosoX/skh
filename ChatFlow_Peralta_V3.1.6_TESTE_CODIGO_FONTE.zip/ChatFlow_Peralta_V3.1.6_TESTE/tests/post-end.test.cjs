'use strict';
const {test,after}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'chatflow-post-end-'));
process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL='http://localhost:8080';process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security');
const {createWorkers}=require('../lib/workers');
const {operation}=require('../lib/admin-workspace');
let serial=0;
after(()=>{store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});
function fixture(t,{profiles=1}={}){
 const n=++serial,user=store.createUser({id:store.id('usr'),username:`Fim ${n}`,active:true,sessionVersion:1});
 const channel=store.upsertGlobalChannel({channelId:`UC${String(n).padStart(22,'0')}`,handle:`@Fim${n}`,canonicalUrl:`https://www.youtube.com/@Fim${n}`});
 let now=Date.now();const start=now,calls=[];let send=()=>{};
 for(let i=1;i<=profiles;i++){
  if(i>1)store.addUserProfile(user.id);
  store.updateUserProfile(user.id,i,p=>{p.api={clientId:'test.apps.googleusercontent.com',clientSecretEnc:security.encryptText('fake-secret'),version:1};p.oauth.refreshTokenEnc=security.encryptText('fake-refresh');p.config.messages=`Mensagem ${i}`;p.config.intervalMinutes=1;p.config.intervalSeconds=1;p.runtime.status='running';});
  store.subscribeChannel(user.id,i,channel,channel.handle);
 }
 const videoId=`E${String(n).padStart(10,'0')}`;
 const live=store.upsertGlobalLive(channel.id,{videoId,liveStatus:'LIVE',chatStatus:'AVAILABLE',activeLiveChatId:`CHAT-${videoId}`,chatVerifiedAt:new Date(now).toISOString(),resolved:true},now).live;
 store.distributeLive(live.id);
 const api={getLiveStates:async()=>{throw Error('Não consultar metadados de vídeo encerrado');},getActiveLiveChatId:async()=>{throw Error('Não buscar outro ID no período adicional');},
  sendLiveChatMessage:async(p,_credentials,chat,message,options)=>{await send(p,options);options.beforeSend();options.onApiRequest();calls.push({userId:p.userId,profile:p.profileNumber,chat,message,at:now});return {};}};
 const workers=createWorkers({storage:store,api,clock:()=>now});
 t.after(async()=>{await workers.shutdown();store.deleteUser(user.id);});
 const ended=(at=now,changes={})=>store.upsertGlobalLive(channel.id,{videoId,liveStatus:'ENDED',chatStatus:'ENDED',actualEndTime:new Date(at).toISOString(),resolved:true,...changes},now).live;
 return {user,channel,live,videoId,workers,api,calls,start,get now(){return now;},at(value){now=value;},onSend(fn){send=fn;},ended,state(i=1){return store.profileLiveStates(user.id,i).find(x=>x.videoId===videoId);},step(i=1){return workers.step(user.id,i);}};
}

test('continua no mesmo chat sem aumentar a frequência e encerra exatamente aos dez minutos',async t=>{
 const f=fixture(t);await f.step();assert.equal(f.calls.length,1);
 f.at(f.start+10000);f.ended();assert.equal(f.state().sendStatus,'FINISHING');
 assert.equal(operation(store.getUser(f.user.id),store.getUserProfile(f.user.id,1),store.profileChannels(f.user.id,1),f.now).code,'finishing');
 for(let i=11;i<61;i++){f.at(f.start+i*1000);await f.step();}
 assert.equal(f.calls.length,1,'polls não antecipam o intervalo');
 f.at(f.start+61000);await f.step();assert.equal(f.calls.length,2);assert.equal(f.calls[1].chat,f.calls[0].chat);
 const deadline=Date.parse(store.getGlobalLive(f.live.id).post_end_deadline);
 f.at(deadline-1);await f.step();assert.equal(f.calls.length,3);
 f.at(deadline);await f.step();assert.equal(f.calls.length,3);assert.equal(f.state().sendStatus,'FINALIZED');
 assert.equal(store.canSendLiveState(f.state().id,f.user.id,1,f.videoId,deadline),false);
});

test('consultas repetidas, sinal antigo ao vivo e reinício não renovam o prazo',async t=>{
 const f=fixture(t);await f.step();f.ended();const deadline=store.getGlobalLive(f.live.id).post_end_deadline;
 f.at(f.start+200000);f.ended(f.now);f.ended(f.now,{liveStatus:'LIVE',chatStatus:'AVAILABLE',activeLiveChatId:'OUTRO-ID'});
 assert.equal(store.getGlobalLive(f.live.id).post_end_deadline,deadline);assert.equal(store.getGlobalLive(f.live.id).active_live_chat_id,`CHAT-${f.videoId}`);
 const code=`const s=require('./lib/store');const live=s.getGlobalLive(${JSON.stringify(f.live.id)});console.log(JSON.stringify({deadline:live.post_end_deadline,inside:s.chatVerificationFresh(live,${f.start+300000}),outside:s.chatVerificationFresh(live,${f.start+600000})}));s.close();`;
 const child=spawnSync(process.execPath,['-e',code],{cwd:path.join(__dirname,'..'),env:process.env,encoding:'utf8'});
 assert.equal(child.status,0,child.stderr);assert.deepEqual(JSON.parse(child.stdout.trim()),{deadline,inside:true,outside:false});
 f.at(f.start+600000);f.ended();assert.equal(store.getGlobalLive(f.live.id).active_live_chat_id,'');assert.ok(store.getGlobalLive(f.live.id).finalized_at);
});

test('perfis parados, pausados antes do fim, desabilitados e lives antigas não começam a enviar',async t=>{
 const f=fixture(t,{profiles:4});
 store.updateUserProfile(f.user.id,2,p=>{p.runtime.status='stopped';p.config.autoStart=true;});
 f.workers.pause(f.user.id,3);store.updateUserProfile(f.user.id,4,p=>{p.enabled=false;});
 f.ended();assert.equal(f.state(1).sendStatus,'FINISHING');
 for(const number of [2,3,4]){assert.equal(f.state(number).sendStatus,'FINALIZED');store.activateProfileLives(f.user.id,number,f.now);await f.step(number);}
 assert.equal(f.calls.length,0);await f.step(1);assert.equal(f.calls.length,1);
 const old=store.upsertGlobalLive(f.channel.id,{videoId:'Z0000000001',liveStatus:'ENDED',chatStatus:'ENDED',actualEndTime:new Date(f.now).toISOString(),resolved:true},f.now).live;
 assert.equal(old.post_end_deadline,null);assert.ok(old.finalized_at);assert.deepEqual(store.distributeLive(old.id),[]);
});

test('endTime antigo limita a janela e um horário futuro não concede mais de dez minutos',async t=>{
 const f=fixture(t);f.ended(f.start-600000);assert.equal(f.state().sendStatus,'FINALIZED');await f.step();assert.equal(f.calls.length,0);
 const g=fixture(t);g.ended(g.start+3600000);assert.equal(Date.parse(store.getGlobalLive(g.live.id).post_end_deadline),g.start+600000);
});

for(const reason of ['liveChatEnded','liveChatDisabled','liveChatNotFound'])test(`YouTube ${reason} encerra o chat para todos sem reabrir no próximo poll`,async t=>{
 const f=fixture(t,{profiles:2});f.ended();
 f.api.sendLiveChatMessage=async(_p,_c,_chat,_msg,options)=>{options.beforeSend();options.onApiRequest();throw Object.assign(Error(reason),{reason,status:reason==='liveChatNotFound'?404:403});};
 await f.step();assert.ok(store.getGlobalLive(f.live.id).finalized_at);assert.equal(f.state(2).sendStatus,'FINALIZED');
 for(const number of [1,2]){
  const messages=store.logs(f.user.id,number,50).filter(entry=>entry.type==='live' && entry.message.includes('Envios nesta live finalizados:'));
  assert.equal(messages.length,1,'cada perfil recebe seu próprio aviso de encerramento');
  assert.ok(messages[0].message.includes(f.videoId));assert.equal(messages[0].status,'info');
 }
 f.ended();assert.equal(store.getGlobalLive(f.live.id).active_live_chat_id,'');
 f.api.sendLiveChatMessage=async()=>{assert.fail('chat encerrado não pode receber outra tentativa');};await f.step(2);
 store.finalizeMissingLive(f.live.id,'Confirmação repetida.',f.now);
 for(const number of [1,2])assert.equal(store.logs(f.user.id,number,50).filter(entry=>entry.type==='live' && entry.message.includes('Envios nesta live finalizados:')).length,1,'polls e confirmações repetidas não duplicam o aviso');
});

test('aviso final chega a outros usuários da mesma live, sem atingir outro chat',async t=>{
 const f=fixture(t,{profiles:2}),g=fixture(t,{profiles:2});
 store.removeSubscription(g.user.id,2,store.profileChannels(g.user.id,2)[0].id);
 store.subscribeChannel(g.user.id,2,f.channel,f.channel.handle);store.distributeLive(f.live.id);
 f.ended();
 store.finalizeMissingLive(f.live.id,'O YouTube confirmou o encerramento do chat.',f.now);
 assert.equal(store.logs(g.user.id,2,50).filter(entry=>entry.type==='live' && entry.message.includes(f.videoId)).length,1);
 assert.equal(g.state().sendStatus,'ACTIVE');await g.step();assert.equal(g.calls.length,1);
 assert.equal(store.logs(g.user.id,1,50).filter(entry=>entry.type==='live' && entry.message.includes(g.videoId)).length,0);
});

test('fim dos dez minutos registra a causa em todos sem repetir no próximo ciclo',async t=>{
 const f=fixture(t,{profiles:2});f.ended();f.at(f.start+600000);
 store.finalizeExpiredLives(f.now);store.finalizeExpiredLives(f.now+1000);
 for(const number of [1,2]){
  const messages=store.logs(f.user.id,number,50).filter(entry=>entry.type==='live' && entry.message.includes('Período adicional encerrado.'));
  assert.equal(messages.length,1);assert.equal(f.state(number).sendStatus,'FINALIZED');
 }
});

test('pausar, retomar e parar preservam o prazo e respeitam o intervalo anterior',async t=>{
 const f=fixture(t);await f.step();f.ended();const deadline=f.state().finalizationDeadline;
 f.workers.pause(f.user.id,1);f.at(f.start+20000);await f.step();assert.equal(f.calls.length,1);
 store.updateUserProfile(f.user.id,1,p=>{p.runtime.status='running';p.runtime.epoch++;});store.activateProfileLives(f.user.id,1,f.now);
 assert.equal(f.state().sendStatus,'FINISHING');assert.equal(f.state().finalizationDeadline,deadline);await f.step();assert.equal(f.calls.length,1);
 f.at(f.start+61000);await f.step();assert.equal(f.calls.length,2);
 f.workers.stop(f.user.id,1);store.updateUserProfile(f.user.id,1,p=>{p.runtime.status='running';});store.activateProfileLives(f.user.id,1,f.now);
 await f.step();assert.equal(f.calls.length,2);assert.equal(f.state().sendStatus,'FINALIZED');
});

for(const action of ['prazo','pausar','parar','desabilitar','bloquear','remover canal','limpar cache','trocar credenciais'])test(`espera de OAuth não permite envio após ${action}`,async t=>{
 const f=fixture(t);f.ended();let entered,release;const ready=new Promise(r=>entered=r),gate=new Promise(r=>release=r);
 f.onSend(async()=>{entered();await gate;});const pending=f.step();await ready;
 if(action==='prazo')f.at(f.start+600000);
 if(action==='pausar')f.workers.pause(f.user.id,1);
 if(action==='parar')f.workers.stop(f.user.id,1);
 if(action==='desabilitar')store.updateUserProfile(f.user.id,1,p=>{p.enabled=false;});
 if(action==='bloquear')store.updateUser(f.user.id,u=>{u.active=false;});
 if(action==='remover canal')store.removeSubscription(f.user.id,1,store.profileChannels(f.user.id,1)[0].id);
 if(action==='limpar cache')store.clearLiveCache();
 if(action==='trocar credenciais')store.updateUserProfile(f.user.id,1,p=>{p.api.version++;});
 release();await pending;assert.equal(f.calls.length,0);
});

test('falha de resposta em um perfil não acelera esse perfil nem os demais usuários',async t=>{
 const f=fixture(t,{profiles:2}),g=fixture(t);f.ended();g.ended();const attempts=[];
 f.api.sendLiveChatMessage=async(p,_c,_chat,_m,options)=>{options.beforeSend();options.onApiRequest();attempts.push([p.profileNumber,f.now]);if(p.profileNumber===1)throw Object.assign(Error('resposta perdida'),{ambiguousWrite:true});};
 await Promise.all([f.step(1),f.step(1),f.step(2),g.step()]);assert.equal(attempts.length,2);
 for(let i=1;i<61;i++){f.at(f.start+i*1000);g.at(g.start+i*1000);await Promise.all([f.step(1),f.step(2),g.step()]);}
 assert.equal(attempts.length,2);assert.equal(g.calls.length,1);
 f.at(f.start+61000);g.at(g.start+61000);await Promise.all([f.step(1),f.step(2),g.step()]);assert.equal(attempts.length,4);assert.equal(g.calls.length,2);
 assert.equal(store.getUserProfile(f.user.id,1).runtime.sendRecoveryPending,false);
});

test('modo fixo mantém horários e não repete o mesmo slot no período adicional',async t=>{
 const f=fixture(t),start=Date.parse('2026-10-22T18:00:00Z');f.at(start);
 store.updateUserProfile(f.user.id,1,p=>{p.config.sendMode='fixed';p.runtime.immediatePending=false;p.runtime.lastAttemptAt=new Date(start).toISOString();});
 store.cacheGlobalLiveChatId(f.live.id,`CHAT-${f.videoId}`,f.now);f.ended();
 await f.step();assert.equal(f.calls.length,0);
 for(const seconds of [61,62,63,100,119,300,301,302,540,541,542,600]){f.at(start+seconds*1000);await f.step();}
 assert.deepEqual(f.calls.map(call=>(call.at-start)/1000),[61,301,541]);assert.equal(f.state().sendStatus,'FINALIZED');
});

test('migração do schema 9 preserva dados e não concede janela a uma live já encerrada',()=>{
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'chatflow-old-ended-'));
 try{
  const create=`const s=require('./lib/store');const u=s.createUser({id:'old-user',username:'Antigo',active:true,sessionVersion:1});s.updateUserProfile(u.id,1,p=>{p.config.messages='Preservada';p.runtime.status='running';p.runtime.sent=27;});const c=s.upsertGlobalChannel({handle:'@antigo',canonicalUrl:'https://www.youtube.com/@antigo'});s.subscribeChannel(u.id,1,c,'@antigo');const l=s.upsertGlobalLive(c.id,{videoId:'O0000000001',liveStatus:'LIVE',chatStatus:'AVAILABLE',activeLiveChatId:'OLD-ID',resolved:true}).live;s.distributeLive(l.id);s.close();const {DatabaseSync}=require('node:sqlite');const d=new DatabaseSync(process.env.DATA_DIR+'/peralta.sqlite');d.exec("UPDATE global_lives SET live_status='ENDED',chat_status='ENDED';UPDATE user_live_state SET send_status='FINISHING';ALTER TABLE global_lives DROP COLUMN post_end_deadline;PRAGMA user_version=9;");d.close();`;
  const read=`const s=require('./lib/store'),l=s.getGlobalLiveByVideo('O0000000001'),p=s.getUserProfile('old-user',1);console.log(JSON.stringify({version:s.schemaVersion(),deadline:l.post_end_deadline,chat:l.active_live_chat_id,finalized:!!l.finalized_at,state:s.profileLiveStates('old-user',1)[0].sendStatus,messages:p.config.messages,sent:p.runtime.sent}));s.close();`;
  const run=code=>spawnSync(process.execPath,['-e',code],{cwd:path.join(__dirname,'..'),env:{...process.env,DATA_DIR:directory},encoding:'utf8'});
  const made=run(create);assert.equal(made.status,0,made.stderr);
  const first=run(read);assert.equal(first.status,0,first.stderr);assert.deepEqual(JSON.parse(first.stdout.trim()),{version:10,deadline:null,chat:'',finalized:true,state:'FINALIZED',messages:'Preservada',sent:27});
  const second=run(read);assert.equal(second.status,0,second.stderr);assert.equal(second.stdout,first.stdout);
 }finally{fs.rmSync(directory,{recursive:true,force:true});}
});
