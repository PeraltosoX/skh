'use strict';

// Somente apresentação. O servidor conserva reason/status e os registros originais.
(function(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ApiErrorsPT = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  const reasons = Object.freeze({
    liveChatEnded: 'Este chat ao vivo já foi encerrado.',
    liveChatDisabled: 'O responsável pela transmissão desativou este chat.',
    liveChatNotFound: 'O chat ao vivo informado não foi encontrado.',
    messageTextInvalid: 'O YouTube recusou o texto desta mensagem por considerá-lo inválido.',
    messageTextRequired: 'O texto da mensagem não foi informado.',
    liveChatIdRequired: 'O identificador do chat ao vivo não foi informado.',
    typeRequired: 'O tipo de mensagem não foi informado.',
    rateLimitExceeded: 'O limite de mensagens ou solicitações em um curto período foi atingido.',
    userRateLimitExceeded: 'O limite de solicitações desta conta em um curto período foi atingido.',
    quotaExceeded: 'A cota de uso da API do YouTube foi excedida.',
    dailyLimitExceeded: 'O limite diário de uso da API foi atingido.',
    forbidden: 'A API recusou esta solicitação por falta de permissão.',
    insufficientPermissions: 'A autorização desta conta não inclui as permissões necessárias.',
    insufficientScopes: 'A autorização desta conta não inclui as permissões necessárias.',
    authError: 'A autorização enviada ao Google não é válida.',
    authorizationRequired: 'É necessário autorizar a conta Google para esta solicitação.',
    invalid_grant: 'A autorização Google é inválida, expirou ou foi revogada.',
    invalid_client: 'As credenciais do cliente OAuth não foram aceitas pelo Google.',
    unauthorized_client: 'Este cliente OAuth não está autorizado a realizar a solicitação.',
    access_denied: 'O acesso solicitado ao Google foi negado.',
    redirect_uri_mismatch: 'O endereço de retorno não corresponde ao cadastrado no Google.',
    invalid_scope: 'Uma das permissões solicitadas ao Google é inválida.',
    youtubeSignupRequired: 'A conta Google precisa ter um canal do YouTube vinculado.',
    accessNotConfigured: 'A API do YouTube não está habilitada neste projeto Google.',
    serviceDisabled: 'A API do YouTube está desativada neste projeto Google.',
    SERVICE_DISABLED: 'A API do YouTube está desativada neste projeto Google.',
    API_KEY_SERVICE_BLOCKED: 'As restrições desta chave não permitem acessar a API solicitada.',
    keyInvalid: 'A chave de API informada é inválida.',
    API_KEY_INVALID: 'A chave de API informada é inválida.',
    ipRefererBlocked: 'As restrições da chave de API não permitem acesso a partir deste servidor.',
    channelNotFound: 'O canal do YouTube informado não foi encontrado.',
    videoNotFound: 'O vídeo informado não foi encontrado.',
    channelClosed: 'O canal do YouTube informado foi encerrado.',
    channelSuspended: 'O canal do YouTube informado está suspenso.',
    authenticatedUserAccountClosed: 'A conta do YouTube autorizada foi encerrada.',
    authenticatedUserAccountSuspended: 'A conta do YouTube autorizada está suspensa.',
    missingRequiredParameter: 'A solicitação está sem um parâmetro obrigatório.',
    backendError: 'O serviço do Google apresentou uma falha interna.',
    internalError: 'O serviço do Google apresentou uma falha interna.',
    UNAVAILABLE: 'O serviço externo está temporariamente indisponível.'
  });
  const phrases = [
    [/The specified live chat is no longer live\.?/gi, reasons.liveChatEnded],
    [/The specified live chat has been disabled by the owner(?:, which means messages cannot be added to the chat)?\.?/gi, reasons.liveChatDisabled],
    [/The live chat identified in the API request does not exist(?:\. This error occurs if the chat has been deleted by the owner)?\.?/gi, reasons.liveChatNotFound],
    [/The specified live chat (?:was not found|does not exist)\.?/gi, reasons.liveChatNotFound],
    [/The request cannot be completed because you have exceeded your (?:<[^>]+>)*quota(?:<[^>]+>)*\.?/gi, reasons.quotaExceeded],
    [/The user has posted too many chat messages in a given timeframe\.?/gi, reasons.rateLimitExceeded],
    [/You (?:do not|don't) have the permissions required to create the specified message\.?/gi, reasons.forbidden],
    [/The message text(?: \([^)]*\))? is not valid\.?/gi, reasons.messageTextInvalid],
    [/Token has been expired or revoked\.?/gi, 'A autorização Google expirou ou foi revogada.'],
    [/Request had insufficient authentication scopes\.?/gi, reasons.insufficientScopes],
    [/Request had invalid authentication credentials\.[\s\S]*?(?=\[HTTP|$)/gi, 'A solicitação não contém uma autorização Google válida. '],
    [/API key not valid\. Please pass a valid API key\.?/gi, reasons.keyInvalid],
    [/YouTube Data API v3 has not been used in project[^.]*before or it is disabled\.[\s\S]*?(?=\[HTTP|$)/gi, 'A API do YouTube não está habilitada neste projeto Google. '],
    [/The OAuth client was not found\.?/gi, reasons.invalid_client],
    [/NetworkError when attempting to fetch resource\.?/gi, 'Não foi possível comunicar com o servidor.'],
    [/Failed to fetch|fetch failed/gi, 'Não foi possível comunicar com o servidor'],
    [/The operation was aborted due to timeout\.?/gi, 'O tempo de espera da conexão foi esgotado.'],
    [/The operation was aborted\.?/gi, 'A operação foi cancelada.']
  ];
  const reasonByLowerCase = Object.fromEntries(Object.entries(reasons).map(([key,value]) => [key.toLowerCase(),value]));

  function translate(value) {
    const original = String(value ?? '');
    if (!original) return original;
    // Preserva o código HTTP, o reason da API e qualquer orientação após eles.
    const marker = original.search(/\[HTTP\s+\d{3}/i);
    const suffix = marker < 0 ? '' : original.slice(marker);
    const body = marker < 0 ? original : original.slice(0,marker).trimEnd();
    let text = body;
    for (const [pattern,replacement] of phrases) text = text.replace(pattern,replacement);
    const reason = /\[HTTP\s+\d{3}\s*·\s*([a-z0-9_.-]+)\s*\]/i.exec(suffix)?.[1];
    const standalone = /^(?:Error:\s*)?([a-z0-9_.-]+)\.?$/i.exec(body.trim())?.[1];
    const mapped = reasonByLowerCase[String(reason || standalone || '').toLowerCase()];
    const portuguese = /[áàãâéêíóôõúç]|\b(?:não|foi|este|esta|perfil|conta|mensagem|falha|aguarde|erro|chave|servidor|permissão|autorização|cota)\b/i.test(body);
    if (text === body && mapped && (!portuguese || standalone)) text = mapped;
    if (text === body) {
      const short = { 'forbidden':reasons.forbidden, 'invalid credentials':reasons.authError,
        'unauthorized':'A solicitação não foi autorizada.', 'quota exceeded':reasons.quotaExceeded,
        'daily limit exceeded':reasons.dailyLimitExceeded, 'rate limit exceeded':reasons.rateLimitExceeded,
        'too many requests':reasons.rateLimitExceeded, 'service unavailable':'O serviço está temporariamente indisponível.',
        'internal server error':'O serviço apresentou uma falha interna.', 'bad request':'A API não aceitou os dados da solicitação.',
        'not found':'O recurso solicitado não foi encontrado.', 'invalid client':reasons.invalid_client,
        'access denied':reasons.access_denied, 'invalid grant':reasons.invalid_grant,
        'invalid value':'A API não aceitou um dos valores enviados.' };
      text = short[body.trim().replace(/\.$/,'').toLowerCase()] || text;
    }
    return suffix ? `${text.trimEnd()} ${suffix}` : text;
  }

  // Cópia de apresentação para detalhes JSON; mensagens enviadas nunca são traduzidas.
  function translateRecord(value) {
    if (Array.isArray(value)) return value.map(translateRecord);
    if (!value || typeof value !== 'object') return value;
    return Object.fromEntries(Object.entries(value).map(([key,item]) => {
      const isError = ['error','lastError','last_error','lastGlobalScanError','resolutionError','error_description'].includes(key);
      const messageOnlyError = key === 'message' && value.status === 'error' && value.type !== 'send' && !value.error;
      return [key, typeof item === 'string' && (isError || messageOnlyError) ? translate(item) : translateRecord(item)];
    }));
  }

  function appendOriginal(parent, original) {
    const value = String(original ?? '');
    if (!value || translate(value) === value) return;
    const details = document.createElement('details');
    details.className = 'api-error-original';
    const summary = document.createElement('summary');
    summary.textContent = 'Ver mensagem original da API';
    const text = document.createElement('pre');
    text.textContent = value;
    details.append(summary,text);
    parent.append(details);
  }
  return Object.freeze({translate,translateRecord,appendOriginal});
});
