'use strict';

// Seletor compartilhado: a lista pertence ao painel, em vez de abrir o menu do sistema.
window.ProfilePicker = class ProfilePicker {
  constructor(select) {
    this.select = select;
    this.items = [];
    this.signature = '';
    const prefix = select.id;
    const node = (tag, className, text) => {
      const element = document.createElement(tag);
      element.className = className;
      if (text) element.textContent = text;
      return element;
    };
    this.node = node;
    select.hidden = true;
    select.tabIndex = -1;
    select.setAttribute('aria-hidden', 'true');
    const label = document.querySelector(`label[for="${prefix}"]`);
    if (label) label.htmlFor = `${prefix}Trigger`;
    this.trigger = node('button', 'profile-select-trigger');
    this.trigger.type = 'button';
    this.trigger.id = `${prefix}Trigger`;
    this.trigger.setAttribute('aria-haspopup', 'dialog');
    this.trigger.setAttribute('aria-controls', `${prefix}Dialog`);
    this.trigger.setAttribute('aria-expanded', 'false');
    this.number = node('span', 'profile-select-number', '01');
    const copy = node('span', 'profile-select-copy');
    this.name = node('strong', 'profile-select-name', 'Carregando perfis…');
    this.detail = node('span', 'profile-select-meta');
    this.status = node('span', 'profile-select-badge');
    this.status.hidden = true;
    this.detail.append(this.status, node('span', 'profile-select-detail', 'Trocar perfil'));
    copy.append(this.name, this.detail);
    const chevron = node('span', 'profile-select-chevron', '⌄');
    chevron.setAttribute('aria-hidden', 'true');
    this.trigger.append(this.number, copy, chevron);
    select.before(this.trigger);
    this.dialog = node('dialog', 'profile-select-dialog');
    this.dialog.id = `${prefix}Dialog`;
    this.dialog.setAttribute('aria-labelledby', `${prefix}Title`);
    const card = node('section', 'profile-select-sheet');
    const handle = node('div', 'profile-select-handle');
    handle.setAttribute('aria-hidden', 'true');
    const heading = node('div', 'profile-select-heading');
    const titleGroup = node('div', 'profile-select-heading-copy');
    const title = node('h2', '', 'Trocar de perfil');
    title.id = `${prefix}Title`;
    this.count = node('p', 'profile-select-count');
    titleGroup.append(node('span', 'profile-select-eyebrow', 'SEUS PERFIS'), title, this.count);
    this.closeButton = node('button', 'profile-select-close', '×');
    this.closeButton.type = 'button';
    this.closeButton.setAttribute('aria-label', 'Fechar seletor de perfis');
    heading.append(titleGroup, this.closeButton);
    this.search = node('input', 'profile-select-search');
    this.search.type = 'search';
    this.search.placeholder = 'Buscar por nome ou número';
    this.search.setAttribute('aria-label', 'Buscar perfil');
    this.search.autocomplete = 'off';
    this.list = node('div', 'profile-select-list');
    this.empty = node('p', 'profile-select-empty', 'Nenhum perfil encontrado.');
    this.empty.hidden = true;
    this.empty.setAttribute('role', 'status');
    card.append(handle, heading, this.search, this.list, this.empty);
    this.dialog.append(card);
    document.body.append(this.dialog);
    this.trigger.addEventListener('click', () => this.open());
    this.closeButton.addEventListener('click', () => this.close());
    this.dialog.addEventListener('click', event => { if (event.target === this.dialog) this.close(); });
    this.dialog.addEventListener('close', () => {
      this.trigger.setAttribute('aria-expanded', 'false');
      document.documentElement.classList.remove('profile-picker-open');
    });
    this.search.addEventListener('input', () => this.filter());
    this.list.addEventListener('click', event => {
      const button = event.target.closest('button[data-profile-choice]');
      if (!button || this.select.disabled) return;
      this.close();
      this.select.value = button.dataset.profileChoice;
      this.select.dispatchEvent(new Event('change', { bubbles: true }));
    });
    this.list.addEventListener('keydown', event => {
      if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
      const buttons = [...this.list.querySelectorAll('button:not([hidden])')];
      if (!buttons.length) return;
      event.preventDefault();
      let index = buttons.indexOf(document.activeElement);
      index = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1
        : (index + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
      buttons[index].focus();
    });
    const mobile = matchMedia('(max-width: 920px)');
    mobile.addEventListener('change', () => { if (!mobile.matches) this.close(); });
  }

  setItems(items, selected) {
    const signature = JSON.stringify(items);
    if (signature !== this.signature) {
      this.signature = signature;
      this.items = items;
      const focused = this.list.querySelector(':focus')?.dataset.profileChoice;
      const scrollTop = this.list.scrollTop;
      this.select.replaceChildren();
      this.list.replaceChildren();
      for (const item of items) {
        const option = document.createElement('option');
        option.value = String(item.id);
        option.textContent = `Perfil ${item.id} · ${item.name} · ${item.detail}`;
        this.select.append(option);
        const button = this.node('button', 'profile-select-option');
        button.type = 'button';
        button.dataset.profileChoice = String(item.id);
        button.dataset.search = this.normalize(`${item.id} ${item.name}`);
        const number = this.node('span', 'profile-select-number', String(item.id).padStart(2, '0'));
        const copy = this.node('span', 'profile-select-copy');
        copy.append(this.node('strong', 'profile-select-name', item.name), this.node('span', 'profile-select-detail',
          `Perfil ${item.id}${item.description ? ` · ${item.description}` : ''}`));
        const side = this.node('span', 'profile-select-side');
        const badge = this.node('span', 'profile-select-badge', item.detail);
        badge.dataset.tone = item.tone;
        const check = this.node('span', 'profile-select-check', '✓');
        check.setAttribute('aria-hidden', 'true');
        side.append(badge, check);
        button.append(number, copy, side);
        this.list.append(button);
      }
      this.search.hidden = items.length < 6;
      if (this.search.hidden) this.search.value = '';
      this.filter();
      if (focused) this.list.querySelector(`[data-profile-choice="${focused}"]`)?.focus({ preventScroll: true });
      this.list.scrollTop = scrollTop;
    }
    this.setValue(selected);
  }

  setValue(selected) {
    this.select.value = String(selected);
    const item = this.items.find(item => String(item.id) === String(selected));
    if (item) {
      this.number.textContent = String(item.id).padStart(2, '0');
      this.name.textContent = item.name;
      this.status.textContent = item.detail;
      this.status.dataset.tone = item.tone;
      this.status.hidden = false;
      this.trigger.setAttribute('aria-label', `Trocar perfil. Perfil ${item.id}: ${item.name}. ${item.detail}`);
      this.trigger.dataset.tone = item.tone;
    }
    for (const button of this.list.children) button.setAttribute('aria-pressed', String(button.dataset.profileChoice === String(selected)));
  }

  setDisabled(value) {
    this.select.disabled = value;
    this.trigger.disabled = value;
    if (value) this.close();
  }

  normalize(value) { return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR'); }

  filter() {
    const query = this.normalize(this.search.value.trim());
    let count = 0;
    for (const button of this.list.children) {
      button.hidden = !button.dataset.search.includes(query);
      if (!button.hidden) count++;
    }
    this.count.textContent = query ? `${count} de ${this.items.length} perfis` : `${this.items.length} ${this.items.length === 1 ? 'perfil disponível' : 'perfis disponíveis'}`;
    this.empty.hidden = count > 0;
  }

  open() {
    if (this.trigger.disabled || this.select.disabled || !this.items.length) return;
    this.search.value = '';
    this.filter();
    this.dialog.showModal();
    this.trigger.setAttribute('aria-expanded', 'true');
    document.documentElement.classList.add('profile-picker-open');
    const selected = this.list.querySelector('[aria-pressed="true"]');
    selected?.focus({ preventScroll: true });
    selected?.scrollIntoView({ block: 'nearest' });
  }

  close() { if (this.dialog.open) this.dialog.close(); }
};
