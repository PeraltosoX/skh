'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { translate, translateRecord } = require('../public/api-errors-pt');

test('tradução de chat encerrado preserva HTTP, reason e instrução de recuperação', () => {
  for (const reason of ['liveChatEnded','chat encerrado']) {
    const suffix = `[HTTP 403 · ${reason}] Nova confirmação do chat; tentativa no próximo intervalo de envio.`;
    const translated = translate(`The specified live chat is no longer live. ${suffix}`);
    assert.equal(translated, `Este chat ao vivo já foi encerrado. ${suffix}`);
    assert.equal(translate(translated), translated);
  }
});

test('permissão, cota, limite, OAuth e API desativada têm explicações diferentes', () => {
  const cases = [
    ['Forbidden [HTTP 403 · forbidden]', /falta de permissão/],
    ['The request cannot be completed because you have exceeded your quota. [HTTP 403 · quotaExceeded]', /cota de uso/],
    ['The user has posted too many chat messages in a given timeframe. [HTTP 403 · rateLimitExceeded]', /curto período/],
    ['Token has been expired or revoked. [HTTP 400 · invalid_grant]', /expirou ou foi revogada/],
    ['Request had insufficient authentication scopes. [HTTP 403 · insufficientPermissions]', /permissões necessárias/],
    ['YouTube Data API v3 has not been used in project 123 before or it is disabled. Enable it by visiting https://example.invalid then retry. [HTTP 403 · accessNotConfigured]', /não está habilitada/],
    ['The specified live chat has been disabled by the owner.', /desativou este chat/],
    ['liveChatNotFound', /não foi encontrado/],
    ['Failed to fetch', /comunicar com o servidor/]
  ];
  for (const [original, expected] of cases) {
    const result = translate(original);
    assert.match(result, expected);
    assert.equal(translate(result), result);
    const suffix = original.match(/\[HTTP[^\]]+\]/)?.[0];
    if (suffix) assert.ok(result.includes(suffix));
  }
  assert.doesNotMatch(translate('Forbidden [HTTP 403 · forbidden]'), /encerrado/);
});

test('avisos em português e erros desconhecidos não recebem causa inventada', () => {
  for (const value of ['Sem permissão para este canal. [HTTP 403 · forbidden]', 'Falha desconhecida', 'A new unexpected API error [HTTP 502]', '', null]) {
    assert.equal(translate(value), value ?? '');
  }
});

test('cópia de apresentação não altera dados originais nem conteúdo enviado pelo usuário', () => {
  const error = 'The specified live chat is no longer live. [HTTP 403 · liveChatEnded]';
  const original = { name:error,config:{messages:error},logs:[{type:'send',status:'error',message:error,error}],runtime:{lastError:error},nested:[{error_description:'invalid_grant'}] };
  const before = structuredClone(original), display = translateRecord(original);
  assert.deepEqual(original, before);
  assert.equal(display.name, error); assert.equal(display.config.messages, error);
  assert.equal(display.logs[0].message,error);
  assert.match(display.logs[0].error,/Este chat/);
  assert.match(display.runtime.lastError,/Este chat/);
  assert.match(display.nested[0].error_description,/autorização Google/);
});

test('texto desconhecido com HTML permanece texto, sem interpretação ou execução', () => {
  const value='<img src=x onerror=alert(1)> <script>alert(1)</script>';
  assert.equal(translate(value), value);
});
