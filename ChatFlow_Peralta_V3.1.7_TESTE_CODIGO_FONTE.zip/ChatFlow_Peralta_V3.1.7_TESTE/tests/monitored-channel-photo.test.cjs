'use strict';
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const { spawnSync } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');
const { safeThumbnailUrl, extractChannelThumbnail } = require('../lib/channel-thumbnail');
const { resolveChannelInput } = require('../lib/channel-normalizer');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(),'cf-monitor-photo-'));
const store = require('../lib/store');
after(() => { store.close(); fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true}); });
const photo = 'https://yt3.ggpht.com/photo-do-canal=s88-c-k';

test('foto vem dos metadados do canal, nunca da miniatura de um vídeo', () => {
  assert.equal(extractChannelThumbnail(`<meta content='${photo}?a=1&amp;b=2' property='og:image'>`),photo+'?a=1&b=2');
  const data={contents:{videoRenderer:{thumbnail:{thumbnails:[{url:'https://yt3.ggpht.com/foto-errada'}]}}},metadata:{channelMetadataRenderer:{title:'Canal com } e "aspas"',avatar:{thumbnails:[{url:photo}]}}}};
  assert.equal(extractChannelThumbnail(`<script>var ytInitialData=${JSON.stringify(data)};</script>`),photo);
  assert.equal(extractChannelThumbnail(JSON.stringify(data.contents)), '');
  assert.equal(extractChannelThumbnail('"channelMetadataRenderer": { "avatar": invalid }'), '');
});

test('URLs de foto só aceitam HTTPS de CDN do YouTube sem credenciais ou porta', () => {
  assert.equal(safeThumbnailUrl(photo),photo);
  assert.equal(safeThumbnailUrl('https://yt3.googleusercontent.com/foto'),'https://yt3.googleusercontent.com/foto');
  for(const bad of ['javascript:alert(1)','data:image/png;base64,AA','http://yt3.ggpht.com/a','https://yt3.ggpht.com.evil.invalid/a','https://evil.invalid/foto','https://user:pass@yt3.ggpht.com/a','https://yt3.ggpht.com:8443/a','//yt3.ggpht.com/a']){
    assert.equal(safeThumbnailUrl(bad),'');
    assert.equal(extractChannelThumbnail(`<meta property="og:image" content="${bad}">`),'');
  }
});

test('cadastro resolve nome, @ e foto na mesma consulta pública sem chamada adicional', async () => {
  let calls=0;
  const data=await resolveChannelInput('@canalteste',{fetchImpl:async()=>{calls++;return new Response(`<meta property="og:title" content="Canal de teste"><meta property="og:image" content="${photo}">`);}});
  assert.equal(calls,1);assert.equal(data.thumbnailUrl,photo);assert.equal(data.handle,'@canalteste');assert.equal(data.displayName,'Canal de teste');
});

test('foto compartilhada do canal não se mistura com a conta OAuth nem com outro perfil', () => {
  const user=store.createUser({id:store.id('usr'),username:'usuario',active:true,sessionVersion:1});store.addUserProfile(user.id);
  const channel=store.upsertGlobalChannel({handle:'@monitorado',canonicalUrl:'https://www.youtube.com/@monitorado',thumbnailUrl:photo});
  store.subscribeChannel(user.id,1,channel,'@monitorado');
  store.updateUserProfile(user.id,1,p=>{p.oauth.channel={thumbnailUrl:'https://yt3.ggpht.com/conta-autorizada'};});
  assert.equal(store.profileChannels(user.id,1)[0].thumbnailUrl,photo);
  assert.equal(store.profileChannels(user.id,2).length,0);
  const withoutPhoto=store.upsertGlobalChannel({handle:'@monitorado',canonicalUrl:channel.canonical_url});
  assert.equal(withoutPhoto.thumbnail_url,photo);
  assert.equal(store.upsertGlobalChannel({handle:'@monitorado',canonicalUrl:channel.canonical_url,thumbnailUrl:'https://evil.invalid/image'}).thumbnail_url,photo);
  assert.equal(store.getUserProfile(user.id,1).oauth.channel.thumbnailUrl,'https://yt3.ggpht.com/conta-autorizada');
});

test('unificação de canal por ID e @ preserva foto já conhecida', () => {
  const byId=store.upsertGlobalChannel({channelId:'UC1111111111111111111111',canonicalUrl:'https://www.youtube.com/channel/UC1111111111111111111111'});
  store.upsertGlobalChannel({handle:'@duplicado',canonicalUrl:'https://www.youtube.com/@duplicado',thumbnailUrl:photo});
  const merged=store.upsertGlobalChannel({channelId:byId.channel_id,handle:'@duplicado',canonicalUrl:'https://www.youtube.com/@duplicado'});
  assert.equal(merged.id,byId.id);assert.equal(merged.thumbnail_url,photo);
});

test('migração do schema 10 preserva contas, perfis, mensagens, canais, logs e contadores', () => {
  const data=fs.mkdtempSync(path.join(os.tmpdir(),'cf-schema11-'));
  const cwd=path.join(__dirname,'..');
  function child(code) { const result=spawnSync(process.execPath,['-e',code],{cwd,env:{...process.env,DATA_DIR:data},encoding:'utf8'});assert.equal(result.status,0,result.stderr);return result.stdout; }
  try {
    const seed=JSON.parse(child(`const s=require('./lib/store');const u=s.createUser({id:s.id('usr'),username:'preservado',active:true,sessionVersion:1});s.addUserProfile(u.id);s.updateUserProfile(u.id,2,p=>{p.name='Nome preservado';p.config.messages='Olá!';p.runtime.sent=23;p.runtime.status='paused';});const c=s.upsertGlobalChannel({handle:'@preservado',canonicalUrl:'https://www.youtube.com/@preservado'});s.subscribeChannel(u.id,2,c,'@preservado');s.appendLog(s.getUserProfile(u.id,2),'system','Registro preservado','info');console.log(JSON.stringify({userId:u.id,profile:s.getUserProfile(u.id,2),channels:s.profileChannels(u.id,2)}));s.close();`));
    const db=new DatabaseSync(path.join(data,'peralta.sqlite'));db.exec('ALTER TABLE global_channels DROP COLUMN thumbnail_url; PRAGMA user_version=10;');
    const counts=Object.fromEntries(['users','user_profiles','user_channels','global_channels','logs'].map(name=>[name,db.prepare('SELECT COUNT(*) AS n FROM '+name).get().n]));db.close();
    const result=JSON.parse(child(`const s=require('./lib/store');console.log(JSON.stringify({version:s.schemaVersion(),profile:s.getUserProfile('${seed.userId}',2),channels:s.profileChannels('${seed.userId}',2)}));s.close();`));
    assert.equal(result.version,11);assert.deepEqual(result.profile,seed.profile);assert.deepEqual(result.channels,seed.channels);
    const afterDb=new DatabaseSync(path.join(data,'peralta.sqlite'));for(const [name,count] of Object.entries(counts))assert.equal(afterDb.prepare('SELECT COUNT(*) AS n FROM '+name).get().n,count);afterDb.close();
    assert.match(child(`const s=require('./lib/store');console.log(s.schemaVersion());s.close();`),/11/);
  } finally { fs.rmSync(data,{recursive:true,force:true}); }
});
