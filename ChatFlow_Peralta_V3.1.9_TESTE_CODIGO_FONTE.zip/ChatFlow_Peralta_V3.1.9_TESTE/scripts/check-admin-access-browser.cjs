'use strict';
// Entrada compatível: a verificação atual foi consolidada neste roteiro.
// Usa somente dados temporários e serviços locais, sem envios reais.
if (process.env.PANEL_CHECK_OUTPUT && !process.env.PANEL_SCREENSHOT_DIR) {
  process.env.PANEL_SCREENSHOT_DIR = process.env.PANEL_CHECK_OUTPUT;
}
require('./check-admin-test-browser.cjs');
