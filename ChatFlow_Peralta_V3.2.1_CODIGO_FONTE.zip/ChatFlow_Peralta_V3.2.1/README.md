# ChatFlow Peralta V3.2.1

Servidor e painéis do ChatFlow Peralta. Versão técnica `3.2.1`, baseada na
V3.2.0 TESTE. SQLite schema 11, sem nova migração.

## Mudanças

- Marca fixa com ícone no cabeçalho mobile do painel de usuário.
- Estado de sincronização junto de Modo de envio.
- Editar nome ao lado de Perfil ativo; no mobile, somente em Conta e canal.
- Identificação da versão sem TESTE.
- Respostas inválidas da API não confirmam chat indisponível.
- Perfis recriados não herdam rascunhos nem cadastro de canal em andamento.
- Rascunhos preservados quando o nome de acesso da conta muda.

Veja `MUDANCAS_V3.2.1.txt` e `MELHORIAS_PARA_DEPOIS.txt`.
Backup automático periódico não foi implementado nesta versão.

## Atualizar

Salve as edições pendentes na versão anterior. Rascunhos legados sem
identificação não são aplicados automaticamente; dados já salvos no servidor
são preservados. Recarregue as guias depois da atualização.
Publique `ChatFlow_Peralta_V3.2.1_CODIGO_FONTE.zip` sem recomprimir no
repositório PeraltosoX/skh, branch main. Execute o comando separado
`COMANDO_ATUALIZACAO_V3.2.1.txt` na VPS como root.
Leia `ATUALIZAR_SEM_PERDER_DADOS.txt`. Não use install.sh para atualizar.

O atualizador mantém a pasta anterior, faz backup consistente e copia .env
com data/. Exige health com versão 3.2.1, schema 11 e armazenamento válido,
valida a sintaxe e tenta religar a versão anterior em caso de falha.
Esta entrega não publica o ZIP no GitHub nem altera a VPS automaticamente.

## Funcionamento

Envios independentes, intervalos, horários fixos, recuperação de envios,
período adicional após a live, contadores e quotas mantêm as regras existentes.
O código de workers não foi alterado.
Administração: `/dbmadmin`. Painel do usuário: `/painel`.
Links administrativos históricos redirecionam para o painel atual. Os nomes
internos admin-test são mantidos por compatibilidade; a interface e a versão
entregues não exibem indicação de teste.
O banco é `data/peralta.sqlite`. Preserve .env junto de data/: a chave
APP_ENCRYPTION_KEY permite ler as credenciais criptografadas existentes.

## Desenvolvimento e testes

Node.js 24.14 ou superior, na linha 24:

```bash
npm ci
npm run check
npm test
```

Os testes usam dados temporários e serviços simulados, sem mensagens reais.
Resultados: `VERIFICACAO_V3.2.1.txt`.
Testes de navegador, com Playwright e Chromium disponíveis:

```bash
node scripts/check-admin-test-browser.cjs
node scripts/check-draft-identity-browser.cjs
```

`PANEL_CHROMIUM_PATH` indica o executável local do Chromium.
`PANEL_SCREENSHOT_DIR` habilita capturas internas do roteiro principal.
check-panel-browser e check-admin-access-browser são atalhos do roteiro
principal; não é necessário executar os três.
Instalação nova: `INSTALAR.txt`. Retorno OAuth:
`https://SEU-DOMINIO/oauth/google/callback`.
Documentos com versões anteriores registram o histórico do projeto.
