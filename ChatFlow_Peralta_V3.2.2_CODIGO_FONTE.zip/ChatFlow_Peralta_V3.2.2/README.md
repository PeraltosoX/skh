# ChatFlow Peralta V3.2.2

Base: V3.2.1. Node.js 24.14 ou superior na linha 24; SQLite schema 11 mantido.

## Novidades

- Foto da conta que envia mensagens: identificação inicial pelo OAuth e
  atualizações seguintes a cada 30 minutos pelas chaves de verificação.
  Cache preservado nas falhas; foto do canal monitorado continua como antes.
- Permissão administrativa individual para editar Client ID e Client Secret
  em Conta e canal. Desativar oculta todo o bloco sem desconectar a conta.
- Link global de tutorial nas Configurações, aberto em nova guia pelo botão
  Assistir ao tutorial. Sem vídeo incorporado; visibilidade segue a permissão.

Detalhes: `MUDANCAS_V3.2.2.txt`.
Planos adiados: `ChatFlow_Peralta_ATUALIZACOES_FUTURAS.txt`.

## Atualização

Publique `ChatFlow_Peralta_V3.2.2_CODIGO_FONTE.zip` sem recomprimir no
repositório PeraltosoX/skh, branch main. Execute o comando separado
`COMANDO_ATUALIZACAO_V3.2.2.txt` no Bash da VPS como root.
Leia `ATUALIZAR_SEM_PERDER_DADOS.txt`. Não use install.sh para atualizar.
Salve as edições pendentes e recarregue as guias após a atualização.

O atualizador faz backup consistente, copia .env e data/ para pasta nova,
valida versão, banco e sintaxe, preserva a origem e tenta retornar a ela se falhar.
Esta entrega não publica o ZIP nem acessa a VPS automaticamente.

## Configuração das novidades

Administração: Usuários e perfis > selecionar perfil > Google e API.
Marque Permitir edição das credenciais Google pelo usuário e salve.
Perfis antigos e novos começam bloqueados. A permissão vale só para esse perfil.
Em Configurações, defina o Link do tutorial; para remover, salve o campo vazio.

No usuário, os campos aparecem em Conta e canal, abaixo de Canal deste perfil.
Segredo vazio mantém o já salvo; trocar Client ID requer o segredo correspondente.
Trocar as credenciais pede nova autorização Google. Bloquear a edição novamente
preserva as credenciais e a conexão existente.

As consultas periódicas de foto usam as chaves administrativas existentes.
Sem chave disponível, fica a última foto. As cotas pertencem ao projeto Google:
chaves do mesmo projeto compartilham saldo, mesmo com contagens separadas no painel.
Referência da consulta pública: https://developers.google.com/youtube/v3/docs/channels/list

## Testes

```bash
npm ci
npm run check
npm test
```

São usados dados temporários e respostas simuladas, sem envios reais.
Relatório completo: `VERIFICACAO_V3.2.2.txt`.
Roteiros de navegador existentes, opcionais com Playwright e Chromium:

```bash
node scripts/check-admin-test-browser.cjs
node scripts/check-draft-identity-browser.cjs
```

`PANEL_CHROMIUM_PATH` indica o executável local do Chromium.
Roteiro funcional do DOM, opcional com jsdom 26.1.0 disponível no NODE_PATH:

```bash
node scripts/check-oauth-ui-dom.cjs
```

O roteiro DOM não substitui revisão visual em navegador. Consulte a limitação
registrada no relatório desta entrega.

Administração: `/dbmadmin`. Usuário: `/painel`.
Preserve `data/peralta.sqlite` e `.env`: APP_ENCRYPTION_KEY decifra as credenciais.
Instalação nova: `INSTALAR.txt`. Callback atual: `/oauth/google/callback`.
Documentos de versões anteriores são mantidos como histórico.
