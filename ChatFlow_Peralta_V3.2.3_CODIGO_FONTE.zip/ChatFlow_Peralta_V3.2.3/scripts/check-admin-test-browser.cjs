'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const { chromium } = require('playwright');
// Roteiro opcional: requer Playwright e Chromium; usa apenas dados temporários.
const root = path.resolve(__dirname, '..');
const out = process.env.PANEL_SCREENSHOT_DIR ? path.resolve(process.env.PANEL_SCREENSHOT_DIR) : null;
if (out) fs.mkdirSync(out,{recursive:true});
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-ui-test-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';
const store = require(root + '/lib/store'), security = require(root + '/lib/security');
const bcrypt = require('bcryptjs');
const admin = { id: store.id('adm'), username: 'Admin Teste', passwordHash: bcrypt.hashSync('SenhaTeste2026',4), active: true, sessionVersion: 1 };
store.createFirstAdmin(admin);
const user = store.createUser({ id: store.id('usr'), username: 'Equipe Peralta', active: true, sessionVersion: 1, passwordHash: bcrypt.hashSync('SenhaTeste2026',4) });
store.addUserProfile(user.id); store.addUserProfile(user.id);
store.updateUserProfile(user.id, 1, p => { p.name='Perfil principal'; p.googleEmail='principal@example.invalid'; });
store.updateUserProfile(user.id, 2, p => { p.config.messages='Primeira mensagem\nSegunda mensagem';p.config.intervalMinutes=4;p.config.intervalSeconds=15;p.config.autoStart=true;p.name='Lives da tarde'; p.googleEmail='tarde@example.invalid'; p.api = { clientId:'test-client.apps.googleusercontent.com', clientSecretEnc:security.encryptText('fake-test-secret'), version:1 }; });
store.updateUserProfile(user.id, 3, p => { p.name='Transmissões especiais'; p.enabled=false; });
const savedChannel=store.upsertGlobalChannel({handle:'@canalteste',canonicalUrl:'https://www.youtube.com/@canalteste',displayName:'Canal de teste'});store.subscribeChannel(user.id,2,savedChannel,'@canalteste');
const savedConfig=structuredClone(store.getUserProfile(user.id,2).config);
const other = store.createUser({ id:store.id('usr'),username:'Equipe de apoio',active:false,sessionVersion:1 });
store.appendLog(store.getUserProfile(user.id,2),'system','Perfil preparado para verificação do painel.','success');
store.appendGlobalEvent('discovery','Consulta de teste concluída: canais atualizados.','success');
const testKey=store.createAdminVerificationKey({name:'Chave principal de teste',apiKeyEnc:security.encryptText('test-key'),keyHint:'AIza...teste',keyFingerprint:crypto.randomBytes(16).toString('hex')});
store.recordAdminKeyCheck(testKey.id,'test','ACTIVE');
for(let n=0;n<2;n++)store.appendLog(store.getUserProfile(user.id,2),'send','Mensagem simulada','error','Falha simulada repetida');
const server=require('node:http').createServer().listen(0,'127.0.0.1');
(async()=>{
 await new Promise(resolve=>server.once('listening',resolve));
 const base=`http://127.0.0.1:${server.address().port}`;
 process.env.PUBLIC_BASE_URL=base;
 const backend=require(root+'/server');backend.globalMonitor.scan=async()=>({ok:true});
 // Nenhuma requisição deste roteiro chega ao YouTube ou envia mensagens.
 const originalFetch=global.fetch;
 global.fetch=(url,options)=>new URL(url).origin===base ? originalFetch(url,options) : Promise.resolve(new Response('<meta property="og:title" content="Canal de teste">',{status:200}));
 server.on('request',backend.createApp());
 const browser=await chromium.launch({headless:true,...(process.env.PANEL_CHROMIUM_PATH ? {executablePath:process.env.PANEL_CHROMIUM_PATH} : {}),args:['--no-sandbox','--disable-dev-shm-usage','--no-zygote','--single-process','--disable-gpu']});
 const context=await browser.newContext({viewport:{width:1440,height:1050},locale:'pt-BR',reducedMotion:'reduce'});
 await context.route('**/*',route=>new URL(route.request().url()).origin===base ? route.continue() : route.abort());
 context.setDefaultTimeout(15000);context.setDefaultNavigationTimeout(15000);
 const page=await context.newPage();
 const errors=[]; page.on('pageerror',e=>errors.push(e.message)); const checks=[];
 checks.push=(...labels)=>{console.log(labels.at(-1));return Array.prototype.push.apply(checks,labels);};
 const visible = async selector => {await page.locator(selector).waitFor({state:'visible'});assert.equal(await page.locator(selector).isVisible(),true,selector);};
 const clean = async label => { const sizes=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth})); assert.ok(sizes.scroll<=sizes.width,`${label}: overflow ${JSON.stringify(sizes)}`); checks.push(label); };
 const snap=async name=>{if (!out) return; await page.screenshot({path:path.join(out,name+'.png'),fullPage:true,animations:'disabled'});};
 const pick = async (surface, id, value) => { await surface.locator('#'+id+'Trigger').click(); await surface.locator('#'+id+'Dialog [data-profile-choice="'+value+'"]').click(); };
 const openWorkspace = async () => { await nav('users'); await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click(); };
 const nav = async name => { if(name!=='settings' && await page.locator('#adminMobileNav').isVisible()) { await page.locator(`#adminMobileNav [data-page-target="${name}"]`).click(); return; } if(await page.locator('#menuToggle').isVisible()) await page.locator('#menuToggle').click(); await page.locator(`[data-page-target="${name}"]:visible`).click(); };
 try {
 await page.goto(base+'/dbmadmin'); await visible('#login');
 await page.locator('#loginUser').fill('Admin Teste'); await page.locator('#loginPass').fill('SenhaTeste2026'); await page.locator('#loginForm button[type=submit]').click();
 await page.waitForFunction(()=>document.getElementById('overviewUsers').textContent==='2'); await clean('Desktop: visão geral'); await snap('01-visao-geral');
 await nav('users'); await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click(); await visible('#profileEditor'); await clean('Desktop: usuário e perfis'); await snap('02-edicao-perfil');
 await page.locator('#profilePicker [data-action="profile-edit"][data-profile="2"]').click();
 assert.equal(await page.locator('#profileName').inputValue(),'Lives da tarde');
 await page.locator('#profileName').fill('Título em edição');
 await page.locator('#refreshBtn').click(); await page.waitForFunction(()=>!document.getElementById('refreshBtn').disabled);
 assert.equal(await page.locator('#profileName').inputValue(),'Título em edição'); checks.push('Atualização preserva rascunho');
 await page.locator('#profilePicker [data-action="profile-edit"][data-profile="1"]').click(); await visible('#confirmModal'); await page.locator('#confirmCancel').click();
 assert.equal(await page.locator('#profileNumber').inputValue(),'2'); assert.equal(await page.locator('#profileName').inputValue(),'Título em edição'); checks.push('Troca de perfil pode ser cancelada sem perder edição');
 await page.locator('#profileForm button[type=submit]').first().click();
 await page.waitForFunction(()=>document.getElementById('profileSaveState').textContent==='Sem alterações pendentes'&&!document.querySelector('#profileForm button[type=submit]').disabled);
 assert.equal(store.getUserProfile(user.id,2).name,'Título em edição'); assert.equal(store.getUserProfile(user.id,1).name,'Perfil principal'); checks.push('Salvar altera somente o perfil selecionado');
 await page.locator('#profileTabGoogle').click(); await visible('#profileClientId'); assert.equal(await page.locator('#profileClientSecret').inputValue(),''); await snap('03-google-api');
 await page.locator('#profileGoogleEmail').fill('novo@example.invalid'); await page.locator('#profileForm button[type=submit]').first().click(); await visible('#confirmModal'); await page.locator('#confirmCancel').click();
 assert.equal(store.getUserProfile(user.id,2).googleEmail,'tarde@example.invalid'); await page.locator('#cancelProfile').click(); await page.locator('#confirmAccept').click(); assert.equal(await page.locator('#profileGoogleEmail').inputValue(),'tarde@example.invalid'); checks.push('Alterar Google exige confirmação e descartar restaura os dados');
 await page.locator('#profileTabStatus').click(); await visible('#profileSummary'); assert.equal(await page.locator('#profilePanelLink').getAttribute('href'),`/dbmadmin/painel/${user.id}?profile=2`);
 await page.locator('#profileLogsButton').click(); await page.waitForFunction(()=>document.getElementById('detailsSummary').textContent.includes('Perfil preparado')); await snap('04-registros'); checks.push('Registros correspondem ao perfil escolhido');
 await nav('overview'); await page.locator('#monitorSeconds').fill('240'); await page.locator('#monitorForm button[type=submit]').click(); await page.waitForFunction(()=>document.getElementById('monitorFb').textContent.includes('salvas')); assert.equal(store.globalDiscoveryIntervalSeconds(),240); checks.push('Formulário global salva os intervalos existentes');
 await nav('create-user'); await page.locator('#username').fill('Conta criada pelo teste'); await page.locator('#userPass').fill('SenhaInicial2026'); await page.locator('#saveUser').click(); await page.waitForFunction(()=>document.getElementById('userFb').textContent.includes('Usuário criado')&&!document.getElementById('saveUser').disabled);
 const createdId=await page.locator('#userId').inputValue();assert.ok(createdId);assert.equal(store.userProfiles(createdId).length,1);assert.equal(await page.locator('[data-page="create-user"]').isVisible(),true);assert.equal(await page.locator('#userPass').inputValue(),'');checks.push('Criar usuário permanece em Criar e editar e abre a edição da conta criada');
 await page.locator('#username').fill('Conta revisada'); await page.locator('#saveUser').click(); await page.waitForFunction(()=>document.getElementById('userTitle').textContent==='Editar Conta revisada'&&!document.getElementById('saveUser').disabled);assert.equal(store.getUser(createdId).username,'Conta revisada');assert.equal(store.userProfiles(createdId).length,1);checks.push('Editar acesso na mesma área mantém os perfis e limpa o campo de senha');
 await openWorkspace();
 await nav('keys'); await clean('Desktop: chaves'); await snap('05-chaves'); assert.ok((await page.locator('#verificationKeys').textContent()).includes('Chave principal de teste'));
 await nav('activity'); await page.locator('#diagBtn').click(); await page.waitForFunction(()=>document.getElementById('detailsSummary').textContent.includes('3.2.3')); await clean('Desktop: atividade');
 await page.locator('#eventsBtn').click(); await page.waitForFunction(()=>document.getElementById('detailsSummary').textContent.includes('Consulta de teste concluída'));
 await page.locator('#auditBtn').click(); await page.waitForFunction(()=>document.getElementById('detailsText').textContent.includes('user_profile_update'));
 await nav('settings'); await clean('Desktop: configurações'); await snap('06-configuracoes');
 await nav('users'); await page.locator(`[data-action="user-open"][data-user-id="${other.id}"]`).click(); assert.equal(await page.locator('#selectedUserHeader a').count(),0); checks.push('Usuário bloqueado não tem atalho de acesso ativo');
 await page.locator('#backToUsers').click(); await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click(); await page.locator('[data-action="profile-add"]').click(); await page.locator('#confirmAccept').click(); await page.waitForFunction(()=>document.getElementById('profileNumber').value==='4'); checks.push('Adicionar perfil abre sua edição');
 await page.locator('#profileTabStatus').click(); await page.locator('#profileDeleteButton').click(); await page.locator('#confirmAccept').click(); await page.waitForFunction(()=>document.getElementById('profileNumber').value==='1'); assert.equal(store.userProfiles(user.id).length,3); assert.equal(await page.locator('#profileDeleteButton').isVisible(),false); checks.push('Excluir perfil adicional preserva Perfil 1');
 for (const width of [1024,390]) {
   await page.setViewportSize({width,height:1000});
   for (const area of ['overview','users','create-user','keys','activity','settings']) { await nav(area); await clean(`${width}px: ${area}`); if(area==='users') await snap('07-perfil-'+width); }
 }
 await openWorkspace(); await pick(page,'profileQuickSelect','2'); assert.equal(await page.locator('#profileNumber').inputValue(),'2'); checks.push('Seletor de perfil funciona no celular');
 await page.setViewportSize({width:1440,height:1050});
 await page.goto(base+'/dbmadmin/classico');await page.waitForURL(base+'/dbmadmin');await visible('#dashboard');assert.equal(await page.locator('script[src^="/admin.js"]').count(),0);assert.equal(await page.locator('[data-layout-switch]').count(),0);checks.push('Link antigo abre o único administrativo, mantendo a sessão');
 await nav('overview');assert.equal(await page.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()),'#070b14');assert.equal(await page.locator('.sidebar').evaluate(el=>el.getBoundingClientRect().width),260);checks.push('Painel único conserva a paleta e a largura do menu administrativo');
 await openWorkspace();await page.locator('#profileName').fill('Rascunho preservado');
 let unloadType='';page.once('dialog',async dialog=>{unloadType=dialog.type();await dialog.dismiss();});await page.reload().catch(()=>{});assert.equal(unloadType,'beforeunload');assert.equal(await page.locator('#profileName').inputValue(),'Rascunho preservado');checks.push('Sair da página avisa sobre formulário não salvo');
 await page.locator('#cancelProfile').click();await page.locator('#confirmAccept').click();

 await page.locator('#profileSearch').fill('tarde@example.invalid');assert.equal(await page.locator('#profilePicker .profile-pick').count(),1);await page.locator('#profilePicker .profile-pick').click();assert.equal(await page.locator('#profileNumber').inputValue(),'2');
 await page.locator('#profileSearch').fill('');await page.locator('#profileFilter').selectOption('disabled');assert.equal(await page.locator('#profilePicker .profile-pick').count(),1);assert.equal(await page.locator('#profileNumber').inputValue(),'2');await page.locator('#profileFilter').selectOption('all');checks.push('Busca e filtro não mudam o perfil em edição');
 assert.equal(await page.locator('#profileTabMessages,#profileTabSchedule,#profileAutoStart,#profileMessages,#profileChannel').count(),0);
 assert.deepEqual(store.getUserProfile(user.id,2).config,savedConfig);assert.equal(store.profileChannels(user.id,2)[0].channelInput,'@canalteste');checks.push('Editor simplificado preserva mensagens, canal, intervalo e início automático já salvos');
 await page.locator('#profileTabHistory').click();await page.waitForFunction(()=>document.getElementById('profileHistoryResults').textContent.includes('Falha simulada repetida'));assert.match(await page.locator('#profileHistoryResults').textContent(),/2 ocorrências/);await page.locator('#profileHistoryStatus').selectOption('success');await page.waitForFunction(()=>!document.getElementById('profileHistoryResults').textContent.includes('Consultando')&&document.getElementById('profileHistoryResults').textContent.includes('Perfil preparado'));assert.ok(!(await page.locator('#profileHistoryResults').textContent()).includes('Falha simulada'));checks.push('Histórico do perfil agrupa erros e filtra resultados');
 await page.locator('#profileTabGoogle').click();
 const popupPromise=context.waitForEvent('page');await page.locator('#editorNewTab').click();const popup=await popupPromise;await popup.waitForFunction(()=>document.getElementById('profileNumber')?.value==='2'&&!document.getElementById('profileGoogle').classList.contains('hidden'));
 assert.equal(await popup.locator('#profileUserId').inputValue(),user.id);assert.equal(await popup.locator('#profileGoogleEmail').inputValue(),'tarde@example.invalid');checks.push('Nova guia abre o mesmo usuário, perfil e aba');
 await page.locator('#profileTabGeneral').click();await page.locator('#profileName').fill('Rascunho da primeira guia');
 await popup.locator('#profileTabGeneral').click();await popup.locator('#profileName').fill('Nome salvo na segunda guia');await popup.locator('#profileForm button[type=submit]').first().click();await popup.waitForFunction(()=>document.getElementById('profileSaveState').textContent==='Sem alterações pendentes'&&!document.querySelector('#profileForm button[type=submit]').disabled);
 await page.locator('#profileForm button[type=submit]').first().click();await visible('#profileConflict');assert.equal(await page.locator('#profileName').inputValue(),'Rascunho da primeira guia');assert.equal(store.getUserProfile(user.id,2).name,'Nome salvo na segunda guia');await page.locator('#reloadProfile').click();await page.locator('#confirmAccept').click();await page.waitForFunction(()=>document.getElementById('profileName').value==='Nome salvo na segunda guia');await popup.close();checks.push('Conflito entre guias preserva rascunho e edição já salva');
 await page.locator('#profileTabStatus').click();await page.reload();await visible('#userListPane');assert.equal(await page.locator('#userWorkspace').isVisible(),false);assert.equal(await page.locator('#profileUserId').inputValue(),'');checks.push('Recarregar volta para todos os usuários sem restaurar a seleção');
 await page.locator('#userSearch').fill('@canalteste');assert.equal(await page.locator('#users [data-action="user-open"]').count(),1);await page.locator('#users [data-action="user-open"]').click();assert.equal(await page.locator('#profileNumber').inputValue(),'2');checks.push('Busca por canal abre o perfil correspondente');
 await nav('overview');await page.locator(`#attentionList [data-user-id="${user.id}"][data-profile="2"]`).click();assert.equal(await page.locator('#profileNumber').inputValue(),'2');await visible('#profileGoogle');checks.push('Pendência da visão geral abre o ajuste correspondente');
 await nav('activity');await page.locator('#activityUser').selectOption(user.id);await page.locator('#activityProfile').selectOption('2');await page.locator('#activityStatus').selectOption('error');await page.locator('#activityForm button[type=submit]').click();await page.waitForFunction(()=>document.getElementById('activityResults').textContent.includes('Falha simulada repetida'));assert.equal(await page.locator('#activityResults .activity-record').count(),1);assert.match(await page.locator('#activityResults').textContent(),/2 ocorrências/);await page.locator('#activityGroup').uncheck();assert.equal(await page.locator('#activityResults .activity-record').count(),2);await page.locator('#activityGroup').check();await snap('10-atividades-filtradas');checks.push('Atividade filtra conta e perfil e permite desagrupar erros');
 await page.locator('#activitySearch').fill('novo filtro');assert.equal(await page.locator('#activityResults .activity-record').count(),0);assert.equal(await page.locator('#downloadActivity').isVisible(),false);checks.push('Alterar filtros remove resultados da consulta anterior');
 await nav('keys');await page.locator('[data-action="key-history"]').click();await page.waitForFunction(()=>document.getElementById('keyHistoryResults').textContent.includes('Teste manual'));assert.match(await page.locator('#keyHistoryResults').textContent(),/ACTIVE|ATIVA|Ativa/);await snap('11-historico-chave');checks.push('Chave mostra o último teste e o histórico');
 await openWorkspace();for(const width of [1440,1024,390]){await page.setViewportSize({width,height:1000});for(const tab of ['General','Google','Status','History']){await page.locator('#profileTab'+tab).click();await clean(`${width}px: editor ${tab}`);}await snap('12-editor-'+width);}


 // Mesma paleta do clássico; cores distintas identificam estados por texto e cor.
 await page.setViewportSize({width:1440,height:1050});
 assert.equal(await page.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()),'#070b14');
 const tones=await page.evaluate(()=>['running','stopped','live','interval','paused','recovery','error','disabled','finishing'].map(code=>operationTone({operation:{code}})));
 assert.deepEqual(tones,['green','red','yellow','yellow','orange','orange','red','gray','orange']);checks.push('Paleta clássica com cores semânticas para execução, espera, pausa, erro e período adicional');
 for(const width of [320,390,768,920]){
   await page.setViewportSize({width,height:900});await openWorkspace();await visible('#adminMobileNav');
   assert.equal(await page.locator('#adminMobileNav button').count(),5);await visible('#profileQuickSelectTrigger');
   const positions=await page.locator('#adminMobileNav button').evaluateAll(items=>items.map(el=>({width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height})));
   assert.ok(positions.every(p=>p.width>=44&&p.height>=44));
   for(const area of ['overview','users','create-user','keys','activity','settings']){await nav(area);assert.equal(await page.locator(`${area==='settings'?'.sidebar-nav':'#adminMobileNav'} [data-page-target="${area}"]`).getAttribute('aria-current'),'page');await clean(`${width}px: navegação inferior ${area}`);}
 }
 await openWorkspace();await pick(page,'profileQuickSelect','2');await page.locator('#profileTabGeneral').click();await snap('13-admin-mobile');
 const userPage=await context.newPage();userPage.on('pageerror',e=>errors.push(e.message));
 await userPage.goto(base+`/dbmadmin/painel/${user.id}?profile=2`);await userPage.waitForFunction(()=>document.getElementById('activeProfileName')?.textContent==='Nome salvo na segunda guia');
 assert.equal(await userPage.locator('[data-page-target="privacy"],[data-page="privacy"]').count(),0);
 for(const width of [320,390,768,920]){
  await userPage.setViewportSize({width,height:900});await userPage.waitForFunction(()=>document.getElementById('renameProfileButton').parentElement.id==='profileNameMobileSlot');assert.equal(await userPage.locator('#profileTabs').isVisible(),false);assert.equal(await userPage.locator('#mobileProfileSelectTrigger').isVisible(),true);
  assert.equal(await userPage.locator('#mobileProfileSelect option').count(),3);
  assert.equal(await userPage.locator('#renameProfileButton').count(),1);
  assert.equal(await userPage.locator('#renameProfileButton').evaluate(el=>el.parentElement.id),'profileNameMobileSlot');
  for(const area of ['home','control','messages','activity']) {await userPage.locator(`#mobileBottomNav [data-page-target="${area}"]`).click();assert.equal(await userPage.locator('#renameProfileButton').isVisible(),false);}
  await userPage.locator('#mobileBottomNav [data-page-target="account"]').click();assert.equal(await userPage.locator('#renameProfileButton').isVisible(),true);
  checks.push(`${width}px: editar nome somente em Conta e canal`);

  await pick(userPage,'mobileProfileSelect','1');await userPage.waitForFunction(()=>document.getElementById('activeProfileName').textContent==='Perfil principal');
  await pick(userPage,'mobileProfileSelect','2');await userPage.waitForFunction(()=>document.getElementById('activeProfileName').textContent==='Nome salvo na segunda guia');
  await userPage.locator('#menuToggle').click();await userPage.locator('.sidebar-footer a[href="/privacy"]').waitFor({state:'visible'});assert.equal(await userPage.locator('.sidebar-footer a[href="/privacy"]').isVisible(),true);assert.equal(await userPage.locator('.sidebar-nav [data-page-target]:visible').count(),0);await userPage.locator('#navBackdrop').click({position:{x:width-8,y:200}});
  assert.ok(await userPage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 }
 await userPage.setViewportSize({width:390,height:900});await userPage.locator('#mobileBottomNav [data-page-target="messages"]').click();
 const messageInput=userPage.locator('#messages');await messageInput.fill('Rascunho de teste');
 await pick(userPage,'mobileProfileSelect','1');await userPage.locator('#confirmCancel').click();assert.equal(await userPage.locator('#mobileProfileSelect').inputValue(),'2');assert.equal(await messageInput.inputValue(),'Rascunho de teste');
 await pick(userPage,'mobileProfileSelect','1');await userPage.locator('#confirmAccept').click();await userPage.waitForFunction(()=>document.getElementById('activeProfileName').textContent==='Perfil principal');
 await userPage.locator('#mobileBottomNav [data-page-target="account"]').click();
 await userPage.locator('#renameProfileButton').click();await userPage.locator('#profileNameInput').fill('Perfil renomeado no celular');await userPage.locator('#profileNameForm button[type="submit"]').click();
 await userPage.waitForFunction(()=>document.getElementById('activeProfileName').textContent==='Perfil renomeado no celular');
 assert.equal(store.getUserProfile(user.id,1).name,'Perfil renomeado no celular');assert.equal(store.getUserProfile(user.id,2).name,'Nome salvo na segunda guia');
 assert.ok((await userPage.locator('#mobileProfileSelect option:checked').textContent()).includes('Perfil renomeado no celular'));
 if(out)await userPage.screenshot({path:path.join(out,'16-editar-nome-mobile.png'),fullPage:true,animations:'disabled'});
 checks.push('Renomear no celular salva somente o perfil selecionado e atualiza o seletor');
 await userPage.locator('#mobileBottomNav [data-page-target="home"]').click();
 if(out)await userPage.screenshot({path:path.join(out,'14-usuario-mobile.png'),fullPage:true});
 await userPage.setViewportSize({width:1440,height:1000});await userPage.waitForFunction(()=>document.getElementById('renameProfileButton').parentElement.id==='profileNameDesktopSlot');assert.equal(await userPage.locator('#profileTabs').isVisible(),true);assert.equal(await userPage.locator('#mobileProfileSelectTrigger').isVisible(),false);
 assert.equal(await userPage.locator('#renameProfileButton').evaluate(el=>el.parentElement.id),'profileNameDesktopSlot');assert.equal(await userPage.locator('#renameProfileButton').isVisible(),true);
 await userPage.locator('#renameProfileButton').click();await userPage.locator('#profileNameInput').fill('Perfil principal');await userPage.locator('#profileNameForm button[type="submit"]').click();await userPage.waitForFunction(()=>document.getElementById('activeProfileName').textContent==='Perfil principal');
 checks.push('Redimensionar para desktop devolve o mesmo botão ao topo e mantém a edição funcional');
 await userPage.locator('#profileTabs [data-profile="2"]').click();await userPage.waitForFunction(()=>document.getElementById('activeProfileName').textContent==='Nome salvo na segunda guia');
 if(out)await userPage.screenshot({path:path.join(out,'15-usuario-desktop.png'),fullPage:true});
 assert.deepEqual(store.getUserProfile(user.id,2).config,savedConfig);checks.push('Usuário: seletor somente mobile, confirmação de rascunho, perfis desktop e privacidade no rodapé preservados');

 // Conexão lenta e resposta fora de ordem: nenhuma chamada externa é feita.
 const holds=[];
 const holdProfile=async number=>{
   let release,arrive,finished;
   const gate=new Promise(resolve=>release=resolve),seen=new Promise(resolve=>arrive=resolve),done=new Promise(resolve=>finished=resolve);
   const matcher=url=>url.pathname.endsWith('/api/profiles/'+number);
   let requests=0;
   const handler=async route=>{requests++;arrive();try{const response=await route.fetch();await gate;await route.fulfill({response});}catch(e){if(!/cancel|closed|abort|Target|disposed|already handled/i.test(e.message))errors.push(e.message);}finally{finished();}};
   await userPage.route(matcher,handler);
   const hold={seen,done,get requests(){return requests;},release:async()=>{release();await userPage.unroute(matcher,handler);}};holds.push(hold);return hold;
 };
 try {
   await userPage.setViewportSize({width:390,height:900});
   const late=await holdProfile(3);
   await pick(userPage,'mobileProfileSelect','3');await late.seen;
   assert.match(await userPage.locator('#mobileProfileSelectTrigger').textContent(),/Transmissões especiais/);
   assert.equal(await userPage.locator('#profileLoadingCard').isVisible(),true);
   assert.equal(await userPage.locator('#profileContent').evaluate(el=>el.inert),true);
   assert.equal(await userPage.evaluate(()=>currentState),null);
   checks.push('Primeira visita mostra imediatamente o perfil escolhido e não mistura os dados anteriores');
   await pick(userPage,'mobileProfileSelect','1');await userPage.waitForFunction(()=>currentState?.selectedProfile===1&&!profileLoading);
   await late.release();await late.done;
   assert.equal(await userPage.evaluate(()=>currentState.selectedProfile),1);
   assert.match(await userPage.locator('#mobileProfileSelectTrigger').textContent(),/Perfil principal/);
   checks.push('Troca rápida cancela consulta anterior e ignora a resposta atrasada');

   const slow=await holdProfile(2);
   await pick(userPage,'mobileProfileSelect','2');await slow.seen;
   assert.equal(await userPage.locator('#profileLoadingCard').isVisible(),false);
   assert.equal(await userPage.locator('#profileContent').isVisible(),true);
   assert.match(await userPage.locator('#activeProfileName').textContent(),/Nome salvo na segunda guia/);
   assert.equal(await userPage.locator('#messages').inputValue(),savedConfig.messages);
   assert.equal(await userPage.locator('#profileContent').evaluate(el=>el.inert),true);
   assert.match(await userPage.locator('#profileSyncNotice').textContent(),/Atualizando/);
   // Ultrapassa o intervalo de atualização para verificar que o poll não reinicia a consulta.
   await userPage.waitForTimeout(5300);
   assert.equal(slow.requests,1);
   checks.push('Perfil já visitado aparece antes da resposta e a atualização automática não duplica a consulta lenta');
   await slow.release();await slow.done;await userPage.waitForFunction(()=>currentState?.selectedProfile===2&&!profileLoading);
   assert.equal(await userPage.locator('#profileContent').evaluate(el=>el.inert),false);

   const offline=url=>url.pathname.endsWith('/api/profiles/3');
   await userPage.route(offline,route=>route.abort('failed'));
   await pick(userPage,'mobileProfileSelect','3');await userPage.locator('#connectionBanner').waitFor({state:'visible'});
   assert.equal(await userPage.locator('#profileContent').evaluate(el=>el.inert),true);
   assert.equal(await userPage.locator('#profileLoadingCard').isVisible(),true);
   await userPage.unroute(offline);await userPage.locator('#retryConnectionButton').click();
   await userPage.waitForFunction(()=>currentState?.selectedProfile===3&&!profileLoading);
   checks.push('Falha de rede mantém ações protegidas e Tentar novamente carrega o perfil correto');

   // Muitos perfis, nomes longos, busca, teclado e renovação de dados com a lista aberta.
   for(let i=4;i<=12;i++){store.addUserProfile(user.id);store.updateUserProfile(user.id,i,p=>{p.name=i===12?'Ranqueada especial — transmissões da noite e torneios 🎮':`Perfil de teste ${i}`;});}
   await userPage.locator('#refreshButton').click();await userPage.waitForFunction(()=>document.querySelectorAll('#mobileProfileSelect option').length===12);
   await userPage.locator('#mobileProfileSelectTrigger').click();await userPage.locator('#mobileProfileSelectDialog .profile-select-search').fill('ranqueada');
   assert.equal(await userPage.locator('#mobileProfileSelectDialog [data-profile-choice]:visible').count(),1);
   await userPage.locator('#mobileProfileSelectDialog [data-profile-choice="12"]').click();await userPage.waitForFunction(()=>currentState?.selectedProfile===12&&!profileLoading);
   await userPage.locator('#mobileProfileSelectTrigger').click();
   await userPage.evaluate(()=>refreshState(false));
   assert.equal(await userPage.locator('#mobileProfileSelectDialog').evaluate(el=>el.open),true);
   assert.equal(await userPage.evaluate(()=>document.activeElement.dataset.profileChoice),'12');
   await userPage.keyboard.press('Home');assert.equal(await userPage.evaluate(()=>document.activeElement.dataset.profileChoice),'1');
   await userPage.keyboard.press('End');assert.equal(await userPage.evaluate(()=>document.activeElement.dataset.profileChoice),'12');
   if(out)await userPage.screenshot({path:path.join(out,'17-seletor-usuario.png'),animations:'disabled'});
   const userTone=await userPage.locator('#mobileProfileSelectDialog').evaluate(el=>getComputedStyle(el).getPropertyValue('--picker-accent').trim());assert.equal(userTone,'#facc15');
   await userPage.keyboard.press('Escape');assert.equal(await userPage.evaluate(()=>document.activeElement.id),'mobileProfileSelectTrigger');
   checks.push('Lista de 12 perfis permite busca, teclado e mantém o foco durante a atualização');
   for(const width of [320,390,768,920]){
     await userPage.setViewportSize({width,height:740});await userPage.locator('#mobileProfileSelectTrigger').click();
     assert.ok(await userPage.locator('#mobileProfileSelectDialog').evaluate(el=>el.scrollWidth<=el.clientWidth));
     assert.ok(await userPage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
     await userPage.locator('#mobileProfileSelectDialog .profile-select-close').click();
   }
   checks.push('Seletor do usuário respeita o tema dourado e cabe de 320 a 920 px com nomes longos');

   await page.setViewportSize({width:390,height:900});await nav('overview');await nav('users');await visible('#userListPane');
   assert.equal(await page.locator('#userWorkspace').isVisible(),false);checks.push('Voltar à aba de perfis sempre abre a lista completa de usuários');
   await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click();await page.locator('#refreshBtn').click();await page.waitForFunction(()=>document.querySelectorAll('#profileQuickSelect option').length===12);
   await page.locator('#profileQuickSelectTrigger').click();
   const adminTone=await page.locator('#profileQuickSelectDialog').evaluate(el=>getComputedStyle(el).getPropertyValue('--picker-accent').trim());assert.equal(adminTone,'#3b82f6');
   if(out)await page.screenshot({path:path.join(out,'18-seletor-admin.png'),animations:'disabled'});
   await page.locator('#profileQuickSelectDialog .profile-select-search').fill('12');await page.locator('#profileQuickSelectDialog [data-profile-choice="12"]').click();
   assert.equal(await page.locator('#profileNumber').inputValue(),'12');
   await page.locator('#profileName').fill('Rascunho preservado no seletor');await pick(page,'profileQuickSelect','1');await page.locator('#confirmCancel').click();
   assert.equal(await page.locator('#profileQuickSelect').inputValue(),'12');assert.equal(await page.locator('#profileName').inputValue(),'Rascunho preservado no seletor');
   await nav('users');await page.locator('#confirmCancel').click();assert.equal(await page.locator('#userWorkspace').isVisible(),true);
   await nav('users');await page.locator('#confirmAccept').click();await visible('#userListPane');
   checks.push('Seletor administrativo segue o azul do painel e preserva rascunhos ao cancelar a troca ou o retorno à lista');
   await page.locator(`[data-action="user-open"][data-user-id="${user.id}"]`).click();
   await page.evaluate(owner=>localStorage.setItem('chatflow.admin.navigation.'+owner,JSON.stringify({page:'users',user:'seleção antiga',profile:12,tab:'google'})),admin.id);
   await page.goto(base+'/dbmadmin/teste');await visible('#userListPane');assert.equal(await page.locator('#userWorkspace').isVisible(),false);
   checks.push('Preferência antiga de usuário e perfil é ignorada ao abrir novamente o administrativo');
 } finally {for(const hold of holds)await hold.release();}

 // V3.2.0: ordem, comandos horizontais, estados, foto e erros em português.
 for (const selector of ['.sidebar-nav','#mobileBottomNav']) {
   assert.deepEqual(await userPage.locator(selector+' [data-page-target]').evaluateAll(nodes=>nodes.map(n=>n.dataset.pageTarget)),['home','account','messages','control','activity']);
 }
 checks.push('Desktop e mobile: Controle depois de Mensagens e envio, com as cinco abas preservadas');
 for(const width of [320,360,390,430,768,1440]){
   await userPage.setViewportSize({width,height:900});
   const menu=width<=920?'#mobileBottomNav':'.sidebar-nav';
   await userPage.locator(menu+' [data-page-target="control"]').click();
   await userPage.mouse.move(0,0);
   await userPage.evaluate(()=>{for(const a of document.getAnimations())if(Number.isFinite(a.effect?.getComputedTiming().endTime))a.finish();});
   const commands=await userPage.locator('.control-actions .button').evaluateAll(nodes=>nodes.map(n=>({id:n.id,x:n.getBoundingClientRect().x,y:n.getBoundingClientRect().y,width:n.getBoundingClientRect().width,height:n.getBoundingClientRect().height,color:getComputedStyle(n).backgroundColor,overflow:n.scrollWidth>n.clientWidth})));
   assert.deepEqual(commands.map(x=>x.id),['startButton','pauseButton','stopButton']);
   assert.ok(commands.every(x=>Math.abs(x.y-commands[0].y)<1&&x.width>=44&&x.height>=44&&!x.overflow),JSON.stringify(commands));
   assert.ok(commands[0].x<commands[1].x&&commands[1].x<commands[2].x);
   assert.equal(commands[0].color,'rgb(21, 128, 61)');assert.equal(commands[1].color,'rgb(225, 184, 45)');assert.equal(commands[2].color,'rgb(185, 28, 28)');
   assert.ok(await userPage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
   if(out&&width===320)await userPage.screenshot({path:path.join(out,'19-controle-320.png'),fullPage:true,animations:'disabled'});
 }
 checks.push('Comandos lado a lado de 320 a 1440 px: Iniciar verde, Pausar amarelo médio e Parar vermelho');
 await userPage.setViewportSize({width:390,height:900});
 await userPage.locator('#mobileBottomNav [data-page-target="home"]').click();
 const order=await userPage.evaluate(()=>({profile:document.getElementById('profileOverviewCard').getBoundingClientRect().bottom,quota:document.getElementById('quotaCard').getBoundingClientRect().top}));
 assert.ok(order.profile<=order.quota);checks.push('Início: identificação e estado do perfil acima da cota do cliente');
 for(const [number,status] of [[1,'running'],[2,'paused'],[12,'stopped']]) store.updateUserProfile(user.id,number,p=>p.runtime.status=status);
 await userPage.evaluate(()=>refreshState(false));
 await userPage.locator('#mobileProfileSelectTrigger').click();
 for(const [number,label,tone,color] of [[1,'RODANDO','green','rgb(134, 239, 172)'],[2,'PAUSADO','yellow','rgb(252, 211, 77)'],[12,'PARADO','red','rgb(252, 165, 165)']]){
   const badge=userPage.locator(`#mobileProfileSelectDialog [data-profile-choice="${number}"] .profile-select-badge`);
   assert.equal(await badge.textContent(),label);assert.equal(await badge.getAttribute('data-tone'),tone);assert.equal(await badge.evaluate(n=>getComputedStyle(n).color),color);
 }
 await userPage.keyboard.press('Escape');
 assert.equal(await userPage.locator('#mobileProfileSelectTrigger .profile-select-badge').getAttribute('data-tone'),'red');
 checks.push('Seletor do usuário aberto e fechado: rodando verde, pausado amarelo e parado vermelho');
 await page.setViewportSize({width:390,height:900});await openWorkspace();await page.locator('#refreshBtn').click();await page.waitForFunction(()=>!document.getElementById('refreshBtn').disabled);
 await page.locator('#profileQuickSelectTrigger').click();
 for(const [number,label,tone] of [[1,'RODANDO','green'],[2,'PAUSADO','yellow'],[12,'PARADO','red']]){
   const badge=page.locator(`#profileQuickSelectDialog [data-profile-choice="${number}"] .profile-select-badge`);assert.equal(await badge.textContent(),label);assert.equal(await badge.getAttribute('data-tone'),tone);
 }
 await page.locator('#profileQuickSelectDialog [data-profile-choice="12"]').click();assert.equal(await page.locator('#profileQuickSelectTrigger .profile-select-badge').getAttribute('data-tone'),'red');
 checks.push('Seletor administrativo usa as mesmas três cores e conserva o detalhe operacional');
 const photo='https://yt3.ggpht.com/chatflow-test-channel-photo';
 await userPage.route(photo,route=>route.fulfill({status:200,contentType:'image/png',body:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6oYAAAAAASUVORK5CYII=','base64')}));
 const monitored=store.upsertGlobalChannel({handle:'@fototeste',canonicalUrl:'https://www.youtube.com/@fototeste',displayName:'Canal monitorado de teste',thumbnailUrl:photo});store.subscribeChannel(user.id,12,monitored,'@fototeste');
 await userPage.evaluate(()=>refreshState(false));await userPage.locator('#mobileBottomNav [data-page-target="account"]').click();
 await userPage.waitForFunction(()=>document.querySelector('.channel-avatar img')?.naturalWidth>0);
 assert.equal(await userPage.locator('.channel-avatar img').isVisible(),true);assert.equal(await userPage.locator('.channel-avatar img').getAttribute('src'),photo);
 assert.match(await userPage.locator('.channel-info').textContent(),/Canal monitorado de teste.*@fototeste/s);
 assert.notEqual(await userPage.locator('#accountPhoto').getAttribute('src'),photo);
 for(const width of [320,390,1440]){
   await userPage.setViewportSize({width,height:1000});
   const aligned=await userPage.locator('.channel-item').evaluate(el=>{const a=el.querySelector('.channel-avatar').getBoundingClientRect(),b=el.querySelector('.channel-info').getBoundingClientRect();return a.right<=b.left&&Math.abs((a.top+a.bottom)/2-(b.top+b.bottom)/2)<50;});assert.ok(aligned);
   assert.ok(await userPage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
   if(out)await userPage.screenshot({path:path.join(out,`20-canal-${width}.png`),fullPage:true,animations:'disabled'});
 }
 checks.push('Foto do canal monitorado à esquerda do nome e @, separada da conta autorizada, sem transbordar no mobile');
 store.upsertGlobalChannel({handle:'@fototeste',canonicalUrl:monitored.canonical_url,thumbnailUrl:photo+'-inexistente'});
 await userPage.route(photo+'-inexistente',route=>route.fulfill({status:404,body:''}));
 await userPage.evaluate(()=>refreshState(false));await userPage.waitForFunction(()=>!document.querySelector('.channel-avatar img'));
 assert.equal(await userPage.locator('.channel-avatar span').textContent(),'C');checks.push('Imagem indisponível usa identificação de reserva, mantendo nome e link do canal');
 const rawError='The specified live chat is no longer live. [HTTP 403 · liveChatEnded]';
 store.updateUserProfile(user.id,12,p=>p.runtime.lastError=rawError);
 store.appendLog(store.getUserProfile(user.id,12),'send','Mensagem original em inglês: The specified live chat is no longer live.','error',rawError);
 await userPage.evaluate(()=>refreshState(false));await userPage.setViewportSize({width:390,height:1000});await userPage.locator('#mobileBottomNav [data-page-target="activity"]').click();
 assert.match(await userPage.locator('#logs .log-error').first().textContent(),/Este chat ao vivo já foi encerrado.*HTTP 403.*liveChatEnded/);
 assert.match(await userPage.locator('#logs .log-message').first().textContent(),/Mensagem original em inglês: The specified/);
 await userPage.locator('#logs .api-error-original summary').first().click();assert.equal(await userPage.locator('#logs .api-error-original pre').first().textContent(),rawError);
 await userPage.locator('#mobileBottomNav [data-page-target="home"]').click();assert.match(await userPage.locator('#lastError').textContent(),/Este chat ao vivo já foi encerrado/);
 assert.match(await userPage.locator('#errorHistoryList .log-error').first().textContent(),/Este chat ao vivo já foi encerrado/);
 checks.push('Usuário: erros em português no estado, histórico e atividade; mensagem enviada e original técnico preservados');
 await nav('activity');await page.locator('#activitySearch').fill('');await page.locator('#activityUser').selectOption(user.id);await page.locator('#activityProfile').selectOption('12');await page.locator('#activityStatus').selectOption('error');await page.locator('#activityForm button[type=submit]').click();await page.waitForFunction(()=>document.getElementById('activityResults').textContent.includes('Este chat ao vivo já foi encerrado'));
 assert.match(await page.locator('#activityResults .error-inline').textContent(),/Este chat ao vivo já foi encerrado/);
 assert.match(await page.locator('#activityResults .record-details pre').textContent(),/The specified live chat is no longer live/);
 checks.push('Erros administrativos em português com original técnico preservado');


 // V3.2.0: contas na área existente, títulos únicos e altura mobile.
 await page.setViewportSize({width:390,height:900});await nav('create-user');await page.locator('#userEditMode').click();
 assert.equal(await page.locator('#userEditor').isVisible(),false);
 await pick(page,'userAccountSelect',user.id);assert.equal(await page.locator('#username').inputValue(),'Equipe Peralta');assert.equal(await page.locator('#userPass').inputValue(),'');
 const profilesBeforeRename=JSON.stringify(store.userProfiles(user.id));
 await page.locator('#username').fill('Equipe Peralta X');await page.locator('#refreshBtn').click();await page.waitForFunction(()=>!document.getElementById('refreshBtn').disabled);assert.equal(await page.locator('#username').inputValue(),'Equipe Peralta X');
 await pick(page,'userAccountSelect',other.id);await page.locator('#confirmCancel').click();assert.equal(await page.locator('#userId').inputValue(),user.id);assert.equal(await page.locator('#username').inputValue(),'Equipe Peralta X');
 await page.locator('#saveUser').click();await page.waitForFunction(()=>document.getElementById('userTitle').textContent==='Editar Equipe Peralta X'&&!document.getElementById('saveUser').disabled);
 assert.equal(store.getUser(user.id).username,'Equipe Peralta X');assert.equal(JSON.stringify(store.userProfiles(user.id)),profilesBeforeRename);assert.match(await page.locator('#userAccountSelectTrigger').textContent(),/Equipe Peralta X/);
 checks.push('Usuários: selecionar conta, renomear e salvar mantém perfis; atualização e troca cancelada preservam o rascunho');
 await pick(page,'userAccountSelect',other.id);assert.equal(await page.locator('#userActive').inputValue(),'false');assert.equal(await page.locator('#userPass').inputValue(),'');
 await page.locator('#userCreateMode').click();assert.equal(await page.locator('#userId').inputValue(),'');assert.equal(await page.locator('#userAccountPicker').isVisible(),false);assert.equal(await page.locator('#userPass').getAttribute('required'),'');
 await page.locator('#username').fill('Rascunho de conta');await page.locator('#userEditMode').click();await page.locator('#confirmCancel').click();assert.equal(await page.locator('#username').inputValue(),'Rascunho de conta');
 await page.locator('#userEditMode').click();await page.locator('#confirmAccept').click();assert.equal(await page.locator('#userEditor').isVisible(),false);
 checks.push('Criar e editar usam a mesma aba, exigem seleção explícita e protegem dados ainda não salvos');
 for(let i=1;i<=5;i++)store.createUser({id:store.id('usr'),username:'Conta adicional '+i,active:true,sessionVersion:1});
 await page.locator('#refreshBtn').click();await page.waitForFunction(()=>document.querySelectorAll('#userAccountSelect option').length===8);
 await page.locator('#userAccountSelectTrigger').click();await page.locator('#userAccountSelectDialog .profile-select-search').fill('Equipe Peralta X');assert.equal(await page.locator('#userAccountSelectDialog [data-profile-choice]:visible').count(),1);await page.locator(`#userAccountSelectDialog [data-profile-choice="${user.id}"]`).click();
 assert.doesNotMatch(await page.locator('#userAccountSelectTrigger').textContent(),/usr_/);
 if(out)await page.screenshot({path:path.join(out,'21-usuarios-mobile.png'),fullPage:true,animations:'disabled'});
 checks.push('Seletor de contas lista usuários ativos e bloqueados, permite busca e segue as cores do administrativo');
 assert.equal(await page.locator('#adminMobileNav [data-page-target="settings"]').count(),0);
 assert.equal(await page.locator('#adminMobileNav [data-page-target="users"]').textContent().then(x=>x.trim()),'Usuários e perfis');
 assert.equal(await page.locator('#adminMobileNav [data-page-target="create-user"]').textContent().then(x=>x.trim()),'Criar e editar');
 await page.locator('#menuToggle').click();await page.locator('.sidebar-nav [data-page-target="settings"]').click();assert.equal(await page.locator('[data-page="settings"]').isVisible(),true);assert.equal(await page.locator('#sidebar').evaluate(n=>n.classList.contains('open')),false);
 checks.push('Mobile administrativo: cinco botões no rodapé e Configurações no menu das três barras');
 await userPage.evaluate(()=>refreshState(false));
 for(const width of [320,390,768,1440]){
   await userPage.setViewportSize({width,height:950});const menu=width<=920?'#mobileBottomNav':'.sidebar-nav';
   for(const area of ['home','account','messages','control','activity']){
     await userPage.locator(menu+` [data-page-target="${area}"]`).click();
     assert.equal(await userPage.locator('.topbar h1').count(),1);assert.equal(await userPage.locator('#pageTitle,#pageSubtitle,#accountPageTitle,#messagesPageTitle,#activityPageTitle').count(),0);
     assert.equal(await userPage.locator('[data-page="'+area+'"] > .page-section-heading').count(),0);
     assert.ok(await userPage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
     assert.ok(await userPage.evaluate(()=>{const h=document.getElementById('pageEyebrow').getBoundingClientRect(),a=document.querySelector('.topbar-actions').getBoundingClientRect();return h.right<=a.left-6||h.bottom<=a.top-6;}),`${width}px: título sem sobrepor ações em ${area}`);
     if(area==='home'){
       assert.equal(await userPage.locator('#pageEyebrow').textContent(),width<=920?'ChatFlow Peralta':'INÍCIO');
       const gap=await userPage.evaluate(()=>document.getElementById('quotaCard').getBoundingClientRect().top-document.getElementById('profileOverviewCard').getBoundingClientRect().bottom);assert.ok(gap>=13&&gap<=20,String(gap));
     }
     if(area==='control'&&width>920){const sizes=await userPage.evaluate(()=>[document.querySelector('.profile-context'),document.querySelector('.control-center-card')].map(x=>({width:x.getBoundingClientRect().width,left:x.getBoundingClientRect().left})));assert.deepEqual(sizes[0],sizes[1]);}
   }
   if(width<=920)assert.ok(await userPage.locator('.profile-context').evaluate(n=>n.getBoundingClientRect().height<160));
   await userPage.locator(menu+' [data-page-target="messages"]').click();assert.equal(await userPage.locator('#sendMode option[value="interval"]').textContent(),'Intervalo manual');
   if(out)await userPage.screenshot({path:path.join(out,`22-titulos-compactos-${width}.png`),fullPage:true,animations:'disabled'});
 }
 checks.push('Usuário: título amarelo único em todas as abas, Início renomeado e Intervalo manual no seletor');
 checks.push('Espaço entre perfil e cota de 320 a 1440 px; seletor mobile compacto e Controle desktop na largura do Perfil ativo');

 // V3.2.0: verificar também o acesso comum, que exibe Atualizar e Sair.
 const regularSession=security.signSession(user.id,'user',store.getUser(user.id).sessionVersion);store.saveSession(regularSession.session);
 await context.addCookies([{name:'auto_server_user',value:regularSession.token,domain:'127.0.0.1',path:'/',httpOnly:true,sameSite:'Strict'}]);
 const regularPage=await context.newPage();regularPage.on('pageerror',e=>errors.push(e.message));
 await regularPage.setViewportSize({width:1440,height:1000});await regularPage.goto(base+'/painel');
 await regularPage.locator('#dashboard').waitFor({state:'visible'});await regularPage.evaluate(()=>selectProfile(1));
 assert.equal(await regularPage.locator('#adminAccessBanner').isVisible(),false);assert.equal(await regularPage.locator('#logoutButton').textContent(),'SAIR');
 const pageTitles={home:'INÍCIO',account:'CONTA E CANAL',messages:'MENSAGENS E ENVIO',control:'CONTROLES',activity:'ATIVIDADE'};
 for(const width of [320,360,390,430,768,920,1024,1440]){
   await regularPage.setViewportSize({width,height:950});
   const menu=width<=920?'#mobileBottomNav':'.sidebar-nav';
   for(const [area,title] of Object.entries(pageTitles)){
     await regularPage.locator(menu+` [data-page-target="${area}"]`).click();
     await regularPage.waitForFunction(size=>parseFloat(getComputedStyle(document.getElementById('pageEyebrow')).fontSize)===size,width>920&&area==='home'?16:13);
     const layout=await regularPage.evaluate(()=>{const rect=n=>{const r=n.getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom,width:r.width,height:r.height};},h=document.getElementById('pageEyebrow'),bar=document.querySelector('.topbar'),refresh=document.getElementById('refreshButton'),logout=document.getElementById('logoutButton');return {title:h.textContent,font:parseFloat(getComputedStyle(h).fontSize),heading:rect(h),refresh:rect(refresh),logout:rect(logout),bar:rect(bar),background:getComputedStyle(bar).backgroundImage,reference:getComputedStyle(document.getElementById('profileOverviewCard')).backgroundImage,circle:getComputedStyle(bar,'::after').backgroundColor,circleReference:getComputedStyle(document.getElementById('profileOverviewCard'),'::after').backgroundColor,overflow:document.documentElement.scrollWidth>innerWidth};});
     assert.equal(layout.title,width<=920?'ChatFlow Peralta':title);assert.equal(layout.font,width>920&&area==='home'?16:13,`${width}px ${area}: fonte do título`);assert.equal(layout.overflow,false);
     assert.equal(layout.background,layout.reference);assert.equal(layout.circle,layout.circleReference);
     assert.ok(Math.abs(layout.refresh.y-layout.logout.y)<1&&layout.refresh.right<layout.logout.x,JSON.stringify(layout));
     assert.ok(layout.heading.right<=layout.refresh.x-6&&Math.abs(layout.heading.y+layout.heading.height/2-layout.refresh.y-layout.refresh.height/2)<2,`${width}px ${area}: cabeçalho em uma linha com título legível: ${JSON.stringify(layout)}`);
     assert.ok(layout.logout.right<=layout.bar.right-8);
     if(area==='account')assert.match(await regularPage.locator('#renameProfileButton').textContent(),/EDITAR NOME/);
     if(area==='control')assert.equal(await regularPage.locator('#pauseButton').evaluate(n=>getComputedStyle(n).color),'rgb(37, 28, 6)');
     if(area==='activity'){
       assert.equal(await regularPage.locator('#activityHistoryCard #clearLogsButton').count(),1);
       const boxes=await regularPage.evaluate(()=>['activityHistoryTitle','clearLogsButton','activityHistoryCard','lives'].map(id=>{const n=document.getElementById(id),r=n.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,center:r.top+r.height/2};}));
       assert.ok(boxes[0].right<=boxes[1].left-6&&Math.abs(boxes[0].center-boxes[1].center)<3,JSON.stringify(boxes));
       assert.ok(boxes[2].top>boxes[3].bottom);
     }
     if(out&&[320,390,1440].includes(width)&&['home','control','activity'].includes(area))await regularPage.screenshot({path:path.join(out,`23-painel-${area}-${width}.png`),fullPage:true,animations:'disabled'});
   }
 }
 checks.push('Acesso comum: marca fixa no mobile, títulos desktop preservados e Atualizar/Sair lado a lado de 320 a 1440 px');
 checks.push('Todas as abas: topo cinza preservado com marca mobile e títulos desktop');
 checks.push('Editar nome identificado; Pausar amarelo médio com texto escuro legível');
 checks.push('Atividade: limpar registros dentro da caixa, à direita do título e abaixo das transmissões em todas as larguras');
 // V3.2.0: o acesso administrativo compacta somente os botões do topo mobile.
 assert.equal(await userPage.locator('#dashboard').evaluate(n=>n.classList.contains('admin-view')),true);
 assert.equal(await regularPage.locator('#dashboard').evaluate(n=>n.classList.contains('admin-view')),false);
 for(const width of [320,360,390,430,768,920,1024,1440]){
   await userPage.setViewportSize({width,height:950});
   const menu=width<=920?'#mobileBottomNav':'.sidebar-nav';
   for(const [area,title] of Object.entries(pageTitles)){
     await userPage.locator(menu+` [data-page-target="${area}"]`).click();
     await userPage.waitForFunction(size=>parseFloat(getComputedStyle(document.getElementById('pageEyebrow')).fontSize)===size,width>920&&area==='home'?16:13);
     const layout=await userPage.evaluate(()=>{
       const rect=n=>{const r=n.getBoundingClientRect();return {left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};};
       const h=document.getElementById('pageEyebrow');
       return {title:h.textContent,font:parseFloat(getComputedStyle(h).fontSize),heading:rect(h),bar:rect(document.querySelector('.topbar')),refresh:rect(document.getElementById('refreshButton')),back:rect(document.getElementById('logoutButton')),overflow:document.documentElement.scrollWidth>innerWidth,textOverflow:h.scrollWidth>h.clientWidth};
     });
     assert.equal(layout.title,width<=920?'ChatFlow Peralta':title);assert.equal(layout.font,width>920&&area==='home'?16:13);assert.equal(layout.overflow,false);assert.equal(layout.textOverflow,false);
     if(width<=920){
       assert.ok(layout.heading.right<=layout.refresh.left-6,`${width}px ${area}: título à esquerda dos botões: ${JSON.stringify(layout)}`);
       assert.ok(layout.refresh.bottom<=layout.back.top-3,JSON.stringify(layout));
       assert.ok(Math.abs(layout.refresh.left-layout.back.left)<1&&Math.abs(layout.refresh.right-layout.back.right)<1,JSON.stringify(layout));
       assert.ok(Math.abs((layout.heading.top+layout.heading.bottom)/2-(layout.refresh.top+layout.back.bottom)/2)<2,JSON.stringify(layout));
       assert.ok(layout.bar.height<=92,`${width}px ${area}: altura compacta: ${JSON.stringify(layout)}`);
     }else{
       assert.ok(Math.abs(layout.refresh.top-layout.back.top)<1&&layout.refresh.right<layout.back.left,JSON.stringify(layout));
     }
     if(out&&[320,390,1440].includes(width)&&['home','messages','activity'].includes(area))await userPage.screenshot({path:path.join(out,`24-admin-acesso-${area}-${width}.png`),fullPage:true,animations:'disabled'});
   }
 }
 checks.push('Acesso administrativo: Atualizar acima de Voltar à direita do título no mobile, cabeçalho compacto; desktop horizontal');
 for(const width of [320,390,920,1440]){
   await page.setViewportSize({width,height:950});
   for(const [area,label] of [['users','Usuários e perfis'],['create-user','Criar e editar']]){
     await nav(area);assert.equal(await page.locator('#pageTitle').textContent(),label);
     const menu=width<=920?'#adminMobileNav':'.sidebar-nav';
     assert.equal((await page.locator(menu+` [data-page-target="${area}"] span`).textContent()).trim(),label);
     assert.ok(await page.locator(menu+` [data-page-target="${area}"]`).evaluate(n=>n.scrollWidth<=n.clientWidth&&n.scrollHeight<=n.clientHeight));
     const header=await page.evaluate(()=>{const range=document.createRange();range.selectNodeContents(document.querySelector('.topbar-heading > div'));return {right:Math.max(...[...range.getClientRects()].map(r=>r.right)),actionsLeft:document.querySelector('.topbar-actions').getBoundingClientRect().left,overflow:document.documentElement.scrollWidth>innerWidth};});
     assert.ok(!header.overflow&&header.right<=header.actionsLeft-6,`${width}px ${area}: título administrativo sem sobreposição: ${JSON.stringify(header)}`);
   }
   if(out&&[320,1440].includes(width))await page.screenshot({path:path.join(out,`25-abas-admin-${width}.png`),fullPage:true,animations:'disabled'});
 }
 checks.push('Administração: Usuários e perfis e Criar e editar na navegação e no título, com os mesmos formulários e rotas');
 for(const width of [390,1440]){
   await regularPage.setViewportSize({width,height:950});
   await regularPage.locator((width<=920?'#mobileBottomNav':'.sidebar-nav')+' [data-page-target="account"]').click();
   const originalName=store.getUserProfile(user.id,1).name;
   await regularPage.locator('#renameProfileButton').click();
   await regularPage.waitForFunction(()=>{const input=document.getElementById('profileNameInput');return document.activeElement===input&&input.selectionStart===input.value.length&&input.selectionEnd===input.value.length;});
   assert.equal(await regularPage.locator('#profileNameInput').inputValue(),originalName);
   await regularPage.locator('#profileNameInput').pressSequentially(' X');assert.equal(await regularPage.locator('#profileNameInput').inputValue(),originalName+' X');
   await regularPage.locator('#profileNameInput').press('Control+A');
   assert.deepEqual(await regularPage.locator('#profileNameInput').evaluate(n=>[n.selectionStart,n.selectionEnd]),[0,(originalName+' X').length]);
   await regularPage.locator('#cancelProfileNameButton').click();assert.equal(store.getUserProfile(user.id,1).name,originalName);
 }
 checks.push('Renomear: abre com nome preservado e cursor no final; digitar acrescenta, seleção manual funciona e cancelar preserva o nome');
 await regularPage.locator('.sidebar-nav [data-page-target="activity"]').click();
 await regularPage.locator('#clearLogsButton').click();await regularPage.locator('#confirmDialog').waitFor({state:'visible'});await regularPage.locator('#confirmCancel').click();
 assert.equal(await regularPage.locator('#confirmDialog').isVisible(),false);
 await regularPage.locator('#refreshButton').click();await regularPage.waitForFunction(()=>!document.getElementById('refreshButton').disabled);
 await regularPage.locator('#logoutButton').click();await regularPage.locator('#confirmCancel').click();assert.equal(await regularPage.locator('#dashboard').isVisible(),true);
 await regularPage.locator('#logoutButton').click();await regularPage.locator('#confirmAccept').click();await regularPage.locator('#loginPanel').waitFor({state:'visible'});
 checks.push('Atualizar funcional; limpar registros e sair mantêm confirmação; saída comum encerra a sessão');
 await regularPage.close();
 await userPage.close();
 assert.deepEqual(errors,[]); checks.push('Sem erros JavaScript');
 if (out) fs.writeFileSync(path.join(out,'result.json'),JSON.stringify({ok:true,checks,errors},null,2)); console.log(JSON.stringify({ok:true,checks:checks.length}));
 } catch(e) { await snap('failure').catch(()=>{}); if (out) fs.writeFileSync(path.join(out,'result.json'),JSON.stringify({ok:false,error:e.stack,checks,errors},null,2)); throw e; }
 finally { await browser.close(); server.closeAllConnections(); await new Promise(resolve=>server.close(resolve)); store.close(); fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true}); }
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
