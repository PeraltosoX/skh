# ChatFlow Peralta V3.2.4

Base: V3.2.3. Node.js >=24.14 e <25; migração automática para SQLite schema 12.

## Novidades

- Configurações > Modo de verificação: **Atual — página pública + API** ou
  **Somente API — playlist do canal**. Escolha persistida; padrão da atualização
  é o modo atual. Chaves continuam em Chaves de verificação.
- Descoberta pela API: identificação do canal, playlist de envios, detalhes em
  lotes de até 50 IDs. Cache persistido evita repetir vídeos comuns/encerrados;
  lives programadas e ativas continuam acompanhadas. Consultas são compartilhadas
  pelos perfis que monitoram o canal, com limites e esperas contra falhas.
- Limite diário estimado, projeto Google, consumo, saldo, prioridade e rotação
  das chaves. Fotos da conta conectada a cada 30 minutos usam o mesmo orçamento.
- Backup cifrado v2 leva as chaves de verificação e modo/intervalos do monitor.
  O resumo avisa que estas configurações globais serão substituídas. A cópia
  anterior também permite recuperar chaves e modo. Backups v1 continuam aceitos.

Leia `DESCOBERTA_POR_API.txt`, `BACKUP_E_RESTAURACAO.txt`, `MUDANCAS_V3.2.4.txt`
e `VERIFICACAO_V3.2.4.txt`. Planejamento: `ChatFlow_Peralta_ATUALIZACOES_FUTURAS.txt`.
Backup/gerenciamento pelo Telegram e callbacks personalizados continuam adiados.

## Atualização

Publique `ChatFlow_Peralta_V3.2.4_CODIGO_FONTE.zip` sem modificar ou recomprimir
no repositório PeraltosoX/skh, branch main. Use o comando separado
`COMANDO_ATUALIZACAO_V3.2.4.txt` no Bash da VPS como root.
Não use `install.sh` para atualizar. Leia `ATUALIZAR_SEM_PERDER_DADOS.txt`.

O atualizador para a versão anterior, copia .env e data/ para backup e pasta
nova, verifica versão/banco/sintaxe e tenta religar a origem em caso de falha.
A pasta data/user-backups/ também é preservada. Recarregue as guias após atualizar.
Esta entrega não publica arquivos no GitHub nem acessa a VPS automaticamente.

## Backup dos usuários

Senha de pelo menos 12 caracteres (até 256 bytes), necessária em qualquer VPS.
O formato cifrado independe de APP_ENCRYPTION_KEY da origem. Não transporta .env,
administração, sessões ou filas de envio antigas. Leva somente as chaves globais
de verificação, com suas configurações, além dos dados de usuários/perfis.
Backup v2 exige V3.2.4 ou posterior para restaurar; v1 mantém as chaves do destino.
No destino, instale primeiro o programa e configure domínio/HTTPS/administração.

32 MB por arquivo; até 100 cópias ou 512 MB locais. Limites de memória também
são conferidos antes da exportação. Cópias concluídas não são apagadas sozinhas.
Upload em partes de 192 KiB para evitar requisições grandes ao proxy.
A análise expira em 30 minutos; repetir a análise não altera cadastros.

Antes de restaurar, a cópia atual é salva com a mesma senha do arquivo importado.
A operação aguarda requisições/envios em andamento, suspende brevemente o serviço
para aplicar os dados e retoma os perfis mantidos. Perfis importados ficam parados
até Iniciar, mesmo que tenham autoStart. A cópia anterior também restaura parados.
Os tokens válidos são transportados; autorizações revogadas exigem reconexão.
Se mudar domínio, configure o retorno Google correspondente para futuras conexões.

## Credenciais e fotos

Permissão por perfil em Usuários e perfis > Google e API. Bloquear novamente
oculta campos e tutorial sem desconectar. Segredo vazio mantém o salvo; trocar
Client ID exige o segredo correspondente. Mudança real exige nova autorização.
Link global do tutorial em Configurações; abre em nova guia. Fotos da conta
continuam com atualização pública a cada 30 minutos pelas chaves administrativas.

## Testes

```bash
npm ci
npm run check
npm test
```

Roteiros opcionais de DOM com jsdom 26.1.0 disponível no NODE_PATH:

```bash
node scripts/check-oauth-ui-dom.cjs
node scripts/check-backup-ui-dom.cjs
node scripts/check-discovery-ui-dom.cjs
```

DOM não verifica renderização visual. O Chromium compatível não estava disponível
no ambiente desta entrega. O roteiro `scripts/check-admin-test-browser.cjs` pode ser executado
com Playwright/Chromium instalados; `PANEL_CHROMIUM_PATH` indica o executável.

Administração: `/dbmadmin`. Usuário: `/painel`. Callback: `/oauth/google/callback`.
Preserve .env e data/peralta.sqlite para a recuperação completa da instalação.
Instalação nova: `INSTALAR.txt`. Documentos anteriores ficam como histórico.
