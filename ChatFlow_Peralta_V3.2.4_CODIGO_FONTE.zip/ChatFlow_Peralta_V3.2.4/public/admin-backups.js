'use strict';
(() => {
  let preview=null, planHash='', storedId='', uploadId='', listing={files:[],lastRestoreId:''}, running=false, generation=0;
  const root=$('usersBackupPane');
  const date=value=>new Date(value).toLocaleString('pt-BR');
  const link=id=>`/dbmadmin/api/backups/${encodeURIComponent(id)}/download`;
  const password=()=>$('backupImportPassword').value;
  function invalidate(){planHash='';show('backupPlan',false);show('backupApply',false);feedback('backupReviewFb','');}
  function clearPreview(){preview=null;invalidate();show('backupPreview',false);}
  function showTab(backup){
    show('usersManagementPane',!backup);show('usersBackupPane',backup);
    for(const [id,on] of [['usersManagementTab',!backup],['usersBackupsTab',backup]]){const b=$(id);b.className=`button ${on?'primary':'secondary'}`;b.setAttribute('aria-selected',String(on));}
  }
  function reset(){generation++;clearPreview();storedId='';uploadId='';$('backupCreateForm').reset();$('backupImportForm').reset();show('backupReadyDownload',false);$('backupReadyDownload').removeAttribute('href');show('backupStoredSource',false);show('backupUseUpload',false);$('backupFile').disabled=false;showTab(false);}
  async function operation(feedbackId,action){
    if(running)return;running=true;const currentGeneration=generation;
    const controls=[...root.querySelectorAll('button,input')].map(element=>({element,disabled:element.disabled}));
    controls.forEach(({element})=>element.disabled=true);root.setAttribute('aria-busy','true');feedback(feedbackId,'Processando…',true,{autoHide:false});
    try{await action(()=>authenticated&&currentGeneration===generation);}
    catch(e){if(authenticated)feedback(feedbackId,e.message);}
    finally{running=false;controls.forEach(({element,disabled})=>element.disabled=disabled);$('backupFile').disabled=!!storedId;root.removeAttribute('aria-busy');}
  }
  function renderFiles(){
    show('backupUndo',!!listing.files.some(f=>f.id===listing.lastRestoreId));
    $('backupFiles').innerHTML=listing.files.length?listing.files.map(f=>`<article class="backup-file"><div><strong>${f.kind==='before-restore'?'Antes da restauração':'Backup manual'}</strong><small>${esc(date(f.createdAt))} • ${f.userCount} usuários • ${f.profileCount} perfis • ${(f.size/1024/1024).toFixed(2)} MB</small></div><div class="backup-file-actions"><a class="button secondary compact" href="${link(f.id)}" download>BAIXAR</a><button type="button" class="button secondary compact" data-restore-backup="${esc(f.id)}">RESTAURAR</button><button type="button" class="button danger compact" data-delete-backup="${esc(f.id)}">EXCLUIR</button></div></article>`).join(''):'<p class="muted">Nenhuma cópia salva nesta VPS.</p>';
  }
  async function refresh(){listing=await api('/dbmadmin/api/backups');if(authenticated)renderFiles();}
  function selectStored(id){
    const item=listing.files.find(f=>f.id===id);if(!item)return;
    clearPreview();uploadId='';storedId=id;$('backupImportForm').reset();$('backupFile').disabled=true;
    $('backupStoredSource').textContent=`Cópia selecionada: ${date(item.createdAt)} — ${item.userCount} usuários. Informe a senha usada ao gerar esta cópia. Nas cópias anteriores à restauração, é a senha do backup que você importou naquela ocasião.`;
    show('backupStoredSource',true);show('backupUseUpload',true);$('backupImportPassword').focus();$('backupImportForm').scrollIntoView({block:'center',behavior:'smooth'});
  }
  function renderPreview(){
    $('backupPreviewSummary').textContent=`Backup de ${date(preview.backup.createdAt)} • V${preview.backup.appVersion} • ${preview.backup.userCount} usuários e ${preview.backup.profileCount} perfis. ${preview.backup.verification?`Inclui ${preview.backup.verification.keyCount} chaves de verificação e o modo ${preview.backup.verification.mode==='api'?'Somente API':'atual'}.`:'Backup antigo: sem chaves de verificação.'} Análise válida por 30 minutos.`;
    const currentIds=new Set(preview.current.users.map(u=>u.id));
    $('backupKeepUsers').innerHTML=preview.current.users.map((u,i)=>`<div class="backup-user keep"><input id="backupKeep${i}" type="checkbox" data-keep-user="${esc(u.id)}" checked><label for="backupKeep${i}">${esc(u.username)}<small>${u.profiles.length} perfis • ID …${esc(u.id.slice(-8))}</small></label></div>`).join('')||'<p class="muted">Esta VPS ainda não tem usuários.</p>';
    $('backupImportUsers').innerHTML=preview.backup.users.map((u,i)=>`<div class="backup-user"><input id="backupPick${i}" type="checkbox" data-import-user="${esc(u.id)}" ${!currentIds.has(u.id)||storedId?'checked':''}><label for="backupPick${i}">${esc(u.username)}<small>${u.profiles.length} perfis • ${currentIds.has(u.id)?'Já existe nesta VPS':'Novo cadastro'} • ID …${esc(u.id.slice(-8))}</small></label><input type="text" maxlength="64" data-import-name="${esc(u.id)}" aria-label="Nome de login para importar ${esc(u.username)}" value="${esc(u.username)}"></div>`).join('')||'<p class="muted">Este backup contém uma lista vazia de usuários.</p>';
    root.querySelector(`input[name=backupMode][value=${storedId?'none':'all'}]`).checked=true;
    show('backupKeepSection',false);show('backupPreview',true);invalidate();
  }
  function selection(){return {mode:root.querySelector('input[name=backupMode]:checked').value,keepIds:[...root.querySelectorAll('[data-keep-user]:checked')].map(e=>e.dataset.keepUser),imports:[...root.querySelectorAll('[data-import-user]:checked')].map(e=>({id:e.dataset.importUser,username:root.querySelector(`[data-import-name="${e.dataset.importUser}"]`).value.trim()}))};}
  async function fileBase64(file){
    if(!file)throw new Error('Selecione um arquivo de backup.');
    if(file.size>32*1024*1024)throw new Error('O arquivo excede 32 MB.');
    return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(new Error('Não foi possível ler o arquivo.'));reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.readAsDataURL(file);});
  }
  $('usersBackupsTab').addEventListener('click',async()=>{if(running||!await mayLeaveProfile())return;showTab(true);await operation('backupFilesFb',async()=>{await refresh();feedback('backupFilesFb','');});});
  $('usersManagementTab').addEventListener('click',()=>{if(!running)showTab(false);});
  $('backupCreateForm').addEventListener('submit',event=>{
    event.preventDefault();operation('backupCreateFb',async current=>{
      const result=await api('/dbmadmin/api/backups/create',{method:'POST',body:{password:$('backupPassword').value,passwordConfirm:$('backupPasswordConfirm').value}});
      if(!current())return;$('backupCreateForm').reset();$('backupReadyDownload').href=link(result.file.id);show('backupReadyDownload',true);
      feedback('backupCreateFb','Backup pronto. Baixe o arquivo e guarde sua senha.',true,{autoHide:false});await refresh();
    });
  });
  $('backupImportForm').addEventListener('submit',event=>{
    event.preventDefault();operation('backupImportFb',async current=>{
      clearPreview();
      if(!storedId&&!uploadId){
        const file=$('backupFile').files[0];if(!file)throw new Error('Selecione um arquivo de backup.');
        if(file.size>32*1024*1024)throw new Error('O arquivo excede 32 MB.');
        const upload=await api('/dbmadmin/api/backups/uploads',{method:'POST',body:{size:file.size}});
        for(let offset=0;offset<file.size;offset+=upload.chunkSize){
          if(!current())return;
          await api(`/dbmadmin/api/backups/uploads/${upload.uploadId}`,{method:'PUT',body:{offset,chunk:await fileBase64(file.slice(offset,offset+upload.chunkSize))}});
          feedback('backupImportFb',`Enviando arquivo… ${Math.min(100,Math.round((offset+upload.chunkSize)/file.size*100))}%`,true,{autoHide:false});
        }
        uploadId=upload.uploadId;
      }
      const body={password:password(),...(storedId?{storedId}:{uploadId})};
      const result=await api('/dbmadmin/api/backups/inspect',{method:'POST',body});if(!current())return;preview=result;renderPreview();feedback('backupImportFb','Arquivo validado. Confira a seleção abaixo; nenhum cadastro foi alterado.',true,{autoHide:false});
      $('backupPreview').scrollIntoView({block:'start',behavior:'smooth'});
    });
  });
  $('backupUseUpload').addEventListener('click',()=>{storedId='';uploadId='';clearPreview();$('backupImportForm').reset();$('backupFile').disabled=false;show('backupStoredSource',false);show('backupUseUpload',false);});
  $('backupFile').addEventListener('change',()=>{uploadId='';clearPreview();});
  $('backupImportPassword').addEventListener('input',invalidate);
  $('backupCancelPreview').addEventListener('click',()=>{clearPreview();$('backupImportPassword').value='';feedback('backupImportFb','Análise cancelada. Nenhum cadastro foi alterado.',true);});
  $('backupPreview').addEventListener('input',invalidate);
  for(const radio of root.querySelectorAll('input[name=backupMode]'))radio.addEventListener('change',()=>{show('backupKeepSection',radio.value==='selected'&&radio.checked);invalidate();});
  for(const [id,checked] of [['backupSelectAll',true],['backupSelectNone',false]])$(id).addEventListener('click',()=>{root.querySelectorAll('[data-import-user]').forEach(e=>e.checked=checked);invalidate();});
  $('backupReview').addEventListener('click',()=>operation('backupReviewFb',async current=>{
    if(!preview)throw new Error('Analise um backup primeiro.');
    const result=await api('/dbmadmin/api/backups/review',{method:'POST',body:{token:preview.token,password:password(),selection:selection()}});if(!current())return;
    planHash=result.planHash;
    if(result.conflicts.length){feedback('backupReviewFb',result.conflicts.join('\n'));show('backupApply',false);return;}
    const labels={kept:'Manter',added:'Adicionar',replaced:'Substituir pelo backup',removed:'Remover'};
    $('backupPlan').innerHTML=Object.entries(labels).map(([key,label])=>`<p><strong>${label}: ${result.counts[key]}</strong>${result.details[key].length?`<br><span>${result.details[key].map(esc).join(', ')}</span>`:''}</p>`).join('');
    const verification=result.verification;
    $('backupPlan').insertAdjacentHTML('beforeend',verification?`<p><strong>Verificação de lives: substituir pelas ${verification.keyCount} chaves do backup.</strong><br>Modo: ${verification.mode==='api'?'Somente API':'Página pública + API'} • Intervalo: ${verification.intervalSeconds}s. Limites, prioridades e consumo estimado serão restaurados. Esta configuração é global, inclusive para usuários mantidos.</p>`:'<p>Backup antigo: chaves e modo de verificação atuais serão preservados.</p>');
    show('backupPlan',true);show('backupApply',true);feedback('backupReviewFb','Sem conflitos. Confira o resumo e confirme somente se estiver correto.',true,{autoHide:false});
  }));
  $('backupApply').addEventListener('click',async()=>{
    if(running||!preview||!planHash)return;
    const token=preview.token, hash=planHash, selected=selection();
    if(!await askConfirmation({title:'Restaurar usuários e perfis?',message:`${$('backupPlan').innerText||$('backupPlan').textContent}\n\nUma cópia dos dados atuais será salva com a senha deste backup. Os envios serão brevemente suspensos; os perfis importados ficarão parados até você iniciar.`,confirmLabel:'CONFIRMAR RESTAURAÇÃO',danger:true}))return;
    if(!preview||preview.token!==token||planHash!==hash)return;
    await operation('backupReviewFb',async current=>{
      const result=await api('/dbmadmin/api/backups/apply',{method:'POST',body:{token,password:password(),selection:selected,planHash:hash,confirm:true}});if(!current())return;
      clearPreview();$('backupImportPassword').value='';$('backupFile').value='';storedId='';uploadId='';show('backupStoredSource',false);show('backupUseUpload',false);
      selectedUserId='';resetProfile();await loadData();await refresh();
      feedback('backupImportFb',`Restauração concluída. ${result.counts.added} usuários adicionados, ${result.counts.replaced} substituídos e ${result.counts.removed} removidos. A cópia anterior está disponível abaixo.`,true,{autoHide:false});
    });
  });
  $('backupRefresh').addEventListener('click',()=>operation('backupFilesFb',async()=>{await refresh();feedback('backupFilesFb','Lista atualizada.',true);}));
  $('backupUndo').addEventListener('click',()=>{if(!running)selectStored(listing.lastRestoreId);});
  $('backupFiles').addEventListener('click',async event=>{
    if(running)return;
    const restore=event.target.closest('[data-restore-backup]');if(restore){selectStored(restore.dataset.restoreBackup);return;}
    const remove=event.target.closest('[data-delete-backup]');if(!remove)return;
    const id=remove.dataset.deleteBackup,item=listing.files.find(f=>f.id===id);if(!item)return;
    if(!await askConfirmation({title:'Excluir esta cópia de backup?',message:`Cópia de ${date(item.createdAt)}. Baixe o arquivo antes se quiser guardá-lo. ${id===listing.lastRestoreId?'Esta é a cópia usada para voltar ao estado anterior; esse atalho deixará de estar disponível.':''} Os usuários atuais não serão removidos.`,confirmLabel:'EXCLUIR CÓPIA',danger:true}))return;
    await operation('backupFilesFb',async()=>{await api(`/dbmadmin/api/backups/${id}`,{method:'DELETE',body:{confirm:true}});await refresh();feedback('backupFilesFb','Cópia excluída.',true);});
  });
  window.addEventListener('pagehide',()=>{$('backupPassword').value='';$('backupPasswordConfirm').value='';$('backupImportPassword').value='';});
  window.ChatFlowBackups={reset,showManagement:()=>showTab(false)};
})();
