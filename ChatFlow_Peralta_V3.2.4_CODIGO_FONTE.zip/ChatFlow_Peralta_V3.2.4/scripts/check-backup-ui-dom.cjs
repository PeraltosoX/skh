'use strict';
// Testes funcionais do DOM e servidor real. jsdom não renderiza pixels.
const {JSDOM,VirtualConsole}=require('jsdom');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),vm=require('node:vm'),bcrypt=require('bcryptjs');
const root=path.resolve(__dirname,'..');
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'cf-backup-ui323-'));
process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security');
const admin={id:store.id('adm'),username:'Administrador teste',passwordHash:bcrypt.hashSync('senha-admin',4),active:true,sessionVersion:1};store.createFirstAdmin(admin);
const create=name=>store.createUser({id:store.id('usr'),username:name,passwordHash:bcrypt.hashSync('senha-teste',4),active:true,sessionVersion:1,createdAt:store.now()});
const initial=create('usuario');store.addUserProfile(initial.id);store.updateUserProfile(initial.id,1,p=>{p.config.messages='Mensagem original';p.config.autoStart=true;});
const sign=security.signSession(admin.id,'admin',1);store.saveSession(sign.session);const cookie=`auto_server_admin=${sign.token}`;
const server=require('node:http').createServer().listen(0,'127.0.0.1'),windows=[],errors=[],checks=[];
const record=label=>{checks.push(label);console.log('OK: '+label);};
const wait=async(condition,label)=>{const until=Date.now()+15000;while(!condition()){if(Date.now()>until)throw new Error('Tempo esgotado: '+label);await new Promise(r=>setTimeout(r,15));}};
(async()=>{
 await new Promise(r=>server.once('listening',r));const base=`http://127.0.0.1:${server.address().port}`;process.env.PUBLIC_BASE_URL=base;
 const app=require('../server').createApp();server.on('request',app);
 function view(width){
  const console=new VirtualConsole();console.on('jsdomError',e=>errors.push(e.message));
  const dom=new JSDOM(fs.readFileSync(path.join(root,'public/admin-test.html'),'utf8'),{url:base+'/dbmadmin',runScripts:'outside-only',pretendToBeVisual:true,virtualConsole:console,beforeParse(w){
   w.fetch=(url,options={})=>fetch(new URL(url,base),{...options,headers:{Cookie:cookie,...options.headers}});w.AbortController=AbortController;w.structuredClone=structuredClone;
   w.matchMedia=q=>({matches:/max-width:\s*(\d+)/.test(q)?width<=Number(RegExp.$1):false,addEventListener(){},removeEventListener(){}});
   Object.defineProperty(w,'innerWidth',{value:width});w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};w.performance.getEntriesByType=()=>[];
  }});windows.push(dom.window);
  for(const script of dom.window.document.querySelectorAll('script[src]'))vm.runInContext(fs.readFileSync(path.join(root,'public',new URL(script.src).pathname.slice(1)),'utf8'),dom.getInternalVMContext(),{filename:new URL(script.src).pathname});
  const $=id=>dom.window.document.getElementById(id),edit=(id,value)=>{const el=$(id);if(el.type==='checkbox'||el.type==='radio')el.checked=value;else el.value=value;el.dispatchEvent(new dom.window.Event('input',{bubbles:true}));el.dispatchEvent(new dom.window.Event('change',{bubbles:true}));};
  const submit=id=>$(id).dispatchEvent(new dom.window.Event('submit',{bubbles:true,cancelable:true}));
  return {dom,$,edit,submit,hidden:id=>$(id).classList.contains('hidden')};
 }
 try{
  const a=view(390),pass='Senha-Backup-UI-123!';
  await wait(()=>a.$('overviewUsers').textContent==='1','admin pronto');
  a.dom.window.document.querySelector('[data-page-target=users]').click();a.$('usersBackupsTab').click();
  await wait(()=>!a.hidden('usersBackupPane')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'aba backup');
  assert.equal(a.hidden('usersManagementPane'),true);assert.equal(a.$('usersBackupsTab').getAttribute('aria-selected'),'true');record('Backup é uma aba interna de Usuários e perfis');
  a.edit('backupPassword',pass);a.edit('backupPasswordConfirm',pass);a.submit('backupCreateForm');
  await wait(()=>!a.hidden('backupReadyDownload')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'backup pronto');
  const download=await fetch(a.$('backupReadyDownload').href,{headers:{Cookie:cookie}});assert.equal(download.status,200);const buffer=Buffer.from(await download.arrayBuffer());
  assert.equal(a.$('backupPassword').value,'');assert.equal(a.$('backupPasswordConfirm').value,'');record('Gerar libera Baixar backup e limpa senhas dos campos');
  store.updateUserProfile(initial.id,1,p=>{p.config.messages='Alteração posterior';p.config.version++;});const kept=create('usuario mantido');
  Object.defineProperty(a.$('backupFile'),'files',{value:[new a.dom.window.File([buffer],'backup.cfbackup',{type:'application/octet-stream'})],configurable:true});
  a.edit('backupImportPassword','Senha-incorreta-123');a.submit('backupImportForm');
  await wait(()=>a.$('backupImportFb').textContent.includes('Senha incorreta'),'senha errada');assert.equal(store.getUserProfile(initial.id,1).config.messages,'Alteração posterior');record('Senha incorreta não abre seleção nem altera cadastros');
  a.edit('backupImportPassword',pass);a.submit('backupImportForm');await wait(()=>!a.hidden('backupPreview')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'prévia');
  assert.equal(a.dom.window.document.querySelector('[data-import-user]').checked,false);record('Usuário com mesmo ID começa ignorado ao manter todos');
  const selected=a.dom.window.document.querySelector('input[name=backupMode][value=selected]');selected.checked=true;selected.dispatchEvent(new a.dom.window.Event('change',{bubbles:true}));
  a.dom.window.document.querySelector(`[data-keep-user="${initial.id}"]`).checked=false;
  a.dom.window.document.querySelector(`[data-import-user="${initial.id}"]`).checked=true;
  a.$('backupReview').click();await wait(()=>!a.hidden('backupApply')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'resumo');
  assert.match(a.$('backupPlan').textContent,/Manter: 1/);assert.match(a.$('backupPlan').textContent,/Substituir pelo backup: 1/);record('Resumo distingue manter, substituir, adicionar e remover');
  a.$('backupApply').click();await wait(()=>!a.hidden('confirmModal'),'confirmação');assert.ok(a.dom.window.document.querySelector('.confirm-dialog.danger-mode'));a.$('confirmCancel').click();
  assert.equal(store.getUserProfile(initial.id,1).config.messages,'Alteração posterior');record('Cancelar confirmação preserva dados atuais');
  a.$('backupApply').click();await wait(()=>!a.hidden('confirmModal'),'confirmação novamente');a.$('confirmAccept').click();
  await wait(()=>a.$('backupImportFb').textContent.includes('Restauração concluída')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'restaurado');
  assert.equal(store.getUserProfile(initial.id,1).config.messages,'Mensagem original');assert.ok(store.getUser(kept.id));assert.equal(store.getUserProfile(initial.id,1).runtime.restoreHold,true);assert.equal(a.$('backupImportPassword').value,'');record('Restauração mantém selecionado, recupera perfil e bloqueia início automático');
  a.$('backupUndo').click();assert.match(a.$('backupStoredSource').textContent,/Cópia selecionada/);a.edit('backupImportPassword',pass);a.submit('backupImportForm');
  await wait(()=>!a.hidden('backupPreview')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'prévia da volta');assert.equal(a.dom.window.document.querySelector('input[name=backupMode]:checked').value,'none');
  a.$('backupReview').click();await wait(()=>!a.hidden('backupApply')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'resumo da volta');a.$('backupApply').click();await wait(()=>!a.hidden('confirmModal'),'confirmação volta');a.$('confirmAccept').click();
  await wait(()=>a.$('backupImportFb').textContent.includes('Restauração concluída')&&!a.$('usersBackupPane').hasAttribute('aria-busy'),'volta completa');assert.equal(store.getUserProfile(initial.id,1).config.messages,'Alteração posterior');record('Voltar ao estado anterior usa cópia automática e recupera os cadastros anteriores');
  for(const width of [320,390,1440]){
   const v=view(width);await wait(()=>v.$('overviewUsers').textContent==='2','admin '+width);v.dom.window.document.querySelector('[data-page-target=users]').click();v.$('usersBackupsTab').click();await wait(()=>!v.hidden('usersBackupPane')&&!v.$('usersBackupPane').hasAttribute('aria-busy'),'backup '+width);
   assert.ok(v.$('backupFiles').querySelector('[data-restore-backup]'));assert.ok(v.$('backupFiles').querySelector('a[download]'));const ids=[...v.dom.window.document.querySelectorAll('[id]')].map(e=>e.id);assert.equal(new Set(ids).size,ids.length);
   assert.ok(!JSON.stringify(v.dom.window.localStorage).includes(pass));assert.ok(!JSON.stringify(v.dom.window.sessionStorage).includes(pass));v.$('usersManagementTab').click();assert.ok(v.hidden('usersBackupPane'));record(`DOM ${width}px: navegação, ações, IDs únicos e senha sem persistência`);
  }
  assert.deepEqual(errors,[]);record('Fluxos de backup sem erros de JavaScript');
  console.log(`${checks.length} verificações funcionais concluídas. Não é inspeção visual.`);
 }finally{windows.forEach(w=>w.close());app.locals.userBackups.dispose();server.closeAllConnections();await new Promise(r=>server.close(r));store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
