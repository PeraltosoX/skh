'use strict';
// Functional UI checks with a real local server. JSDOM does not render pixels.
const {JSDOM,VirtualConsole}=require('jsdom');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'cf-discovery-ui324-'));process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security');
const admin={id:store.id('adm'),username:'admin',active:true,sessionVersion:1};store.createFirstAdmin(admin);
const sign=security.signSession(admin.id,'admin',1);store.saveSession(sign.session);const cookie='auto_server_admin='+sign.token;
const server=require('node:http').createServer().listen(0,'127.0.0.1'),windows=[],errors=[],checks=[];
const record=s=>{checks.push(s);console.log('OK: '+s);};
const wait=async(fn,label)=>{const until=Date.now()+12000;while(!fn()){if(Date.now()>until)throw new Error('Tempo esgotado: '+label);await new Promise(r=>setTimeout(r,10));}};
(async()=>{
 await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;process.env.PUBLIC_BASE_URL=base;
 const backend=require('../server');backend.globalMonitor.requestScan=()=>true;const app=backend.createApp();server.on('request',app);
 const original=global.fetch;global.fetch=(url,options)=>{const u=new URL(url);if(u.origin===base)return original(url,options);assert.equal(u.hostname,'www.googleapis.com');return Promise.resolve(new Response(JSON.stringify({items:[{id:u.searchParams.get('id'),snippet:{title:'Teste',liveBroadcastContent:'none'}}]}),{status:200,headers:{'Content-Type':'application/json'}}));};
 function view(width){
  const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
  const dom=new JSDOM(fs.readFileSync(path.join(root,'public/admin-test.html'),'utf8'),{url:base+'/dbmadmin',runScripts:'outside-only',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.fetch=(url,options={})=>original(new URL(url,base),{...options,headers:{Cookie:cookie,...options.headers}});w.AbortController=AbortController;w.structuredClone=structuredClone;w.matchMedia=q=>({matches:/max-width:\s*(\d+)/.test(q)?width<=Number(RegExp.$1):false,addEventListener(){},removeEventListener(){}});Object.defineProperty(w,'innerWidth',{value:width});w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};w.performance.getEntriesByType=()=>[];}});
  windows.push(dom.window);for(const script of dom.window.document.querySelectorAll('script[src]'))vm.runInContext(fs.readFileSync(path.join(root,'public',new URL(script.src).pathname.slice(1)),'utf8'),dom.getInternalVMContext(),{filename:new URL(script.src).pathname});
  const $=id=>dom.window.document.getElementById(id),edit=(id,value)=>{$(id).value=value;$(id).dispatchEvent(new dom.window.Event('input',{bubbles:true}));$(id).dispatchEvent(new dom.window.Event('change',{bubbles:true}));if($(id).form)vm.runInContext('dirtyForms.add('+JSON.stringify($(id).form.id)+')',dom.getInternalVMContext());};
  const submit=id=>$(id).dispatchEvent(new dom.window.Event('submit',{bubbles:true,cancelable:true}));return {dom,$,edit,submit};
 }
 try {
  const a=view(390);await wait(()=>a.$('discoveryModeStatus').textContent.includes('Modo salvo'),'bootstrap');
  assert.equal(a.$('discoveryMode').value,'public');record('Atualização começa no modo público');
  a.dom.window.document.querySelector('[data-page-target=keys]').click();const secret='AIza'+'g'.repeat(35);
  a.edit('verificationKeyName','Minha chave');a.edit('verificationApiKey',secret);a.edit('verificationProjectId','projeto-testes');a.edit('verificationDailyLimit','8000');a.submit('verificationKeyForm');
  await wait(()=>a.$('verificationKeys').textContent.includes('Minha chave'),'chave criada');const k=store.adminVerificationKeys(true)[0];assert.equal(k.daily_limit,8000);assert.equal(k.project_id,'projeto-testes');assert.equal(a.$('verificationApiKey').value,'');assert.ok(!a.$('verificationKeys').innerHTML.includes(secret));record('Cadastro grava nome/projeto/limite, mostra consumo e oculta segredo');
  a.$('verificationKeys').querySelector('[data-action=key-edit]').click();assert.equal(a.$('verificationApiKey').required,false);assert.equal(a.$('verificationDailyLimit').value,'8000');
  a.edit('verificationDailyLimit','7500');a.edit('verificationKeyName','Chave editada');a.submit('verificationKeyForm');await wait(()=>a.$('verificationKeys').textContent.includes('Chave editada'),'edição salva');assert.equal(store.getAdminVerificationKey(k.id).daily_limit,7500);assert.equal(security.decryptText(store.getAdminVerificationKey(k.id).api_key_enc),secret);assert.equal(a.$('verificationKeySave').textContent,'ADICIONAR CHAVE');record('Editar altera limite/nome e mantém a chave quando o campo fica vazio');
  a.$('verificationKeys').querySelector('[data-action=key-edit]').click();a.edit('verificationDailyLimit','50');a.$('verificationKeyCancel').click();assert.equal(store.getAdminVerificationKey(k.id).daily_limit,7500);record('Cancelar edição preserva configuração');
  a.$('verificationKeys').querySelector('[data-action=key-test]').click();await wait(()=>a.$('verificationKeyFb').textContent.includes('validada'),'teste de chave');assert.equal(store.adminVerificationKeyUsage(k.id).attempts,1);record('Testar usa API simulada e entra na contagem');
  a.dom.window.document.querySelector('[data-page-target=settings]').click();a.edit('discoveryMode','api');a.submit('discoveryModeForm');await wait(()=>a.$('discoveryModeStatus').textContent.includes('Modo salvo: Somente API'),'modo API');assert.equal(store.liveDiscoveryMode(),'api');record('Modo API salva no servidor e informa a seleção ativa');
  a.edit('discoveryMode','public');await vm.runInContext('loadData()',a.dom.getInternalVMContext());assert.equal(a.$('discoveryMode').value,'public');record('Atualização de dados não sobrescreve escolha ainda não salva');
  for(const width of [320,390,1440]){const v=view(width);await wait(()=>v.$('discoveryModeStatus').textContent.includes('Modo salvo'),'nova tela');assert.equal(v.$('discoveryMode').value,'api');assert.ok(v.$('verificationKeys').querySelector('[data-action=key-edit]'));assert.match(v.$('verificationKeys').textContent,/7500/);const ids=[...v.dom.window.document.querySelectorAll('[id]')].map(e=>e.id);assert.equal(new Set(ids).size,ids.length);record(`DOM ${width}px: modo persistido, campos e ações acessíveis`);}
  assert.deepEqual(errors,[]);record('Sem erros de JavaScript nos fluxos novos');console.log(checks.length+' verificações funcionais concluídas. Não é inspeção visual.');
 } finally {windows.forEach(w=>w.close());global.fetch=original;app.locals.userBackups.dispose();server.closeAllConnections();await new Promise(r=>server.close(r));store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
