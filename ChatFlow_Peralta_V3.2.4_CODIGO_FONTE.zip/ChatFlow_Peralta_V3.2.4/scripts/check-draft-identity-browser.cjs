'use strict';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..');process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'chatflow-draft-browser-'));process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');process.env.NODE_ENV='test';
const store=require(root+'/lib/store'),security=require(root+'/lib/security');
const user=store.createUser({id:store.id('usr'),username:'usuario',active:true,sessionVersion:1});store.addUserProfile(user.id);store.updateUserProfile(user.id,2,p=>{p.config.messages='Mensagem salva';});
const admin={id:store.id('adm'),username:'administrador',active:true,sessionVersion:1};store.createFirstAdmin(admin);
let browser,server;const checks=[];const check=label=>{checks.push(label);console.log(label);};process.on('exit',()=>{if(checks.length!==8)process.exitCode=1;});
(async()=>{
 server=http.createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;process.env.PUBLIC_BASE_URL=base;
 const originalFetch=global.fetch;global.fetch=(url,o)=>new URL(url).origin===base?originalFetch(url,o):Promise.reject(new Error('Serviço externo bloqueado no teste'));server.on('request',require(root+'/server').createApp());
 browser=await chromium.launch({headless:true,...(process.env.PANEL_CHROMIUM_PATH?{executablePath:process.env.PANEL_CHROMIUM_PATH}:{}),args:['--no-sandbox','--disable-dev-shm-usage','--no-zygote','--single-process','--disable-gpu']});
 const context=await browser.newContext({viewport:{width:390,height:900},locale:'pt-BR'});context.setDefaultTimeout(10000);context.setDefaultNavigationTimeout(10000);
 await context.route('**/*',r=>new URL(r.request().url()).origin===base?r.continue():r.abort());
 // As atualizações são disparadas explicitamente para controlar a ordem das respostas.
 await context.addInitScript(()=>{window.setInterval=()=>0;});
 for(const [subject,kind,name,cookiePath]of [[user,'user','auto_server_user','/'],[admin,'admin','auto_server_admin','/dbmadmin']]){const signed=security.signSession(subject.id,kind,1);store.saveSession(signed.session);await context.addCookies([{name,value:signed.token,domain:'127.0.0.1',path:cookiePath,httpOnly:true,sameSite:'Strict'}]);}
 const regular=await context.newPage(),managed=await context.newPage(),errors=[];for(const page of [regular,managed]){page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());}
 const ready=page=>page.waitForFunction(()=>typeof currentState!=='undefined'&&currentState?.selectedProfile===2&&!profileLoading);
 await regular.goto(base+'/painel?profile=2');await ready(regular);await managed.goto(base+'/dbmadmin/painel/'+user.id+'?profile=2');await ready(managed);
 for(const [page,text]of [[regular,'Rascunho do usuário'],[managed,'Rascunho administrativo']]){await page.evaluate(()=>goPage('messages'));await page.locator('#messages').fill(text);assert.equal(await page.locator('#saveState').textContent(),'Rascunho não salvo');}
 store.updateUser(user.id,u=>{u.username='usuario novo';});
 for(const [page,text]of [[regular,'Rascunho do usuário'],[managed,'Rascunho administrativo']]){await page.reload();await ready(page);assert.equal(await page.locator('#messages').inputValue(),text);assert.equal(await page.locator('#saveState').textContent(),'Rascunho recuperado');assert.equal(await page.evaluate(()=>currentUsername),'usuario novo');}
 check('Renomear usuário preserva os rascunhos separados do acesso comum e administrativo');
 await regular.locator('#saveButton').click();await regular.waitForFunction(()=>!dirty&&!busy);assert.equal(store.getUserProfile(user.id,2).config.messages,'Rascunho do usuário');assert.equal(await regular.evaluate(()=>readDraft()),null);
 check('Salvar após renomear grava no mesmo perfil e remove somente o rascunho salvo');
 await regular.locator('#messages').fill('Rascunho do perfil antigo');const oldUid=store.getUserProfile(user.id,2).id;store.deleteUserProfile(user.id,2);assert.notEqual(store.addUserProfile(user.id).id,oldUid);
 const stale=await managed.evaluate(async()=>{try{await api('/api/profiles/2/settings',{method:'PUT',body:configBody()});return 200;}catch(e){return e.status;}});assert.equal(stale,409);assert.equal(store.getUserProfile(user.id,2).config.messages,'');
 check('Uma guia antiga não consegue salvar no perfil recriado');
 await regular.evaluate(()=>refreshState(false));assert.equal(await regular.locator('#messages').inputValue(),'');assert.equal(await regular.evaluate(()=>dirty),false);assert.equal(await regular.evaluate(uid=>Object.keys(sessionStorage).some(k=>k.endsWith(':'+uid)),oldUid),false);
 check('Atualização com rascunho aberto mostra o novo perfil sem herdar o anterior');
 await managed.reload();await ready(managed);assert.equal(await managed.locator('#messages').inputValue(),'');assert.equal(await managed.locator('#saveState').textContent(),'Sincronizado');
 check('Recarregar não recupera rascunho de perfil excluído com número reutilizado');
 await regular.evaluate(()=>sessionStorage.setItem('auto-server-config-draft:usuario%20novo:2',JSON.stringify({profile:2,messages:'Legado sem identidade',savedAt:new Date().toISOString(),version:0})));await regular.reload();await ready(regular);assert.equal(await regular.locator('#messages').inputValue(),'');
 check('Rascunho legado sem identidade não é aplicado automaticamente');
 await regular.evaluate(()=>goPage('messages'));await regular.locator('#messages').fill('Rascunho da conta anterior');store.deleteUser(user.id);const newUser=store.createUser({id:store.id('usr'),username:'usuario novo',active:true,sessionVersion:1});store.addUserProfile(newUser.id);const signed=security.signSession(newUser.id,'user',1);store.saveSession(signed.session);
 await context.addCookies([{name:'auto_server_user',value:signed.token,domain:'127.0.0.1',path:'/',httpOnly:true,sameSite:'Strict'}]);await regular.reload();await ready(regular);assert.equal(await regular.locator('#messages').inputValue(),'');assert.equal(await regular.evaluate(()=>currentUserId),newUser.id);
 check('Conta recriada com o mesmo nome não herda rascunho da conta anterior');
 for(const width of [320,390,920,1440]){
  await regular.setViewportSize({width,height:950});await regular.evaluate(()=>goPage('messages'));assert.equal(await regular.locator('#saveState').evaluate(n=>!!n.closest('.send-mode-heading')),true);
  for(const text of ['Sincronizado','Rascunho não salvo','Rascunho recuperado','Configuração salva']){await regular.locator('#saveState').evaluate((n,t)=>{n.textContent=t;},text);const b=await regular.evaluate(()=>['sendMode','saveState'].map(id=>{const r=document.getElementById(id).getBoundingClientRect();return {top:r.top,bottom:r.bottom,left:r.left,right:r.right};}));const label=await regular.locator('label[for=sendMode]').boundingBox();assert.ok(label.x+label.width<=b[1].left-5);assert.ok(b[1].bottom<=b[0].top);assert.ok(b[1].right<=b[0].right+1);}
  await regular.evaluate(()=>goPage('account'));assert.match(await regular.locator('#renameProfileButton').textContent(),/EDITAR NOME/);
  if(width<=920){assert.equal(await regular.locator('#renameProfileButton').evaluate(n=>!!n.closest('.profile-context-heading')),true);const b=await regular.locator('#renameProfileButton').boundingBox(),left=await regular.locator('.profile-context-heading .eyebrow').boundingBox();assert.ok(left.x+left.width<b.x);assert.ok(Math.abs(left.y+left.height/2-b.y-b.height/2)<3);}
  assert.ok(await regular.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 }
 check('Status junto ao modo de envio e Editar nome junto do Perfil ativo, sem overflow de 320 a 1440 px');assert.deepEqual(errors,[]);console.log(JSON.stringify({ok:true,checks:checks.length,errors}));
})().catch(e=>{console.error(e.stack);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});
