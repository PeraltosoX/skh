'use strict';
// Verificação funcional do DOM com jsdom 26.1.0 e servidor local real.
// Não substitui a inspeção visual em Chromium. Não usa contas/rede externas.
const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-dom323-'));
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.NODE_ENV = 'test';
const store = require('../lib/store'), security = require('../lib/security');
const admin = { id: store.id('adm'), username: 'Administrador teste', passwordHash: 'test-only', active: true, sessionVersion: 1 };
store.createFirstAdmin(admin);
const user = store.createUser({ id: store.id('usr'), username: 'usuario', active: true, sessionVersion: 1 });
store.addUserProfile(user.id);
store.updateUserProfile(user.id, 1, p => {
  p.api = { clientId: 'teste.apps.googleusercontent.com', clientSecretEnc: security.encryptText('secret-saved'), version: 1 };
  p.oauth.refreshTokenEnc = security.encryptText('refresh-saved'); p.runtime.status = 'running'; p.runtime.sent = 9;
});
const auth = (id, kind) => { const s = security.signSession(id, kind, 1); store.saveSession(s.session); return `auto_server_${kind}=${s.token}`; };
const adminCookie = auth(admin.id, 'admin'), userCookie = auth(user.id, 'user');
const nativeFetch = global.fetch, windows = [], errors = [], checks = [];
const record = label => { checks.push(label); console.log('OK: ' + label); };
const wait = async (condition, label) => { const until = Date.now() + 5000; while (!condition()) { if (Date.now() > until) throw new Error('Tempo esgotado: ' + label); await new Promise(r => setTimeout(r, 10)); } };
const p = () => store.getUserProfile(user.id, 1);
const server = require('node:http').createServer().listen(0, '127.0.0.1');
(async () => {
  await new Promise(r => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  process.env.PUBLIC_BASE_URL = base;
  const backend = require('../server'); backend.globalMonitor.scan = async () => ({ ok: true });
  global.fetch = (url, options) => new URL(url).origin === base ? nativeFetch(url, options) : Promise.resolve(new Response('{}'));
  server.on('request', backend.createApp());
  function view(kind, width = 1440, adminAccess = false) {
    const html = kind === 'admin' ? 'admin-test.html' : 'panel.html';
    const route = kind === 'admin' ? '/dbmadmin' : adminAccess ? `/dbmadmin/painel/${user.id}` : '/painel';
    const cookie = kind === 'admin' || adminAccess ? adminCookie : userCookie;
    const console = new VirtualConsole(); console.on('jsdomError', error => { if (!/Not implemented: navigation/.test(error.message)) errors.push(error.message); });
    const dom = new JSDOM(fs.readFileSync(path.join(root, 'public', html), 'utf8'), {
      url: base + route, runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: console,
      beforeParse(w) {
        w.fetch = (url, options = {}) => nativeFetch(new URL(url, base), { ...options, headers: { Cookie: cookie, ...options.headers } });
        w.AbortController = global.AbortController; w.AbortSignal = global.AbortSignal; w.structuredClone = structuredClone;
        w.matchMedia = query => ({ matches: /max-width:\s*(\d+)/.test(query) ? width <= Number(RegExp.$1) : false, addEventListener() {}, removeEventListener() {} });
        Object.defineProperty(w, 'innerWidth', { value: width });
        w.performance.getEntriesByType = () => []; w.scrollTo = () => {};
        w.HTMLElement.prototype.scrollIntoView = () => {};
        w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
        w.HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); };
        w.addEventListener('error', e => errors.push(e.message));
      }
    });
    windows.push(dom.window);
    for (const script of dom.window.document.querySelectorAll('script[src]')) require('node:vm').runInContext(fs.readFileSync(path.join(root, 'public', new URL(script.src).pathname.slice(1)), 'utf8'), dom.getInternalVMContext(), {filename:new URL(script.src).pathname});
    const $ = id => dom.window.document.getElementById(id);
    const edit = (id, value) => { const el = $(id); if (el.type === 'checkbox') el.checked = value; else el.value = value; el.dispatchEvent(new dom.window.Event('input', { bubbles: true })); el.dispatchEvent(new dom.window.Event('change', { bubbles: true })); };
    const submit = id => $(id).dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
    const hidden = id => $(id).classList.contains('hidden');
    return { dom, $, edit, submit, hidden };
  }
  async function unlock(v) {
    v.$('editGoogleCredentials').click(); await wait(()=>v.$('confirmDialog').hasAttribute('open'),'confirmar edição');
    v.$('confirmAccept').click(); await wait(()=>!v.$('userGoogleClientId').disabled,'campos liberados');
  }
  async function confirmSave(v) {
    v.submit('oauthCredentialsForm'); await wait(()=>v.$('confirmDialog').hasAttribute('open'),'confirmar salvamento');
    v.$('confirmAccept').click();
  }
  try {
    const a = view('admin'), u = view('user');
    await wait(() => a.$('overviewUsers').textContent === '1' && u.$('currentUsername').textContent === 'usuario' && !u.$('profileContent').inert, 'painéis prontos');
    assert.ok(u.hidden('oauthCredentialsCard')); record('Bloco e tutorial ocultos por padrão');
    a.dom.window.document.querySelector('[data-page-target="users"]').click();
    a.dom.window.document.querySelector(`[data-action="user-open"][data-user-id="${user.id}"]`).click();
    await wait(() => a.$('profileUserId').value === user.id && a.$('profileNumber').value === '1', 'editor de perfil pronto');
    a.$('profileTabGoogle').click(); a.edit('profileAllowOAuthEdit', true); a.submit('profileForm');
    await wait(() => p().allowUserOAuthEdit && !a.$('profileAllowOAuthEdit').disabled, 'permissão salva');
    u.$('refreshButton').click(); await wait(() => !u.hidden('oauthCredentialsCard'), 'bloco liberado');
    assert.equal(u.$('userGoogleClientSecret').value, ''); assert.equal(u.$('userGoogleClientId').value, 'teste.apps.googleusercontent.com');
    assert.ok(u.hidden('oauthTutorialBlock')); record('Administrador libera campos sem revelar segredo salvo');
    a.edit('oauthTutorialUrl', 'https://www.youtube.com/watch?v=teste'); a.submit('oauthTutorialForm');
    await wait(() => store.globalSetting('google_oauth_tutorial_url').includes('watch?v=teste') && !a.$('oauthTutorialForm').querySelector('button').disabled, 'link salvo');
    u.$('refreshButton').click(); await wait(() => !u.hidden('oauthTutorialBlock'), 'tutorial disponível');
    assert.equal(u.$('oauthTutorialLink').target, '_blank'); assert.match(u.$('oauthTutorialLink').rel, /noopener/); assert.match(u.$('oauthTutorialLink').rel, /noreferrer/);
    assert.equal(u.dom.window.document.querySelectorAll('video,iframe').length, 0); record('Tutorial é link em nova guia, sem vídeo incorporado');
    const href = u.$('oauthTutorialLink').href;
    a.edit('oauthTutorialUrl', 'https://example.invalid/tutorial-novo'); a.submit('oauthTutorialForm');
    await wait(() => store.globalSetting('google_oauth_tutorial_url').includes('tutorial-novo'), 'link alterado');
    const redirected = await nativeFetch(href, { headers: { Cookie: userCookie }, redirect: 'manual' });
    assert.equal(redirected.headers.get('location'), 'https://example.invalid/tutorial-novo'); record('Guia já aberta usa o novo link global ao assistir');
    assert.equal(u.$('userGoogleClientId').disabled,true);assert.equal(u.$('saveGoogleCredentials').disabled,true);
    u.$('editGoogleCredentials').click();await wait(()=>u.$('confirmDialog').hasAttribute('open'),'modal de editar');
    assert.match(u.$('confirmMessage').textContent,/certeza/);u.$('confirmCancel').click();assert.equal(u.$('userGoogleClientId').disabled,true);record('Cancelar edição mantém credenciais bloqueadas no tema do painel');
    await unlock(u);u.submit('oauthCredentialsForm');await wait(()=>u.$('confirmDialog').hasAttribute('open'),'cancelar salvar');
    u.$('confirmCancel').click();assert.equal(u.$('userGoogleClientId').disabled,false);record('Cancelar salvamento mantém editor e não grava');
    const before = p(); await confirmSave(u);
    await wait(() => u.$('oauthCredentialsFeedback').textContent.includes('Credenciais mantidas'), 'salvar sem mudanças');
    assert.deepEqual(p().oauth, before.oauth); assert.deepEqual(p().runtime, before.runtime); record('Salvar sem alteração mantém conexão e execução');
    await unlock(u);u.edit('userGoogleClientSecret', 'secret-new'); await confirmSave(u);
    await wait(() => u.$('oauthCredentialsFeedback').textContent.includes('Credenciais salvas'), 'novas credenciais');
    assert.equal(p().runtime.status, 'paused'); assert.equal(p().oauth.refreshTokenEnc, ''); assert.equal(u.$('userGoogleClientSecret').value, ''); record('Troca real salva com segredo oculto e pede nova autorização');
    store.updateUserProfile(user.id, 1, p => { p.runtime.status = 'running'; p.oauth.refreshTokenEnc = security.encryptText('new-refresh'); });
    // A guia antiga ainda exibe o formulário quando o admin revoga a permissão.
    await unlock(u);u.edit('userGoogleClientSecret', 'must-not-save');
    store.updateUserProfile(user.id, 1, p => { p.allowUserOAuthEdit = false; });
    const blocked = p(); await confirmSave(u);
    await wait(() => u.hidden('oauthCredentialsCard') && u.$('accountFeedback').textContent.includes('desativada'), 'bloqueio de guia antiga');
    assert.ok(u.hidden('oauthTutorialBlock')); assert.equal(u.$('userGoogleClientSecret').value, '');
    for (const key of ['api', 'oauth', 'runtime']) assert.deepEqual(p()[key], blocked[key]); record('Revogação bloqueia guia antiga, esconde tutorial e mantém conta conectada');
    store.updateUserProfile(user.id, 1, p => { p.allowUserOAuthEdit = true; });
    for (const width of [320, 390, 1440]) {
      const v = view('user', width);
      await wait(() => !v.hidden('oauthCredentialsCard') && !v.$('profileContent').inert, 'perfil em largura ' + width);
      assert.equal(v.$('oauthCredentialsCard').parentElement.dataset.page, 'account');
      assert.ok(v.$('channels').compareDocumentPosition(v.$('oauthCredentialsCard')) & 4);
      await unlock(v);v.edit('userGoogleClientSecret', 'rascunho-apenas-local');
      if (width < 920) { v.$('mobileProfileSelectTrigger').click(); v.dom.window.document.querySelector('#mobileProfileSelectDialog [data-profile-choice="2"]').click(); }
      else v.$('profileTabs').querySelector('[data-profile="2"]').click();
      await wait(() => v.$('activeProfileName').textContent === 'Perfil 2' && !v.$('profileContent').inert, 'troca para perfil sem permissão');
      assert.ok(v.hidden('oauthCredentialsCard')); assert.ok(v.hidden('oauthTutorialBlock')); assert.equal(v.$('userGoogleClientSecret').value, '');
      assert.ok(!JSON.stringify(v.dom.window.localStorage).includes('rascunho-apenas-local'));
      assert.ok(!JSON.stringify(v.dom.window.sessionStorage).includes('rascunho-apenas-local'));
      record(`DOM ${width}px: posição correta, troca isolada e segredo sem persistência`); v.dom.window.close();
    }
    const adminView = view('user', 390, true);
    await wait(() => !adminView.hidden('oauthCredentialsCard') && !adminView.$('profileContent').inert, 'abrir painel via admin');
    assert.ok(adminView.$('oauthTutorialLink').href.includes(`/dbmadmin/painel/${user.id}/api/profiles/1/oauth/tutorial`)); record('Abrir painel pelo administrador mantém o contexto correto do tutorial');
    assert.deepEqual(errors, []); record('Sem erros de JavaScript nos fluxos exercitados');
    console.log(`${checks.length} verificações funcionais do DOM concluídas. Não é teste visual de navegador.`);
  } finally {
    windows.forEach(w => w.close()); global.fetch = nativeFetch;
    server.closeAllConnections(); await new Promise(r => server.close(r)); store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true });
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
