'use strict';
const {test,after}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'cf-api324-'));
process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security');
const {createAdminLiveVerifier}=require('../lib/admin-live-verifier'),{createApiLiveDiscovery}=require('../lib/api-live-discovery'),{createGlobalMonitor}=require('../lib/global-monitor');
let seq=0; const vid=n=>'V'+String(n).padStart(10,'0');
const response=(body,status=200,headers={})=>({ok:status===200,status,headers:{get:n=>headers[n]||null},json:async()=>body});
function key(t,{project,limit=10000,secret}={}) {
  const n=++seq,value=secret || 'AIza'+String(n).padStart(35,'x');
  const k=store.createAdminVerificationKey({name:'Chave '+n,apiKeyEnc:security.encryptText(value),keyHint:'oculta',keyFingerprint:crypto.createHash('sha256').update(value).digest('hex'),projectId:project || 'project-'+n,dailyLimit:limit});
  t.after(()=>store.deleteAdminVerificationKey(k.id));return {...k,secret:value};
}
function channel(t) {
  const n=++seq,cid='UC'+String(n).padStart(22,'0');
  const c=store.upsertGlobalChannel({channelId:cid,handle:'@canal'+n,canonicalUrl:'https://www.youtube.com/channel/'+cid});
  const users=[];
  for(let i=0;i<2;i++){const u=store.createUser({id:store.id('usr'),username:'usuario '+n+' '+i,active:true,sessionVersion:1});users.push(u);store.subscribeChannel(u.id,1,c,c.handle);}
  t.after(()=>users.forEach(u=>store.deleteUser(u.id)));return {...c,cid,users};
}
function video(id,state='live') {return {id,snippet:{title:id,liveBroadcastContent:state==='ended'?'none':state},liveStreamingDetails:state==='none'?{}:state==='upcoming'?{scheduledStartTime:'2026-11-01T12:00:00Z'}:state==='ended'?{actualStartTime:'2026-11-01T12:00:00Z',actualEndTime:'2026-11-01T13:00:00Z'}:{actualStartTime:'2026-11-01T12:00:00Z',activeLiveChatId:'CHAT-'+id}};}
after(()=>{store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});

test('modo padrão é público e seleção persiste ao abrir outra instância do armazenamento',()=>{
 assert.equal(store.liveDiscoveryMode(),'public');store.setLiveDiscoveryMode('api');
 const {spawnSync}=require('node:child_process');const r=spawnSync(process.execPath,['-e',"const s=require('./lib/store');console.log(s.liveDiscoveryMode());s.close();"],{cwd:path.join(__dirname,'..'),env:process.env,encoding:'utf8'});
 assert.equal(r.status,0,r.stderr);assert.equal(r.stdout.trim(),'api');store.setLiveDiscoveryMode('public');
});

test('API descobre live já aberta, compartilha entre perfis, guarda IDs e acompanha início/fim sem página pública',async t=>{
 key(t);const c=channel(t);let time=Date.now(),phase=0,calls=[];
 const a=vid(1001),b=vid(1002),upload=vid(1003);
 const api=createAdminLiveVerifier({clock:()=>time,fetchImpl:async address=>{
   const u=new URL(address),method=u.pathname.split('/').at(-1);calls.push([method,u.searchParams.get('id')]);
   if(method==='channels')return response({items:[{id:c.cid,snippet:{title:'Canal'},contentDetails:{relatedPlaylists:{uploads:'UU'+c.cid.slice(2)}}}]});
   if(method==='playlistItems')return response({items:[a,b,upload].map(v=>({contentDetails:{videoId:v}}))});
   return response({items:u.searchParams.get('id').split(',').map(id=>video(id,id===upload?'none':id===a?(phase?'ended':'live'):(phase?'live':'upcoming')))});
 }});
 const make=()=>{const discovery=createApiLiveDiscovery({storage:store,api,clock:()=>time});return createGlobalMonitor({storage:store,apiDiscover:discovery.discover,clock:()=>time,discover:()=>{throw new Error('HTML PROIBIDO');},recheck:()=>{throw new Error('HTML PROIBIDO');}});};
 store.setLiveDiscoveryMode('api');t.after(()=>store.setLiveDiscoveryMode('public'));const m=make();t.after(()=>m.stop());
 let result=await m.scan();assert.deepEqual(result.errors,[]);assert.equal(calls.length,3);assert.equal(store.getGlobalLiveByVideo(a).live_status,'LIVE');assert.equal(store.getGlobalLiveByVideo(b).live_status,'SCHEDULED');assert.equal(store.getGlobalLiveByVideo(upload),undefined);
 for(const u of c.users)assert.ok(store.profileLiveStates(u.id,1).some(l=>l.videoId===a));
 calls=[];const restarted=make();t.after(()=>restarted.stop());await restarted.scan();assert.deepEqual(calls.map(c=>c[0]),['playlistItems']);
 phase=1;time+=store.liveVerificationTtlMs()+1;calls=[];await restarted.scan();assert.equal(store.getGlobalLiveByVideo(a).live_status,'ENDED');assert.equal(store.getGlobalLiveByVideo(b).live_status,'LIVE');assert.equal(calls.filter(c=>c[0]==='videos').length,1);assert.ok(!calls.find(c=>c[0]==='videos')[1].includes(upload));
 time+=store.liveVerificationTtlMs()+1;calls=[];await restarted.scan();const checked=calls.find(c=>c[0]==='videos')[1].split(',');assert.deepEqual(checked,[b]);
});

test('resposta atrasada após trocar modo não grava lives nem IDs descartados',async t=>{
 key(t);const c=channel(t);store.saveApiDiscoveryChannel(c.cid,'UU'+c.cid.slice(2));let release;
 const api={getPlaylistItems:()=>new Promise(r=>{release=()=>r({ok:true,data:{items:[{contentDetails:{videoId:vid(2001)}}]}});}),verifyKnownLives:()=>{throw new Error('Não pode confirmar após a troca');}};
 store.setLiveDiscoveryMode('api');const discovery=createApiLiveDiscovery({storage:store,api});const m=createGlobalMonitor({apiDiscover:discovery.discover});t.after(()=>m.stop());
 const running=m.scan();await new Promise(r=>setImmediate(r));store.setLiveDiscoveryMode('public');release();const result=await running;
 assert.equal(result.obsolete,true);assert.equal(store.getGlobalLiveByVideo(vid(2001)),undefined);assert.equal(store.apiDiscoveryVideos(c.cid).length,0);
});

test('paginação continua do cursor e detalhes são agrupados em até 50 IDs',async t=>{
 const c=channel(t);store.saveApiDiscoveryChannel(c.cid,'UU'+c.cid.slice(2));let pages=[],batches=[];
 const api={getPlaylistItems:async(_,token)=>{const page=token?Number(token):0;pages.push(page);return {ok:true,data:{items:Array.from({length:50},(_,i)=>({contentDetails:{videoId:vid(3000+page*50+i)}})),...(page<6?{nextPageToken:String(page+1)}:{})}};},verifyKnownLives:async ids=>{batches.push(ids);return {ok:true,candidates:ids.map(videoId=>({videoId,liveStatus:'UNKNOWN',chatStatus:'UNKNOWN',unavailable:false}))};}};
 const d=createApiLiveDiscovery({storage:store,api});await d.discover(c);assert.deepEqual(pages,[0,1,2,3,4]);assert.equal(store.getApiDiscoveryChannel(c.cid).cursor,'5');assert.deepEqual(batches.map(b=>b.length),[50,50,50,50,50]);
 pages=[];batches=[];await d.discover(c);assert.deepEqual(pages,[0,5,6]);assert.deepEqual(batches.map(b=>b.length),[50,50]);assert.equal(store.getApiDiscoveryChannel(c.cid).cursor,'');
});

test('falha de detalhes não transforma IDs em vídeos descartados',async t=>{
 const c=channel(t);store.saveApiDiscoveryChannel(c.cid,'UU'+c.cid.slice(2));let at=Date.now(),ok=false,calls=0;
 const api={getPlaylistItems:async()=>({ok:true,data:{items:[{contentDetails:{videoId:vid(4001)}}]}}),verifyKnownLives:async()=>{calls++;return ok?{ok:true,candidates:[{videoId:vid(4001),liveStatus:'LIVE',chatStatus:'AVAILABLE',activeLiveChatId:'CHAT'}]}:{ok:false,error:'Falha simulada'};}};
 const d=createApiLiveDiscovery({storage:store,api,clock:()=>at});let r=await d.discover(c);assert.equal(r.errors.length,1);assert.equal(store.apiDiscoveryVideos(c.cid)[0].kind,'MISSING');
 await d.discover(c);assert.equal(calls,1);at+=60001;ok=true;r=await d.discover(c);assert.equal(calls,2);assert.equal(r.lives[0].candidate.liveStatus,'LIVE');
});

test('falha na segunda página preserva o cursor mesmo após marcar a primeira como conhecida',async t=>{
 const c=channel(t);store.saveApiDiscoveryChannel(c.cid,'UU'+c.cid.slice(2));let fail=true,pages=[];
 const api={getPlaylistItems:async(_,token)=>{pages.push(token);if(token && fail)return {ok:false,error:'Falha temporária'};return {ok:true,data:token?{items:[{contentDetails:{videoId:vid(9901)}}]}:{items:Array.from({length:50},(_,i)=>({contentDetails:{videoId:vid(10000+i)}})),nextPageToken:'next'}};},verifyKnownLives:async ids=>({ok:true,candidates:ids.map(videoId=>({videoId,liveStatus:'UNKNOWN',chatStatus:'UNKNOWN'}))})};
 const d=createApiLiveDiscovery({storage:store,api});await d.discover(c);assert.equal(store.getApiDiscoveryChannel(c.cid).cursor,'next');
 fail=false;pages=[];await d.discover(c);assert.deepEqual(pages,['','next']);assert.ok(store.apiDiscoveryVideos(c.cid).some(v=>v.video_id===vid(9901)));
});

test('cursor inválido é reiniciado sem invalidar credencial nem varrer todas as chaves',async t=>{
 const k=key(t);let calls=0;
 const api=createAdminLiveVerifier({fetchImpl:async()=>{calls++;return response({error:{errors:[{reason:'invalidPageToken'}]}},400);}});
 const r=await api.getPlaylistItems('UU'+'0'.repeat(22),'expired');assert.equal(r.reason,'invalidPageToken');assert.equal(calls,1);assert.notEqual(store.getAdminVerificationKey(k.id).status,'INVALID');
});

test('reservas simultâneas respeitam limite antes da rede, inclusive fotos e teste manual',async t=>{
 const k=key(t,{limit:7});let sent=0;
 const api=createAdminLiveVerifier({fetchImpl:async address=>{sent++;await new Promise(r=>setTimeout(r,5));const u=new URL(address);return response({items:[video(u.searchParams.get('id'))]});}});
 const results=await Promise.all(Array.from({length:30},(_,i)=>api.verifyKnownLive(vid(5000+i))));assert.equal(results.filter(r=>r.ok).length,7);assert.equal(sent,7);
 assert.equal(store.publicAdminVerificationKey(store.getAdminVerificationKey(k.id)).budget.remaining,0);
 assert.equal((await api.testKey(k.id)).ok,false);assert.equal((await api.getPublicChannel('UC'+'1'.repeat(22))).ok,false);assert.equal(sent,7);
});

test('chaves do mesmo projeto compartilham limite; exclusão e recadastro não devolvem cota',async t=>{
 const project='shared-'+(++seq),k=key(t,{project,limit:3}),second=key(t,{project,limit:3});
 for(let i=0;i<3;i++)assert.ok(store.reserveAdminVerificationCall(i%2?k.id:second.id,'videos.list'));
 assert.equal(store.reserveAdminVerificationCall(k.id,'channels.list'),null);assert.equal(store.reserveAdminVerificationCall(second.id,'playlistItems.list'),null);
 store.deleteAdminVerificationKey(k.id);const replacement=key(t,{project,limit:3,secret:k.secret});assert.equal(store.reserveAdminVerificationCall(replacement.id,'videos.list'),null);
});

test('quotaExceeded pausa o projeto e escolhe reserva elegível sem repetir a chave irmã',async t=>{
 const project='quota-'+(++seq),one=key(t,{project}),two=key(t,{project}),three=key(t);let sent=[];
 const api=createAdminLiveVerifier({fetchImpl:async address=>{const u=new URL(address),secret=u.searchParams.get('key');sent.push(secret);return secret===one.secret?response({error:{message:'Cota esgotada',errors:[{reason:'quotaExceeded'}]}},403):response({items:[video(vid(6001))]});}});
 const r=await api.verifyKnownLive(vid(6001));assert.equal(r.ok,true);assert.equal(r.keyId,three.id);assert.deepEqual(sent,[one.secret,three.secret]);assert.ok(store.publicAdminVerificationKey(store.getAdminVerificationKey(two.id)).budget.pauseUntil);
});

test('404 de playlist não inutiliza nem percorre chaves saudáveis',async t=>{
 const k=key(t);key(t);let calls=0;
 const api=createAdminLiveVerifier({fetchImpl:async()=>{calls++;return response({error:{errors:[{reason:'playlistNotFound'}]}},404);}});
 const r=await api.getPlaylistItems('UU'+'0'.repeat(22));assert.equal(r.ok,false);assert.equal(r.resourceMissing,true);assert.equal(calls,1);assert.notEqual(store.getAdminVerificationKey(k.id).status,'INVALID');
});

test('sucesso atrasado não apaga bloqueio de cota criado por outra consulta',async t=>{
 const k=key(t);let release;
 const api=createAdminLiveVerifier({fetchImpl:address=>{const u=new URL(address);if(u.searchParams.get('id')===vid(7001))return new Promise(r=>{release=()=>r(response({items:[video(vid(7001))]}));});return Promise.resolve(response({error:{errors:[{reason:'quotaExceeded'}]}},403));}});
 const slow=api.verifyKnownLive(vid(7001));await new Promise(r=>setImmediate(r));await api.verifyKnownLive(vid(7002));release();await slow;
 assert.equal(store.getAdminVerificationKey(k.id).status,'QUOTA');assert.equal((await api.testKey(k.id)).ok,false);
});

test('workers no modo API compartilham confirmação, preservam intervalos e não gastam consulta OAuth de cada perfil',async t=>{
 const c=channel(t),videoId=vid(8001);let at=Date.now(),lookups=0,sends=[];
 for(const u of c.users) store.updateUserProfile(u.id,1,p=>{p.api={clientId:'test.apps.googleusercontent.com',clientSecretEnc:security.encryptText('fake-secret'),version:1};p.oauth.refreshTokenEnc=security.encryptText('fake-refresh');p.config.messages='Mensagem de teste';p.config.intervalMinutes=2;p.config.intervalSeconds=0;p.runtime.status='running';});
 const live=store.upsertGlobalLive(c.id,{videoId,liveStatus:'LIVE',chatStatus:'VERIFYING',resolved:true},at).live;store.distributeLive(live.id);
 store.setLiveDiscoveryMode('api');t.after(()=>store.setLiveDiscoveryMode('public'));
 const admin={verifyKnownLives:async()=>{lookups++;await new Promise(r=>setTimeout(r,10));return {ok:true,candidates:[{videoId,liveStatus:'LIVE',chatStatus:'AVAILABLE',activeLiveChatId:'CHAT',resolved:true}]};}};
 const api={getLiveStates:()=>{throw new Error('Consulta OAuth proibida neste modo');},getActiveLiveChatId:()=>{throw new Error('Consulta individual proibida');},sendLiveChatMessage:async(p,_,chat,message,opts)=>{opts.beforeSend();opts.onApiRequest();sends.push({userId:p.userId,at,chat});}};
 const w=require('../lib/workers').createWorkers({storage:store,api,adminLiveVerifier:admin,clock:()=>at});t.after(()=>w.shutdown());
 await Promise.all(c.users.map(u=>w.step(u.id,1)));assert.equal(lookups,1);assert.equal(sends.length,2);
 for(let i=0;i<30;i++){at+=1000;await Promise.all(c.users.map(u=>w.step(u.id,1)));}
 assert.equal(sends.length,2);assert.equal(lookups,1);
 const due=store.getUserProfile(c.users[0].id,1).runtime.nextAt;store.setLiveDiscoveryMode('public');store.setLiveDiscoveryMode('api');assert.equal(store.getUserProfile(c.users[0].id,1).runtime.nextAt,due);
 at=Date.parse(due)+1;await Promise.all(c.users.map(u=>w.step(u.id,1)));assert.equal(sends.length,4,JSON.stringify(c.users.map(u=>({runtime:store.getUserProfile(u.id,1).runtime,states:store.profileLiveStates(u.id,1),at,lookups}))));
 for(const u of c.users)assert.equal(store.apiUsage(u.id,1).videosList.attempts,0);
});

test('renovação diária libera orçamento e rate limit respeita Retry-After para o projeto',async t=>{
 const k=key(t,{limit:1}),first=Date.parse('2026-11-01T07:59:00Z');
 assert.ok(store.reserveAdminVerificationCall(k.id,'channels.list',first));assert.equal(store.reserveAdminVerificationCall(k.id,'channels.list',first),null);
 const reset=require('../lib/quota').nextPacificMidnight(first);assert.ok(store.reserveAdminVerificationCall(k.id,'channels.list',reset+1));
 const sibling=key(t,{project:k.project_id});let sent=0,at=Date.now()+3*86400000;
 const api=createAdminLiveVerifier({clock:()=>at,fetchImpl:async()=>{sent++;return response({error:{errors:[{reason:'rateLimitExceeded'}]}},429,{'retry-after':'120'});}});
 await api.verifyKnownLive(vid(9001));assert.equal(sent,1);assert.equal(store.verificationBudget(store.getAdminVerificationKey(sibling.id),at).pauseUntil,new Date(at+120000).toISOString());
});
