'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),express=require('express'),http=require('node:http');
const {createBackupMaintenance}=require('../lib/backup-maintenance');
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
function fixture(extra={}){const events=[];const gate=createBackupMaintenance({
  workers:{activeCount:()=>1,suspend:async()=>{events.push('suspend-workers');if(extra.worker)await extra.worker.promise;},resume:restart=>events.push(`resume-workers:${restart}`)},
  monitor:{isStarted:()=>true,stop:async()=>{events.push('stop-monitor');},start:()=>events.push('start-monitor')},
  photos:{isStarted:()=>true,suspend:async()=>{events.push('stop-photos');},resume:restart=>events.push(`resume-photos:${restart}`)},timeoutMs:extra.timeout||2000
});return {gate,events};}
async function serve(t,gate){const app=express();app.use(gate.middleware);gate.wrapRoutes(app);const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));t.after(async()=>{server.closeAllConnections();await new Promise(r=>server.close(r));});return {app,base:`http://127.0.0.1:${server.address().port}`};}
test('restauração espera workers, bloqueia novas operações e retoma serviços',async t=>{
  const worker=deferred(),operation=deferred(),{gate,events}=fixture({worker}),{app,base}=await serve(t,gate);app.get('/api/state',(_req,res)=>res.json({ok:true}));let started=false;
  const task=gate.run(async()=>{started=true;await operation.promise;return 42;});assert.equal(started,false);
  const blocked=await fetch(base+'/api/state');assert.equal(blocked.status,503);assert.equal(blocked.headers.get('retry-after'),'5');
  await assert.rejects(gate.run(async()=>{}),/Outra restauração/);worker.resolve();await new Promise(r=>setImmediate(r));assert.equal(started,true);operation.resolve();assert.equal(await task,42);
  assert.equal((await fetch(base+'/api/state')).status,200);assert.ok(events.includes('resume-workers:true'));assert.ok(events.includes('start-monitor'));
});
test('cliente desconectado não permite restaurar antes do handler antigo terminar',async t=>{
  const {gate}=fixture(),{app,base}=await serve(t,gate),entered=deferred(),release=deferred();let handlerEnded=false,applied=false;
  app.get('/api/slow',async(_req,res)=>{entered.resolve();await release.promise;handlerEnded=true;res.json({ok:true});});
  const request=http.get(base+'/api/slow');request.on('error',()=>{});await entered.promise;request.destroy();await new Promise(r=>setImmediate(r));
  const task=gate.run(async()=>{assert.equal(handlerEnded,true);applied=true;});await new Promise(r=>setImmediate(r));assert.equal(applied,false);release.resolve();await task;assert.equal(applied,true);
});
test('timeout e falha da operação liberam manutenção sem aplicar mudanças parciais',async()=>{
  const worker=deferred(),{gate,events}=fixture({worker,timeout:20});let applied=false;
  await assert.rejects(gate.run(async()=>{applied=true;}),/Nenhum cadastro foi substituído/);assert.equal(applied,false);assert.equal(gate.isActive(),false);worker.resolve();
  await assert.rejects(gate.run(async()=>{throw new Error('falha simulada');}),/falha simulada/);assert.equal(gate.isActive(),false);assert.ok(events.filter(e=>e==='resume-workers:true').length===2);
});
