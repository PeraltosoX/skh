'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-oauth-edit-'));
process.env.JWT_SECRET = crypto.randomBytes(48).toString('hex');
process.env.SETUP_TOKEN = crypto.randomBytes(32).toString('hex');
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.PUBLIC_BASE_URL = 'http://localhost:8080';
process.env.NODE_ENV = 'test';
const store = require('../lib/store'), security = require('../lib/security'), youtube = require('../lib/youtube');
const workspace = require('../lib/admin-workspace'), { createApp } = require('../server');
const admin = { id: store.id('adm'), username: 'Admin teste', passwordHash: 'test-only', active: true, sessionVersion: 1 };
store.createFirstAdmin(admin);
const auth = (id, kind) => { const signed = security.signSession(id, kind, 1); store.saveSession(signed.session); return { Cookie: `auto_server_${kind}=${signed.token}`, 'X-CSRF-Token': security.csrf(signed.session.id) }; };
const adminHeaders = auth(admin.id, 'admin');
let server, base, serial = 0, revoked = [];
const originalRevoke = youtube.revoke;
youtube.revoke = async token => { revoked.push(token); };
before(async () => { server = createApp().listen(0, '127.0.0.1'); await new Promise(r => server.once('listening', r)); base = `http://127.0.0.1:${server.address().port}`; });
after(async () => { youtube.revoke = originalRevoke; server.closeAllConnections(); await new Promise(r => server.close(r)); store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); });
function fixture(t) {
  const user = store.createUser({ id: store.id('usr'), username: `Conta ${++serial}`, active: true, sessionVersion: 1 });
  store.addUserProfile(user.id);
  for (const n of [1, 2]) store.updateUserProfile(user.id, n, p => {
    p.api = { clientId: 'test-client.apps.googleusercontent.com', clientSecretEnc: security.encryptText('secret-saved'), version: 3 };
    p.oauth.refreshTokenEnc = security.encryptText('refresh-saved'); p.oauth.email = 'conta@example.invalid';
    p.runtime.status = 'running'; p.runtime.sent = 17; p.runtime.nextAt = new Date(Date.now() + 120000).toISOString();
    p.config.messages = 'Mensagem preservada';
  });
  t.after(() => store.deleteUser(user.id));
  return { user, headers: auth(user.id, 'user') };
}
const get = (f, n = 1) => store.getUserProfile(f.user.id, n);
const body = (p, extra = {}) => ({ clientId: p.api.clientId, clientSecret: '', expectedProfileUid: p.id, expectedApiVersion: p.api.version, ...extra });
async function request(url, headers, method = 'GET', payload) {
  return fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...headers }, body: payload === undefined ? undefined : JSON.stringify(payload), redirect: 'manual' });
}
const save = (f, b, n = 1, headers = f.headers) => request(`/api/profiles/${n}/oauth/credentials`, headers, 'PUT', b);
const toggle = (f, allowed, n = 1) => request(`/dbmadmin/api/users/${f.user.id}/profiles/${n}`, adminHeaders, 'PATCH', { allowUserOAuthEdit: allowed });
const tutorial = (url, headers = adminHeaders) => request('/dbmadmin/api/settings/oauth-tutorial', headers, 'PUT', { url });

test('perfis antigos e novos começam bloqueados; permissão persiste por perfil', async t => {
  const f = fixture(t);
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(path.join(process.env.DATA_DIR, 'peralta.sqlite'));
  const old = get(f); delete old.allowUserOAuthEdit;
  db.prepare('UPDATE user_profiles SET body=? WHERE id=?').run(JSON.stringify(old), old.id); db.close();
  assert.equal(get(f).allowUserOAuthEdit, false);
  assert.equal(store.addUserProfile(f.user.id).allowUserOAuthEdit, false);
  assert.equal((await toggle(f, true)).status, 200);
  assert.equal(get(f).allowUserOAuthEdit, true); assert.equal(get(f, 2).allowUserOAuthEdit, false);
});

test('usuário bloqueado não grava, não libera a própria permissão e não recebe segredo', async t => {
  const f = fixture(t), old = get(f);
  assert.equal((await save(f, body(old, { clientSecret: 'new-secret', allowUserOAuthEdit: true }))).status, 403);
  assert.equal((await request(`/dbmadmin/api/users/${f.user.id}/profiles/1`, f.headers, 'PATCH', { allowUserOAuthEdit: true })).status, 401);
  assert.equal((await request('/api/profiles/1/settings', f.headers, 'PUT', { expectedVersion: old.config.version, allowUserOAuthEdit: true })).status, 200);
  assert.equal(get(f).allowUserOAuthEdit, false);
  const response = await request('/api/profiles/1', f.headers);
  const text = await response.text(); assert.ok(!text.includes('secret-saved')); assert.ok(!text.includes('clientSecretEnc'));
  assert.equal(JSON.parse(text).oauthTutorialAvailable, false);
});

test('ativar e bloquear preserva tokens, credenciais, configuração, contadores e execução', async t => {
  const f = fixture(t), old = get(f), beforeRevoke = revoked.length;
  for (const allowed of [true, false]) {
    assert.equal((await toggle(f, allowed)).status, 200);
    const now = get(f);
    for (const key of ['api', 'oauth', 'runtime', 'config']) assert.deepEqual(now[key], old[key], key);
  }
  assert.equal(revoked.length, beforeRevoke);
});

test('editor administrativo completo salva a permissão sem invalidar OAuth', async t => {
  const f = fixture(t), old = get(f), profile = workspace.publicProfile(f.user, old);
  const response = await request(`/dbmadmin/api/users/${f.user.id}/profiles/1/workspace`, adminHeaders, 'PUT', {
    expectedEditVersion: profile.editVersion, name: profile.name, enabled: true, googleEmail: profile.googleEmail,
    clientId: profile.clientId, clientSecret: 'secret-saved', allowUserOAuthEdit: true
  });
  assert.equal(response.status, 200, await response.clone().text());
  assert.equal(get(f).allowUserOAuthEdit, true);
  for (const key of ['api', 'oauth', 'runtime', 'config']) assert.deepEqual(get(f)[key], old[key], key);
  assert.notEqual(workspace.publicProfile(f.user, get(f)).editVersion, profile.editVersion);
});

test('salvar credenciais idênticas ou segredo vazio mantém autorização e versão', async t => {
  const f = fixture(t); await toggle(f, true);
  const old = get(f), before = revoked.length;
  for (const secret of ['', 'secret-saved']) {
    const response = await save(f, body(old, { clientSecret: secret }));
    assert.equal(response.status, 200); assert.equal((await response.json()).changed, false);
    assert.deepEqual(get(f), old);
  }
  assert.equal(revoked.length, before);
});

test('trocar credenciais pausa somente o perfil afetado e exige nova autorização', async t => {
  const f = fixture(t), other = fixture(t); await toggle(f, true);
  const old = get(f), second = get(f, 2), otherProfile = get(other);
  assert.equal((await save(f, body(old, { clientId: 'new-client.apps.googleusercontent.com' }))).status, 400);
  assert.deepEqual(get(f), old);
  const response = await save(f, body(old, { clientId: 'new-client.apps.googleusercontent.com', clientSecret: 'new-secret' }));
  assert.equal(response.status, 200); assert.equal((await response.json()).changed, true);
  const now = get(f);
  assert.equal(now.api.version, old.api.version + 1); assert.equal(security.decryptText(now.api.clientSecretEnc), 'new-secret');
  assert.equal(now.oauth.refreshTokenEnc, ''); assert.equal(now.runtime.status, 'paused'); assert.equal(now.runtime.sent, 17);
  assert.deepEqual(now.config, old.config); assert.deepEqual(get(f, 2), second); assert.deepEqual(get(other), otherProfile);
  await toggle(f, false); assert.equal(security.decryptText(get(f).api.clientSecretEnc), 'new-secret');
});

test('servidor rejeita guia antiga, perfil recriado, acesso sem CSRF e edição de outro usuário', async t => {
  const f = fixture(t), other = fixture(t); await toggle(f, true); await toggle(other, true);
  const oldBody = body(get(f), { clientSecret: 'new-secret' });
  await toggle(f, false); assert.equal((await save(f, oldBody)).status, 403);
  await toggle(f, true); assert.equal((await save(f, oldBody, 1, { Cookie: f.headers.Cookie })).status, 403);
  assert.equal((await save(other, oldBody)).status, 409);
  store.updateUserProfile(f.user.id, 1, p => { p.api.version++; }); assert.equal((await save(f, oldBody)).status, 409);
  await toggle(f, true, 2); const removed = body(get(f, 2)); store.deleteUserProfile(f.user.id, 2); store.addUserProfile(f.user.id); await toggle(f, true, 2);
  assert.equal((await save(f, removed, 2)).status, 409);
  assert.equal((await save(f, body(get(f)), 1, {})).status, 401);
});

test('tutorial global exige admin e CSRF, valida URL e abre o destino atual em todos os perfis', async t => {
  const f = fixture(t), other = fixture(t); await toggle(f, true); await toggle(other, true);
  assert.equal((await tutorial('https://example.invalid/tutorial', f.headers)).status, 401);
  assert.equal((await tutorial('https://example.invalid/tutorial', { Cookie: adminHeaders.Cookie })).status, 403);
  for (const invalid of ['javascript:alert(1)', 'data:text/html,a', '//example.invalid/a', 'https://user:secret@example.invalid/a', 'https://example.invalid/a\n']) {
    // Espaço final comum é normalizado, mas controles no meio da URL são inválidos.
    const value = invalid.endsWith('\n') ? 'https://example.invalid/a\nb' : invalid;
    assert.equal((await tutorial(value)).status, 400, value);
  }
  for (const url of ['https://www.youtube.com/watch?v=abc123', 'https://example.invalid/tutorial-novo']) {
    assert.equal((await tutorial(url)).status, 200);
    for (const target of [f, other]) {
      const state = await (await request('/api/profiles/1', target.headers)).json(); assert.equal(state.oauthTutorialAvailable, true);
      const response = await request('/api/profiles/1/oauth/tutorial', target.headers);
      assert.equal(response.status, 302); assert.equal(response.headers.get('location'), url); assert.equal(response.headers.get('cache-control'), 'no-store');
    }
  }
  await toggle(f, false); assert.equal((await request('/api/profiles/1/oauth/tutorial', f.headers)).status, 403);
  assert.equal((await request('/api/profiles/2/oauth/tutorial', other.headers)).status, 403);
  await tutorial(''); assert.equal((await request('/api/profiles/1/oauth/tutorial', other.headers)).status, 404);
  assert.equal((await (await request('/api/profiles/1', other.headers)).json()).oauthTutorialAvailable, false);
});
