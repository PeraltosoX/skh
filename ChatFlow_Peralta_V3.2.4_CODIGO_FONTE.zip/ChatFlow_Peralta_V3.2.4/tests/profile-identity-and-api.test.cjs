'use strict';
const {test,after}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'chatflow-identity-'));
process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');process.env.PUBLIC_BASE_URL='http://localhost:8080';process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security'),youtube=require('../lib/youtube'),{createAdminLiveVerifier}=require('../lib/admin-live-verifier'),{createGlobalMonitor}=require('../lib/global-monitor'),backend=require('../server');
const realFetch=global.fetch;let serial=0;
function fixture(t){const user=store.createUser({id:store.id('usr'),username:'Identidade '+(++serial),active:true,sessionVersion:1});store.addUserProfile(user.id);const session=security.signSession(user.id,'user',1);store.saveSession(session.session);t.after(()=>store.deleteUser(user.id));return {user,token:session.token};}
function verifier(fetchImpl,storage={}){return createAdminLiveVerifier({storage:{adminVerificationKeys:()=>[{id:'key',enabled:true,status:'ACTIVE',api_key_enc:'fake'}],...storage},vault:{decryptText:x=>x},fetchImpl});}
const videoId='A1234567890',validBody={items:[{id:videoId,snippet:{title:'Live simulada',liveBroadcastContent:'live'},liveStreamingDetails:{activeLiveChatId:'CHAT'}}]};
test('respostas administrativas inválidas não confirmam vídeo ausente nem chave ativa',async t=>{
 const cases=['<html>erro</html>','',null,{},[],{items:null},{items:[null]},{items:[{}]},{items:[{id:'B1234567890'}]},{items:[validBody.items[0],validBody.items[0]]},{items:[{id:videoId,liveStreamingDetails:{actualEndTime:'inválido'}}]}];
 for(const [index,body]of cases.entries())await t.test('resposta inválida '+index,async()=>{const marks=[],calls=[];const result=await verifier(async()=>new Response(typeof body==='string'?body:JSON.stringify(body),{status:200}),{markAdminVerificationKey:(_id,v)=>marks.push(v),recordAdminVerificationCall:(_id,ok)=>calls.push(ok)}).verifyKnownLive(videoId);assert.equal(result.ok,false);assert.equal(result.candidate,undefined);assert.equal(marks[0].status,'ERROR');assert.deepEqual(calls,[false]);});
});
test('resposta inválida usa a reserva; lista vazia válida continua representando ausência',async()=>{
 let attempts=0;const result=await verifier(async()=>new Response(JSON.stringify(++attempts===1?{}:validBody),{status:200}),{adminVerificationKeys:()=>['first','reserve'].map(id=>({id,enabled:true,status:'ACTIVE',api_key_enc:'fake'}))}).verifyKnownLive(videoId);
 assert.equal(result.ok,true);assert.equal(result.keyId,'reserve');assert.equal(result.candidate.chatStatus,'AVAILABLE');assert.equal(attempts,2);
 const absent=await verifier(async()=>new Response('{"items":[]}',{status:200})).verifyKnownLive(videoId);assert.equal(absent.ok,true);assert.equal(absent.candidate.unavailable,true);
});
test('monitor preserva chat confirmado após resposta inválida e exige confirmação após o prazo',async t=>{
 const {user}=fixture(t);let at=Date.now(),invalid=true;const channel=store.upsertGlobalChannel({handle:'@IdentityMonitor',canonicalUrl:'https://www.youtube.com/@IdentityMonitor'});
 for(const n of [1,2]){store.updateUserProfile(user.id,n,p=>{p.runtime.status='running';});store.subscribeChannel(user.id,n,channel,channel.handle);}
 const candidate={videoId,liveStatus:'LIVE',chatStatus:'AVAILABLE',activeLiveChatId:'CHAT',resolved:true,chatVerifiedAt:new Date(at).toISOString()},live=store.upsertGlobalLive(channel.id,candidate,at).live;store.distributeLive(live.id);
 const check=verifier(async()=>new Response(invalid?'invalid':JSON.stringify(validBody),{status:200}));
 const monitor=createGlobalMonitor({clock:()=>at,storage:store,discover:async()=>[candidate],recheck:async()=>candidate,verifyKnownLives:check.verifyKnownLives});t.after(()=>monitor.stop());
 await monitor.scan();assert.equal(store.getGlobalLive(live.id).chat_status,'AVAILABLE');assert.equal(store.activeLiveCount(user.id,1,at),1);assert.equal(store.activeLiveCount(user.id,2,at),1);
 at+=store.liveVerificationTtlMs()+1000;await monitor.scan();assert.equal(store.getGlobalLive(live.id).chat_status,'VERIFYING');assert.equal(store.getGlobalLive(live.id).live_status,'LIVE');assert.equal(store.getGlobalLive(live.id).finalized_at,null);
 invalid=false;at+=301000;await monitor.scan();assert.equal(store.getGlobalLive(live.id).chat_status,'AVAILABLE');assert.equal(store.activeLiveCount(user.id,1,at),1);
});
test('OAuth rejeita resposta incompleta tanto na consulta em lote quanto na individual',async t=>{
 const {user}=fixture(t);store.updateUserProfile(user.id,1,p=>{p.oauth.accessTokenEnc=security.encryptText('fake-access');p.oauth.accessTokenExpiresAt=Date.now()+3600000;});const p=store.getUserProfile(user.id,1);t.after(()=>{global.fetch=realFetch;});global.fetch=async()=>new Response('{}',{status:200});
 await assert.rejects(youtube.getLiveStates(p,p.api,[videoId]),{status:502});await assert.rejects(youtube.getActiveLiveChatId(p,p.api,videoId),{status:502});global.fetch=async()=>new Response(JSON.stringify(validBody),{status:200});assert.equal((await youtube.getLiveStates(p,p.api,[videoId]))[0].activeLiveChatId,'CHAT');assert.equal(await youtube.getActiveLiveChatId(p,p.api,videoId),'CHAT');
});
for(const method of ['POST','PUT'])test(method+' pendente de canal não grava em perfil excluído e recriado',async t=>{
 const {user,token}=fixture(t);const server=backend.createApp().listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 let entered,release;const ready=new Promise(r=>{entered=r;});global.fetch=(url,o)=>new URL(url).origin===base?realFetch(url,o):new Promise(r=>{release=r;entered();});t.after(async()=>{global.fetch=realFetch;server.closeAllConnections();await new Promise(r=>server.close(r));});
 const old=store.getUserProfile(user.id,2);const pending=fetch(base+'/api/profiles/2/channels',{method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(method==='POST'?{channel:'@PendingIdentity'}:{channels:['@PendingIdentity']})});
 await ready;store.deleteUserProfile(user.id,2);assert.notEqual(store.addUserProfile(user.id).id,old.id);release(new Response('<meta property="og:title" content="Canal simulado">',{status:200}));const response=await pending;assert.equal(response.status,409);assert.match((await response.json()).error,/excluído|substituído/);assert.deepEqual(store.profileChannels(user.id,2),[]);
});
test('identidade estável ao renomear conta e proteção contra edição de guia antiga',async t=>{
 const {user,token}=fixture(t),old=store.publicProfile(store.getUserProfile(user.id,2));store.updateUser(user.id,u=>{u.username+=' Renomeado';});assert.equal(store.publicProfile(store.getUserProfile(user.id,2)).profileUid,old.profileUid);store.deleteUserProfile(user.id,2);const replacement=store.addUserProfile(user.id);assert.notEqual(replacement.id,old.profileUid);
 const server=backend.createApp().listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));t.after(async()=>{server.closeAllConnections();await new Promise(r=>server.close(r));});const route='http://127.0.0.1:'+server.address().port+'/api/profiles/2/settings';
 const send=expected=>realFetch(route,{method:'PUT',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json',...(expected?{'X-Profile-Instance':expected}:{})},body:JSON.stringify({messages:'Mensagem nova',expectedVersion:replacement.config.version})});
 assert.equal((await send(old.profileUid)).status,409);assert.equal(store.getUserProfile(user.id,2).config.messages,'');assert.equal((await send()).status,200);assert.equal(store.getUserProfile(user.id,2).config.messages,'Mensagem nova');
});
after(()=>{global.fetch=realFetch;store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});
