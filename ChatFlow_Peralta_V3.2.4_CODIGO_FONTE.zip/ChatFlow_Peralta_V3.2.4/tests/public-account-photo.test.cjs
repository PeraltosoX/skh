'use strict';
const { test, after } = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'chatflow-public-photo-'));
process.env.APP_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
const store = require('../lib/store'), security = require('../lib/security');
const { createAdminLiveVerifier } = require('../lib/admin-live-verifier');
const { createConnectedChannelCache, REFRESH_MS, publicConnectedChannel } = require('../lib/connected-channel');
let serial = 0;
const channelId = 'UC0000000000000000000001';
const item = { id: channelId, snippet: { title: 'Conta real', customUrl: '@ContaReal', thumbnails: { default: { url: 'https://yt3.ggpht.com/foto-nova' } } } };
function fixture(t, { withKey = true } = {}) {
  const user = store.createUser({ id: store.id('usr'), username: `Foto ${++serial}`, active: true, sessionVersion: 1 });
  const at = Date.parse('2026-10-29T15:00:00Z');
  store.updateUserProfile(user.id, 1, p => {
    p.api = { clientId: 'photo.apps.googleusercontent.com', clientSecretEnc: security.encryptText('test-secret'), version: 1 };
    p.oauth.refreshTokenEnc = security.encryptText('test-refresh'); p.oauth.email = 'conta@example.invalid';
    p.oauth.channel = { id: channelId, title: 'Conta real', handle: '@ContaReal', thumbnailUrl: 'https://yt3.ggpht.com/foto-antiga', apiVersion: 1, lastAttemptAt: at - REFRESH_MS, nextRefreshAt: at, fetchedAt: new Date(at - REFRESH_MS).toISOString() };
    p.runtime.status = 'running'; p.runtime.sent = 9; p.config.messages = 'Mensagem preservada';
  });
  const secret = 'AIza' + crypto.randomBytes(20).toString('hex');
  const key = withKey ? store.createAdminVerificationKey({ name: 'Foto teste', apiKeyEnc: security.encryptText(secret), keyHint: 'AIza…test', keyFingerprint: crypto.randomUUID() }) : null;
  t.after(() => { store.deleteUser(user.id); if (key) store.deleteAdminVerificationKey(key.id); });
  return { user, at, key, secret };
}
const noOAuth = { getConnectedChannel: async () => assert.fail('Canal já identificado não pode voltar ao OAuth para atualizar a foto') };
after(() => { store.close(); fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); });

test('foto pelo ID usa chave administrativa sem OAuth, contabiliza no admin e respeita meia hora', async t => {
  const f = fixture(t); let at = f.at, calls = 0;
  const reader = createAdminLiveVerifier({ clock: () => at, fetchImpl: async (input, options) => {
    calls++; const url = new URL(input);
    assert.equal(url.pathname, '/youtube/v3/channels'); assert.equal(url.searchParams.get('id'), channelId);
    assert.equal(url.searchParams.get('key'), f.secret); assert.equal(url.searchParams.has('mine'), false);
    assert.equal(options.headers.Authorization, undefined);
    return new Response(JSON.stringify({ items: [item] }));
  } });
  const cache = createConnectedChannelCache({ clock: () => at, publicApi: reader, api: noOAuth }); t.after(() => cache.shutdown());
  const before = store.getUserProfile(f.user.id, 1);
  await Promise.all(Array.from({ length: 12 }, () => cache.refresh(f.user.id, 1)));
  assert.equal(calls, 1);
  let now = store.getUserProfile(f.user.id, 1);
  assert.equal(publicConnectedChannel(now).thumbnailUrl, item.snippet.thumbnails.default.url);
  assert.deepEqual(now.runtime, before.runtime); assert.deepEqual(now.config, before.config); assert.equal(now.oauth.refreshTokenEnc, before.oauth.refreshTokenEnc);
  at += REFRESH_MS - 1; await cache.refresh(f.user.id, 1); assert.equal(calls, 1);
  at++; await cache.refresh(f.user.id, 1); assert.equal(calls, 2);
  assert.equal(store.adminVerificationKeyUsage(f.key.id, at).attempts, 2);
  assert.equal(store.profileQuotaEstimate(f.user.id, 1, at).unitsUsed, 0);
});

test('ausência de chaves e indisponibilidade preservam cache sem fallback OAuth ou envios extras', async t => {
  const f = fixture(t, { withKey: false });
  let calls = 0;
  const reader = createAdminLiveVerifier({ clock: () => f.at, fetchImpl: async () => { calls++; assert.fail('Sem chave não deve consultar a rede'); } });
  const cache = createConnectedChannelCache({ clock: () => f.at, publicApi: reader, api: noOAuth }); t.after(() => cache.shutdown());
  const before = store.getUserProfile(f.user.id, 1);
  await cache.refresh(f.user.id, 1); await cache.refresh(f.user.id, 1);
  const now = store.getUserProfile(f.user.id, 1);
  assert.equal(now.oauth.channel.thumbnailUrl, before.oauth.channel.thumbnailUrl); assert.deepEqual(now.runtime, before.runtime); assert.equal(calls, 0);
});

test('resposta inválida, canal errado/ausente, HTTP e foto insegura mantêm a foto e não bloqueiam verificação de lives', async t => {
  const f = fixture(t); let at = f.at;
  const responses = [ {}, { items: [] }, { items: [{ ...item, id: 'UC0000000000000000000002' }] },
    { error: { errors: [{ reason: 'channelForbidden' }], message: 'Canal indisponível' } },
    { items: [{ ...item, snippet: { ...item.snippet, thumbnails: { default: { url: 'javascript:alert(1)' } } } }] } ];
  let index = 0;
  const reader = createAdminLiveVerifier({ clock: () => at, fetchImpl: async () => new Response(JSON.stringify(responses[index]), { status: index === 3 ? 403 : 200 }) });
  const cache = createConnectedChannelCache({ clock: () => at, publicApi: reader, api: noOAuth }); t.after(() => cache.shutdown());
  const before = store.getUserProfile(f.user.id, 1);
  for (; index < responses.length; index++, at += REFRESH_MS) {
    await cache.refresh(f.user.id, 1);
    const now = store.getUserProfile(f.user.id, 1);
    assert.equal(now.oauth.channel.thumbnailUrl, before.oauth.channel.thumbnailUrl); assert.deepEqual(now.runtime, before.runtime);
    assert.notEqual(store.getAdminVerificationKey(f.key.id).status, 'INVALID'); assert.equal(store.getAdminVerificationKey(f.key.id).cooldown_until, null);
  }
});

test('migrar cache antigo de uma hora adota 30 minutos sem repetir na abertura do painel', async t => {
  const f = fixture(t); let calls = 0;
  store.updateUserProfile(f.user.id, 1, p => { p.oauth.channel.nextRefreshAt = f.at + REFRESH_MS; });
  const cache = createConnectedChannelCache({ clock: () => f.at, api: noOAuth, publicApi: { getPublicChannel: async () => { calls++; return { ok: true, channel: item }; } } }); t.after(() => cache.shutdown());
  await cache.refresh(f.user.id, 1); await cache.refresh(f.user.id, 1); assert.equal(calls, 1);
});

test('resposta de foto atrasada não remove o cooldown marcado pela verificação de live', async t => {
  const f = fixture(t); let release, calls = 0;
  const reader = createAdminLiveVerifier({ clock: () => f.at, fetchImpl: () => { calls++; return new Promise(resolve => { release = resolve; }); } });
  const first = reader.getPublicChannel(channelId), second = reader.getPublicChannel(channelId);
  assert.equal(calls, 1);
  const until = new Date(f.at + 3600000).toISOString();
  store.markAdminVerificationKey(f.key.id, { status: 'QUOTA', error: 'Cota indisponível', cooldownUntil: until });
  release(new Response(JSON.stringify({ items: [item] })));
  assert.equal((await first).ok, true); assert.equal((await second).ok, true);
  assert.equal(store.getAdminVerificationKey(f.key.id).status, 'QUOTA');
  assert.equal(store.getAdminVerificationKey(f.key.id).cooldown_until, until);
  assert.equal(reader.activeRequests(), 0);
});

test('foto pública atrasada não entra em conta reconectada, perfil excluído ou credenciais substituídas', async t => {
  for (const mode of ['reconnect', 'credentials', 'delete']) {
    const f = fixture(t); let release;
    const cache = createConnectedChannelCache({ clock: () => f.at, api: noOAuth, publicApi: { getPublicChannel: () => new Promise(resolve => { release = resolve; }) } });
    const pending = cache.refresh(f.user.id, 1);
    if (mode === 'delete') store.deleteUser(f.user.id);
    else store.updateUserProfile(f.user.id, 1, p => { if (mode === 'reconnect') p.oauth.version++; else p.api.version++; p.oauth.channel = undefined; });
    release({ ok: true, channel: item }); await pending; await cache.shutdown();
    assert.equal(store.getUserProfile(f.user.id, 1)?.oauth.channel, undefined);
  }
});
