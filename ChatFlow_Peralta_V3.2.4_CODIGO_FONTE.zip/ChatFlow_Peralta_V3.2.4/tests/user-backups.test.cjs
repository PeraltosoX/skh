'use strict';
const {test,after}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),bcrypt=require('bcryptjs');
const {spawnSync}=require('node:child_process');
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'cf-backup-323-'));
process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');process.env.PUBLIC_BASE_URL='http://localhost:8080';process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security'),format=require('../lib/user-backup-format');
const {createApp}=require('../server');
const admin={id:store.id('adm'),username:'Administrador',passwordHash:bcrypt.hashSync('senha-admin-teste',4),active:true,sessionVersion:1};store.createFirstAdmin(admin);
const pass='Senha-de-backup-123!';let serial=0;
function auth(id,kind){const s=security.signSession(id,kind,1);store.saveSession(s.session);return {Cookie:`auto_server_${kind}=${s.token}`,'X-CSRF-Token':security.csrf(s.session.id)};}
function user(name='usuario'){
  const u=store.createUser({id:store.id('usr'),username:`${name} ${++serial}`,passwordHash:bcrypt.hashSync('senha-usuario-teste',4),active:true,sessionVersion:1,createdAt:store.now()});
  store.addUserProfile(u.id);
  for(const number of [1,2])store.updateUserProfile(u.id,number,p=>{p.name=`Nome do perfil ${number}`;p.api={clientId:'teste.apps.googleusercontent.com',clientSecretEnc:security.encryptText('segredo-google'),version:2};p.oauth.refreshTokenEnc=security.encryptText('refresh-google');p.oauth.email='conta@example.invalid';p.config.messages='Mensagem um\nMensagem dois';p.config.autoStart=true;p.runtime.status='running';p.runtime.sent=7;p.allowUserOAuthEdit=true;});
  const channel=store.upsertGlobalChannel({handle:'@canalteste',canonicalUrl:'https://www.youtube.com/@canalteste',displayName:'Canal de teste'});
  store.subscribeChannel(u.id,1,channel,'@canalteste');store.appendLog(store.getUserProfile(u.id,1),'send','teste histórico');store.recordApiCall(u.id,1,'liveChatMessages.insert',true);
  return u;
}
function archive(){return format.exportArchive(store.userBackupData(),'3.2.3');}
async function server(t){
  for(const u of store.users())store.deleteUser(u.id);
  const dir=path.join(process.env.DATA_DIR,'user-backups');fs.rmSync(dir,{force:true,recursive:true});
  const app=createApp(),http=app.listen(0,'127.0.0.1');await new Promise(r=>http.once('listening',r));
  t.after(async()=>{app.locals.userBackups.dispose();http.closeAllConnections();await new Promise(r=>http.close(r));});
  const headers=auth(admin.id,'admin'),base=`http://127.0.0.1:${http.address().port}`;
  async function request(url,body,method=body===undefined?'GET':'POST',custom=headers){const response=await fetch(base+'/dbmadmin/api/backups'+url,{method,headers:{'Content-Type':'application/json',...custom},body:body===undefined?undefined:JSON.stringify(body)});return {status:response.status,body:response.headers.get('content-type')?.includes('json')?await response.json():Buffer.from(await response.arrayBuffer()),headers:response.headers};}
  return {app,request,headers,base};
}
async function preview(api,buffer){const r=await api.request('/inspect',{file:buffer.toString('base64'),password:pass});assert.equal(r.status,200,JSON.stringify(r.body));return r.body;}
async function apply(api,view,selection){
  const reviewed=await api.request('/review',{token:view.token,password:pass,selection});assert.equal(reviewed.status,200,JSON.stringify(reviewed.body));assert.deepEqual(reviewed.body.conflicts,[]);
  return api.request('/apply',{token:view.token,password:pass,selection,planHash:reviewed.body.planHash,confirm:true});
}
after(()=>{store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});

test('arquivo portátil: criptografia aleatória, senha errada, adulteração e formato inválido',async t=>{
  await server(t);user();const a=archive(),one=await format.encrypt(a,pass),two=await format.encrypt(a,pass);
  assert.notDeepEqual(one,two);assert.equal(one.includes(Buffer.from('segredo-google')),false);assert.equal(one.includes(Buffer.from(process.env.APP_ENCRYPTION_KEY)),false);
  assert.deepEqual(await format.decrypt(one,pass),a);
  await assert.rejects(format.decrypt(one,'Uma-senha-errada!'),/Senha incorreta/);
  for(const position of [10,25,40,one.length-1]){const broken=Buffer.from(one);broken[position]^=1;await assert.rejects(format.decrypt(broken,pass),/Senha incorreta/);}
  await assert.rejects(format.decrypt(Buffer.from('ZIP inválido'),pass),/Arquivo inválido/);
  await assert.rejects(format.encrypt(a,'curta'),/12 caracteres/);
});

test('somente admin com CSRF gera/analisa/exclui; download cifrado não é público',async t=>{
  const api=await server(t),u=user();
  assert.equal((await api.request('',undefined,'GET',{})).status,401);
  assert.equal((await api.request('/create',{password:pass,passwordConfirm:pass},'POST',auth(u.id,'user'))).status,401);
  assert.equal((await api.request('/create',{password:pass,passwordConfirm:pass},'POST',{Cookie:api.headers.Cookie})).status,403);
  const created=await api.request('/create',{password:pass,passwordConfirm:pass});assert.equal(created.status,200,JSON.stringify(created.body));
  const id=created.body.file.id,download=await api.request(`/${id}/download`);assert.equal(download.status,200);assert.match(download.headers.get('content-disposition'),/attachment/);
  assert.equal((await api.request(`/${id}/download`,undefined,'GET',{})).status,401);
  const recovered=await format.decrypt(download.body,pass);assert.equal(recovered.users[0].id,u.id);assert.equal(recovered.profiles.length,2);assert.ok(!Object.hasOwn(recovered,'admins'));
  assert.equal(fs.statSync(api.app.locals.userBackups.file(id)).mode&0o777,0o600);
  assert.equal((await api.request(`/${id}`,{confirm:false},'DELETE')).status,400);
  assert.equal((await api.request(`/${id}`,{confirm:true},'DELETE')).status,200);
  assert.equal((await api.request(`/${id}/download`)).status,404);
});

for(const mode of ['all','selected','none'])test(`restauração ${mode} preserva vínculos, cópia anterior e configurações da VPS`,async t=>{
  const api=await server(t),source=user('importado'),sourceArchive=archive(),sourceProfile=store.getUserProfile(source.id,1),buffer=await format.encrypt(sourceArchive,pass);
  store.deleteUser(source.id);const one=user('atual um'),two=user('atual dois'),old=store.getUserProfile(one.id,1),session=auth(one.id,'user');
  store.setGlobalSetting('google_oauth_tutorial_url','https://example.invalid/tutorial-local');
  const v=await preview(api,buffer),selection={mode,keepIds:[one.id],imports:[{id:source.id,username:source.username}]};
  const result=await apply(api,v,selection);assert.equal(result.status,200,JSON.stringify(result.body));
  assert.equal(!!store.getUser(one.id),mode!=='none');assert.equal(!!store.getUser(two.id),mode==='all');
  const p=store.getUserProfile(source.id,1);assert.equal(p.id,sourceProfile.id);assert.equal(p.name,sourceProfile.name);assert.equal(p.runtime.status,'stopped');assert.equal(p.runtime.restoreHold,true);assert.equal(p.config.autoStart,true);
  assert.equal(security.decryptText(p.api.clientSecretEnc),'segredo-google');assert.equal(security.decryptText(p.oauth.refreshTokenEnc),'refresh-google');assert.notEqual(p.api.clientSecretEnc,sourceProfile.api.clientSecretEnc);
  assert.equal(store.profileChannels(source.id,1).length,1);assert.ok(store.logs(source.id,1).some(r=>r.message==='teste histórico'));
  assert.equal(store.globalSetting('google_oauth_tutorial_url'),'https://example.invalid/tutorial-local');assert.equal(store.admins()[0].id,admin.id);
  assert.equal(store.globalSetting('user_backup_last_restore'),result.body.recovery.id);
  const before=await format.decrypt((await api.request(`/${result.body.recovery.id}/download`)).body,pass);assert.deepEqual(before.users.map(u=>u.id).sort(),[one.id,two.id].sort());
  if(mode!=='none'){assert.deepEqual(store.getUserProfile(one.id,1),old);const response=await fetch(api.base+'/api/web/bootstrap',{headers:session});assert.equal((await response.json()).authenticated,true);}
  const again=await api.request('/apply',{token:v.token,password:pass,selection,planHash:'old',confirm:true});assert.equal(again.status,409);
});

test('IDs repetidos, login repetido e seleção explícita evitam misturar usuários',async t=>{
  const api=await server(t),same=user('original'),snapshot=archive(),buffer=await format.encrypt(snapshot,pass),v=await preview(api,buffer);
  const collision=await api.request('/review',{token:v.token,password:pass,selection:{mode:'all',keepIds:[],imports:[{id:same.id,username:same.username}]}});
  assert.equal(collision.status,200);assert.ok(collision.body.conflicts.length);assert.equal(collision.body.planHash,'');
  const unsafe=await api.request('/apply',{token:v.token,password:pass,selection:{mode:'all',imports:[{id:same.id,username:same.username}]},planHash:'any',confirm:true});assert.equal(unsafe.status,409);
  store.deleteUser(same.id);const current=user('outro');store.updateUser(current.id,u=>{u.username=same.username;});
  const view=await preview(api,buffer),selection={mode:'all',imports:[{id:same.id,username:same.username}]};
  const named=await api.request('/review',{token:view.token,password:pass,selection});assert.ok(named.body.conflicts.some(s=>s.includes('login')));
  selection.imports[0].username='importado renomeado';assert.equal((await apply(api,view,selection)).status,200);assert.equal(store.users().length,2);assert.equal(store.getUser(current.id).username,same.username);
});

test('voltar à cópia anterior restaura cadastros e preserva uma nova cópia para desfazer',async t=>{
  const api=await server(t),previous=user('anterior'),originalId=store.getUserProfile(previous.id,1).id;
  const empty={...archive(),users:[],profiles:[],channels:[],logs:[],errors:[],usage:[]},v=await preview(api,await format.encrypt(empty,pass));
  const removed=await apply(api,v,{mode:'none',imports:[]});assert.equal(removed.status,200);assert.equal(store.users().length,0);
  const inspect=await api.request('/inspect',{storedId:removed.body.recovery.id,password:pass});assert.equal(inspect.status,200);
  const restored=await apply(api,inspect.body,{mode:'none',imports:inspect.body.backup.users.map(u=>({id:u.id,username:u.username}))});assert.equal(restored.status,200,JSON.stringify(restored.body));
  assert.equal(store.users().length,1);assert.equal(store.getUserProfile(previous.id,1).id,originalId);assert.equal(store.getUserProfile(previous.id,1).runtime.status,'stopped');
  assert.notEqual(restored.body.recovery.id,removed.body.recovery.id);
});

test('mudanças após a análise e confirmação alterada são recusadas antes de gravar',async t=>{
  const api=await server(t),u=user(),buffer=await format.encrypt(archive(),pass),v=await preview(api,buffer),selection={mode:'none',imports:[{id:u.id,username:u.username}]};
  const review=await api.request('/review',{token:v.token,password:pass,selection});assert.equal(review.status,200);
  store.updateUserProfile(u.id,1,p=>{p.name='alteração mais recente';});
  const result=await api.request('/apply',{token:v.token,password:pass,selection,planHash:review.body.planHash,confirm:true});assert.equal(result.status,409);assert.equal(store.getUserProfile(u.id,1).name,'alteração mais recente');assert.equal(api.app.locals.userBackups.list().files.length,0);
});

test('falha dentro da transação reverte todos os dados sem perder os usuários atuais',async t=>{
  const api=await server(t),u=user(),raw=archive(),before=store.userBackupData();
  const localized=format.localize(raw);localized.channels.push({...localized.channels[0]});
  assert.throws(()=>store.applyUserBackup({keepIds:[],imports:localized.users,archive:localized,recoveryId:'nao-aplicar',expectedRevision:store.userBackupRevision()}));
  assert.deepEqual(store.userBackupData(),before);assert.ok(store.getUser(u.id));
});

test('arquivo pode ser restaurado com outra APP_ENCRYPTION_KEY em outra instalação',async t=>{
  await server(t);const u=user(),folder=fs.mkdtempSync(path.join(os.tmpdir(),'cf-other-vps-')),file=path.join(folder,'portable.cfbackup');t.after(()=>fs.rmSync(folder,{recursive:true,force:true}));fs.writeFileSync(file,await format.encrypt(archive(),pass));
  const script=`(async()=>{const fs=require('node:fs'),assert=require('node:assert/strict'),store=require('./lib/store'),f=require('./lib/user-backup-format'),s=require('./lib/security');const a=f.localize(await f.decrypt(fs.readFileSync(process.env.IMPORT_FILE),process.env.IMPORT_PASSWORD));store.applyUserBackup({keepIds:[],imports:a.users,archive:a,recoveryId:'migration',expectedRevision:store.userBackupRevision()});const p=store.getUserProfile(a.users[0].id,1);assert.equal(s.decryptText(p.api.clientSecretEnc),'segredo-google');assert.equal(s.decryptText(p.oauth.refreshTokenEnc),'refresh-google');assert.equal(p.runtime.restoreHold,true);store.close();})().catch(e=>{console.error(e);process.exit(1);});`;
  const result=spawnSync(process.execPath,['-e',script],{cwd:path.join(__dirname,'..'),env:{...process.env,DATA_DIR:path.join(folder,'data'),APP_ENCRYPTION_KEY:crypto.randomBytes(32).toString('hex'),IMPORT_FILE:file,IMPORT_PASSWORD:pass},encoding:'utf8'});
  assert.equal(result.status,0,result.stderr);assert.ok(store.getUser(u.id));
});

test('validação rejeita vínculos cruzados, IDs duplicados, SQL no login e versões incompatíveis',async t=>{
  await server(t);user();const a=archive();
  for(const mutate of [b=>{b.profiles[1].id=b.profiles[0].id;},b=>{b.profiles[0].userId=store.id('usr');},b=>{b.users[0].username="x';DELETE FROM users;";},b=>{b.formatVersion=99;},b=>{b.channels[0].canonical_url='https://evil.invalid';},b=>{b.users[0].passwordHash='$2a$31$'+'a'.repeat(53);}]){const b=structuredClone(a);mutate(b);assert.throws(()=>format.validate(b));}
});

test('upload em partes exige ordem, sessão dona, arquivo completo e checksum autenticado',async t=>{
  const api=await server(t);user();const buffer=await format.encrypt(archive(),pass),start=await api.request('/uploads',{size:buffer.length});assert.equal(start.status,200);
  const id=start.body.uploadId,wrong=await api.request(`/uploads/${id}`,{offset:1,chunk:buffer.toString('base64')},'PUT');assert.equal(wrong.status,409);
  const foreign=await api.request(`/uploads/${id}`,{offset:0,chunk:buffer.toString('base64')},'PUT',auth(admin.id,'admin'));assert.equal(foreign.status,409);
  assert.equal((await api.request('/inspect',{uploadId:id,password:pass})).status,409);
  let offset=0;while(offset<buffer.length){const chunk=buffer.subarray(offset,Math.min(buffer.length,offset+777));const r=await api.request(`/uploads/${id}`,{offset,chunk:chunk.toString('base64')},'PUT');assert.equal(r.status,200,JSON.stringify(r.body));offset+=chunk.length;}
  const inspected=await api.request('/inspect',{uploadId:id,password:pass});assert.equal(inspected.status,200,JSON.stringify(inspected.body));assert.equal(inspected.body.backup.userCount,1);
  assert.equal((await api.request('/review',{token:inspected.body.token,password:pass,selection:{mode:'all',imports:[]}},'POST',auth(admin.id,'admin'))).status,409);
});

test('substituir mesmo usuário invalida sessões antigas; usuário mantido conserva seu acesso',async t=>{
 const api=await server(t),u=user('substituir'),kept=user('preservar'),oldSession=auth(u.id,'user'),keptSession=auth(kept.id,'user');
 const view=await preview(api,await format.encrypt(archive(),pass));
 const result=await apply(api,view,{mode:'selected',keepIds:[kept.id],imports:[{id:u.id,username:u.username}]});assert.equal(result.status,200);
 const old=await fetch(api.base+'/api/web/bootstrap',{headers:oldSession}),untouched=await fetch(api.base+'/api/web/bootstrap',{headers:keptSession});
 assert.equal((await old.json()).authenticated,false);assert.equal((await untouched.json()).authenticated,true);
 assert.ok(bcrypt.compareSync('senha-usuario-teste',store.getUser(u.id).passwordHash));
});

test('falha ao gravar cópia anterior impede a restauração antes de tocar nos cadastros',async t=>{
 const api=await server(t),u=user(),view=await preview(api,await format.encrypt(archive(),pass)),selection={mode:'none',imports:[{id:u.id,username:'nome alterado'}]};
 const reviewed=await api.request('/review',{token:view.token,password:pass,selection}),before=store.userBackupData(),oldSync=fs.fsyncSync;
 fs.fsyncSync=()=>{throw Object.assign(new Error('Disco cheio simulado'),{code:'ENOSPC'});};
 try{const response=await api.request('/apply',{token:view.token,password:pass,selection,planHash:reviewed.body.planHash,confirm:true});assert.equal(response.status,409,JSON.stringify(response.body));assert.match(response.body.error,/Não há espaço/);}finally{fs.fsyncSync=oldSync;}
 assert.deepEqual(store.userBackupData(),before);assert.equal(api.app.locals.userBackups.list().files.length,0);
});

test('início manual libera a retenção de um perfil restaurado e mantém o outro parado',async t=>{
 await server(t);const u=user();store.updateUserProfile(u.id,1,p=>{p.runtime.status='stopped';p.runtime.restoreHold=true;});store.updateUserProfile(u.id,2,p=>{p.runtime.status='stopped';p.runtime.restoreHold=true;});
 const worker=require('../lib/workers').createWorkers({storage:store,api:{}});
 assert.equal(worker.start(u.id,1,true),true);await worker.suspend();
 assert.equal(store.getUserProfile(u.id,1).runtime.restoreHold,false);assert.equal(store.getUserProfile(u.id,2).runtime.restoreHold,true);assert.equal(store.getUserProfile(u.id,2).runtime.status,'stopped');await worker.shutdown();
});

test('seleção detecta identidade de perfil que pertence a outro usuário mantido',async t=>{
 await server(t);const first=user('primeiro'),second=user('segundo'),a=archive();
 const source={...structuredClone(a),users:a.users.filter(u=>u.id===first.id),profiles:a.profiles.filter(p=>p.userId===first.id),channels:a.channels.filter(c=>c.user_id===first.id),logs:a.logs.filter(c=>c.user_id===first.id),errors:[],usage:a.usage.filter(c=>c.user_id===first.id)};
 source.profiles[0].id=store.getUserProfile(second.id,1).id;
 const valid=format.validate(source),plan=format.plan(valid,store.userBackupData({history:false}),{mode:'selected',keepIds:[second.id],imports:[{id:first.id,username:first.username}]});
 assert.ok(plan.conflicts.some(s=>s.includes('identidade')));
});
