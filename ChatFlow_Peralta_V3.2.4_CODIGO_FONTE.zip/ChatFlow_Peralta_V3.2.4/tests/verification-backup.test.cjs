'use strict';
const {test,after}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
process.env.DATA_DIR=fs.mkdtempSync(path.join(os.tmpdir(),'cf-keys-backup324-'));process.env.APP_ENCRYPTION_KEY=crypto.randomBytes(32).toString('hex');process.env.JWT_SECRET=crypto.randomBytes(48).toString('hex');process.env.SETUP_TOKEN=crypto.randomBytes(32).toString('hex');process.env.NODE_ENV='test';
const store=require('../lib/store'),security=require('../lib/security'),format=require('../lib/user-backup-format');
const pass='Senha-backup-portatil-324';let seq=0;
function key(){const secret='AIza'+String(++seq).padStart(35,'z');const value=store.createAdminVerificationKey({name:'Principal '+seq,apiKeyEnc:security.encryptText(secret),keyHint:'oculta',keyFingerprint:crypto.createHash('sha256').update(secret).digest('hex'),projectId:'project-'+seq,dailyLimit:8000});return {...value,secret};}
function archive(){return format.exportArchive(store.userBackupData(),'3.2.4');}
function apply(a){store.applyUserBackup({keepIds:store.users().map(u=>u.id),imports:[],archive:format.localize(a),recoveryId:'test',expectedRevision:store.userBackupRevision()});}
after(()=>{store.close();fs.rmSync(process.env.DATA_DIR,{recursive:true,force:true});});

test('backup cifra somente chaves administrativas de verificação e configuração permitida; resumo nunca expõe segredo',async()=>{
 const k=key();store.setLiveDiscoveryMode('api');store.setGlobalSetting('live_discovery_interval_seconds',240);store.setGlobalSetting('chat_availability_retry_seconds',90);store.setGlobalSetting('google_oauth_tutorial_url','https://example.invalid/nao-exportar');store.setGlobalSetting('other_secret','NAO-EXPORTAR');
 const ticket=store.reserveAdminVerificationCall(k.id,'channels.list');store.finishAdminVerificationCall(ticket,true);
 const a=archive(),buffer=await format.encrypt(a,pass),decoded=await format.decrypt(buffer,pass);
 assert.equal(a.formatVersion,2);assert.equal(buffer.includes(Buffer.from(k.secret)),false);assert.equal(buffer.includes(Buffer.from(process.env.APP_ENCRYPTION_KEY)),false);
 assert.equal(decoded.verification.keys.find(i=>i.id===k.id).apiKey,k.secret);assert.deepEqual(decoded.verification.settings,{mode:'api',intervalSeconds:240,chatRetrySeconds:90});
 assert.equal(JSON.stringify(decoded).includes('NAO-EXPORTAR'),false);assert.equal(JSON.stringify(decoded).includes('nao-exportar'),false);assert.equal(JSON.stringify(format.summary(decoded)).includes(k.secret),false);
});

test('importação e voltar à cópia anterior recuperam chaves/modo sem devolver unidades gastas',()=>{
 const before=archive(),savedId=before.verification.keys[0].id;const originalKey=store.getAdminVerificationKey(savedId);
 store.reserveAdminVerificationCall(savedId,'videos.list');const used=store.verificationBudget(originalKey).keyUsed;
 for(const k of store.adminVerificationKeys(true))store.deleteAdminVerificationKey(k.id);
 key();store.setLiveDiscoveryMode('public');store.setGlobalSetting('live_discovery_interval_seconds',600);const other=archive();
 apply(before);assert.equal(store.liveDiscoveryMode(),'api');assert.equal(store.globalDiscoveryIntervalSeconds(),240);assert.equal(store.adminVerificationKeys(true).length,before.verification.keys.length);
 assert.equal(store.verificationBudget(store.getAdminVerificationKey(savedId)).keyUsed,used);
 assert.equal(security.decryptText(store.getAdminVerificationKey(savedId).api_key_enc),before.verification.keys[0].apiKey);
 apply(other);assert.equal(store.liveDiscoveryMode(),'public');assert.equal(store.globalDiscoveryIntervalSeconds(),600);assert.equal(store.adminVerificationKeys(true)[0].id,other.verification.keys[0].id);
 assert.equal(store.globalSetting('other_secret'),'NAO-EXPORTAR');
});

test('restauração portátil funciona com outra chave de criptografia da VPS',async t=>{
 store.setLiveDiscoveryMode('api');const a=archive(),buffer=await format.encrypt(a,pass),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'cf-portable324-'));t.after(()=>fs.rmSync(tmp,{recursive:true,force:true}));
 const file=path.join(tmp,'backup.cfbackup');fs.writeFileSync(file,buffer);
 const source=`(async()=>{const fs=require('node:fs'),assert=require('node:assert/strict'),s=require('./lib/store'),f=require('./lib/user-backup-format'),security=require('./lib/security');const a=await f.decrypt(fs.readFileSync(process.env.BACKUP_FILE),process.env.BACKUP_PASS);s.applyUserBackup({keepIds:[],imports:[],archive:f.localize(a),recoveryId:'portable',expectedRevision:s.userBackupRevision()});assert.equal(s.liveDiscoveryMode(),'api');for(const key of a.verification.keys){const restored=s.getAdminVerificationKey(key.id);assert.equal(security.decryptText(restored.api_key_enc),key.apiKey);assert.equal(restored.daily_limit,key.daily_limit);assert.equal(restored.project_id,key.project_id);}s.close();console.log('portable-ok');})().catch(e=>{console.error(e);process.exit(1);});`;
 const r=spawnSync(process.execPath,['-e',source],{cwd:path.join(__dirname,'..'),env:{...process.env,DATA_DIR:path.join(tmp,'new-vps'),APP_ENCRYPTION_KEY:crypto.randomBytes(32).toString('hex'),BACKUP_FILE:file,BACKUP_PASS:pass},encoding:'utf8'});
 assert.equal(r.status,0,r.stderr);assert.equal(r.stdout.trim(),'portable-ok');
});

test('backup V1 continua aceito e preserva chaves/modo da instalação de destino',async()=>{
 const before=store.adminVerificationKeys(true).map(k=>k.id),mode=store.liveDiscoveryMode();const old=archive();old.formatVersion=1;delete old.verification;
 const parsed=await format.decrypt(await format.encrypt(old,pass),pass);assert.equal(format.summary(parsed).verification,null);apply(parsed);
 assert.deepEqual(store.adminVerificationKeys(true).map(k=>k.id),before);assert.equal(store.liveDiscoveryMode(),mode);
});

test('formato rejeita modo inválido, chaves duplicadas e limite incorreto antes da restauração',()=>{
 const original=archive();
 for(const mutate of [a=>a.verification.settings.mode='anything',a=>a.verification.keys.push(a.verification.keys[0]),a=>a.verification.keys[0].daily_limit=-1,a=>a.verification.keys[0].apiKey='invalida']) {
   const a=structuredClone(original);mutate(a);assert.throws(()=>format.validate(a));
 }
});

test('editar limites/modo invalida a análise de backup, consultas e fotos não invalidam',()=>{
 const k=store.adminVerificationKeys(true)[0],before=store.userBackupRevision();store.reserveAdminVerificationCall(k.id,'channels.list');assert.equal(store.userBackupRevision(),before);
 store.updateAdminVerificationKey(k.id,{dailyLimit:7000});assert.notEqual(store.userBackupRevision(),before);const next=store.userBackupRevision();store.setLiveDiscoveryMode(store.liveDiscoveryMode()==='api'?'public':'api');assert.notEqual(store.userBackupRevision(),next);
});

test('rotas de configuração exigem admin/CSRF, validam limites e nunca devolvem chave completa',async t=>{
 const admin={id:store.id('adm'),username:'admin',active:true,sessionVersion:1};store.createFirstAdmin(admin);
 const http=require('node:http').createServer().listen(0,'127.0.0.1');await new Promise(r=>http.once('listening',r));const base='http://127.0.0.1:'+http.address().port;process.env.PUBLIC_BASE_URL=base;
 const backend=require('../server');const old=backend.globalMonitor.requestScan;backend.globalMonitor.requestScan=()=>true;
 const app=backend.createApp();http.on('request',app);t.after(async()=>{backend.globalMonitor.requestScan=old;app.locals.userBackups.dispose();http.closeAllConnections();await new Promise(r=>http.close(r));});
 const signed=security.signSession(admin.id,'admin',1);store.saveSession(signed.session);const headers={'Content-Type':'application/json',Cookie:'auto_server_admin='+signed.token,'X-CSRF-Token':security.csrf(signed.session.id)};
 const request=(url,method,body,h=headers)=>fetch(base+url,{method,headers:h,body:JSON.stringify(body)});
 const url='/dbmadmin/api/settings/live-discovery';assert.equal((await request(url,'PUT',{mode:'api'},{'Content-Type':'application/json'})).status,401);assert.equal((await request(url,'PUT',{mode:'api'},{...headers,'X-CSRF-Token':''})).status,403);
 assert.equal((await request(url,'PUT',{mode:'invalid'})).status,400);assert.equal((await request(url,'PUT',{mode:'api'})).status,200);assert.equal(store.liveDiscoveryMode(),'api');
 const secret='AIza'+'a'.repeat(35);const r=await request('/dbmadmin/api/verification-keys','POST',{name:'nova',apiKey:secret,projectId:'project-ui',dailyLimit:555});assert.equal(r.status,201);const body=await r.json();assert.equal(JSON.stringify(body).includes(secret),false);assert.equal(body.key.dailyLimit,555);
 assert.equal((await request('/dbmadmin/api/verification-keys/'+body.key.id,'PATCH',{dailyLimit:0})).status,400);
 const update=await request('/dbmadmin/api/verification-keys/'+body.key.id,'PATCH',{dailyLimit:777,name:'renomeada'});assert.equal(update.status,200);assert.equal((await update.json()).key.dailyLimit,777);
 const created=await request('/dbmadmin/api/backups/create','POST',{password:pass,passwordConfirm:pass});assert.equal(created.status,200);const meta=await created.json();
 store.setLiveDiscoveryMode('public');store.updateAdminVerificationKey(body.key.id,{dailyLimit:900});
 const inspection=await request('/dbmadmin/api/backups/inspect','POST',{storedId:meta.file.id,password:pass});assert.equal(inspection.status,200);const view=await inspection.json();assert.equal(view.backup.verification.mode,'api');assert.equal(view.backup.verification.keyCount,store.adminVerificationKeys(true).length);assert.equal(JSON.stringify(view).includes(secret),false);
 const review=await request('/dbmadmin/api/backups/review','POST',{token:view.token,password:pass,selection:{mode:'all',imports:[]}});assert.equal(review.status,200);const reviewed=await review.json();assert.equal(reviewed.verification.mode,'api');
 const restored=await request('/dbmadmin/api/backups/apply','POST',{token:view.token,password:pass,selection:{mode:'all',imports:[]},planHash:reviewed.planHash,confirm:true});assert.equal(restored.status,200);const done=await restored.json();assert.equal(store.liveDiscoveryMode(),'api');assert.equal(store.getAdminVerificationKey(body.key.id).daily_limit,777);
 const undoView=await (await request('/dbmadmin/api/backups/inspect','POST',{storedId:done.recovery.id,password:pass})).json();
 const undoReview=await (await request('/dbmadmin/api/backups/review','POST',{token:undoView.token,password:pass,selection:{mode:'all',imports:[]}})).json();
 const undo=await request('/dbmadmin/api/backups/apply','POST',{token:undoView.token,password:pass,selection:{mode:'all',imports:[]},planHash:undoReview.planHash,confirm:true});assert.equal(undo.status,200);assert.equal(store.liveDiscoveryMode(),'public');assert.equal(store.getAdminVerificationKey(body.key.id).daily_limit,900);
});
