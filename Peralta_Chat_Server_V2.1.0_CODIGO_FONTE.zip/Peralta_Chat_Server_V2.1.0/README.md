# Peralta Chat Server V2.1.0

Backend independente para o aplicativo Android. O app apenas controla a execução; o servidor continua trabalhando se o celular ficar sem internet, fechar o app ou entrar em Modo Offline.

## Recursos
- `/dbmadmin` com primeiro cadastro de administrador.
- Perfis API separados (Client ID / Client Secret) e vínculo por usuário.
- E-mail Google autorizado por usuário, sem depender de nome, @ ou Channel ID.
- OAuth iniciado pelo aplicativo e concluído no servidor.
- Refresh token criptografado com AES-256-GCM.
- Mensagens/intervalo alteráveis enquanto o worker está rodando.
- Iniciar / Pausar / Parar.
- Persistência de estado e retomada automática após reinício do container.
- Últimos logs, contadores de enviadas, falhas e tentativas.
- Docker Compose em segundo plano com `restart: unless-stopped`.

## Segurança
Use HTTPS em produção. Nunca exponha `.env` nem a pasta `data`. Faça backup da pasta `data` e do `.env` juntos: sem `APP_ENCRYPTION_KEY`, os refresh tokens não podem ser descriptografados.

## Cota por usuário
Para que usuários tenham cotas realmente independentes, cadastre Perfis API cujos Client IDs/Secrets venham de projetos Google Cloud diferentes. Vários OAuth Clients dentro do mesmo projeto continuam vinculados à cota daquele projeto.

## OAuth
O Client OAuth deve ser do tipo **Web application**. Em cada projeto, cadastre exatamente `${PUBLIC_BASE_URL}/oauth/google/callback` como redirect URI autorizado. Em produção, use HTTPS.
