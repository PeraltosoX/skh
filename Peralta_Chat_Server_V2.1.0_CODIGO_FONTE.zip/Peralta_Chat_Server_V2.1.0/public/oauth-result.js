'use strict';
setTimeout(()=>{location.href='peraltachat://oauth-complete?ok='+(document.body.dataset.oauthOk==='1'?'1':'0');},1600);
