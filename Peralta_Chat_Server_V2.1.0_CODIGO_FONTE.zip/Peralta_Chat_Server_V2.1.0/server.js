'use strict';
const express=require('express');
const cookieParser=require('cookie-parser');
const bcrypt=require('bcryptjs');
const path=require('node:path');
const security=require('./lib/security');
if(require.main===module)security.validateEnvironment();
const store=require('./lib/store');
const youtube=require('./lib/youtube');
const workers=require('./lib/workers');
const v=require('./lib/validation');
const VERSION='2.1.0',COOKIE='peralta_admin';
const base=String(process.env.PUBLIC_BASE_URL||'http://localhost:8080').replace(/\/$/,'');
const origin=new URL(base);
if(origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw new Error('PUBLIC_BASE_URL deve conter apenas https://dominio, sem caminho ou credenciais.');
if(origin.protocol!=='https:'&&!(origin.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(origin.hostname)&&process.env.NODE_ENV!=='production'))throw new Error('Use HTTPS em PUBLIC_BASE_URL. HTTP é permitido apenas no desenvolvimento local.');
const redirectUri=base+'/oauth/google/callback';
const fail=(res,status,error,extra={})=>res.status(status).json({ok:false,error,...extra});
const escape=s=>String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function invalidateOAuth(u) {u.oauth={email:'',refreshTokenEnc:'',accessTokenEnc:'',accessTokenExpiresAt:0,scope:'',version:u.oauth.version+1};u.runtime.status='paused';u.runtime.epoch++;u.runtime.nextAt=null;u.runtime.activeLiveChatId='';u.runtime.activeVideoId='';u.runtime.lastError='Conecte a conta do YouTube novamente.';store.deleteOAuthAttempts(u.id);}
function requireSession(kind) {return (req,res,next)=>{try{const token=kind==='admin'?req.cookies[COOKIE]:String(req.headers.authorization||'').replace(/^Bearer /,'');const p=security.verifySession(token||'',kind);const user=kind==='admin'?store.getAdmin(p.sub):store.getUser(p.sub);if(!user||user.active===false||p.ver!==user.sessionVersion||!store.sessionValid(p.sid,p.sub,kind))throw new Error();req.session=p;req[kind]=user;next();}catch{return fail(res,401,'Sessão inválida ou expirada. Entre novamente.');}};}
function issue(res,user,kind) {const s=security.signSession(user.id,kind,user.sessionVersion);store.saveSession(s.session);if(kind==='admin')res.cookie(COOKIE,s.token,{httpOnly:true,secure:origin.protocol==='https:',sameSite:'strict',path:'/dbmadmin',maxAge:43200000});return s.token;}
function rateLimit(limit,windowMs,keyFn) {const entries=new Map();return (req,res,next)=>{const now=Date.now();if(entries.size>10000)for(const [k,x]of entries)if(x.until<=now)entries.delete(k);const key=keyFn(req);let x=entries.get(key);if(!x||x.until<=now){x={count:0,until:now+windowMs};entries.set(key,x);}if(++x.count>limit){res.set('Retry-After',String(Math.ceil((x.until-now)/1000)));return fail(res,429,'Muitas tentativas. Aguarde e tente novamente.');}next();};}
function createApp() {
  security.validateEnvironment();
  const app=express();app.disable('x-powered-by');app.set('trust proxy','loopback, linklocal, uniquelocal');
  app.use((req,res,next)=>{res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"});if(req.path.startsWith('/api/')||req.path.startsWith('/dbmadmin')||req.path.startsWith('/oauth/'))res.set('Cache-Control','no-store');next();});
  app.use(express.json({limit:'128kb'}));app.use(cookieParser());
  app.use((req,res,next)=>{if(!['GET','HEAD','OPTIONS'].includes(req.method)){if(req.headers.origin&&req.headers.origin!==origin.origin)return fail(res,403,'Origem da solicitação não autorizada.');if(!req.is('application/json'))return fail(res,415,'Envie JSON nesta operação.');}next();});
  app.use(express.static(path.join(__dirname,'public'),{index:false,dotfiles:'deny'}));
  const userAuth=requireSession('user'),adminAuth=requireSession('admin');
  const loginLimit=rateLimit(40,900000,req=>req.ip);
  const accountLimit=rateLimit(12,900000,req=>req.ip+'|'+String(req.body?.email||req.body?.username||'').toLowerCase().slice(0,254));
  const csrf=(req,res,next)=>security.equal(req.headers['x-csrf-token'],security.csrf(req.session.sid))?next():fail(res,403,'Sessão do painel mudou. Atualize a página.');
  const adminWrite=[adminAuth,csrf];
  app.get('/health',(_req,res)=>{try{if(!store.health())return fail(res,503,'Instância indisponível.');res.json({ok:true,version:VERSION,time:store.now()});}catch{return fail(res,503,'Armazenamento indisponível.');}});
  app.get('/api/info',(_req,res)=>res.json({ok:true,version:VERSION,privacyUrl:base+'/privacy',termsUrl:'https://www.youtube.com/t/terms',minClientVersion:'2.1.0'}));
  app.post('/api/login',loginLimit,accountLimit,async(req,res)=>{
    const email=v.email(req.body.email),password=String(req.body.password||'');if(password.length>200)return fail(res,401,'E-mail ou senha inválidos.');
    const old=store.findUserByEmail(email);if(!old||!old.active||!await bcrypt.compare(password,old.passwordHash))return fail(res,401,'E-mail ou senha inválidos.');
    const latest=store.getUser(old.id);if(!latest?.active||latest.passwordHash!==old.passwordHash)return fail(res,401,'Credenciais alteradas. Entre novamente.');
    if(req.body.privacyAccepted!==true)return fail(res,400,'Leia e aceite a política de privacidade antes de entrar.');
    store.updateUser(latest.id,u=>{u.privacyAcceptedAt=store.now();u.privacyVersion='2026-09-05';});
    res.json({ok:true,token:issue(res,latest,'user'),user:store.publicUser(latest)});
  });
  app.post('/api/logout',userAuth,(req,res)=>{store.revokeSession(req.session.sid);res.json({ok:true});});
  app.get('/api/me',userAuth,(req,res)=>res.json({ok:true,user:store.publicUser(req.user)}));
  app.get('/api/state',userAuth,(req,res)=>{const u=req.user;res.json({ok:true,version:VERSION,serverTime:Date.now(),user:store.publicUser(u),config:u.config,runtime:{status:u.runtime.status,sent:u.runtime.sent,failures:u.runtime.failures,attempts:u.runtime.attempts,connectionErrors:u.runtime.connectionErrors,lastError:u.runtime.lastError,nextAt:u.runtime.nextAt,oauthConnected:!!u.oauth.refreshTokenEnc,oauthEmail:u.oauth.email,hourlySent:u.runtime.hourlySends.filter(t=>t>Date.now()-3600000).length,effectiveDelayMs:workers.effectiveDelay(u.config)},logs:store.logs(u.id)});});
  app.get('/api/logs',userAuth,(req,res)=>{const before=req.query.before?Number(req.query.before):Number.MAX_SAFE_INTEGER;if(!Number.isSafeInteger(before)||before<1)return fail(res,400,'Cursor inválido.');res.json({ok:true,logs:store.logs(req.user.id,100,before)});});
  app.post('/api/logs/clear',userAuth,(req,res)=>{store.clearLogs(req.user.id);res.json({ok:true});});
  app.put('/api/config',userAuth,(req,res)=>{
    const patch=v.config(req.body);const expected=v.integer(req.body.expectedVersion,'Versão da configuração',1,Number.MAX_SAFE_INTEGER);
    const u=store.updateUser(req.user.id,u=>{if(u.config.version!==expected)v.invalid('A configuração mudou em outra sessão. Recarregue ou revise seu rascunho.',409);
      const changed=Object.entries(patch).some(([k,val])=>u.config[k]!==val);if(!changed)return;
      if(patch.liveUrl!==undefined&&patch.liveUrl!==u.config.liveUrl){u.runtime.activeLiveChatId='';u.runtime.activeVideoId='';u.runtime.retryAt=0;}
      if(patch.messages!==undefined&&patch.messages!==u.config.messages)u.config.messageIndex=0;
      Object.assign(u.config,patch);u.config.version++;u.runtime.lastError='';
    });workers.wake(u.id);res.json({ok:true,config:u.config});
  });
  app.post('/api/control/:action',userAuth,(req,res)=>{
    const u=store.getUser(req.user.id),action=req.params.action;
    if(action==='start'){if(!u.oauth.refreshTokenEnc)return fail(res,409,'Conecte a conta do YouTube primeiro.');if(!extractValid(u))return fail(res,409,'Configure uma live e pelo menos uma mensagem.');if(u.runtime.status!=='running')workers.start(u.id,u.runtime.status==='stopped');}
    else if(action==='pause')workers.pause(u.id);else if(action==='stop')workers.stop(u.id);else return fail(res,404,'Comando desconhecido.');res.json({ok:true,action});
  });
  function extractValid(u){return youtube.extractVideoId(u.config.liveUrl)&&workers.parseMessages(u.config.messages).length;}
  app.get('/api/oauth/start',userAuth,(req,res)=>{const u=req.user,p=store.getProfile(u.apiProfileId);if(!p||p.active===false)return fail(res,409,'Perfil API não configurado.');
    const state=security.randomState();store.saveOAuthAttempt(state,u);const url=new URL('https://accounts.google.com/o/oauth2/v2/auth');
    for(const [k,val]of Object.entries({client_id:p.clientId,redirect_uri:redirectUri,response_type:'code',scope:`openid email ${youtube.YOUTUBE_SCOPE}`,access_type:'offline',prompt:'consent select_account',include_granted_scopes:'true',state,login_hint:u.googleEmail}))url.searchParams.set(k,val);
    res.json({ok:true,url:url.toString(),redirectUri});
  });
  app.get('/oauth/google/callback',async(req,res)=>{try{
    const attempt=store.consumeOAuthAttempt(String(req.query.state||''));if(!attempt)throw new Error('Autorização expirada ou já utilizada. Inicie novamente pelo aplicativo.');
    if(req.query.error)throw new Error(req.query.error==='access_denied'?'Autorização cancelada. Nenhuma nova conta foi conectada.':'Google recusou a autorização. Inicie novamente pelo aplicativo.');
    const u=store.getUser(attempt.user_id),p=store.getProfile(attempt.profile_id);
    if(!u?.active||!p||p.active===false||u.apiProfileId!==p.id||u.oauth.version!==attempt.version)throw new Error('Cadastro alterado. Inicie a autorização novamente.');
    const tokens=await youtube.jsonFetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code:String(req.query.code||''),client_id:p.clientId,client_secret:security.decryptText(p.clientSecretEnc),redirect_uri:redirectUri,grant_type:'authorization_code'})});
    const info=await youtube.jsonFetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:`Bearer ${tokens.access_token}`}});
    if(info.email_verified!==true||String(info.email||'').toLowerCase()!==u.googleEmail)throw new Error('Use exatamente a conta Google autorizada pelo administrador.');
    if(!String(tokens.scope||'').split(/\s+/).includes(youtube.YOUTUBE_SCOPE))throw new Error('Permissão do YouTube não concedida. Refaça a autorização e conceda a permissão solicitada.');
    if(!tokens.refresh_token||!tokens.access_token)throw new Error('Google não retornou autorização offline. Revise o consentimento e tente novamente.');
    const expires=Math.min(86400,Math.max(60,Number(tokens.expires_in)||3600));
    const updated=store.updateUser(u.id,current=>{const profileNow=store.getProfile(p.id);if(!current.active||current.googleEmail!==u.googleEmail||current.apiProfileId!==p.id||current.oauth.version!==attempt.version||!profileNow?.active||profileNow.version!==p.version)v.invalid('Cadastro alterado durante a autorização. Tente novamente.',409);
      current.oauth={email:info.email.toLowerCase(),refreshTokenEnc:security.encryptText(tokens.refresh_token),accessTokenEnc:security.encryptText(tokens.access_token),accessTokenExpiresAt:Date.now()+(expires-30)*1000,scope:tokens.scope,version:current.oauth.version+1};
      current.runtime.epoch++;current.runtime.status='paused';current.runtime.nextAt=null;current.runtime.activeLiveChatId='';current.runtime.activeVideoId='';current.runtime.lastError='';store.appendLog(current,'oauth','Conta YouTube autorizada. Confira a live e toque Iniciar.','success');
    });if(!updated)throw new Error('Usuário removido durante a autorização.');workers.wake(u.id);res.type('html').send(oauthHtml(true,'Conta autorizada. Volte ao aplicativo, confira a live e toque Iniciar.'));
  }catch(e){res.status(400).type('html').send(oauthHtml(false,e.message||'Falha na autorização.'));}});
  app.post('/api/oauth/disconnect',userAuth,async(req,res)=>{const token=req.user.oauth.refreshTokenEnc;store.updateUser(req.user.id,invalidateOAuth);workers.wake(req.user.id);let warning='';try{await youtube.revoke(token);}catch{warning='Acesso removido deste servidor. Confira também as permissões da sua Conta Google.';}res.json({ok:true,warning});});
  app.delete('/api/account',userAuth,async(req,res)=>{const token=req.user.oauth.refreshTokenEnc;workers.stop(req.user.id);store.deleteUser(req.user.id);try{await youtube.revoke(token);}catch{}res.json({ok:true});});
  app.get('/dbmadmin',(_req,res)=>res.sendFile(path.join(__dirname,'public/admin.html')));
  app.get('/dbmadmin/api/bootstrap',(req,res)=>{const needsSetup=store.admins().length===0;if(needsSetup)return res.json({ok:true,needsSetup:true,authenticated:false});
    try{const p=security.verifySession(req.cookies[COOKIE]||'','admin'),a=store.getAdmin(p.sub);if(!a?.active||a.sessionVersion!==p.ver||!store.sessionValid(p.sid,p.sub,'admin'))throw new Error();res.json({ok:true,needsSetup:false,authenticated:true,csrfToken:security.csrf(p.sid),admin:{id:a.id,username:a.username}});}catch{res.json({ok:true,needsSetup:false,authenticated:false});}
  });
  app.post('/dbmadmin/api/setup',loginLimit,accountLimit,async(req,res)=>{if(!security.equal(req.body.setupToken,process.env.SETUP_TOKEN))return fail(res,403,'Código de instalação inválido. Consulte o arquivo ACESSO_INICIAL.txt na VPS.');if(store.admins().length)return fail(res,409,'Administrador inicial já criado.');
    const username=v.string(req.body.username,'Usuário',64);if(username.length<3)v.invalid('Usuário deve ter no mínimo 3 caracteres.');const hash=await bcrypt.hash(v.password(req.body.password),12);
    const a={id:store.id('adm'),username,passwordHash:hash,active:true,sessionVersion:1,createdAt:store.now()};if(!store.createFirstAdmin(a))return fail(res,409,'Administrador inicial já criado.');store.audit(a.id,'setup');issue(res,a,'admin');res.json({ok:true});
  });
  app.post('/dbmadmin/api/login',loginLimit,accountLimit,async(req,res)=>{const a=store.findAdmin(String(req.body.username||'').trim());const password=String(req.body.password||'');if(password.length>200||!a?.active||!await bcrypt.compare(password,a.passwordHash))return fail(res,401,'Usuário ou senha inválidos.');const latest=store.getAdmin(a.id);if(!latest?.active||latest.passwordHash!==a.passwordHash)return fail(res,401,'Credenciais alteradas. Entre novamente.');issue(res,latest,'admin');store.audit(a.id,'login');res.json({ok:true});});
  app.post('/dbmadmin/api/logout',...adminWrite,(req,res)=>{store.revokeSession(req.session.sid);res.clearCookie(COOKIE,{path:'/dbmadmin'});res.json({ok:true});});
  app.post('/dbmadmin/api/password',...adminWrite,async(req,res)=>{if(!await bcrypt.compare(String(req.body.currentPassword||''),req.admin.passwordHash))return fail(res,401,'Senha atual incorreta.');const hash=await bcrypt.hash(v.password(req.body.password),12);store.updateAdmin(req.admin.id,a=>{if(a.passwordHash!==req.admin.passwordHash)v.invalid('Senha já alterada. Entre novamente.',401);a.passwordHash=hash;a.sessionVersion++;});store.revokeSessions(req.admin.id);store.audit(req.admin.id,'admin_password');res.clearCookie(COOKIE,{path:'/dbmadmin'});res.json({ok:true});});
  app.get('/dbmadmin/api/data',adminAuth,(_req,res)=>res.json({ok:true,apiProfiles:store.profiles().map(p=>({id:p.id,name:p.name,clientId:p.clientId,active:p.active,version:p.version})),users:store.users().map(store.publicUser)}));
  app.get('/dbmadmin/api/diagnostics',adminAuth,(_req,res)=>res.json({ok:true,version:VERSION,node:process.version,storage:store.health()?'ok':'error',https:origin.protocol==='https:',publicBaseUrl:base,redirectUri,workers:workers.activeCount(),users:store.users().length,uptimeSeconds:Math.floor(process.uptime())}));
  app.get('/dbmadmin/api/audit',adminAuth,(_req,res)=>res.json({ok:true,events:store.auditLog()}));
  app.get('/dbmadmin/api/users/:id/logs',adminAuth,(req,res)=>res.json({ok:true,logs:store.logs(req.params.id,100)}));
  app.post('/dbmadmin/api/profiles',...adminWrite,(req,res)=>{const p=profileInput(req.body);p.id=store.id('api');p.version=1;p.createdAt=store.now();store.putProfile(p);store.audit(req.admin.id,'profile_create',p.id);res.json({ok:true,id:p.id});});
  app.patch('/dbmadmin/api/profiles/:id',...adminWrite,(req,res)=>{const old=store.getProfile(req.params.id);if(!old)return fail(res,404,'Perfil não encontrado.');const p=profileInput(req.body,old);p.version=old.version+1;store.putProfile(p);if(p.clientId!==old.clientId||p.clientSecretEnc!==old.clientSecretEnc||!p.active){for(const u of store.users().filter(u=>u.apiProfileId===p.id)){store.updateUser(u.id,invalidateOAuth);workers.wake(u.id);}}store.audit(req.admin.id,'profile_update',p.id);res.json({ok:true});});
  app.delete('/dbmadmin/api/profiles/:id',...adminWrite,(req,res)=>{if(!store.deleteProfile(req.params.id))return fail(res,409,'Mova os usuários para outro perfil antes de excluir.');store.audit(req.admin.id,'profile_delete',req.params.id);res.json({ok:true});});
  app.post('/dbmadmin/api/users',...adminWrite,async(req,res)=>{const email=v.email(req.body.email),googleEmail=v.email(req.body.googleEmail),apiProfileId=String(req.body.apiProfileId||'');const hash=await bcrypt.hash(v.password(req.body.password),12);if(!store.getProfile(apiProfileId)?.active)return fail(res,400,'Perfil API inválido ou inativo.');const u=store.createUser({id:store.id('usr'),email,googleEmail,apiProfileId,passwordHash:hash,active:true,createdAt:store.now()});store.audit(req.admin.id,'user_create',u.id);res.json({ok:true,id:u.id});});
  app.patch('/dbmadmin/api/users/:id',...adminWrite,async(req,res)=>{
    const body=req.body,patch={};if(body.email!==undefined)patch.email=v.email(body.email);if(body.googleEmail!==undefined)patch.googleEmail=v.email(body.googleEmail);if(body.active!==undefined)patch.active=v.boolean(body.active,'Status');if(body.apiProfileId!==undefined)patch.apiProfileId=v.string(body.apiProfileId,'Perfil API',100);
    if(body.password)patch.passwordHash=await bcrypt.hash(v.password(body.password),12);
    if(patch.apiProfileId&&!store.getProfile(patch.apiProfileId)?.active)return fail(res,400,'Perfil inválido ou inativo.');
    const u=store.updateUser(req.params.id,u=>{const changedIdentity=(patch.googleEmail!==undefined&&patch.googleEmail!==u.googleEmail)||(patch.apiProfileId!==undefined&&patch.apiProfileId!==u.apiProfileId);Object.assign(u,patch);if(changedIdentity)invalidateOAuth(u);if(patch.passwordHash||patch.active===false){u.sessionVersion++;store.revokeSessions(u.id);}if(!u.active){u.runtime.status='stopped';u.runtime.epoch++;u.runtime.nextAt=null;}});
    if(!u)return fail(res,404,'Usuário não encontrado.');workers.wake(u.id);store.audit(req.admin.id,'user_update',u.id);res.json({ok:true,user:store.publicUser(u)});
  });
  app.post('/dbmadmin/api/users/:id/revoke',...adminWrite,(req,res)=>{const u=store.updateUser(req.params.id,u=>{u.sessionVersion++;store.revokeSessions(u.id);});if(!u)return fail(res,404,'Usuário não encontrado.');store.audit(req.admin.id,'sessions_revoke',u.id);res.json({ok:true});});
  app.delete('/dbmadmin/api/users/:id',...adminWrite,async(req,res)=>{const u=store.getUser(req.params.id);if(!u)return fail(res,404,'Usuário não encontrado.');workers.stop(u.id);store.deleteUser(u.id);try{await youtube.revoke(u.oauth.refreshTokenEnc);}catch{}store.audit(req.admin.id,'user_delete',u.id);res.json({ok:true});});
  app.get('/privacy',(_req,res)=>res.type('html').send(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Privacidade • Peralta Chat</title><link rel="stylesheet" href="/admin.css"></head><body><main class="shell card"><h1>Privacidade e uso</h1><p>O Peralta Chat envia as mensagens que você configurar para o chat da live escolhida, enquanto a execução estiver ativa. Fechar o app ou sair da conta não para os envios: use Parar.</p><p>Este servidor guarda seu e-mail de acesso, senha protegida por hash, e-mail Google autorizado, permissões Google criptografadas, configurações, contadores e até 2.000 registros recentes por usuário. O administrador pode administrar seu cadastro e a execução. Não coletamos sua senha Google.</p><p>Google/YouTube recebe as autorizações, consultas e mensagens necessárias ao serviço. Você pode desconectar o YouTube, excluir seus dados no aplicativo ou revogar permissões na Conta Google. Backups do operador podem manter cópias durante a retenção informada por ele.</p><p>Operador/contato: ${escape(process.env.OPERATOR_CONTACT||'consulte o administrador deste servidor')}.</p><p>Use mensagens pertinentes à transmissão e respeite os limites do YouTube. Ao aceitar, você também concorda com os <a href="https://www.youtube.com/t/terms">Termos do YouTube</a>. Consulte a <a href="https://policies.google.com/privacy">Política de Privacidade Google</a> e <a href="https://myaccount.google.com/permissions">suas permissões</a>.</p><p>Versão da política: 05/09/2026. Solicite ao operador detalhes de retenção, localização e atendimento antes de usar.</p></main></body></html>`));
  app.use((_req,res)=>fail(res,404,'Endereço não encontrado.'));
  app.use((e,_req,res,_next)=>{if(res.headersSent)return;if(/UNIQUE constraint failed/i.test(e.message))return fail(res,409,'Já existe um cadastro com esse e-mail ou usuário.');const status=Number.isInteger(e.status)&&e.status>=400&&e.status<500?e.status:500;if(status===500)console.error('Erro interno:',e.code||e.name);fail(res,status,status===500?'Erro interno. Consulte o diagnóstico do servidor.':e.message);});
  return app;
}
function profileInput(body,old={}) {const name=v.string(body.name??old.name,'Nome do perfil',100),clientId=v.string(body.clientId??old.clientId,'Client ID',300);if(!/^[a-zA-Z\d._-]+\.apps\.googleusercontent\.com$/.test(clientId))v.invalid('Client ID Google inválido.');const secret=body.clientSecret?v.string(body.clientSecret,'Client Secret',300):'';if(!secret&&!old.clientSecretEnc)v.invalid('Informe o Client Secret.');return {...old,name,clientId,clientSecretEnc:secret?security.encryptText(secret):old.clientSecretEnc,active:body.active===undefined?old.active!==false:v.boolean(body.active,'Status')};}
function oauthHtml(ok,message) {return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Autorização YouTube</title><link rel="stylesheet" href="/admin.css"></head><body data-oauth-ok="${ok?'1':'0'}"><main class="shell card"><h1>${ok?'Conta autorizada':'Autorização não concluída'}</h1><p>${escape(message)}</p><a class="button" href="peraltachat://oauth-complete?ok=${ok?'1':'0'}">VOLTAR AO APLICATIVO</a></main><script src="/oauth-result.js"></script></body></html>`;}
if(require.main===module){const app=createApp();store.acquireLease();const server=app.listen(Number(process.env.PORT||8080),process.env.BIND_HOST||'0.0.0.0',()=>{console.log(`Peralta Chat ${VERSION} ativo na porta ${server.address().port}.`);workers.resumeAll();});let closing=false;
 const heartbeat=setInterval(()=>{try{if(!store.renewLease())shutdown(1);}catch{shutdown(1);}},5000);heartbeat.unref();
 async function shutdown(code=0){if(closing)return;closing=true;clearInterval(heartbeat);server.close();const force=setTimeout(()=>process.exit(1),35000);force.unref();await workers.shutdown();store.close();clearTimeout(force);process.exit(code);}
 process.on('SIGTERM',()=>shutdown());process.on('SIGINT',()=>shutdown());process.on('unhandledRejection',e=>{console.error('Falha não tratada:',e?.name||'Error');shutdown(1);});process.on('uncaughtException',e=>{console.error('Falha fatal:',e.name);shutdown(1);});
}
module.exports={createApp,invalidateOAuth};
